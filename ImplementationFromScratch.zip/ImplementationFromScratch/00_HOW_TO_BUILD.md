# AutoAuth Agent — How to Build This: 0 to 1
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026

This is the single guide you read before touching any other document.
It tells you exactly what to do, in what order, to go from an empty repo to a running system.

---

## The Big Picture

You have 13 reference documents. Think of them as blueprints, not instructions.
Your job is to use them to write actual code. The order below matches the dependency chain —
nothing will work if you build it out of order.

```
[04] Schema → [07] Common Lib → [08] API Server → [09] Planner
                                                         ↓
                                               [10] Control Plane
                                                         ↓
                                               [11] Browser Agent
                                                         ↓
                                               [12] Tracking Agent
                                                         ↓
                                               [13] Frontend
```

---

## Phase 0 — One-Time Environment Setup (Do This First)

### 1. GCP Project
```
- Create a GCP project
- Enable APIs: Cloud SQL, Redis (Memorystore), Pub/Sub, Secret Manager,
  Artifact Registry, GKE, Cloud Build
- Create a service account for local dev, download key
```

### 2. Local Tools Required
```
- Python 3.12+
- Node 20+
- Docker Desktop
- kubectl + gcloud CLI
- Poetry (pip install poetry)
- Playwright (installed via pyproject.toml)
```

### 3. Clone / Init Monorepo
```
autoauthagent/
├── common/           ← shared library
├── api-server/
├── planner/
├── control-plane/
├── browser-agent/
├── tracking-agent/
└── frontend/
```
Create these folders. Each service has its own `pyproject.toml`.

### 4. GCP Secret Manager — Seed Secrets
Before any service can start, these secrets must exist:
```
autoauth/dev/db/password
autoauth/dev/redis/auth
autoauth/dev/n8n/webhook_secret
autoauth/dev/portal/availity/username
autoauth/dev/portal/availity/password
autoauth/dev/portal/navinet/username
autoauth/dev/portal/navinet/password
autoauth/dev/capsolver/api_key
autoauth/dev/anthropic/api_key
autoauth/dev/jwt/secret_key
```
Do this via GCP Console or:
```bash
echo -n "my_password" | gcloud secrets create autoauth/dev/db/password \
  --data-file=- --project=YOUR_PROJECT
```

---

## Phase 1 — Infrastructure (Before Any Code Runs)

### Step 1: Spin Up Local Dependencies
Copy `docker-compose.yaml` from **[Doc 06]** → root of repo.
```bash
docker compose up -d postgres redis pubsub-emulator n8n
```
This gives you: PostgreSQL 15, Redis 7, Pub/Sub emulator, N8N.

### Step 2: Run Database Migrations
Build the common library first (Step 3 below), then:
```bash
cd common
alembic upgrade head
```
The migration in **[Doc 04 — Section: Alembic]** creates all 18 tables.
If you hit errors: check `DB_HOST`, `DB_USER`, `DB_PASSWORD` env vars.

### Step 3: Seed Reference Data
After migrations, run the seed script from **[Doc 04 — Section: Seed Data]**:
```bash
python scripts/seed_data.py
```
This inserts: 5 payers, 5 portals, 4 AI model pricing rows, 1 admin user.

---

## Phase 2 — Build in This Exact Order

---

### Step 4: common/ (Document 07)

**What it is:** Shared Python library used by every service.
**Build it first** — nothing else can even import without it.

```bash
cd common
poetry install
```

What to implement (in this order within common/):
1. `logs/` — configure_logging, PHI redactor, trace context
2. `db_layer/` — engine, base model, unit of work, base repository
3. `redis_layer/` — client, worker pool, credential pool, stream logger, keyspace
4. `pubsub_layer/` — publisher, base consumer, consumer thread
5. `secret/` — secret_manager with lru_cache

**Test it works:**
```python
from common.logs.logger import get_logger
log = get_logger("test")
log.info("hello", foo="bar")   # should print JSON, no PHI fields visible
```

**Reference:** [07_Common_Library_Implementation.md](07_Common_Library_Implementation.md)

---

### Step 5: api-server/ (Document 08)

**What it is:** The only publicly-exposed HTTP service. Frontend talks to this.

```bash
cd api-server
poetry install
uvicorn src.main:app --reload --port 8080
```

Implement in this order:
1. `config.py` — Settings from env
2. `auth/` — JWT handler, register, login endpoints
3. `dependencies.py` — `get_db()`, `get_current_user()`, `require_role()`
4. `routers/health.py` — GET /health (quickest smoke test)
5. `routers/prior_auth.py` — POST /agentic-platform/prior-auths
6. `services/batch_service.py` — ingest + publish to Pub/Sub
7. `routers/recipes.py`, `routers/alerts.py`, `routers/dashboard.py`

**Smoke test:**
```bash
curl http://localhost:8080/health
# → {"status":"ok","checks":{"db":"ok","redis":"ok"}}

curl -X POST http://localhost:8080/api/v1/auth/login \
  -d '{"email":"admin@autoauth.com","password":"admin123"}'
# → {"access_token":"eyJ..."}
```

**Reference:** [08_API_Server_Implementation.md](08_API_Server_Implementation.md)

---

### Step 6: planner/ (Document 09)

**What it is:** Consumes Pub/Sub messages from api-server → triggers N8N.

```bash
cd planner
poetry install
uvicorn src.main:app --reload --port 8082
```

Implement in this order:
1. `consumer/dedup_cache.py` — OrderedDict LRU + TTL
2. `services/case_updater.py` — set_status() helper
3. `services/one_session_manager.py` — Redis SET NX lock
4. `services/n8n_trigger.py` — HMAC-signed httpx POST
5. `consumer/planner_consumer.py` — 5-step pipeline
6. `services/mfa_service.py` — Redis-based OTP delivery
7. `routers/planner_router.py` — /retrigger, /handle-mfa
8. `routers/sse_router.py` — SSE log stream

**Test it works:** Submit a case via api-server, watch planner logs, verify
`prior_auth_planner_agent_status` row appears in DB.

**Reference:** [09_Planner_Implementation.md](09_Planner_Implementation.md)

---

### Step 7: N8N Webhooks (Between Planner and Control Plane)

N8N is the workflow glue. Before building control-plane, set up N8N:

1. Open N8N at http://localhost:5678
2. Create 7 webhook workflows (from **[Doc 06 — Section: N8N]**)
   - `prior-auth-submission` → publishes to Pub/Sub Topic #2
   - `prior-auth-agents` → calls control-plane POST /sessions
   - `prior-auth-completed` → calls control-plane POST /tracking/sessions
   - `prior-auth-status-capture` → updates case status
   - `prior-auth-mfa-notification` → sends MFA alert
   - `prior-auth-hitl-notification` → sends HITL alert
   - `prior-auth-retrigger` → calls planner /retrigger
3. Set `N8N_WEBHOOK_SECRET` in your `.env`
4. Copy webhook URLs into each service's `.env`

---

### Step 8: control-plane/ (Document 10)

**What it is:** Orchestrates browser-agent pods. Acquires workers, creates sessions.

```bash
cd control-plane
poetry install
uvicorn src.main:app --reload --port 8083
```

Implement in this order:
1. `managers/worker_manager.py` — startup pool init
2. `managers/session_registry.py` — in-memory session store
3. `services/browser_agent_client.py` — httpx client for browser-agent
4. `consumer/session_consumer.py` — Pub/Sub Topic #2 consumer
5. `routers/sessions.py` — POST/DELETE /sessions
6. `services/keepalive_sender.py` — 30s heartbeat thread
7. `services/expired_event_consumer.py` — Redis keyspace crash detection
8. `routers/vnc_proxy.py` — HTTP + WebSocket proxy
9. `routers/hitl.py` — HITL task routes
10. `routers/tracking.py` — tracking session routes

**Reference:** [10_Control_Plane_Implementation.md](10_Control_Plane_Implementation.md)

---

### Step 9: browser-agent/ (Document 11)

**What it is:** The actual browser automation engine. Most complex service.
Run locally without Docker first (Playwright + Xvfb work on Linux/Mac; on Windows use WSL2).

```bash
cd browser-agent
poetry install
playwright install chromium
uvicorn src.main:app --reload --port 8081
```

Implement in this order:
1. `display/allocator.py` + `display/vnc_manager.py` — Xvfb slots
2. `recipe/resolver.py` — resolve_value() with 7 sources
3. `recipe/pick_option.py` — fuzzy dropdown matching
4. `recipe/loader.py` — LRU recipe fetch from api-server
5. `recipe/runner.py` — RecipeRunner with all 14 action types
6. `captcha/capsolver_client.py` — CAPTCHA solver
7. `hitl/hitl_manager.py` — threading.Event registry
8. `mfa/mfa_manager.py` — Redis OTP reader
9. `streaming/log_streamer.py` — Redis XADD
10. `heartbeat/heartbeat_thread.py` — 30s keepalive
11. `sessions/session_thread.py` — full lifecycle thread
12. `services/completion_service.py` — N8N callbacks
13. `services/summarization.py` — Claude Haiku summary
14. `llm/agent_runner.py` + `llm/custom_tools.py` — LLM fallback

**Milestone test:** Submit a real Availity test case end-to-end.
Watch the VNC viewer in browser at `http://localhost:6080/vnc.html`.

**Reference:** [11_Browser_Agent_Implementation.md](11_Browser_Agent_Implementation.md)

---

### Step 10: tracking-agent/ (Document 12)

**What it is:** Post-submission polling. Checks portal for APPROVED/DENIED.

```bash
cd tracking-agent
poetry install
uvicorn src.main:app --reload --port 8084
```

Implement in this order:
1. `scheduler/poll_scheduler.py` — backoff schedule
2. `runner/status_normalizer.py` — portal status → normalized
3. `runner/tracking_recipe.py` — recipe loader (tracking type)
4. `runner/tracking_runner.py` — headless Playwright check
5. `services/case_updater.py` — update case on terminal status
6. `services/status_callback.py` — N8N webhook on change
7. `sessions/tracking_store.py` — in-memory store
8. `sessions/tracking_thread.py` — polling loop thread
9. `routers/sessions.py` — POST/DELETE /sessions

**Reference:** [12_Tracking_Agent_Implementation.md](12_Tracking_Agent_Implementation.md)

---

### Step 11: frontend/ (Document 13)

**What it is:** React dashboard. Build last — all APIs must exist first.

```bash
cd frontend
npm install
npm run dev    # → http://localhost:5173
```

Implement in this order:
1. `api/client.ts` + `api/types.ts` — Axios + TypeScript interfaces
2. `store/authStore.ts` + `store/alertStore.ts` — Zustand state
3. `pages/LoginPage.tsx` — JWT login form
4. `components/layout/` — AppLayout, Sidebar, TopBar
5. `components/common/Badge.tsx` + `DataTable.tsx` + `AlertToast.tsx`
6. `pages/CasesPage.tsx` + `CaseDetailPage.tsx`
7. `hooks/useSSELogs.ts` + `components/cases/LogStream.tsx`
8. `hooks/useVNCViewer.ts` + `components/cases/VNCViewer.tsx`
9. `components/hitl/` — HITLTaskCard, MFAEntryForm, HITLResolveModal
10. `pages/HITLPage.tsx`
11. `pages/AnalyticsPage.tsx` + analytics chart components
12. `components/recipes/RecipeEditor.tsx` + `pages/RecipesPage.tsx`

**Reference:** [13_Frontend_Implementation.md](13_Frontend_Implementation.md)

---

## Phase 3 — End-to-End Smoke Test (Local)

Run all services together:
```bash
docker compose up   # starts all services from docker-compose.yaml in Doc 06
```

Then run this test sequence:

```
1. Open http://localhost:5173 → Login as admin
2. Submit a test case (use Batch Ingest form with a fake member_id)
3. Watch Cases table → status should move: PENDING → PLANNING → QUEUED → IN_PROGRESS
4. Open Case Detail → VNC viewer shows browser navigating the portal
5. If HITL fires → go to HITL Queue page → resolve it
6. Case completes → status → SUBMITTED
7. Tracking agent starts → eventually updates to APPROVED/DENIED
8. Analytics page shows the run
```

---

## Phase 4 — Deploy to GKE

Only attempt this after everything works locally.

### 4a. Build & Push Docker Images
```bash
# From repo root — triggers Cloud Build for each changed service
gcloud builds submit --config cloudbuild.yaml
```
Reference: **[Doc 06 — Section: Cloud Build]**

### 4b. Apply Kubernetes Manifests
```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/secrets/          # SecretProviderClass for each service
kubectl apply -f k8s/deployments/
kubectl apply -f k8s/services/
kubectl apply -f k8s/ingress.yaml
kubectl apply -f k8s/hpa.yaml
kubectl apply -f k8s/keda-scaledobject.yaml
```
Reference: **[Doc 06 — Sections: K8s Manifests, KEDA, Ingress]**

### 4c. Run DB Migration Job
```bash
kubectl apply -f k8s/jobs/db-migration.yaml
kubectl wait --for=condition=complete job/db-migration --timeout=120s
```

### 4d. Verify
```bash
kubectl get pods -n autoauth
kubectl logs -n autoauth deployment/api-server --tail=50
curl https://your-domain.com/health
```

---

## Document Reference Map

| When you need to implement... | Read this document |
|---|---|
| Database tables, ORM models, migrations | [04_Database_Schema_Design.md](04_Database_Schema_Design.md) |
| Portal recipe YAML, resolve_value(), action types | [05_Recipe_Engine_and_Portal_Specification.md](05_Recipe_Engine_and_Portal_Specification.md) |
| Dockerfiles, Cloud Build, K8s YAML, Helm, blue/green | [06_CICD_and_Deployment_Guide.md](06_CICD_and_Deployment_Guide.md) |
| Shared library (db, redis, pubsub, secret, logs) | [07_Common_Library_Implementation.md](07_Common_Library_Implementation.md) |
| REST API, auth, batch ingest, SSE alerts | [08_API_Server_Implementation.md](08_API_Server_Implementation.md) |
| Pub/Sub consumer, N8N trigger, MFA, dedup | [09_Planner_Implementation.md](09_Planner_Implementation.md) |
| Worker pool, session orchestration, VNC proxy, HITL | [10_Control_Plane_Implementation.md](10_Control_Plane_Implementation.md) |
| Playwright automation, all 14 recipe actions, CAPTCHA | [11_Browser_Agent_Implementation.md](11_Browser_Agent_Implementation.md) |
| Post-submission status polling, status normalization | [12_Tracking_Agent_Implementation.md](12_Tracking_Agent_Implementation.md) |
| React dashboard, SSE logs, VNC viewer, analytics | [13_Frontend_Implementation.md](13_Frontend_Implementation.md) |

---

## Common Pitfalls to Avoid

| Pitfall | What to do instead |
|---|---|
| Storing portal passwords in `.env` | Always use GCP Secret Manager (`get_portal_credentials()`) |
| Logging `patient_data` directly | Pass through structlog — PHI redactor strips it automatically |
| Hard-deleting a case | Set `is_deleted=True` or `status=CANCELLED` — never `DELETE` |
| Calling `get_secret()` on every request | `@lru_cache(256)` is already on it — just call it normally |
| Starting browser-agent before control-plane | Control-plane must exist to receive the pod registration call |
| Skipping the seed script | Portal IDs won't exist → foreign key violations on first case insert |
| Running browser-agent on Windows natively | Xvfb doesn't exist on Windows — use WSL2 or the Docker container |
| Building frontend before api-server has /health | Frontend dev server proxies to api-server — it must be running |

---

## The One-Line Summary of Each Service

| Service | One sentence |
|---|---|
| **api-server** | Receives PA requests from callers, validates, publishes to Pub/Sub |
| **planner** | Consumes Pub/Sub, decides which portal session to create, calls N8N |
| **control-plane** | Picks an idle browser-agent pod, creates the browser session, manages VNC |
| **browser-agent** | Runs Playwright inside a virtual display, follows the recipe step by step |
| **tracking-agent** | Periodically checks the portal for APPROVED/DENIED after submission |
| **frontend** | React dashboard: see case status, watch VNC live, handle HITL/MFA |
| **common** | Shared code that all services import — do not skip or rush this |

---

*Start with Step 4 (common library). Everything depends on it.*
