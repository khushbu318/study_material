# AutoAuth Agent — Requirements & System Design
**Phase 1 | Weeks 1–2**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Business Requirements](#2-business-requirements)
3. [Functional Requirements](#3-functional-requirements)
4. [Non-Functional Requirements](#4-non-functional-requirements)
5. [System Architecture — High-Level Design](#5-system-architecture--high-level-design)
6. [Microservices Design](#6-microservices-design)
7. [Data Flow Diagrams](#7-data-flow-diagrams)
8. [External Integrations Map](#8-external-integrations-map)
9. [Database Schema Design](#9-database-schema-design)
10. [Redis Architecture Design](#10-redis-architecture-design)
11. [GCP Pub/Sub Design](#11-gcp-pubsub-design)
12. [N8N Workflow Design](#12-n8n-workflow-design)
13. [Recipe Engine Design](#13-recipe-engine-design)
14. [Security Design](#14-security-design)
15. [API Contract Overview](#15-api-contract-overview)
16. [Execution Modes](#16-execution-modes)
17. [HITL (Human-in-the-Loop) Design](#17-hitl-human-in-the-loop-design)
18. [Deployment Architecture](#18-deployment-architecture)
19. [Open Questions & Decisions Needed](#19-open-questions--decisions-needed)

---

## 1. Executive Summary

### What is AutoAuth Agent?

AutoAuth Agent (A2) is an AI-powered **Prior Authorization (PA) automation platform** for healthcare. It automatically submits prior authorization requests to payer portals on behalf of healthcare providers — eliminating manual, time-consuming form submission that today requires clinical staff to log into each payer's web portal and fill in patient/clinical data by hand.

### The Problem It Solves

Prior Authorization is a mandatory insurance process requiring providers to get approval before delivering certain medical services. Each payer (UnitedHealth, Aetna, Cigna, etc.) has its own web portal with different forms, workflows, and authentication mechanisms. The current manual process:

- Takes 1–3 days per case
- Requires dedicated clinical admin staff
- Is prone to errors and omissions
- Causes treatment delays for patients
- Creates high staff burnout

### The Solution

A2 uses browser automation (Playwright) combined with AI (Google Gemini) to:
1. Receive PA case data via API
2. Log into the correct payer portal automatically
3. Fill in all required fields using patient + clinical data
4. Handle CAPTCHA, MFA, and ambiguous UI states
5. Submit the PA request and capture the outcome
6. Report back status in real time

---

## 2. Business Requirements

### BR-01: Multi-Payer Support
The system must support multiple payer portals (e.g., Availity, Navinet, CareCore, individual payer portals). Adding a new portal should not require code changes — only a new configuration file (recipe).

### BR-02: Batch Processing
Healthcare organizations submit PA requests in batches (e.g., 50 cases per morning). The system must accept batch submissions and process them efficiently, ideally reusing a single authenticated session per batch per portal.

### BR-03: Real-Time Status Visibility
Clinical staff must be able to see the live status of every PA case — submitted, in-progress, approved, denied, pending — through a dashboard.

### BR-04: Live Browser Monitoring
Supervisors must be able to watch the browser agent working in real time via a VNC viewer embedded in the dashboard.

### BR-05: Human-in-the-Loop (HITL)
When the agent cannot proceed autonomously (ambiguous UI, unexpected state, MFA challenge), it must pause and notify a human operator who can intervene and allow the agent to resume.

### BR-06: MFA / OTP Handling
Many payer portals require multi-factor authentication. The system must support OTP delivery to a human operator (via notification) who inputs the code, and the agent continues.

### BR-07: Cost Tracking
All LLM API calls must be tracked for cost attribution per case, per payer, per time period.

### BR-08: Audit Trail
Every action taken by the agent must be logged and stored for compliance and debugging purposes.

### BR-09: High Availability
The system must handle pod crashes gracefully — in-flight cases must be recoverable without manual intervention.

### BR-10: Autoscaling
The browser automation layer must scale automatically based on the number of pending PA requests in the queue.

---

## 3. Functional Requirements

### 3.1 API Server Requirements

| ID | Requirement |
|---|---|
| FR-001 | Accept batch PA requests via REST API (JSON payload with patient, clinical, and payer data) |
| FR-002 | Authenticate API users via JWT (register/login) |
| FR-003 | Persist each PA case to the database with a unique case reference ID |
| FR-004 | Publish each accepted case to GCP Pub/Sub for downstream processing |
| FR-005 | Serve portal recipes (YAML/JSON) to browser agents on demand |
| FR-006 | Expose dashboard data endpoints (run volume, LLM cost, case status) |
| FR-007 | Manage portal credentials (create, update, rotate secrets via GCP Secret Manager) |
| FR-008 | Support Server-Sent Events (SSE) for real-time alert streaming to the dashboard |
| FR-009 | Track and expose LLM cost data per case |
| FR-010 | Support payer-specific LLM prompt customization |

### 3.2 Planner Requirements

| ID | Requirement |
|---|---|
| FR-011 | Consume PA case messages from GCP Pub/Sub Topic #1 |
| FR-012 | Deduplicate messages within a batch to avoid duplicate sessions |
| FR-013 | Implement ONE_SESSION_PER_BATCH mode — reuse a single authenticated browser session for all cases in a batch |
| FR-014 | Trigger N8N webhook to initiate the PA submission workflow |
| FR-015 | Support re-triggering of expired/failed cases |
| FR-016 | Handle MFA chatbot interactions (ADK integration) |

### 3.3 Control Plane Requirements

| ID | Requirement |
|---|---|
| FR-017 | Consume PA case messages from GCP Pub/Sub Topic #2 |
| FR-018 | Maintain a pool of available browser-agent workers in Redis |
| FR-019 | Assign an idle browser-agent worker to each incoming case |
| FR-020 | Create a browser session on the assigned worker via REST API |
| FR-021 | Proxy VNC connections from the dashboard to the active browser-agent |
| FR-022 | Monitor worker heartbeats; detect and handle crashed pods |
| FR-023 | Recover in-flight cases when a worker pod crashes |
| FR-024 | Manage tracking sessions for post-submission status checks |
| FR-025 | Support HITL task management (list, update) |

### 3.4 Browser Agent Requirements

| ID | Requirement |
|---|---|
| FR-026 | Create isolated browser sessions with virtual display (Xvfb), VNC server, and Playwright |
| FR-027 | Execute deterministic portal recipes (Recipe Mode) |
| FR-028 | Execute LLM-driven browser automation (Agent Mode) as fallback |
| FR-029 | Support 14 recipe action types: navigate, fill, click, click_path, type_and_pick, select_if_mismatch, select_row, foreach, wait, upload, mfa, hitl, extract, assert_visible |
| FR-030 | Resolve field values from patient data, credentials, and context variables |
| FR-031 | Handle CAPTCHA solving via Capsolver |
| FR-032 | Pause execution and notify operator when HITL intervention is needed |
| FR-033 | Request OTP from operator when MFA is required |
| FR-034 | Stream all browser logs to Redis Streams in real time |
| FR-035 | Summarize logs using LLM and deliver summary via N8N webhook |
| FR-036 | Track and report LLM call costs per case |
| FR-037 | Register with Redis worker pool on startup; send heartbeat every 30 seconds |
| FR-038 | Call completion webhook (N8N) with final outcome when case finishes |

### 3.5 Tracking Agent Requirements

| ID | Requirement |
|---|---|
| FR-039 | Create isolated browser sessions for post-submission status tracking |
| FR-040 | Navigate to payer portal and check current PA status |
| FR-041 | Report status back via webhook |
| FR-042 | Clean up browser profiles after sessions |

### 3.6 Frontend Requirements

| ID | Requirement |
|---|---|
| FR-043 | Login page with JWT authentication |
| FR-044 | Dashboard showing all PA cases with status, payer, timestamp |
| FR-045 | Embedded noVNC viewer to watch browser agent in real time |
| FR-046 | HITL resolution interface — view paused case, take action, resume |
| FR-047 | Portal credential management UI |
| FR-048 | Run volume charts (daily/weekly/monthly) |
| FR-049 | LLM cost analytics |
| FR-050 | Alert notifications via SSE |

---

## 4. Non-Functional Requirements

### 4.1 Performance

| ID | Requirement | Target |
|---|---|---|
| NFR-001 | API ingestion throughput | >100 PA cases/minute |
| NFR-002 | Browser session creation time | <30 seconds |
| NFR-003 | End-to-end PA submission time (simple portal) | <5 minutes |
| NFR-004 | Dashboard page load time | <2 seconds |
| NFR-005 | VNC stream latency | <500ms |

### 4.2 Availability & Reliability

| ID | Requirement | Target |
|---|---|---|
| NFR-006 | API server uptime | 99.9% |
| NFR-007 | Zero case loss on pod crash | 100% (via Redis + heartbeat recovery) |
| NFR-008 | Max retry attempts per failed case | 3 |
| NFR-009 | Pub/Sub message ack deadline | 600 seconds |

### 4.3 Scalability

| ID | Requirement |
|---|---|
| NFR-010 | Browser-agent pods: autoscale 1–6 replicas based on Pub/Sub queue depth (KEDA) |
| NFR-011 | Each browser-agent pod handles up to 5 concurrent browser sessions |
| NFR-012 | PostgreSQL connection pooling via SQLAlchemy (pool_size=10, max_overflow=20) |
| NFR-013 | Redis connection pooling |

### 4.4 Security

| ID | Requirement |
|---|---|
| NFR-014 | All portal credentials stored in GCP Secret Manager — never in code or env files |
| NFR-015 | JWT tokens expire in 60 minutes; refresh required |
| NFR-016 | All inter-service communication within GKE cluster (no public exposure except api-server + frontend) |
| NFR-017 | Workload Identity for GCP API access (no long-lived service account keys on pods) |
| NFR-018 | TLS on all external endpoints |
| NFR-019 | No PII/PHI logged in plain text |

### 4.5 Observability

| ID | Requirement |
|---|---|
| NFR-020 | Structured JSON logging on all services |
| NFR-021 | Trace ID propagated across all services for a given case |
| NFR-022 | Cloud Monitoring dashboards for all services |
| NFR-023 | Alerting on: pod crash, Pub/Sub lag >100 messages, Redis pool empty, DB connection failure |

---

## 5. System Architecture — High-Level Design

### 5.1 Overall Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              EXTERNAL CLIENTS                                   │
│         Healthcare Providers / EHR Systems / Clinical Admin Staff               │
└────────────────────────────┬──────────────────────────────┬─────────────────────┘
                             │ REST API                      │ Browser (Dashboard)
                             ▼                               ▼
┌────────────────────────────────────────────────────────────────────────────────┐
│                              GKE CLUSTER  (agentic-app namespace)              │
│                                                                                │
│  ┌─────────────────┐     ┌──────────────────────────────────────────────────┐ │
│  │   FRONTEND (ui) │     │                  API SERVER                      │ │
│  │  React / Vite   │◄────│  FastAPI | JWT Auth | Batch Ingest | Dashboard   │ │
│  │   Port: 80      │     │  Recipe Serving | Cost Tracking | SSE Alerts     │ │
│  └─────────────────┘     └──────────────────┬───────────────────────────────┘ │
│                                             │                                  │
│                                             │ Publish to Pub/Sub Topic #1      │
│                                             ▼                                  │
│                           ┌────────────────────────────┐                       │
│                           │    GCP PUB/SUB TOPIC #1    │                       │
│                           │  prior-auth-agent-requests  │                       │
│                           └────────────────┬───────────┘                       │
│                                            │ Subscribe                         │
│                                            ▼                                   │
│                           ┌────────────────────────────┐                       │
│                           │          PLANNER           │                       │
│                           │  Pub/Sub Consumer          │                       │
│                           │  Deduplication Cache       │                       │
│                           │  ONE_SESSION_PER_BATCH     │                       │
│                           │  N8N Webhook Trigger       │                       │
│                           └────────────────┬───────────┘                       │
│                                            │                                   │
│                                            │ HTTP POST → N8N Webhook           │
│                                            ▼                                   │
│                           ┌────────────────────────────┐                       │
│                           │            N8N             │                       │
│                           │  Workflow Automation       │                       │
│                           │  7 Webhook Endpoints       │                       │
│                           └────────────────┬───────────┘                       │
│                                            │                                   │
│                                            │ Publish to Pub/Sub Topic #2       │
│                                            ▼                                   │
│                           ┌────────────────────────────┐                       │
│                           │    GCP PUB/SUB TOPIC #2    │                       │
│                           │ prior-auth-browser-agent-  │                       │
│                           │      requests              │                       │
│                           └────────────────┬───────────┘                       │
│                                            │ Subscribe                         │
│                                            ▼                                   │
│                           ┌────────────────────────────┐                       │
│                           │       CONTROL PLANE        │                       │
│                           │  Pub/Sub Consumer          │                       │
│                           │  Worker Pool Management    │◄──────┐               │
│                           │  VNC Proxy                 │       │               │
│                           │  Heartbeat Monitor         │       │ Redis         │
│                           │  Crash Recovery            │       │ Worker Pool   │
│                           └────────────────┬───────────┘       │               │
│                                            │                   │               │
│                         ┌──────────────────┘                   │               │
│                         │ HTTP: create_session()               │               │
│                         ▼                                      │               │
│  ┌──────────────────────────────────────────────────────────┐  │               │
│  │              BROWSER AGENT POOL  (1–6 pods, KEDA)        │  │               │
│  │                                                          │  │               │
│  │  Pod 1              Pod 2              Pod N             │  │               │
│  │ ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │  │               │
│  │ │ FastAPI      │  │ FastAPI      │  │ FastAPI      │   │  │               │
│  │ │ Playwright   │  │ Playwright   │  │ Playwright   │   │──┘               │
│  │ │ Xvfb + VNC   │  │ Xvfb + VNC   │  │ Xvfb + VNC   │   │                  │
│  │ │ RecipeRunner │  │ RecipeRunner │  │ RecipeRunner │   │                  │
│  │ │ LLM Agent    │  │ LLM Agent    │  │ LLM Agent    │   │                  │
│  │ │ HITL Handler │  │ HITL Handler │  │ HITL Handler │   │                  │
│  │ └──────────────┘  └──────────────┘  └──────────────┘   │                  │
│  └──────────────────────────────────────────────────────────┘                  │
│                                                                                │
│  ┌────────────────────────────────────────────────────────────────────────┐   │
│  │                        TRACKING AGENT POOL                             │   │
│  │         Separate pool for post-submission PA status checks             │   │
│  └────────────────────────────────────────────────────────────────────────┘   │
│                                                                                │
│  ┌──────────────────┐   ┌──────────────────┐   ┌──────────────────────────┐  │
│  │   REDIS          │   │   POSTGRESQL     │   │   GCP SERVICES           │  │
│  │  Worker Pools    │   │  25+ Tables      │   │  Pub/Sub | Secret Mgr   │  │
│  │  Credential Pool │   │  Case Data       │   │  Cloud Storage | Vertex  │  │
│  │  Log Streams     │   │  Audit Logs      │   │  AI / Gemini             │  │
│  │  Heartbeats      │   │  Cost Tracking   │   │                          │  │
│  └──────────────────┘   └──────────────────┘   └──────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Component Responsibility Matrix

| Component | Owns | Does NOT Own |
|---|---|---|
| api-server | External API, JWT auth, batch ingestion, recipe serving, dashboard data | Browser automation, Pub/Sub consumption |
| planner | Pub/Sub #1 consumption, batch deduplication, N8N trigger | Session management, browser control |
| control-plane | Worker pool, session routing, VNC proxy, crash recovery | Business logic, recipe execution |
| browser-agent | Browser sessions, recipe execution, LLM agent, HITL | Routing, worker pool, DB writes (uses api-server) |
| tracking-agent | Post-submission status checks | PA submission, HITL |
| common | DB ORM, Redis layer, Pub/Sub base, Secret Manager, logging | Business logic |
| N8N | Workflow orchestration, webhook routing | Data persistence, browser control |

---

## 6. Microservices Design

### 6.1 api-server

```
api-server/
├── app/
│   ├── main.py                        # FastAPI app, lifespan hooks
│   ├── core/
│   │   └── config.py                  # Pydantic Settings (all env vars)
│   ├── api/
│   │   ├── __init__.py                # Aggregated router
│   │   ├── authentication.py          # POST /auth/register, POST /auth/login
│   │   ├── sequential_batch.py        # POST /prior-auths (batch ingest)
│   │   ├── dashboard_apis.py          # Dashboard data endpoints
│   │   ├── payer_prompts.py           # Payer-specific LLM prompts CRUD
│   │   ├── portal_secret.py           # Portal credential management
│   │   ├── run_volume.py              # Run volume metrics
│   │   ├── llm_cost.py               # LLM cost data
│   │   ├── vnc_update.py             # VNC session updates
│   │   ├── alert_sse.py              # SSE alert stream
│   │   └── system.py                 # Health check
│   ├── services/
│   │   ├── batch_processing_service.py  # Core batch logic + Pub/Sub publish
│   │   ├── stats_service.py
│   │   ├── user_auth_service.py
│   │   └── payer_prompts_service_api.py
│   ├── db/
│   │   └── redis.py                  # Redis client
│   └── models/
│       └── prior_auth/
│           └── batch.py              # VendorRequest, batch models
```

**Startup sequence:**
1. Initialize DB connection pool
2. Initialize Redis connection
3. Load `PriorAuthSubmissionCredentialManager` (pre-loads portal credentials into Redis)
4. Load `PriorAuthTrackingCredentialManager`
5. Start FastAPI server

**Key Design Decisions:**
- Stateless — all state in PostgreSQL + Redis
- Credentials never stored in memory beyond startup load into Redis pool
- Recipe endpoint acts as a cache layer — DB first, YAML fallback

---

### 6.2 planner

```
planner/
├── main.py                                    # FastAPI app, lifespan
├── prior_auth_request_submission_consumer.py  # PlannerConsumer (Pub/Sub)
├── adk/
│   ├── pre_auth.py                            # start_pre_auth(), preauth endpoint
│   ├── chatbot_handler.py                     # MFA chatbot router
│   └── adk_consumer.py                        # ADK consumer
├── api/
│   ├── agent_tools.py                         # trigger_n8n_logic()
│   ├── prior_auth_request_submission_producer.py  # Pub/Sub producer
│   ├── retrigger.py                           # Retry expired cases
│   ├── sse_and_consumer.py                    # SSE + consumer endpoints
│   └── sync_case_logs.py                      # Log sync
```

**Startup sequence:**
1. Initialize `PlannerService` (DB service)
2. Register portal credentials into Redis
3. Start `PlannerConsumer` thread (Pub/Sub subscription)
4. Start FastAPI server

**Key Design: `InMemoryCache` for Deduplication**
```
ONE_SESSION_PER_BATCH = true:
  - Batch ID X arrives → first case triggers N8N
  - Subsequent cases in same batch → cached, piggybacked on same session
  - Cache TTL = session lifetime estimate (e.g., 30 minutes)
```

---

### 6.3 control-plane

```
control-plane/
├── app/
│   ├── main.py                              # FastAPI app, lifespan
│   ├── consumers/
│   │   ├── prior_auth_request_submission_consumer.py    # ControlPlaneSessionConsumer
│   │   └── prior_auth_request_submission_consumer_factory.py
│   ├── routers/
│   │   ├── sessions.py                      # Session CRUD + VNC proxy
│   │   ├── agents.py                        # Agent management
│   │   ├── hitl.py                          # HITL routes
│   │   └── tracking_sessions.py             # Tracking session routes
│   ├── models/
│   │   ├── sessions_models.py
│   │   ├── redis_models.py                  # WorkerQueue
│   │   ├── agents_models.py
│   │   └── tracking_models.py
│   └── config/
│       ├── redis.py
│       └── redis_queue.py
```

**Worker Pool State Machine:**
```
Pod starts → registers in Redis "IDLE" set
          ↓
Case arrives → control-plane moves pod from IDLE → BUSY set
          ↓
Case completes → browser-agent calls completion webhook
          ↓
Control-plane moves pod from BUSY → COOLING set (brief cooldown)
          ↓
After cooldown → moves pod back to IDLE set
          ↓
Pod crashes → Redis key expires → ExpiredEventConsumer fires
          ↓
CrashRecovery: case marked failed/retried, STATUS_CAPTURE_WEBHOOK called
```

**VNC Proxy Design:**
```
Browser (Dashboard)
    → GET /sessions/{id}/vnc/vnc.html     (control-plane HTTP proxy)
        → GET http://browser-agent-pod-ip:8080/vnc.html

    → WS /sessions/{id}/vnc/websockify   (control-plane WS proxy)
        → WS ws://browser-agent-pod-ip:8080/websockify
            → TCP localhost:5900 (x11vnc)
                → Xvfb DISPLAY=:{display_num}
```

---

### 6.4 browser-agent

```
browser-agent/
├── app/
│   ├── main.py                           # FastAPI app, lifespan, worker registration
│   ├── routers/
│   │   ├── sessions.py                   # POST/DELETE /sessions
│   │   ├── agents.py                     # POST /agents (run recipe/LLM)
│   │   └── hitl.py                       # HITL pause/resume
│   ├── engine/
│   │   ├── runner.py                     # RecipeRunner — 14 action types
│   │   ├── recipe_loader.py              # load_recipe() — DB or YAML
│   │   ├── feature_flag.py               # playwright_enabled() check
│   │   ├── hitl.py                       # request_hitl(), request_mfa()
│   │   ├── matching.py                   # pick_option() — fuzzy matching
│   │   └── resolvers.py                  # resolve_value() — field resolution
│   ├── services/
│   │   ├── displayAllocation.py          # Xvfb/VNC/websockify process mgmt
│   │   ├── secret_manager.py             # GCP Secret Manager wrapper
│   │   └── summarization_thread.py       # SummarizationThread
│   ├── custom_llm/
│   │   └── browser_use_wrapper.py        # CustomGoogleChat (Gemini wrapper)
│   ├── utility/
│   │   ├── constants.py                  # Port/display allocation maps
│   │   ├── pricing.py                    # Token cost tracking
│   │   ├── queue_helper.py               # Redis queue helpers
│   │   ├── redis_logging.py              # Redis log streaming setup
│   │   ├── session_telemetry.py          # LLM call telemetry
│   │   └── filedownload.py               # GCS file download for uploads
│   ├── system/
│   │   └── system_prompt.py              # LLM system prompt (Agent Mode)
│   └── recipes/
│       ├── cohere.yaml
│       └── gia-carelon.yaml
```

**Session Allocation (per pod):**
```
Session slots:  1, 2, 3, 4, 5  (max 5 per pod)
Display nums:  :10, :11, :12, :13, :14
VNC ports:     5910, 5911, 5912, 5913, 5914
Web ports:     6080, 6081, 6082, 6083, 6084
(BASE_DISPLAY_NUM + slot, BASE_VNC_PORT + slot, BASE_WEB_PORT + slot)
```

---

### 6.5 tracking-agent

```
tracking-agent/
├── app/
│   ├── main.py
│   ├── routers/
│   │   ├── sessions.py
│   │   └── profile_cleanup.py
│   └── services/
│       ├── displayAllocation.py
│       └── secret_manager.py
```

Structurally mirrors browser-agent but only handles status checking (read-only portal navigation), not full PA submission.

---

### 6.6 common (Shared Library)

```
common/
├── db_layer/
│   ├── db_config.py                     # DatabaseConfig (multi-env PostgreSQL)
│   ├── create_tables_iks_schema.py       # Schema DDL
│   ├── orm_models/                       # SQLAlchemy ORM models (25+ tables)
│   ├── repositories/                     # Repository pattern per ORM model
│   ├── services/
│   │   ├── planner_service.py            # Core DB service (all business queries)
│   │   ├── batch_processing_service.py
│   │   ├── StatsService.py
│   │   ├── user_service.py
│   │   ├── payer_prompts_service.py
│   │   └── case_logs_service.py
│   └── patterns/
│       ├── unit_of_work.py               # UnitOfWork pattern
│       └── di_container.py              # ServiceContainer DI
├── redis_layer/
│   ├── connection_manager.py             # RedisConnectionManager singleton
│   ├── config/redis_config.py
│   ├── token_service/service/
│   │   ├── prior_auth_submission_worker_manager.py
│   │   ├── prior_auth_submission_credential_manager.py
│   │   └── prior_auth_submission_in_flight_request_manager.py
│   ├── heartbeat/
│   │   ├── sender/
│   │   │   ├── prior_auth_submission_keep_alive_sender.py
│   │   │   └── prior_auth_submission_in_flight_sender.py
│   │   └── monitor/
│   │       ├── consumer/expired_event_consumer.py
│   │       └── handler/
│   │           ├── prior_auth_submission_worker_completion_handler.py
│   │           ├── prior_auth_submission_worker_expiration_handler.py
│   │           └── prior_auth_submission_credential_completion_handler.py
│   └── redis_stream_service.py
├── pubsub_layer/
│   └── consumer/
│       └── base_consumer.py              # BaseConsumer(ABC), ConsumerThread
├── secret/
│   └── secret_manager.py                 # GCP Secret Manager wrapper
├── cache/
│   └── prior_auth_submission_payer_cache.py
├── logs/
│   ├── log_summarizer.py                 # LLM log summarization
│   └── redis_logging.py
├── recipe_models.py                       # Step, PortalRecipe, ActionType
├── browser_agent/models.py               # AgentCreateRequest
└── enums/hitl_task_status.py
```

---

## 7. Data Flow Diagrams

### 7.1 Happy Path — Full PA Submission Flow

```
Step 1: Batch Ingestion
────────────────────────
Client
  │  POST /api/v1/agentic-platform/prior-auths
  │  Body: { batch_id, cases: [{patient, clinical, payer_id, portal_id}] }
  ▼
api-server
  │  → Validate request
  │  → Insert batch record into PostgreSQL (prior_auth_batch_request)
  │  → Insert each case into PostgreSQL (prior_auth_case_request, status=PENDING)
  │  → Publish message to Pub/Sub Topic #1
  │    Message: { batch_id, case_ref_id, payer_id, portal_id, ... }
  ▼
Return 201: { batch_id, case_count, status: "accepted" }

Step 2: Planning
────────────────────────
planner (PlannerConsumer thread)
  │  ← Receives message from Pub/Sub Topic #1
  │  → Check InMemoryCache: is batch_id already being processed?
  │     YES → Skip (ONE_SESSION_PER_BATCH mode)
  │     NO  → Cache batch_id, proceed
  │  → Update case status → PLANNING in PostgreSQL
  │  → POST to N8N webhook: PRIOR_AUTH_SUBMISSION_WEBHOOK_URL
  │    Body: { case_ref_id, batch_id, portal_id, payer_id }
  ▼
N8N Workflow (submission flow)
  │  → Applies business rules / enrichment
  │  → Publishes to Pub/Sub Topic #2
  │    Message: { case_ref_id, worker_url, credentials_key, ... }

Step 3: Session Assignment
────────────────────────
control-plane (ControlPlaneSessionConsumer thread)
  │  ← Receives message from Pub/Sub Topic #2
  │  → Pick idle browser-agent worker from Redis IDLE set
  │  → Move worker: IDLE → BUSY in Redis
  │  → POST /api/v1/sessions to browser-agent-pod
  │    Body: { case_ref_id, portal_id, display_slot }
  ▼
browser-agent (sessions router)
  │  → Allocate display slot (Xvfb, VNC port, web port)
  │  → Launch Xvfb process (virtual display)
  │  → Launch x11vnc process (VNC server on virtual display)
  │  → Launch websockify process (TCP→WebSocket bridge)
  │  → Launch Playwright (connects to Xvfb display)
  │  → Return session info: { session_id, vnc_port, web_port }
  ▼
control-plane
  │  → Store session info in Redis (case_ref_id → pod_ip, session_id, ports)
  │  → POST to N8N: TRIGGER_PRIOR_AUTH_SUBMISSION_AGENT
  │    Body: { case_ref_id, session_id, browser_agent_url }

Step 4: Recipe Execution
────────────────────────
browser-agent (agents router)
  │  ← POST /api/v1/agents from N8N
  │  → Load recipe: GET /api/v1/agentic-platform/prior-auths/recipes/{portal_id}
  │    from api-server (LRU cached)
  │  → Fetch credentials from GCP Secret Manager
  │  → Fetch patient/clinical data from api-server or request payload
  │  → Start RecipeRunner (in background thread)
  │     For each step in recipe:
  │       → resolve_value(step.value, context)
  │       → execute action (navigate/fill/click/select/etc.)
  │       → stream log to Redis Stream (case_ref_id/logs)
  │       → if CAPTCHA → call Capsolver API
  │       → if MFA → call N8N MFA_WEBHOOK_URL → wait for OTP
  │       → if HITL → call N8N HITL_WEBHOOK_URL → wait for resume
  │  → On completion:
  │     → POST to N8N: COMP_WEBHOOK_URL { case_ref_id, outcome, screenshot_url }
  │     → POST to N8N: STATUS_CAPTURE_WEBHOOK_URL
  │     → Update case status in PostgreSQL via api-server

Step 5: Cleanup
────────────────────────
control-plane
  │  ← Receives completion callback (via N8N or direct)
  │  → DELETE /api/v1/sessions/{case_ref_id} on browser-agent
  │     → Kill Xvfb, VNC, websockify processes
  │     → Close Playwright browser
  │  → Move worker: BUSY → COOLING → IDLE in Redis
```

### 7.2 HITL Intervention Flow

```
RecipeRunner
  │  Hits unknown state / ambiguous UI
  │  → Call request_hitl(case_ref_id, screenshot, message)
  │  → POST to N8N: HITL_WEBHOOK_URL
  │  → Insert HITL task into PostgreSQL (prior_auth_hitl_task, status=PENDING)
  │  → PAUSE execution (asyncio.Event / threading.Event wait)
  ▼
N8N → notifies operator (email, Slack, dashboard alert via SSE)

Operator opens dashboard
  │  → Sees paused case with screenshot
  │  → Takes action (manual portal interaction via VNC viewer)
  │  → Clicks "Resume" in dashboard UI
  ▼
Frontend → POST /api/v1/hitl/{task_id}/resolve (control-plane)
  │  → Update HITL task status → RESOLVED in PostgreSQL
  │  → POST /api/v1/hitl/{task_id}/resume on browser-agent
  ▼
browser-agent
  │  → Event.set() → RecipeRunner resumes from where it paused
```

### 7.3 MFA / OTP Flow

```
RecipeRunner hits MFA step
  │  → Call request_mfa(case_ref_id, portal_id)
  │  → POST to N8N: MFA_WEBHOOK_URL
  │  → Blocks on asyncio.Queue.get() (waiting for OTP)
  ▼
N8N → routes to ADK chatbot handler (planner service)
  → Operator receives OTP on their phone
  → Operator types OTP into chatbot / dashboard

Chatbot handler (planner/adk)
  │  → POST to browser-agent: /api/v1/hitl/mfa/{case_ref_id}
  │    Body: { otp: "123456" }
  ▼
browser-agent
  │  → asyncio.Queue.put(otp)
  │  → RecipeRunner: queue.get() returns OTP
  │  → Fills OTP field in portal
  │  → Continues recipe execution
```

### 7.4 Pod Crash Recovery Flow

```
browser-agent pod crashes mid-execution
  │
  ▼ (30 seconds pass with no heartbeat)
Redis key expires: worker:submission:{pod_id}:heartbeat
  │
  ▼
control-plane ExpiredEventConsumer
  │  ← Redis keyspace notification: __keyevent@0__:expired
  │  → Parse pod_id from expired key
  │  → Call PriorAuthSubmissionWorkerCompletionHandler
  │     → Find in-flight case for this pod (from Redis in-flight set)
  │     → Update case status → CRASHED in PostgreSQL
  │     → POST to N8N: STATUS_CAPTURE_WEBHOOK_URL
  │       { case_ref_id, status: "CRASHED", retry: true }
  │     → Remove pod from BUSY set in Redis
  │     → (Optional) Re-publish case to Pub/Sub for retry
```

---

## 8. External Integrations Map

### 8.1 Integration Overview

```
┌────────────────────────────────────────────────────────────────────────────┐
│                     AUTOAUTH AGENT EXTERNAL INTEGRATIONS                   │
│                                                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                          GCP SERVICES                               │  │
│  │                                                                     │  │
│  │  ┌─────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │  │
│  │  │  CLOUD PUB/SUB  │  │  SECRET MANAGER  │  │  CLOUD STORAGE   │  │  │
│  │  │  Topic #1:      │  │  Portal creds    │  │  PA documents    │  │  │
│  │  │  agent-requests │  │  (user/pass per  │  │  for upload      │  │  │
│  │  │  Topic #2:      │  │   portal)        │  │  steps           │  │  │
│  │  │  browser-agent- │  │                  │  │                  │  │  │
│  │  │  requests       │  │                  │  │                  │  │  │
│  │  └─────────────────┘  └──────────────────┘  └──────────────────┘  │  │
│  │                                                                     │  │
│  │  ┌──────────────────────────────────────────────────────────────┐  │  │
│  │  │              VERTEX AI / GEMINI                              │  │  │
│  │  │  Model: gemini-2.5-pro                                       │  │  │
│  │  │  Used by: browser-agent (LLM Agent Mode + Log Summarizer)   │  │  │
│  │  │           planner (ADK chatbot)                              │  │  │
│  │  │           api-server (payer prompt management)              │  │  │
│  │  └──────────────────────────────────────────────────────────────┘  │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                       DATA STORES                                   │  │
│  │                                                                     │  │
│  │  ┌──────────────────┐              ┌──────────────────────────┐    │  │
│  │  │    POSTGRESQL    │              │         REDIS            │    │  │
│  │  │  Cloud SQL (GCP) │              │   Memorystore (GCP)      │    │  │
│  │  │  25+ tables      │              │   Worker pools           │    │  │
│  │  │  Case data       │              │   Credential pools       │    │  │
│  │  │  Audit logs      │              │   Heartbeats             │    │  │
│  │  │  Cost tracking   │              │   Log streams            │    │  │
│  │  └──────────────────┘              └──────────────────────────┘    │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                   THIRD-PARTY SERVICES                              │  │
│  │                                                                     │  │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │  │
│  │  │    CAPSOLVER     │  │      N8N         │  │   PAYER PORTALS  │  │  │
│  │  │  CAPTCHA solving │  │  Self-hosted     │  │  (Availity,      │  │  │
│  │  │  API Key auth    │  │  workflow engine │  │   Navinet,       │  │  │
│  │  │                  │  │  7 webhooks      │  │   CareCore, etc) │  │  │
│  │  └──────────────────┘  └──────────────────┘  └──────────────────┘  │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

### 8.2 N8N Webhook Inventory

| Webhook Name | Env Variable | Direction | Trigger | Payload |
|---|---|---|---|---|
| PA Submission | `PRIOR_AUTH_SUBMISSION_WEBHOOK_URL` | planner → N8N | New case from Pub/Sub | `{ case_ref_id, batch_id, portal_id }` |
| Agent Trigger | `TRIGGER_PRIOR_AUTH_SUBMISSION_AGENT` | control-plane → N8N | Session ready | `{ case_ref_id, session_id, browser_agent_url }` |
| HITL | `HITL_WEBHOOK_URL` | browser-agent → N8N | Agent stuck | `{ case_ref_id, screenshot, message }` |
| MFA / OTP | `MFA_WEBHOOK_URL` | browser-agent → N8N | MFA required | `{ case_ref_id, portal_id }` |
| Completion | `COMP_WEBHOOK_URL` | browser-agent → N8N | Case done | `{ case_ref_id, outcome, ref_number }` |
| Summary | `SUMMARY_WEBHOOK_URL` | browser-agent → N8N | Log summary ready | `{ case_ref_id, summary_text }` |
| Status Capture | `STATUS_CAPTURE_WEBHOOK_URL` | browser-agent/control-plane → N8N | Any status change | `{ case_ref_id, status }` |

### 8.3 GCP Pub/Sub Topic Design

| Topic | Publisher | Subscriber | Message Schema |
|---|---|---|---|
| `prior-auth-agent-requests` | api-server | planner | `{ batch_id, case_ref_id, payer_id, portal_id, case_data }` |
| `prior-auth-browser-agent-requests` | N8N (via planner trigger) | control-plane | `{ case_ref_id, portal_id, credentials_key, worker_config }` |

**Subscription config:**
- Ack deadline: 600 seconds
- Retry policy: exponential backoff (min 10s, max 600s)
- Dead-letter topic: `prior-auth-*-dlq` (after 5 delivery attempts)

---

## 9. Database Schema Design

### 9.1 Schema Overview (PostgreSQL, schema: `iks_schema`)

```
CORE ENTITIES
─────────────
prior_auth_payer                    → Payer/Insurance company master data
prior_auth_portal                   → Web portal master data per payer
prior_auth_portal_credential        → Portal credential metadata (secret key ref)
prior_auth_batch_request            → Batch of PA cases from one API call
prior_auth_case_request             → Individual PA case (one per patient/procedure)

AGENT ENTITIES
──────────────
prior_auth_agent_session            → Browser session lifecycle record
prior_auth_vnc_session              → VNC session details (pod IP, ports)
prior_auth_planner_agent_status     → Planner processing state per case

HITL & INTERVENTION
────────────────────
prior_auth_hitl_task                → HITL intervention tasks

LOGGING & AUDIT
────────────────
prior_auth_case_logs                → Structured logs per case (agent actions)

COST TRACKING
─────────────
agentic_platform_ai_model_pricing   → LLM model pricing config (per 1K tokens)
agentic_platform_request_cost       → Per-case LLM call cost records

USER MANAGEMENT
────────────────
agentic_platform_user               → Dashboard users (JWT auth)
agentic_platform_agent              → Registered agent entities

CONFIGURATION
─────────────
prior_auth_payer_prompt             → Per-payer LLM system prompt overrides
```

### 9.2 Core Tables DDL

```sql
-- Payer / Insurance Company
CREATE TABLE iks_schema.prior_auth_payer (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payer_name      VARCHAR(255) NOT NULL,
    payer_code      VARCHAR(100) UNIQUE NOT NULL,  -- e.g., "UHC", "AETNA"
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Payer Portal (each payer can have multiple portals)
CREATE TABLE iks_schema.prior_auth_portal (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payer_id        UUID REFERENCES prior_auth_payer(id),
    portal_name     VARCHAR(255) NOT NULL,
    portal_id       VARCHAR(100) UNIQUE NOT NULL,  -- e.g., "availity", "navinet"
    base_url        VARCHAR(500),
    recipe_yaml     TEXT,                          -- Stored recipe (YAML)
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Portal Credentials (secret reference, not actual secret)
CREATE TABLE iks_schema.prior_auth_portal_credential (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    portal_id       UUID REFERENCES prior_auth_portal(id),
    credential_alias VARCHAR(255) NOT NULL,        -- GCP Secret Manager alias
    username_secret  VARCHAR(500),                 -- Secret Manager path
    password_secret  VARCHAR(500),                 -- Secret Manager path
    service_account  VARCHAR(500),                 -- For MFA SIM credentials
    is_active        BOOLEAN DEFAULT TRUE,
    created_at       TIMESTAMPTZ DEFAULT NOW(),
    updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- Batch Request (one API call = one batch)
CREATE TABLE iks_schema.prior_auth_batch_request (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id        VARCHAR(255) UNIQUE NOT NULL,
    portal_id       UUID REFERENCES prior_auth_portal(id),
    payer_id        UUID REFERENCES prior_auth_payer(id),
    total_cases     INTEGER NOT NULL,
    status          VARCHAR(50) DEFAULT 'PENDING',  -- PENDING/IN_PROGRESS/COMPLETED/FAILED
    submitted_by    UUID REFERENCES agentic_platform_user(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Individual PA Case
CREATE TABLE iks_schema.prior_auth_case_request (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) UNIQUE NOT NULL,  -- External reference ID
    batch_id        UUID REFERENCES prior_auth_batch_request(id),
    portal_id       UUID REFERENCES prior_auth_portal(id),
    payer_id        UUID REFERENCES prior_auth_payer(id),

    -- Patient Data (JSONB for flexibility)
    patient_data    JSONB NOT NULL,
    -- { first_name, last_name, dob, member_id, group_id, ... }

    -- Clinical Data
    clinical_data   JSONB NOT NULL,
    -- { procedure_codes, diagnosis_codes, npi, provider_name, dates_of_service, ... }

    -- Status Tracking
    status          VARCHAR(100) DEFAULT 'PENDING',
    -- PENDING → PLANNING → QUEUED → IN_PROGRESS → SUBMITTED → APPROVED/DENIED/PENDING_INFO → FAILED/CRASHED

    -- Outcome
    pa_reference_number  VARCHAR(255),            -- PA approval/denial number from payer
    outcome              VARCHAR(100),            -- APPROVED/DENIED/PENDING/ERROR
    outcome_details      TEXT,

    -- Metadata
    retry_count     INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    submitted_at    TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ
);
CREATE INDEX idx_case_status ON iks_schema.prior_auth_case_request(status);
CREATE INDEX idx_case_batch ON iks_schema.prior_auth_case_request(batch_id);
CREATE INDEX idx_case_portal ON iks_schema.prior_auth_case_request(portal_id);

-- Browser Agent Session
CREATE TABLE iks_schema.prior_auth_agent_session (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) REFERENCES prior_auth_case_request(case_ref_id),
    pod_id          VARCHAR(255),                  -- K8s pod name
    pod_ip          VARCHAR(50),
    session_id      VARCHAR(255) UNIQUE NOT NULL,
    display_slot    INTEGER,
    vnc_port        INTEGER,
    web_port        INTEGER,
    status          VARCHAR(50),                   -- ACTIVE/COMPLETED/CRASHED
    started_at      TIMESTAMPTZ DEFAULT NOW(),
    ended_at        TIMESTAMPTZ
);

-- HITL Task
CREATE TABLE iks_schema.prior_auth_hitl_task (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) REFERENCES prior_auth_case_request(case_ref_id),
    task_type       VARCHAR(50),                   -- HITL / MFA
    status          VARCHAR(50) DEFAULT 'PENDING', -- PENDING/RESOLVED/EXPIRED
    message         TEXT,                          -- What the agent needs help with
    screenshot_url  VARCHAR(1000),
    resolution      TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    resolved_at     TIMESTAMPTZ,
    resolved_by     UUID REFERENCES agentic_platform_user(id)
);

-- Case Logs
CREATE TABLE iks_schema.prior_auth_case_logs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) REFERENCES prior_auth_case_request(case_ref_id),
    log_level       VARCHAR(20),                   -- INFO/WARN/ERROR/DEBUG
    step_name       VARCHAR(255),
    message         TEXT,
    metadata        JSONB,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_logs_case ON iks_schema.prior_auth_case_logs(case_ref_id);
CREATE INDEX idx_logs_time ON iks_schema.prior_auth_case_logs(created_at);

-- LLM Cost Tracking
CREATE TABLE iks_schema.agentic_platform_ai_model_pricing (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_name      VARCHAR(255) UNIQUE NOT NULL,  -- e.g., "gemini-2.5-pro"
    input_cost_per_1k  DECIMAL(10,6),              -- USD per 1K input tokens
    output_cost_per_1k DECIMAL(10,6),              -- USD per 1K output tokens
    effective_from  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE iks_schema.agentic_platform_request_cost (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) REFERENCES prior_auth_case_request(case_ref_id),
    model_name      VARCHAR(255),
    input_tokens    INTEGER,
    output_tokens   INTEGER,
    total_cost_usd  DECIMAL(12,6),
    call_type       VARCHAR(100),                  -- "browser_agent" / "log_summary" / "page_extract"
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Dashboard Users
CREATE TABLE iks_schema.agentic_platform_user (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email           VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(500) NOT NULL,
    full_name       VARCHAR(255),
    role            VARCHAR(50) DEFAULT 'VIEWER', -- ADMIN/OPERATOR/VIEWER
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Payer-specific LLM Prompt Overrides
CREATE TABLE iks_schema.prior_auth_payer_prompt (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    portal_id       UUID REFERENCES prior_auth_portal(id),
    prompt_type     VARCHAR(100),                  -- "system" / "extraction" / "summary"
    prompt_text     TEXT NOT NULL,
    model_name      VARCHAR(255),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### 9.3 Case Status State Machine

```
                         ┌─────────┐
                         │ PENDING │  ← Created by api-server on batch ingest
                         └────┬────┘
                              │ planner consumes Pub/Sub
                              ▼
                         ┌──────────┐
                         │ PLANNING │  ← Planner dedup check + N8N trigger
                         └────┬─────┘
                              │ control-plane receives from Pub/Sub #2
                              ▼
                         ┌────────┐
                         │ QUEUED │  ← Waiting for idle browser-agent worker
                         └───┬────┘
                             │ Worker assigned + session created
                             ▼
                        ┌─────────────┐
                        │ IN_PROGRESS │  ← RecipeRunner executing
                        └──────┬──────┘
                     ┌─────────┴──────────┐
                     │                    │
                     ▼                    ▼
               ┌──────────┐        ┌──────────┐
               │ HITL_WAIT│        │ MFA_WAIT │
               └────┬─────┘        └────┬─────┘
                    │ operator resolves  │ OTP provided
                    └─────────┬──────────┘
                              │ resumes
                              ▼
                         ┌───────────┐
                         │ SUBMITTED │  ← Form submitted to payer portal
                         └─────┬─────┘
              ┌────────────────┼──────────────────┐
              ▼                ▼                   ▼
        ┌──────────┐   ┌──────────────┐   ┌──────────────┐
        │ APPROVED │   │    DENIED    │   │ PENDING_INFO │
        └──────────┘   └──────────────┘   └──────────────┘

    ┌─────────┐    (any point)
    │ CRASHED │  ← Pod crash + heartbeat expiry
    └────┬────┘
         │ retry (up to 3 attempts)
         └──────────────────────────► PENDING (retry)
              or
         └──────────────────────────► FAILED  (max retries exceeded)
```

---

## 10. Redis Architecture Design

### 10.1 Key Naming Convention

```
All keys use colon-separated namespacing:

Worker Pool (Submission):
  worker:submission:idle                   → Set of idle pod IDs
  worker:submission:busy                   → Set of busy pod IDs
  worker:submission:cooling                → Set of cooling-down pod IDs
  worker:submission:{pod_id}:heartbeat     → String key with 35s TTL (30s interval + 5s buffer)
  worker:submission:{pod_id}:info          → Hash { ip, port, max_slots }

Worker Pool (Tracking):
  worker:tracking:idle
  worker:tracking:busy
  worker:tracking:{pod_id}:heartbeat

Credential Pool:
  credential:submission:{portal_id}:available  → List of credential keys
  credential:submission:{portal_id}:in_use     → Set of in-use credential keys
  credential:submission:{portal_id}:{key}:ttl  → TTL key for credential lease

In-Flight Sessions:
  inflight:submission:{case_ref_id}         → Hash { pod_id, session_id, started_at }
  inflight:submission:{case_ref_id}:hb      → String key with TTL (in-flight heartbeat)

Log Streams:
  stream:{case_ref_id}/logs                 → Redis Stream (XADD/XREAD)
  stream:{case_ref_id}/summary              → Redis Stream (summarized logs)

Payer Cache:
  cache:payer:{payer_id}:portal             → String (portal_id mapping)
```

### 10.2 Worker Pool Lifecycle in Redis

```
Browser-agent pod starts:
  SADD worker:submission:idle {pod_id}
  SET  worker:submission:{pod_id}:heartbeat "alive" EX 35
  HSET worker:submission:{pod_id}:info ip {ip} port {port} max_slots 5

Heartbeat (every 30s from browser-agent):
  SET worker:submission:{pod_id}:heartbeat "alive" EX 35  [refresh TTL]

Control-plane assigns case:
  SMOVE worker:submission:idle worker:submission:busy {pod_id}
  HSET  inflight:submission:{case_ref_id} pod_id {pod_id} session_id {sid} started_at {ts}

Case completes:
  SMOVE worker:submission:busy worker:submission:cooling {pod_id}
  DEL   inflight:submission:{case_ref_id}
  [After 10s cooling period]
  SMOVE worker:submission:cooling worker:submission:idle {pod_id}

Pod crashes (heartbeat key expires):
  [Redis keyspace notification fires]
  → ExpiredEventConsumer receives: "worker:submission:{pod_id}:heartbeat"
  → SREM worker:submission:busy {pod_id}
  → Look up case from inflight:submission:* for this pod_id
  → Trigger crash recovery
```

### 10.3 Redis Streams for Log Streaming

```
browser-agent (during recipe execution):
  XADD stream:{case_ref_id}/logs * \
    level INFO \
    step "fill_patient_name" \
    message "Filled patient first name: John" \
    timestamp 1725350400

Dashboard (real-time log view):
  XREAD COUNT 100 BLOCK 5000 STREAMS stream:{case_ref_id}/logs {last_id}

SummarizationThread (background):
  Every {LOG_SUMMARIZATION_INTERVAL} seconds:
    XRANGE stream:{case_ref_id}/logs - +   (read all entries)
    → Send to Gemini: "Summarize these logs..."
    → XADD stream:{case_ref_id}/summary * summary "..."
    → POST to N8N: SUMMARY_WEBHOOK_URL
```

---

## 11. GCP Pub/Sub Design

### 11.1 Topic & Subscription Configuration

```
Topic #1: prior-auth-agent-requests
  Publisher:     api-server
  Subscriber:    planner
  Subscription:  prior-auth-agent-request-sub-{env}
  Config:
    ack_deadline_seconds: 600
    message_retention_duration: 7 days
    retry_policy:
      minimum_backoff: 10s
      maximum_backoff: 600s
    dead_letter_policy:
      dead_letter_topic: prior-auth-agent-requests-dlq
      max_delivery_attempts: 5

Topic #2: prior-auth-browser-agent-requests
  Publisher:     N8N (triggered by planner)
  Subscriber:    control-plane
  Subscription:  prior-auth-browser-agent-request-sub-{env}
  Config:        (same as Topic #1)

Dead Letter Topics:
  prior-auth-agent-requests-dlq
  prior-auth-browser-agent-requests-dlq
  (Messages here trigger alerts and manual review)
```

### 11.2 Message Schema

```json
// Topic #1 Message (api-server → planner)
{
  "message_id": "uuid-v4",
  "published_at": "2026-09-03T10:00:00Z",
  "data": {
    "batch_id": "BATCH-2026-001",
    "case_ref_id": "CASE-2026-001-001",
    "portal_id": "availity",
    "payer_id": "uuid-of-payer",
    "priority": "normal",
    "retry_count": 0
  }
}

// Topic #2 Message (N8N → control-plane)
{
  "message_id": "uuid-v4",
  "published_at": "2026-09-03T10:00:05Z",
  "data": {
    "case_ref_id": "CASE-2026-001-001",
    "portal_id": "availity",
    "credential_key": "portal/availity/primary",
    "execution_mode": "recipe",
    "patient_data": { ... },
    "clinical_data": { ... }
  }
}
```

---

## 12. N8N Workflow Design

### 12.1 Workflow 1: PA Submission Orchestration

```
Trigger: POST /webhook/preauth
  ├─ Validate payload (case_ref_id, portal_id required)
  ├─ Lookup portal config (which Topic #2 to publish to)
  ├─ Enrich payload (fetch case data from api-server if needed)
  ├─ Publish to GCP Pub/Sub Topic #2
  └─ Return 200 OK

Trigger: POST /webhook/agents (TRIGGER_PRIOR_AUTH_SUBMISSION_AGENT)
  ├─ Validate session is ready
  ├─ POST /api/v1/agents to browser-agent
  │    Body: { case_ref_id, session_id, recipe_mode: true }
  └─ Return 200 OK
```

### 12.2 Workflow 2: HITL Handling

```
Trigger: POST /webhook/hitl
  ├─ Parse case_ref_id, screenshot_url, message
  ├─ Update HITL task status in DB (via api-server endpoint)
  ├─ Send notification to operator:
  │    Option A: Slack message with VNC link
  │    Option B: Email with screenshot
  │    Option C: Dashboard SSE alert
  └─ Return 200 OK

Resolution comes from dashboard:
  → POST /api/v1/hitl/{task_id}/resolve (control-plane)
  → control-plane → POST /api/v1/hitl/resume to browser-agent
```

### 12.3 Workflow 3: MFA Handling

```
Trigger: POST /webhook/mfa
  ├─ Parse case_ref_id, portal_id
  ├─ Look up MFA phone number from credential config
  ├─ Route to ADK chatbot handler (POST planner/api/handle-mfa)
  │    → Chatbot sends OTP request to operator
  │    → Operator replies with OTP
  │    → Chatbot POSTs OTP to browser-agent /api/v1/hitl/mfa/{case_ref_id}
  └─ Return 200 OK
```

### 12.4 Workflow 4: Completion & Status Capture

```
Trigger: POST /webhook/completed
  ├─ Parse case_ref_id, outcome, pa_reference_number
  ├─ Update case status in DB (via api-server)
  ├─ Trigger status capture workflow
  └─ Notify dashboard (SSE alert)

Trigger: POST /webhook/summary
  ├─ Parse case_ref_id, summary_text
  ├─ Store summary in DB (case_logs)
  └─ Return 200 OK

Trigger: POST /webhook/status-capture
  ├─ Covers: completion, crash, HITL timeout
  ├─ Update case status
  └─ Trigger downstream notifications
```

---

## 13. Recipe Engine Design

### 13.1 Recipe YAML Schema

```yaml
# Recipe schema for a payer portal
portal_id: "availity"
portal_name: "Availity"
version: "1.0"
base_url: "https://apps.availity.com"

# Credentials resolved from GCP Secret Manager at runtime
credentials:
  username_field: "username"      # Name in resolver context
  password_field: "password"

steps:
  - name: "navigate_to_login"
    action: navigate
    url: "https://apps.availity.com/login"

  - name: "fill_username"
    action: fill
    selector: "#username"
    value: "{{ credentials.username }}"   # Resolved from Secret Manager

  - name: "fill_password"
    action: fill
    selector: "#password"
    value: "{{ credentials.password }}"

  - name: "click_login"
    action: click
    selector: "#login-button"

  - name: "handle_mfa_if_present"
    action: mfa
    selector: "#otp-input"               # Field to fill OTP into
    condition:                            # Only run if element present
      selector: "#otp-prompt"
      visible: true

  - name: "navigate_to_prior_auth"
    action: navigate
    url: "https://apps.availity.com/prior-auth/new"

  - name: "fill_member_id"
    action: fill
    selector: "#member-id"
    value: "{{ patient.member_id }}"     # Resolved from patient_data

  - name: "fill_procedure_code"
    action: type_and_pick
    selector: "#cpt-search"
    value: "{{ clinical.procedure_codes[0] }}"
    pick_from: ".autocomplete-option"    # Pick from dropdown that appears

  - name: "select_diagnosis"
    action: select_if_mismatch
    selector: "#diagnosis-select"
    value: "{{ clinical.diagnosis_codes[0] }}"
    # Only selects if current value doesn't match

  - name: "handle_each_service_date"
    action: foreach
    items: "{{ clinical.dates_of_service }}"
    steps:
      - action: fill
        selector: ".service-date-input"
        value: "{{ item.date }}"

  - name: "upload_clinical_notes"
    action: upload
    selector: "#file-upload"
    file_url: "{{ clinical.notes_document_url }}"  # GCS URL

  - name: "submit_form"
    action: click
    selector: "#submit-pa-button"

  - name: "extract_pa_number"
    action: extract
    selector: ".confirmation-number"
    store_as: "pa_reference_number"     # Stored in context, returned in completion

  - name: "verify_submission"
    action: assert_visible
    selector: ".success-banner"
    timeout: 10000

  - name: "human_review_if_needed"
    action: hitl
    condition:
      selector: ".manual-review-required"
      visible: true
    message: "Portal requires manual review — please inspect"
```

### 13.2 Value Resolution (`resolve_value`)

```
Template syntax: "{{ source.field_path }}"

Sources:
  credentials.*     → Retrieved from GCP Secret Manager at session start
  patient.*         → From patient_data JSONB field in case
  clinical.*        → From clinical_data JSONB field in case
  context.*         → Runtime context (previously extracted values)
  env.*             → Environment variable (limited, for config only)

Examples:
  "{{ patient.member_id }}"              → patient_data["member_id"]
  "{{ clinical.procedure_codes[0] }}"    → clinical_data["procedure_codes"][0]
  "{{ context.pa_reference_number }}"    → extracted in earlier step
  "{{ credentials.username }}"           → secret from GCP Secret Manager
```

### 13.3 Action Type Reference

| Action | Purpose | Key Parameters |
|---|---|---|
| `navigate` | Go to URL | `url` |
| `fill` | Type text into field | `selector`, `value` |
| `click` | Click an element | `selector` |
| `click_path` | Click nested element by DOM path | `path[]` |
| `type_and_pick` | Type and select from autocomplete | `selector`, `value`, `pick_from` |
| `select_if_mismatch` | Set dropdown only if value differs | `selector`, `value` |
| `select_row` | Select a row in a table | `selector`, `match_column`, `match_value` |
| `foreach` | Loop over a list of items | `items`, `steps[]` |
| `wait` | Wait for element or time | `selector` or `ms` |
| `upload` | Upload a file from GCS URL | `selector`, `file_url` |
| `mfa` | Request OTP from operator | `selector`, `condition?` |
| `hitl` | Request human intervention | `message`, `condition?` |
| `extract` | Extract text value from element | `selector`, `store_as` |
| `assert_visible` | Assert element is visible (fail if not) | `selector`, `timeout` |

---

## 14. Security Design

### 14.1 Authentication & Authorization

```
External API Access:
  → JWT Bearer token (HS256, 60-minute expiry)
  → Obtained via POST /api/v1/auth/login
  → User roles: ADMIN > OPERATOR > VIEWER

Inter-Service Communication:
  → All within GKE cluster (no public exposure)
  → Service-to-service: direct HTTP (no mTLS initially; add later)
  → N8N webhooks: shared secret header (X-N8N-Signature)

GCP Access (from pods):
  → Workload Identity (no long-lived service account keys)
  → Each service has a KSA (Kubernetes Service Account)
  → KSA bound to GSA (Google Service Account) via IAM binding
  → Minimum privilege: each service only gets the GCP APIs it needs
```

### 14.2 Secret Management

```
Secret Storage Hierarchy:
  Level 1: GCP Secret Manager (authoritative source)
    → Portal credentials (username/password per portal per env)
    → Service account files
    → API keys (Capsolver, etc.)

  Level 2: Redis (operational cache, short-lived)
    → Credential pool: references to Secret Manager keys
    → TTL-bounded (credential leases expire)

  Level 3: Process memory (ephemeral)
    → Credentials fetched from Secret Manager at session start
    → Discarded after session ends
    → Never logged

  NOT allowed:
    → Secrets in environment variables (except non-sensitive config)
    → Secrets in code, YAML, or Docker images
    → Secrets in logs or API responses
```

### 14.3 GCP IAM Roles per Service

| Service | GCP Roles Required |
|---|---|
| api-server | `pubsub.publisher`, `secretmanager.viewer`, `cloudtrace.agent` |
| planner | `pubsub.subscriber`, `pubsub.publisher`, `secretmanager.viewer` |
| control-plane | `pubsub.subscriber`, `redis.viewer` |
| browser-agent | `secretmanager.secretAccessor`, `storage.objectViewer`, `aiplatform.user` |
| tracking-agent | `secretmanager.secretAccessor`, `storage.objectViewer` |

### 14.4 Network Security

```
Public endpoints (via GKE Ingress + TLS):
  → api-server: /api/v1/* (requires JWT)
  → frontend: / (requires JWT after login)

Internal only (ClusterIP, no Ingress):
  → control-plane: port 8080
  → browser-agent: port 8081
  → tracking-agent: port 8083
  → planner: port 8001
  → N8N: port 5678

Database access:
  → PostgreSQL: only api-server, planner, control-plane (via common library)
  → Redis: all services (via common redis_layer)

VPN/private network:
  → Cloud SQL (PostgreSQL): VPC peering, private IP only
  → Redis Memorystore: VPC peering, private IP only
```

---

## 15. API Contract Overview

### 15.1 api-server Endpoints

```
Base URL: https://api.autoauth.internal/api/v1

Authentication:
  POST  /auth/register
    Body: { email, password, full_name }
    Returns: { user_id, email }

  POST  /auth/login
    Body: { email, password }
    Returns: { access_token, token_type: "bearer", expires_in: 3600 }

Prior Auth Cases:
  POST  /agentic-platform/prior-auths
    Auth: Bearer token
    Body: {
      batch_id: string,
      portal_id: string,
      cases: [{
        case_ref_id: string,
        patient_data: { first_name, last_name, dob, member_id, ... },
        clinical_data: { procedure_codes[], diagnosis_codes[], npi, ... }
      }]
    }
    Returns: { batch_id, case_count, status: "accepted" }

  GET   /agentic-platform/prior-auths/requests
    Auth: Bearer token
    Query: ?status=&portal_id=&from=&to=&page=&limit=
    Returns: { cases: [...], total, page, limit }

  GET   /agentic-platform/prior-auths/recipes/{portal_id}
    Auth: Internal (no JWT — service-to-service)
    Returns: { portal_id, recipe_yaml: string }

  PATCH /agentic-platform/prior-auths/{case_ref_id}/status
    Auth: Internal
    Body: { status, outcome?, pa_reference_number? }

Dashboard:
  GET   /dashboard/run-volume?from=&to=&group_by=day
  GET   /dashboard/llm-cost?from=&to=&portal_id=
  GET   /dashboard/case-stats

  GET   /alert-sse (SSE stream)
    Streams: { event: "alert", data: { case_ref_id, type, message } }

Portal Management:
  GET   /portal-secret/{portal_id}
  POST  /portal-secret
  PUT   /portal-secret/{portal_id}
  DELETE /portal-secret/{portal_id}

  GET   /payer-prompts/{portal_id}
  PUT   /payer-prompts/{portal_id}

System:
  GET   /health → { status: "ok", db: "ok", redis: "ok" }
```

### 15.2 control-plane Endpoints (Internal)

```
Base URL: http://control-plane:8080/api/v1

Sessions:
  POST   /sessions
    Body: { case_ref_id, portal_id, worker_url }
    Returns: { session_id, pod_ip, vnc_port, web_port }

  DELETE /sessions/{case_ref_id}
    Returns: 204 No Content

  GET    /sessions
    Returns: { workers: [{ pod_id, status, active_sessions }] }

VNC Proxy:
  GET    /sessions/{case_ref_id}/vnc/vnc.html
  GET    /sessions/{case_ref_id}/vnc/{path:path}
  WS     /sessions/{case_ref_id}/vnc/websockify

HITL:
  GET    /hitl/tasks?status=PENDING
  POST   /hitl/{task_id}/resolve  Body: { resolution }
  POST   /hitl/{task_id}/resume

Tracking:
  POST   /tracking/sessions
  DELETE /tracking/sessions/{id}
```

### 15.3 browser-agent Endpoints (Internal)

```
Base URL: http://browser-agent-pod:8081/api/v1

Sessions:
  POST   /sessions
    Body: { case_ref_id, portal_id, display_slot? }
    Returns: { session_id, display_num, vnc_port, web_port }

  DELETE /sessions/{session_id}

  GET    /sessions

Agents:
  POST   /agents
    Body: {
      case_ref_id, session_id,
      execution_mode: "recipe" | "llm",
      portal_id,
      patient_data, clinical_data,
      credentials_key
    }
    Returns: { agent_id, status: "started" }

  GET    /agents/{agent_id}/status
  GET    /agents/{agent_id}/stop
  GET    /agents/{agent_id}/pause
  GET    /agents/{agent_id}/resume

HITL:
  POST   /hitl/mfa/{case_ref_id}
    Body: { otp: string }

  POST   /hitl/resume/{case_ref_id}

Health:
  GET    /health
```

---

## 16. Execution Modes

### 16.1 Mode Selection

```
Feature flag: PLAYWRIGHT_EXECUTION_ENGINE = "yes" | "no"

"yes" → Recipe Mode (default, preferred)
  → Deterministic YAML recipe execution
  → Fast, reliable, no LLM costs per step
  → Requires: recipe YAML exists for portal

"no" → LLM Agent Mode (fallback)
  → Gemini-driven browser-use agent
  → Slower, more expensive, handles novel UIs
  → Used when: no recipe exists, or recipe fails
```

### 16.2 Recipe Mode Architecture

```
POST /api/v1/agents  { execution_mode: "recipe" }
  │
  ▼
recipe_loader.load_recipe(portal_id)
  → Try: GET /api/v1/recipes/{portal_id} from api-server (LRU cache)
  → Fallback: load from app/recipes/{portal_id}.yaml

  ▼
RecipeRunner(recipe, page, context)
  For each step:
    value = resolve_value(step.value, context)
    await execute_action(step.action, step.selector, value, page)
    stream_log(step.name, "completed")

  On success:
    context["pa_reference_number"] = extracted value
    return RecipeResult(success=True, reference=...)

  On failure:
    if retryable: retry step (max 2 per step)
    else: raise RecipeStepError → trigger HITL
```

### 16.3 LLM Agent Mode Architecture

```
POST /api/v1/agents  { execution_mode: "llm" }
  │
  ▼
CustomGoogleChat(model="gemini-2.5-pro")
  → Wraps Vertex AI API with token tracking

browser_use.Agent(
  task=build_task_description(patient_data, clinical_data, portal_id),
  llm=CustomGoogleChat,
  browser=playwright_page,
  controller=customController  # Custom tools for Playwright actions
)

agent.run()  → Gemini decides actions step by step
  Each step: LLM sees page screenshot → decides action → Playwright executes
  Token costs tracked → logged to agentic_platform_request_cost

On completion:
  Extract PA reference from final page
  Return outcome
```

---

## 17. HITL (Human-in-the-Loop) Design

### 17.1 HITL State Machine

```
RecipeRunner pauses
  │
  ├─ Type: HITL (ambiguous/unexpected UI)
  │    → Insert prior_auth_hitl_task (type=HITL, status=PENDING)
  │    → POST to N8N: HITL_WEBHOOK_URL
  │    → threading.Event.wait(timeout=3600)  ← blocks runner thread
  │    → Operator: views VNC, interacts manually, clicks Resume
  │    → threading.Event.set()
  │    → RecipeRunner resumes from SAME step (re-evaluates state)
  │
  └─ Type: MFA (OTP required)
       → POST to N8N: MFA_WEBHOOK_URL
       → asyncio.Queue().get(timeout=300)  ← blocks for OTP
       → ADK chatbot routes OTP to browser-agent
       → asyncio.Queue().put(otp)
       → RecipeRunner fills OTP field, continues
```

### 17.2 HITL Timeout Handling

```
HITL wait timeout (60 minutes):
  → Update HITL task status: EXPIRED
  → Update case status: FAILED
  → POST to N8N: STATUS_CAPTURE_WEBHOOK_URL { status: "HITL_TIMEOUT" }
  → Release browser session

MFA wait timeout (5 minutes):
  → Retry MFA request (up to 3 times)
  → After 3 failures: escalate to HITL
```

---

## 18. Deployment Architecture

### 18.1 GKE Cluster Design

```
GKE Cluster: autoauth-cluster
  Region: us-central1
  Version: 1.29+

Node Pools:
  ┌─────────────────────────────────────────────────────────────┐
  │  default-pool                                               │
  │  Machine: n2-standard-4  (4 vCPU, 16GB RAM)                │
  │  Nodes: 2–4 (autoscale)                                     │
  │  Hosts: api-server, planner, control-plane, frontend, N8N  │
  └─────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────┐
  │  browser-agent-pool                                         │
  │  Machine: n2-standard-8  (8 vCPU, 32GB RAM)                │
  │  Nodes: 1–6 (KEDA autoscale based on Pub/Sub depth)        │
  │  Hosts: browser-agent pods, tracking-agent pods            │
  │  Taint: dedicated=browser-agent:NoSchedule                 │
  └─────────────────────────────────────────────────────────────┘

Namespace: agentic-app

Ingress:
  → GKE Ingress (Google-managed load balancer)
  → TLS via Google-managed certificates
  → Routes: /api/* → api-server, /* → frontend
```

### 18.2 KEDA Autoscaling

```yaml
# ScaledObject for browser-agent
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: browser-agent-scaler
  namespace: agentic-app
spec:
  scaleTargetRef:
    name: browser-agent
  minReplicaCount: 1
  maxReplicaCount: 6
  cooldownPeriod: 300
  triggers:
    - type: gcp-pub-sub
      metadata:
        subscriptionName: prior-auth-browser-agent-request-sub-prod
        value: "5"   # Scale up when >5 messages pending per pod
```

### 18.3 Resource Limits

| Service | CPU Request | CPU Limit | Memory Request | Memory Limit |
|---|---|---|---|---|
| api-server | 250m | 1000m | 256Mi | 512Mi |
| planner | 250m | 500m | 256Mi | 512Mi |
| control-plane | 250m | 500m | 256Mi | 512Mi |
| browser-agent | 2000m | 4000m | 4Gi | 8Gi |
| tracking-agent | 1000m | 2000m | 2Gi | 4Gi |
| frontend | 100m | 200m | 128Mi | 256Mi |
| N8N | 500m | 1000m | 512Mi | 1Gi |

### 18.4 Environment Strategy

| Environment | Purpose | Notes |
|---|---|---|
| `local` | Developer machines | docker-compose, local PostgreSQL + Redis |
| `dev` | Integration testing | GKE dev cluster, real GCP services (dev project) |
| `uat` | UAT with clinical team | GKE UAT cluster, sandboxed payer portals |
| `prod` | Production | GKE prod cluster, real payer portals |

---

## 19. Open Questions & Decisions Needed

| # | Question | Impact | Decision Needed By |
|---|---|---|---|
| OQ-01 | How many payer portals for MVP? | Recipe development scope | Week 1 |
| OQ-02 | Is N8N required or can we simplify to direct HTTP calls? | Architecture complexity | Week 1 |
| OQ-03 | What is the SLA for PA submission (how fast must each case complete)? | Browser session timeout config | Week 1 |
| OQ-04 | Does tracking-agent need LLM mode or recipe mode only? | tracking-agent scope | Week 2 |
| OQ-05 | HA for N8N (single PVC vs. external DB for N8N)? | N8N reliability | Week 2 |
| OQ-06 | mTLS between services (zero-trust internal network)? | Security posture | Week 2 |
| OQ-07 | Should recipe failures auto-fallback to LLM mode? | browser-agent logic | Week 2 |
| OQ-08 | How long should credentials be cached in Redis? | Credential TTL config | Week 2 |
| OQ-09 | HITL timeout — 60 minutes ok, or configurable per payer? | HITL config | Week 2 |
| OQ-10 | PII/PHI handling — do logs need to be masked? | Compliance requirement | Week 1 (URGENT) |

---

*Document Status: DRAFT — Awaiting review and sign-off before Phase 2 begins.*
*Next Document: [02_Infrastructure_and_Security_Design.md](02_Infrastructure_and_Security_Design.md)*
