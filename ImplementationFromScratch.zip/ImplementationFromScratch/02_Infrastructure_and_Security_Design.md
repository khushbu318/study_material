# AutoAuth Agent — Infrastructure & Security Design
**Phase 1 | Weeks 3–4**
**Author:** Niranjan Sai Koppisetti
**Date:** September 17, 2026
**Version:** 1.0
**Prerequisite:** [01_Requirements_and_System_Design.md](01_Requirements_and_System_Design.md)

---

## Table of Contents

1. [Infrastructure Overview](#1-infrastructure-overview)
2. [GCP Project Structure](#2-gcp-project-structure)
3. [VPC & Network Design](#3-vpc--network-design)
4. [GKE Cluster Design](#4-gke-cluster-design)
5. [Cloud SQL (PostgreSQL) Design](#5-cloud-sql-postgresql-design)
6. [Redis (Memorystore) Design](#6-redis-memorystore-design)
7. [GCP Pub/Sub Design](#7-gcp-pubsub-design)
8. [GCP Secret Manager Design](#8-gcp-secret-manager-design)
9. [GCP Cloud Storage Design](#9-gcp-cloud-storage-design)
10. [Vertex AI / Gemini Setup](#10-vertex-ai--gemini-setup)
11. [Workload Identity Design](#11-workload-identity-design)
12. [GCP IAM Design](#12-gcp-iam-design)
13. [KEDA Autoscaling Design](#13-keda-autoscaling-design)
14. [N8N Infrastructure Design](#14-n8n-infrastructure-design)
15. [CI/CD Pipeline Design](#15-cicd-pipeline-design)
16. [Kubernetes Manifest Design](#16-kubernetes-manifest-design)
17. [TLS & Ingress Design](#17-tls--ingress-design)
18. [Monitoring & Alerting Design](#18-monitoring--alerting-design)
19. [Security Hardening Checklist](#19-security-hardening-checklist)
20. [Local Development Environment](#20-local-development-environment)
21. [Environment Promotion Strategy](#21-environment-promotion-strategy)
22. [Disaster Recovery Design](#22-disaster-recovery-design)
23. [Step-by-Step Infrastructure Setup Runbook](#23-step-by-step-infrastructure-setup-runbook)

---

## 1. Infrastructure Overview

### 1.1 Full Infrastructure Diagram

```
┌───────────────────────────────────────────────────────────────────────────────────────┐
│                              GCP PROJECT: autoauth-prod                               │
│                                                                                       │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐  │
│  │                        VPC: autoauth-vpc  (10.0.0.0/16)                        │  │
│  │                                                                                 │  │
│  │  ┌──────────────────────────────────────────────────────────────────────────┐  │  │
│  │  │              SUBNET: gke-subnet  (10.0.1.0/24)                          │  │  │
│  │  │              Secondary: pods 10.1.0.0/16, services 10.2.0.0/20          │  │  │
│  │  │                                                                          │  │  │
│  │  │  ┌──────────────────────────────────────────────────────────────────┐   │  │  │
│  │  │  │            GKE CLUSTER: autoauth-cluster                        │   │  │  │
│  │  │  │            Zone: us-central1-a,b,c (regional)                   │   │  │  │
│  │  │  │                                                                  │   │  │  │
│  │  │  │  ┌─────────────────────┐  ┌──────────────────────────────────┐  │   │  │  │
│  │  │  │  │  default-pool       │  │  browser-agent-pool              │  │   │  │  │
│  │  │  │  │  n2-standard-4      │  │  n2-standard-8                   │  │   │  │  │
│  │  │  │  │  2–4 nodes          │  │  1–6 nodes (KEDA)                │  │   │  │  │
│  │  │  │  │                     │  │  Taint: browser-agent            │  │   │  │  │
│  │  │  │  │  Pods:              │  │                                  │  │   │  │  │
│  │  │  │  │  - api-server       │  │  Pods:                           │  │   │  │  │
│  │  │  │  │  - planner          │  │  - browser-agent (1–6)           │  │   │  │  │
│  │  │  │  │  - control-plane    │  │  - tracking-agent (1–3)          │  │   │  │  │
│  │  │  │  │  - frontend         │  │                                  │  │   │  │  │
│  │  │  │  │  - n8n              │  │                                  │  │   │  │  │
│  │  │  │  └─────────────────────┘  └──────────────────────────────────┘  │   │  │  │
│  │  │  │                                                                  │   │  │  │
│  │  │  │  Namespace: agentic-app                                         │   │  │  │
│  │  │  │  Ingress: GKE Ingress + Google-managed TLS cert                 │   │  │  │
│  │  │  └──────────────────────────────────────────────────────────────────┘   │  │  │
│  │  └──────────────────────────────────────────────────────────────────────────┘  │  │
│  │                                                                                 │  │
│  │  ┌──────────────────────────────┐   ┌──────────────────────────────────────┐  │  │
│  │  │  SUBNET: data-subnet         │   │  SUBNET: services-subnet             │  │  │
│  │  │  (10.0.2.0/24)               │   │  (10.0.3.0/24)                       │  │  │
│  │  │                              │   │                                      │  │  │
│  │  │  Cloud SQL (PostgreSQL)      │   │  Memorystore (Redis)                 │  │  │
│  │  │  Private IP: 10.0.2.5        │   │  Private IP: 10.0.3.5                │  │  │
│  │  │  VPC Peering: servicenet     │   │  VPC Peering: servicenet             │  │  │
│  │  └──────────────────────────────┘   └──────────────────────────────────────┘  │  │
│  └─────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐ │
│  │  PUB/SUB     │  │  SECRET MGR  │  │  CLOUD       │  │  ARTIFACT REGISTRY       │ │
│  │  2 topics    │  │  Portal creds│  │  STORAGE     │  │  Docker images           │ │
│  │  2 DLQ topics│  │  API keys    │  │  PA documents│  │  autoauth-repo           │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────────────────┘ │
│                                                                                       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐ │
│  │  VERTEX AI   │  │  CLOUD BUILD │  │  CLOUD       │  │  CLOUD LOGGING +         │ │
│  │  Gemini APIs │  │  CI/CD       │  │  MONITORING  │  │  ERROR REPORTING         │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────────────────┘

EXTERNAL:
  Internet → Cloud Load Balancer (HTTPS) → GKE Ingress → api-server / frontend
  Payer Portals ← browser-agent (outbound HTTPS, via Cloud NAT)
  Capsolver API ← browser-agent (outbound HTTPS)
```

---

## 2. GCP Project Structure

### 2.1 Project Layout

```
Organization: ikshealth.com
  │
  ├── Project: autoauth-dev      (Development / Integration testing)
  ├── Project: autoauth-uat      (UAT / Staging)
  └── Project: autoauth-prod     (Production)
```

### 2.2 Naming Conventions

```
All GCP resources follow this naming pattern:
  {service}-{resource-type}-{environment}

Examples:
  autoauth-cluster-prod           ← GKE cluster
  autoauth-vpc-prod               ← VPC
  autoauth-db-prod                ← Cloud SQL instance
  autoauth-redis-prod             ← Memorystore instance
  autoauth-pubsub-pa-requests-prod  ← Pub/Sub topic
  autoauth-bucket-pa-docs-prod    ← Cloud Storage bucket
  autoauth-repo-prod              ← Artifact Registry repo
```

### 2.3 GCP APIs to Enable (per project)

```bash
# Run once per project
gcloud services enable \
  container.googleapis.com \           # GKE
  sqladmin.googleapis.com \            # Cloud SQL
  redis.googleapis.com \               # Memorystore
  pubsub.googleapis.com \              # Pub/Sub
  secretmanager.googleapis.com \       # Secret Manager
  storage.googleapis.com \             # Cloud Storage
  artifactregistry.googleapis.com \    # Artifact Registry
  cloudbuild.googleapis.com \          # Cloud Build
  cloudtrace.googleapis.com \          # Cloud Trace
  monitoring.googleapis.com \          # Cloud Monitoring
  logging.googleapis.com \             # Cloud Logging
  aiplatform.googleapis.com \          # Vertex AI (Gemini)
  iam.googleapis.com \                 # IAM
  iamcredentials.googleapis.com \      # Workload Identity
  servicenetworking.googleapis.com     # VPC Peering (for Cloud SQL/Redis)
```

---

## 3. VPC & Network Design

### 3.1 VPC Configuration

```
VPC Name:     autoauth-vpc-{env}
Region:       us-central1
Mode:         Custom subnet mode
MTU:          1460

Subnets:
┌──────────────────┬──────────────┬─────────────────────────────────────────────┐
│ Subnet Name      │ CIDR         │ Purpose                                     │
├──────────────────┼──────────────┼─────────────────────────────────────────────┤
│ gke-subnet       │ 10.0.1.0/24  │ GKE nodes                                   │
│   pods-range     │ 10.1.0.0/16  │ GKE pods (secondary range)                  │
│   services-range │ 10.2.0.0/20  │ GKE services (secondary range)              │
│ data-subnet      │ 10.0.2.0/24  │ Cloud SQL private IP                        │
│ services-subnet  │ 10.0.3.0/24  │ Memorystore private IP                      │
└──────────────────┴──────────────┴─────────────────────────────────────────────┘
```

### 3.2 Firewall Rules

```
Rule Name                           Direction  Priority  Source         Dest/Ports
─────────────────────────────────────────────────────────────────────────────────
allow-gke-internal                  INGRESS    1000      10.0.0.0/8    all
allow-lb-health-checks              INGRESS    1000      130.211.0.0/22, 35.191.0.0/16  tcp:8000,8080,80
allow-ssh-iap                       INGRESS    1000      35.235.240.0/20  tcp:22
deny-all-ingress                    INGRESS    65534     0.0.0.0/0     all
allow-https-egress                  EGRESS     1000      all           tcp:443 (payer portals, GCP APIs)
allow-internal-egress               EGRESS     1000      10.0.0.0/8    all
deny-all-egress                     EGRESS     65534     0.0.0.0/0     all
```

### 3.3 Cloud NAT (for browser-agent outbound traffic)

```
NAT Gateway:     autoauth-nat-{env}
Router:          autoauth-router-{env}
Region:          us-central1
NAT IP:          Static external IP (whitelisted by payer portals)
Subnet:          gke-subnet (browser-agent-pool nodes only)

Purpose:
  → browser-agent pods need outbound internet access to reach payer portals
  → Uses Cloud NAT so all traffic appears from a fixed IP
  → Payer portals can whitelist this IP for access control
```

### 3.4 VPC Peering for Managed Services

```
Cloud SQL (PostgreSQL):
  → servicenetworking.googleapis.com VPC peering
  → Private IP: 10.0.2.5
  → No public IP on Cloud SQL instance

Memorystore (Redis):
  → VPC peering to autoauth-vpc
  → Private IP: 10.0.3.5
  → No public access
  → AUTH enabled + in-transit encryption
```

---

## 4. GKE Cluster Design

### 4.1 Cluster Configuration

```yaml
# Cluster: autoauth-cluster-prod
Cluster:
  name: autoauth-cluster-prod
  location: us-central1          # Regional (3-zone HA)
  release_channel: REGULAR       # Auto-upgraded
  version: 1.29+

  # Networking
  network: autoauth-vpc-prod
  subnetwork: gke-subnet
  cluster_secondary_range: pods-range
  services_secondary_range: services-range
  enable_private_nodes: true     # Nodes have no public IP
  enable_private_endpoint: false # Control plane accessible from authorized networks
  master_authorized_networks:
    - cidr: {VPN_CIDR}           # Office/VPN IP range only

  # Security
  workload_identity_pool: autoauth-prod.svc.id.goog
  enable_shielded_nodes: true
  enable_binary_authorization: true
  network_policy: CALICO

  # Features
  enable_vertical_pod_autoscaling: true
  enable_cluster_autoscaler: true
  logging_service: logging.googleapis.com/kubernetes
  monitoring_service: monitoring.googleapis.com/kubernetes
```

### 4.2 Node Pool Configurations

```yaml
# Node Pool 1: default-pool (system services)
nodePool:
  name: default-pool
  machine_type: n2-standard-4    # 4 vCPU, 16 GB RAM
  disk_size_gb: 100
  disk_type: pd-ssd
  initial_node_count: 2
  autoscaling:
    min_node_count: 2
    max_node_count: 4
  management:
    auto_repair: true
    auto_upgrade: true
  node_config:
    service_account: autoauth-node-sa@autoauth-prod.iam.gserviceaccount.com
    oauth_scopes:
      - https://www.googleapis.com/auth/cloud-platform
    shielded_instance_config:
      enable_secure_boot: true
      enable_integrity_monitoring: true
    labels:
      pool: default
    tags:
      - gke-node
      - default-pool

# Node Pool 2: browser-agent-pool (browser automation)
nodePool:
  name: browser-agent-pool
  machine_type: n2-standard-8    # 8 vCPU, 32 GB RAM
  disk_size_gb: 200              # Larger disk for browser profiles/screenshots
  disk_type: pd-ssd
  initial_node_count: 1
  autoscaling:
    min_node_count: 1
    max_node_count: 6
  management:
    auto_repair: true
    auto_upgrade: true
  node_config:
    taints:
      - key: dedicated
        value: browser-agent
        effect: NO_SCHEDULE        # Only browser-agent pods scheduled here
    labels:
      pool: browser-agent
    tags:
      - gke-node
      - browser-agent-pool
```

### 4.3 Namespace Design

```yaml
# Namespace: agentic-app
apiVersion: v1
kind: Namespace
metadata:
  name: agentic-app
  labels:
    environment: prod
    team: autoauth
  annotations:
    # Resource quotas applied at namespace level
    kubectl.kubernetes.io/last-applied-configuration: ""

---
# Resource Quota for namespace
apiVersion: v1
kind: ResourceQuota
metadata:
  name: agentic-app-quota
  namespace: agentic-app
spec:
  hard:
    requests.cpu: "20"
    requests.memory: 60Gi
    limits.cpu: "40"
    limits.memory: 120Gi
    pods: "50"
    services: "20"
    persistentvolumeclaims: "10"

---
# Default LimitRange for containers
apiVersion: v1
kind: LimitRange
metadata:
  name: agentic-app-limits
  namespace: agentic-app
spec:
  limits:
    - type: Container
      default:
        cpu: 500m
        memory: 512Mi
      defaultRequest:
        cpu: 100m
        memory: 128Mi
```

---

## 5. Cloud SQL (PostgreSQL) Design

### 5.1 Instance Configuration

```yaml
Instance:
  name: autoauth-db-prod
  database_version: POSTGRES_16
  region: us-central1
  tier: db-custom-4-16384       # 4 vCPU, 16 GB RAM
  availability_type: REGIONAL   # HA with automatic failover
  disk_type: PD_SSD
  disk_size: 100 GB
  disk_autoresize: true
  disk_autoresize_limit: 500 GB

  # Connectivity
  ip_configuration:
    ipv4_enabled: false          # No public IP
    private_network: autoauth-vpc-prod
    require_ssl: true

  # Backups
  backup_configuration:
    enabled: true
    start_time: "02:00"          # 2 AM UTC daily backup
    location: us
    point_in_time_recovery: true
    transaction_log_retention_days: 7
    retained_backups: 30

  # Maintenance
  maintenance_window:
    day: 7                       # Sunday
    hour: 3                      # 3 AM UTC
    update_track: stable

  # Flags
  database_flags:
    - name: max_connections
      value: "200"
    - name: shared_preload_libraries
      value: pg_stat_statements
    - name: log_min_duration_statement
      value: "1000"              # Log queries > 1 second
    - name: log_connections
      value: "on"
```

### 5.2 Database & User Setup

```sql
-- Run after instance creation

-- Create database
CREATE DATABASE autoauth
  WITH ENCODING = 'UTF8'
  LC_COLLATE = 'en_US.UTF-8'
  LC_CTYPE = 'en_US.UTF-8';

-- Create schema
\c autoauth
CREATE SCHEMA iks_schema;

-- Create application user (least privilege)
CREATE USER autoauth_app WITH PASSWORD '{generated_password}';
GRANT CONNECT ON DATABASE autoauth TO autoauth_app;
GRANT USAGE ON SCHEMA iks_schema TO autoauth_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA iks_schema TO autoauth_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA iks_schema TO autoauth_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA iks_schema
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO autoauth_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA iks_schema
  GRANT USAGE, SELECT ON SEQUENCES TO autoauth_app;

-- Create migration user (for Alembic, more privileges)
CREATE USER autoauth_migrations WITH PASSWORD '{generated_password}';
GRANT CONNECT ON DATABASE autoauth TO autoauth_migrations;
GRANT CREATE ON SCHEMA iks_schema TO autoauth_migrations;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA iks_schema TO autoauth_migrations;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA iks_schema TO autoauth_migrations;

-- Create read-only user (for analytics/dashboards)
CREATE USER autoauth_readonly WITH PASSWORD '{generated_password}';
GRANT CONNECT ON DATABASE autoauth TO autoauth_readonly;
GRANT USAGE ON SCHEMA iks_schema TO autoauth_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA iks_schema TO autoauth_readonly;

-- Enable pg_stat_statements for query monitoring
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
```

### 5.3 Connection Pooling Strategy

```
Services → SQLAlchemy connection pool → Cloud SQL Auth Proxy → Cloud SQL

Per service pool config (SQLAlchemy):
  pool_size=5          # Permanent connections kept open
  max_overflow=10      # Extra connections allowed under load
  pool_timeout=30      # Wait up to 30s for a connection
  pool_recycle=1800    # Recycle connections every 30 min
  pool_pre_ping=True   # Verify connection before use

Total max connections per service:
  api-server:     15 (5+10) × replicas
  planner:        10 (3+7)  × replicas
  control-plane:  10 (3+7)  × replicas

Max connections to DB: 200 (Cloud SQL limit for this tier)
Safety margin:  200 - (15×2 + 10×2 + 10×2) = 130 reserved for bursts

Cloud SQL Auth Proxy:
  → Runs as sidecar container in each pod (OR as separate DaemonSet)
  → Handles TLS, IAM auth (no password needed in app — uses Workload Identity)
  → Listens on 127.0.0.1:5432 inside pod
```

### 5.4 Alembic Migration Strategy

```
common/db_layer/alembic/
  alembic.ini
  env.py
  versions/
    0001_initial_schema.py
    0002_add_hitl_tasks.py
    0003_add_cost_tracking.py
    ...

Migration workflow:
  1. Developer creates migration: alembic revision --autogenerate -m "description"
  2. Review generated migration file
  3. Run in dev: alembic upgrade head
  4. CI validates: alembic check (no pending migrations)
  5. Deploy: Kubernetes Job runs migration before new pods start

Kubernetes migration Job (runs before deployment):
  apiVersion: batch/v1
  kind: Job
  metadata:
    name: db-migration-{version}
  spec:
    template:
      spec:
        containers:
          - name: migrate
            image: autoauth-api-server:{version}
            command: ["alembic", "upgrade", "head"]
        restartPolicy: Never
```

---

## 6. Redis (Memorystore) Design

### 6.1 Instance Configuration

```yaml
Instance:
  name: autoauth-redis-prod
  tier: STANDARD_HA             # High availability (primary + replica)
  region: us-central1
  memory_size_gb: 4
  redis_version: REDIS_7_0
  display_name: AutoAuth Redis

  # Connectivity
  authorized_network: autoauth-vpc-prod
  connect_mode: PRIVATE_SERVICE_ACCESS
  # Resulting IP: 10.0.3.5

  # Security
  auth_enabled: true             # AUTH required
  transit_encryption_mode: SERVER_AUTHENTICATION  # TLS

  # Persistence
  persistence_config:
    persistence_mode: RDB       # Snapshot-based persistence
    rdb_snapshot_period: ONE_HOUR

  # Maintenance
  maintenance_policy:
    weekly_maintenance_window:
      day: SUNDAY
      start_time: "03:00"       # 3 AM UTC
```

### 6.2 Redis Configuration Requirements

```
Required Redis config (set via redis.conf or instance flags):
  notify-keyspace-events "KEx"   # Enable keyspace expiry notifications
                                 # K = keyspace events
                                 # E = keyevent events
                                 # x = expired events
  maxmemory-policy allkeys-lru   # Evict least-recently-used when full
  maxmemory 3gb                  # Leave 1GB headroom
  save 3600 1                    # RDB snapshot: 1 change in 3600s
  save 300 10                    # RDB snapshot: 10 changes in 300s
  tcp-keepalive 300

Connection from pods:
  Host: 10.0.3.5 (private IP)
  Port: 6379
  TLS: enabled
  AUTH: password from GCP Secret Manager
  DB: 0 (default)
```

### 6.3 Redis Memory Capacity Planning

```
Key categories and estimated sizes:

Worker pool sets (per env):
  IDLE set:     ~6 entries × 50 bytes = ~300 bytes
  BUSY set:     ~6 entries × 50 bytes = ~300 bytes
  COOLING set:  ~6 entries × 50 bytes = ~300 bytes
  Worker info:  ~6 entries × 200 bytes = ~1.2 KB

Heartbeat keys:
  ~12 keys (6 submission + 6 tracking) × 50 bytes = ~600 bytes
  TTL: 35 seconds → constantly refreshed

In-flight sessions:
  ~30 concurrent × 300 bytes = ~9 KB

Credential pool:
  ~50 portals × 10 credentials × 100 bytes = ~50 KB

Log streams (Redis Streams):
  ~30 active cases × 1000 log entries × 200 bytes = ~6 MB
  Streams trimmed to last 10,000 entries per case (MAXLEN)

Payer cache:
  ~200 payers × 100 bytes = ~20 KB

Summary streams:
  ~30 active × 3 summaries × 2 KB = ~180 KB

TOTAL ESTIMATED: ~10 MB active data
4 GB instance provides massive headroom for bursts and stream retention.
```

---

## 7. GCP Pub/Sub Design

### 7.1 Topic & Subscription Details

```
Project: autoauth-prod

Topics:
┌────────────────────────────────────────────┬──────────────────────────────────────┐
│ Topic Name                                 │ Publisher                            │
├────────────────────────────────────────────┼──────────────────────────────────────┤
│ prior-auth-agent-requests                  │ api-server                           │
│ prior-auth-browser-agent-requests          │ N8N (via planner trigger)            │
│ prior-auth-agent-requests-dlq              │ Pub/Sub (dead letter)                │
│ prior-auth-browser-agent-requests-dlq      │ Pub/Sub (dead letter)                │
└────────────────────────────────────────────┴──────────────────────────────────────┘

Subscriptions:
┌──────────────────────────────────────────────────────┬────────────────────────────┐
│ Subscription Name                                    │ Subscriber                 │
├──────────────────────────────────────────────────────┼────────────────────────────┤
│ prior-auth-agent-request-sub-prod                    │ planner                    │
│ prior-auth-browser-agent-request-sub-prod            │ control-plane              │
│ prior-auth-agent-requests-dlq-sub                    │ Alert/manual review        │
│ prior-auth-browser-agent-requests-dlq-sub            │ Alert/manual review        │
└──────────────────────────────────────────────────────┴────────────────────────────┘
```

### 7.2 Subscription Configuration

```yaml
# For both main subscriptions
Subscription config:
  ack_deadline_seconds: 600          # 10 minutes to process a message
  message_retention_duration: 604800s  # 7 days
  retain_acked_messages: false
  expiration_policy: never            # Don't auto-delete subscription

  retry_policy:
    minimum_backoff: 10s
    maximum_backoff: 600s

  dead_letter_policy:
    dead_letter_topic: {topic}-dlq
    max_delivery_attempts: 5          # After 5 failures → DLQ

  enable_message_ordering: false      # Order not guaranteed (parallel processing)

  # For KEDA scaling (control-plane subscription)
  # KEDA reads this subscription's undelivered message count
```

### 7.3 Pub/Sub IAM

```
Topic: prior-auth-agent-requests
  Publisher: api-server-gsa@autoauth-prod.iam.gserviceaccount.com
    Role: roles/pubsub.publisher

Subscription: prior-auth-agent-request-sub-prod
  Subscriber: planner-gsa@autoauth-prod.iam.gserviceaccount.com
    Role: roles/pubsub.subscriber

Topic: prior-auth-browser-agent-requests
  Publisher: n8n-gsa@autoauth-prod.iam.gserviceaccount.com
    Role: roles/pubsub.publisher

Subscription: prior-auth-browser-agent-request-sub-prod
  Subscriber: control-plane-gsa@autoauth-prod.iam.gserviceaccount.com
    Role: roles/pubsub.subscriber

KEDA TriggerAuth (for ScaledObject):
  keda-gsa@autoauth-prod.iam.gserviceaccount.com
    Role: roles/monitoring.viewer   (reads Pub/Sub metrics)
    Role: roles/pubsub.viewer       (reads subscription metadata)
```

---

## 8. GCP Secret Manager Design

### 8.1 Secret Naming Convention

```
Naming pattern:
  autoauth/{environment}/{category}/{name}

Examples:
  autoauth/prod/portal/availity-username
  autoauth/prod/portal/availity-password
  autoauth/prod/portal/navinet-username
  autoauth/prod/portal/navinet-password
  autoauth/prod/portal/carecore-username
  autoauth/prod/portal/carecore-password
  autoauth/prod/portal/availity-mfa-service-account
  autoauth/prod/db/app-password
  autoauth/prod/db/migration-password
  autoauth/prod/redis/auth-password
  autoauth/prod/app/jwt-secret
  autoauth/prod/app/capsolver-api-key
  autoauth/prod/app/n8n-webhook-secret
  autoauth/prod/app/gemini-api-key
```

### 8.2 Secret Access Matrix

```
Secret Category          │ api-server │ planner │ control-plane │ browser-agent │ tracking-agent
─────────────────────────┼────────────┼─────────┼───────────────┼───────────────┼───────────────
portal/*/username        │            │         │               │ READ          │ READ
portal/*/password        │            │         │               │ READ          │ READ
portal/*/mfa-sa          │            │         │               │ READ          │
db/app-password          │ READ       │ READ    │ READ          │               │
db/migration-password    │ READ (job) │         │               │               │
redis/auth-password      │ READ       │ READ    │ READ          │ READ          │ READ
app/jwt-secret           │ READ       │         │               │               │
app/capsolver-api-key    │            │         │               │ READ          │ READ
app/n8n-webhook-secret   │ READ       │ READ    │ READ          │ READ          │
app/gemini-api-key       │            │ READ    │               │ READ          │
```

### 8.3 Secret Injection Strategy

```
Method: Kubernetes Secrets Store CSI Driver
  → Mounts GCP secrets as files inside pod
  → No secrets in environment variables
  → Secrets rotated without pod restart (file-based)

SecretProviderClass per service:
  apiVersion: secrets-store.csi.x-k8s.io/v1
  kind: SecretProviderClass
  metadata:
    name: browser-agent-secrets
    namespace: agentic-app
  spec:
    provider: gcp
    parameters:
      secrets: |
        - resourceName: "projects/autoauth-prod/secrets/autoauth-prod-redis-auth-password/versions/latest"
          path: "redis-password"
        - resourceName: "projects/autoauth-prod/secrets/autoauth-prod-capsolver-api-key/versions/latest"
          path: "capsolver-api-key"
        - resourceName: "projects/autoauth-prod/secrets/autoauth-prod-app-n8n-webhook-secret/versions/latest"
          path: "n8n-secret"

Mounted in pod at: /var/secrets/{path}
Application reads: open("/var/secrets/redis-password").read()
```

### 8.4 Secret Rotation Policy

```
Portal credentials (username/password):
  Rotation: Manual (when portal password changed)
  Process: Update secret version in Secret Manager → pods pick up on next session start

JWT secret:
  Rotation: Every 90 days
  Process: Add new version → update app config → old tokens expire naturally

Database passwords:
  Rotation: Every 180 days via Cloud SQL rotation
  Process: Cloud SQL automated password rotation → update Secret Manager

API keys (Capsolver, Gemini):
  Rotation: As required by provider
```

---

## 9. GCP Cloud Storage Design

### 9.1 Bucket Configuration

```yaml
Bucket: autoauth-pa-documents-prod
  Location: us-central1
  Storage class: STANDARD
  Versioning: enabled
  Uniform bucket-level access: true
  Public access prevention: enforced

  # Lifecycle rules
  Lifecycle:
    - condition:
        age: 90                    # Delete files older than 90 days
      action: Delete
    - condition:
        num_newer_versions: 3      # Keep only 3 versions
      action: Delete

  # CORS (for direct browser downloads if needed)
  CORS:
    origin: ["https://autoauth.ikshealth.com"]
    method: ["GET"]
    max_age_seconds: 3600

Object naming convention:
  pa-documents/{case_ref_id}/{filename}
  pa-screenshots/{case_ref_id}/{timestamp}_{step_name}.png
```

### 9.2 Access Control

```
Write access:
  → Clinical staff upload documents BEFORE submitting PA request
  → Upload via Signed URL (api-server generates, 15-minute expiry)
  → api-server-gsa: roles/storage.objectCreator

Read access:
  → browser-agent downloads documents to upload to payer portal
  → browser-agent-gsa: roles/storage.objectViewer
  → Tracking-agent: roles/storage.objectViewer

No public access:
  → All access via service accounts or signed URLs only
```

---

## 10. Vertex AI / Gemini Setup

### 10.1 API Access Configuration

```yaml
Project: autoauth-prod
Region: us-central1              # Gemini API endpoint

Enabled APIs:
  - aiplatform.googleapis.com

Model: gemini-2.5-pro            # Primary model
Fallback: gemini-1.5-flash       # For log summarization (cheaper)

IAM:
  browser-agent-gsa:
    roles/aiplatform.user        # Can call Vertex AI prediction APIs

Usage limits (set via GCP quotas):
  Requests per minute: 60        # Per project limit
  Tokens per minute: 1,000,000

Cost controls:
  Cloud Billing budget alert: $500/month threshold
  → Alert to: niranjansai.k@ikshealth.com
  → Auto-throttle via quota if budget exceeded (manual decision)
```

### 10.2 Model Usage Per Service

```
Service             Model                    Use Case
──────────────────────────────────────────────────────────────────
browser-agent       gemini-2.5-pro          LLM Agent Mode (PLAYWRIGHT_EXECUTION_ENGINE=no)
browser-agent       gemini-1.5-flash        Log summarization (SummarizationThread)
browser-agent       gemini-2.5-pro          Page content extraction (extract action)
planner             gemini-2.5-pro          ADK chatbot (MFA resolution)
api-server          (no direct LLM calls)
control-plane       (no direct LLM calls)
tracking-agent      gemini-2.5-pro          Status extraction from portal page
```

---

## 11. Workload Identity Design

### 11.1 Overview

```
Workload Identity eliminates the need for service account key files on pods.

Flow:
  Pod (K8s Service Account: browser-agent-ksa)
    → Requests token from metadata server
    → Metadata server exchanges K8s SA token for Google access token
    → Pod uses Google access token to call GCP APIs
    → No JSON key file needed

Binding format:
  KSA: {namespace}/{ksa-name}
  GSA: {gsa-name}@{project}.iam.gserviceaccount.com
  Binding: roles/iam.workloadIdentityUser on GSA
```

### 11.2 Service Account Mapping

```
For each service, create:
  1. Google Service Account (GSA) - GCP identity
  2. Kubernetes Service Account (KSA) - K8s identity
  3. IAM binding: KSA can impersonate GSA

┌─────────────────┬──────────────────────────────┬────────────────────────────────────────┐
│ Service         │ KSA (namespace/name)         │ GSA                                    │
├─────────────────┼──────────────────────────────┼────────────────────────────────────────┤
│ api-server      │ agentic-app/api-server-ksa   │ api-server-gsa@autoauth-prod.iam.g...  │
│ planner         │ agentic-app/planner-ksa      │ planner-gsa@autoauth-prod.iam.g...     │
│ control-plane   │ agentic-app/control-plane-ksa│ control-plane-gsa@autoauth-prod.iam.g. │
│ browser-agent   │ agentic-app/browser-agent-ksa│ browser-agent-gsa@autoauth-prod.iam.g. │
│ tracking-agent  │ agentic-app/tracking-agent-ksa│ tracking-agent-gsa@autoauth-prod.iam.g│
│ n8n             │ agentic-app/n8n-ksa          │ n8n-gsa@autoauth-prod.iam.g...         │
│ keda            │ keda/keda-ksa                │ keda-gsa@autoauth-prod.iam.g...        │
└─────────────────┴──────────────────────────────┴────────────────────────────────────────┘
```

### 11.3 Setup Commands

```bash
# Example for browser-agent (repeat for each service)

# 1. Create Google Service Account
gcloud iam service-accounts create browser-agent-gsa \
  --project=autoauth-prod \
  --display-name="Browser Agent GSA"

# 2. Create Kubernetes Service Account
kubectl create serviceaccount browser-agent-ksa \
  --namespace=agentic-app

# 3. Annotate KSA with GSA email
kubectl annotate serviceaccount browser-agent-ksa \
  --namespace=agentic-app \
  iam.gke.io/gcp-service-account=browser-agent-gsa@autoauth-prod.iam.gserviceaccount.com

# 4. Bind IAM: allow KSA to impersonate GSA
gcloud iam service-accounts add-iam-policy-binding \
  browser-agent-gsa@autoauth-prod.iam.gserviceaccount.com \
  --role=roles/iam.workloadIdentityUser \
  --member="serviceAccount:autoauth-prod.svc.id.goog[agentic-app/browser-agent-ksa]"

# 5. Grant GCP API permissions to GSA
gcloud projects add-iam-policy-binding autoauth-prod \
  --member="serviceAccount:browser-agent-gsa@autoauth-prod.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"

gcloud projects add-iam-policy-binding autoauth-prod \
  --member="serviceAccount:browser-agent-gsa@autoauth-prod.iam.gserviceaccount.com" \
  --role="roles/storage.objectViewer"

gcloud projects add-iam-policy-binding autoauth-prod \
  --member="serviceAccount:browser-agent-gsa@autoauth-prod.iam.gserviceaccount.com" \
  --role="roles/aiplatform.user"
```

---

## 12. GCP IAM Design

### 12.1 IAM Role Assignment Matrix

```
GSA                      │ pubsub  │ pubsub   │ secret  │ storage │ aiplatform │ sql    │ monitoring
                         │ publish │ subscribe│ access  │ viewer  │ user       │ client │ viewer
─────────────────────────┼─────────┼──────────┼─────────┼─────────┼────────────┼────────┼───────────
api-server-gsa           │   ✓     │          │         │         │            │   ✓    │
planner-gsa              │   ✓     │    ✓     │         │         │     ✓      │   ✓    │
control-plane-gsa        │         │    ✓     │         │         │            │   ✓    │
browser-agent-gsa        │         │          │    ✓    │   ✓     │     ✓      │        │
tracking-agent-gsa       │         │          │    ✓    │   ✓     │     ✓      │        │
n8n-gsa                  │   ✓     │          │         │         │            │        │
keda-gsa                 │         │          │         │         │            │        │   ✓
autoauth-node-sa         │         │          │         │         │            │        │
```

### 12.2 Custom Roles (Least Privilege)

```
Create custom roles to limit to exactly needed permissions:

Role: autoauth.pubsubPublisher
  permissions:
    - pubsub.topics.publish

Role: autoauth.pubsubSubscriber
  permissions:
    - pubsub.subscriptions.consume
    - pubsub.subscriptions.get

Role: autoauth.secretReader
  permissions:
    - secretmanager.versions.access
    - secretmanager.secrets.get

Role: autoauth.storageDocReader
  permissions:
    - storage.objects.get
    - storage.objects.list
    (Bucket-scoped, not project-scoped)
```

---

## 13. KEDA Autoscaling Design

### 13.1 KEDA Installation

```bash
# Install KEDA via Helm
helm repo add kedacore https://kedacore.github.io/charts
helm repo update
helm install keda kedacore/keda \
  --namespace keda \
  --create-namespace \
  --set serviceAccount.annotations."iam\.gke\.io/gcp-service-account"="keda-gsa@autoauth-prod.iam.gserviceaccount.com"
```

### 13.2 ScaledObject Configuration

```yaml
# browser-agent ScaledObject
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: browser-agent-scaler
  namespace: agentic-app
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: browser-agent
  pollingInterval: 30             # Check every 30 seconds
  cooldownPeriod: 300             # Wait 5 min before scaling down
  minReplicaCount: 1              # Always keep at least 1 pod
  maxReplicaCount: 6              # Max 6 pods
  fallback:
    failureThreshold: 3
    replicas: 2                   # On trigger failure, keep 2 replicas
  triggers:
    - type: gcp-pubsub
      authenticationRef:
        name: keda-trigger-auth
      metadata:
        subscriptionName: projects/autoauth-prod/subscriptions/prior-auth-browser-agent-request-sub-prod
        value: "5"                # 1 pod per 5 pending messages
        activationValue: "1"      # Scale up when ≥1 message

---
# TriggerAuthentication for KEDA → GCP
apiVersion: keda.sh/v1alpha1
kind: TriggerAuthentication
metadata:
  name: keda-trigger-auth
  namespace: agentic-app
spec:
  podIdentity:
    provider: gcp               # Use Workload Identity
```

### 13.3 Scaling Behavior

```
Scale-up:
  Message count 1–5   → 1 pod
  Message count 6–10  → 2 pods
  Message count 11–15 → 3 pods
  Message count 16–20 → 4 pods
  Message count 21–25 → 5 pods
  Message count 26+   → 6 pods (max)

Scale-down:
  → Only after 5 minutes of low queue depth (cooldownPeriod: 300)
  → Gradual scale-down (1 pod at a time)
  → In-progress sessions complete before pod terminates (preStop hook)
```

### 13.4 Graceful Shutdown (PreStop Hook)

```yaml
# In browser-agent Deployment spec
lifecycle:
  preStop:
    exec:
      command:
        - /bin/sh
        - -c
        - |
          # Signal the app to stop accepting new sessions
          curl -X POST http://localhost:8080/api/v1/drain
          # Wait for active sessions to complete (max 10 minutes)
          timeout 600 /bin/sh -c 'while curl -sf http://localhost:8080/api/v1/sessions | grep -q "active"; do sleep 10; done'
terminationGracePeriodSeconds: 660   # 11 minutes (10 min for sessions + 1 min buffer)
```

---

## 14. N8N Infrastructure Design

### 14.1 N8N Deployment

```yaml
# N8N runs in GKE as a StatefulSet (persistent data)
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: n8n
  namespace: agentic-app
spec:
  replicas: 1                     # Single instance (HA requires external DB)
  selector:
    matchLabels:
      app: n8n
  serviceName: n8n
  template:
    metadata:
      labels:
        app: n8n
    spec:
      serviceAccountName: n8n-ksa
      containers:
        - name: n8n
          image: n8nio/n8n:latest
          ports:
            - containerPort: 5678
          env:
            - name: N8N_HOST
              value: "n8n.agentic-app.svc.cluster.local"
            - name: N8N_PORT
              value: "5678"
            - name: N8N_PROTOCOL
              value: "http"
            - name: DB_TYPE
              value: "postgresdb"
            - name: DB_POSTGRESDB_HOST
              value: "127.0.0.1"    # Cloud SQL Auth Proxy sidecar
            - name: DB_POSTGRESDB_PORT
              value: "5432"
            - name: DB_POSTGRESDB_DATABASE
              value: "n8n"
            - name: N8N_ENCRYPTION_KEY
              valueFrom:
                secretKeyRef:
                  name: n8n-secrets
                  key: encryption-key
            - name: WEBHOOK_URL
              value: "http://n8n.agentic-app.svc.cluster.local:5678/"
          volumeMounts:
            - name: n8n-data
              mountPath: /home/node/.n8n
        - name: cloud-sql-proxy    # Sidecar for N8N DB connection
          image: gcr.io/cloud-sql-connectors/cloud-sql-proxy:2.0.0
          args:
            - "--structured-logs"
            - "--port=5432"
            - "autoauth-prod:us-central1:autoauth-db-prod"
  volumeClaimTemplates:
    - metadata:
        name: n8n-data
      spec:
        accessModes: ["ReadWriteOnce"]
        resources:
          requests:
            storage: 10Gi
        storageClassName: standard-rwo
```

### 14.2 N8N Webhook Security

```
All N8N webhooks secured with:
  Header: X-N8N-Signature: {HMAC-SHA256 of payload + shared secret}

Shared secret stored in:
  GCP Secret Manager: autoauth/prod/app/n8n-webhook-secret

Verification in calling services:
  def sign_webhook_payload(payload: dict, secret: str) -> str:
      import hmac, hashlib, json
      body = json.dumps(payload, sort_keys=True)
      return hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()

N8N validates signature using Function node before processing.
```

---

## 15. CI/CD Pipeline Design

### 15.1 Pipeline Overview

```
Developer pushes code
  │
  ▼
GitHub / Cloud Source Repository
  │
  ├── Branch: feature/*  → Run tests only (no deploy)
  ├── Branch: develop     → Build + Deploy to DEV
  ├── Branch: release/*   → Build + Deploy to UAT
  └── Branch: main/master → Build + Deploy to PROD (with approval gate)
```

### 15.2 Cloud Build Pipeline per Service

```yaml
# cloudbuild.yaml (same structure for each service)
# Located at: {service}/cloudbuild.yaml

steps:
  # Step 1: Run unit tests
  - name: "python:3.12"
    id: "unit-tests"
    entrypoint: "bash"
    args:
      - "-c"
      - |
        pip install -r requirements.txt -r requirements-test.txt
        pytest tests/unit/ -v --junitxml=test-results.xml --cov=app --cov-report=xml
    dir: "{service}"

  # Step 2: Run linting
  - name: "python:3.12"
    id: "lint"
    entrypoint: "bash"
    args:
      - "-c"
      - |
        pip install ruff black
        ruff check app/
        black --check app/
    dir: "{service}"

  # Step 3: Security scan
  - name: "python:3.12"
    id: "security-scan"
    entrypoint: "bash"
    args:
      - "-c"
      - |
        pip install bandit
        bandit -r app/ -ll  # Medium and higher severity only
    dir: "{service}"

  # Step 4: Build Docker image
  - name: "gcr.io/cloud-builders/docker"
    id: "build-image"
    args:
      - "build"
      - "-t"
      - "us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}:$SHORT_SHA"
      - "-t"
      - "us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}:latest"
      - "--cache-from"
      - "us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}:latest"
      - "."
    dir: "{service}"

  # Step 5: Vulnerability scan
  - name: "gcr.io/cloud-builders/gcloud"
    id: "vuln-scan"
    args:
      - "artifacts"
      - "docker"
      - "images"
      - "scan"
      - "us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}:$SHORT_SHA"
      - "--remote"

  # Step 6: Push to Artifact Registry
  - name: "gcr.io/cloud-builders/docker"
    id: "push-image"
    args:
      - "push"
      - "--all-tags"
      - "us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}"

  # Step 7: Run DB migrations (api-server only)
  - name: "gcr.io/cloud-builders/kubectl"
    id: "run-migrations"
    args:
      - "apply"
      - "-f"
      - "k8s/migration-job.yaml"
    env:
      - "CLOUDSDK_CONTAINER_CLUSTER=autoauth-cluster-prod"
      - "CLOUDSDK_COMPUTE_REGION=us-central1"

  # Step 8: Deploy to GKE
  - name: "gcr.io/cloud-builders/kubectl"
    id: "deploy"
    args:
      - "set"
      - "image"
      - "deployment/{service}"
      - "{service}=us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}:$SHORT_SHA"
      - "--namespace=agentic-app"
    env:
      - "CLOUDSDK_CONTAINER_CLUSTER=autoauth-cluster-prod"
      - "CLOUDSDK_COMPUTE_REGION=us-central1"

  # Step 9: Verify rollout
  - name: "gcr.io/cloud-builders/kubectl"
    id: "verify-rollout"
    args:
      - "rollout"
      - "status"
      - "deployment/{service}"
      - "--namespace=agentic-app"
      - "--timeout=300s"

images:
  - "us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}:$SHORT_SHA"
  - "us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}:latest"

options:
  machineType: E2_HIGHCPU_8
  logging: CLOUD_LOGGING_ONLY

timeout: "1200s"
```

### 15.3 Dockerfile Design (Standard across services)

```dockerfile
# Multi-stage build for smaller images
# Stage 1: Builder
FROM python:3.12-slim AS builder

WORKDIR /build

# Install build dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip wheel --no-cache-dir --no-deps --wheel-dir /wheels -r requirements.txt

# Stage 2: Runtime
FROM python:3.12-slim AS runtime

WORKDIR /app

# Install runtime system dependencies
RUN apt-get update && apt-get install -y \
    libpq5 \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Install common library (from local path or built wheel)
COPY --from=builder /wheels /wheels
COPY requirements.txt .
RUN pip install --no-cache /wheels/*

# Copy application code
COPY app/ ./app/

# Non-root user
RUN adduser --disabled-password --gecos '' appuser
USER appuser

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=30s --retries=3 \
  CMD curl -f http://localhost:8000/health || exit 1

EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

```dockerfile
# browser-agent has additional system dependencies
FROM python:3.12-slim AS runtime

# Browser automation deps
RUN apt-get update && apt-get install -y \
    xvfb \
    x11vnc \
    websockify \
    novnc \
    libpq5 \
    curl \
    wget \
    fonts-liberation \
    libnss3 \
    libxss1 \
    libasound2 \
    && rm -rf /var/lib/apt/lists/*

# Install Playwright browsers
RUN pip install playwright && playwright install chromium && playwright install-deps chromium

EXPOSE 8081
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8081"]
```

---

## 16. Kubernetes Manifest Design

### 16.1 Standard Deployment Template

```yaml
# Template used by all services (customize per service)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {service}
  namespace: agentic-app
  labels:
    app: {service}
    version: "1.0"
spec:
  replicas: 2                    # 2 for HA on default services
  selector:
    matchLabels:
      app: {service}
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0          # Zero downtime deployments
  template:
    metadata:
      labels:
        app: {service}
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8000"
        prometheus.io/path: "/metrics"
    spec:
      serviceAccountName: {service}-ksa
      terminationGracePeriodSeconds: 60

      # Anti-affinity: spread pods across nodes
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
            - weight: 100
              podAffinityTerm:
                labelSelector:
                  matchExpressions:
                    - key: app
                      operator: In
                      values: [{service}]
                topologyKey: kubernetes.io/hostname

      volumes:
        - name: secrets-store
          csi:
            driver: secrets-store.csi.k8s.io
            readOnly: true
            volumeAttributes:
              secretProviderClass: {service}-secrets

      initContainers:
        - name: wait-for-db
          image: busybox:1.35
          command: ['sh', '-c',
            'until nc -z 127.0.0.1 5432; do echo waiting for db; sleep 2; done']

      containers:
        - name: {service}
          image: us-central1-docker.pkg.dev/autoauth-prod/autoauth-repo/{service}:{version}
          imagePullPolicy: Always
          ports:
            - containerPort: 8000
              name: http
          resources:
            requests:
              cpu: 250m
              memory: 256Mi
            limits:
              cpu: 1000m
              memory: 512Mi
          env:
            - name: ENVIRONMENT
              value: "prod"
            - name: REDIS_HOST
              value: "10.0.3.5"
            - name: DB_HOST
              value: "127.0.0.1"    # Cloud SQL Auth Proxy
            - name: DB_NAME
              value: "autoauth"
            - name: DB_SCHEMA
              value: "iks_schema"
          envFrom:
            - configMapRef:
                name: {service}-config
          volumeMounts:
            - name: secrets-store
              mountPath: /var/secrets
              readOnly: true
          livenessProbe:
            httpGet:
              path: /health
              port: 8000
            initialDelaySeconds: 30
            periodSeconds: 30
            failureThreshold: 3
          readinessProbe:
            httpGet:
              path: /health
              port: 8000
            initialDelaySeconds: 10
            periodSeconds: 10
            failureThreshold: 3
          lifecycle:
            preStop:
              exec:
                command: ["/bin/sh", "-c", "sleep 5"]  # Allow load balancer to drain

        - name: cloud-sql-proxy
          image: gcr.io/cloud-sql-connectors/cloud-sql-proxy:2.0.0
          args:
            - "--structured-logs"
            - "--port=5432"
            - "autoauth-prod:us-central1:autoauth-db-prod"
          resources:
            requests:
              cpu: 100m
              memory: 128Mi
            limits:
              cpu: 200m
              memory: 256Mi
          securityContext:
            runAsNonRoot: true

---
# HorizontalPodAutoscaler
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {service}-hpa
  namespace: agentic-app
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: {service}
  minReplicas: 2
  maxReplicas: 5
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80

---
# Service
apiVersion: v1
kind: Service
metadata:
  name: {service}
  namespace: agentic-app
spec:
  selector:
    app: {service}
  ports:
    - port: 80
      targetPort: 8000
      name: http
  type: ClusterIP

---
# ConfigMap for non-sensitive config
apiVersion: v1
kind: ConfigMap
metadata:
  name: {service}-config
  namespace: agentic-app
data:
  PUBSUB_TOPIC_PRIOR_AUTH_AGENT_REQUESTS: "prior-auth-agent-requests"
  PUBSUB_SUBSCRIPTION_PRIOR_AUTH_AGENT_REQUESTS: "prior-auth-agent-request-sub-prod"
  GOOGLE_CLOUD_PROJECT: "autoauth-prod"
  DB_PORT: "5432"
  REDIS_PORT: "6379"
  REDIS_SSL: "true"
  LOG_LEVEL: "INFO"
```

### 16.2 PodDisruptionBudget

```yaml
# Ensure at least 1 replica always available during node maintenance
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {service}-pdb
  namespace: agentic-app
spec:
  minAvailable: 1
  selector:
    matchLabels:
      app: {service}
```

---

## 17. TLS & Ingress Design

### 17.1 Ingress Configuration

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: autoauth-ingress
  namespace: agentic-app
  annotations:
    kubernetes.io/ingress.class: "gce"
    kubernetes.io/ingress.global-static-ip-name: "autoauth-static-ip"
    networking.gke.io/managed-certificates: "autoauth-ssl-cert"
    kubernetes.io/ingress.allow-http: "false"   # HTTP → HTTPS redirect
    nginx.ingress.kubernetes.io/rate-limit: "100"
    nginx.ingress.kubernetes.io/rate-limit-window: "1m"
spec:
  rules:
    - host: autoauth.ikshealth.com
      http:
        paths:
          - path: /api/*
            pathType: ImplementationSpecific
            backend:
              service:
                name: api-server
                port:
                  number: 80
          - path: /*
            pathType: ImplementationSpecific
            backend:
              service:
                name: frontend
                port:
                  number: 80

---
# Google-managed SSL certificate
apiVersion: networking.gke.io/v1
kind: ManagedCertificate
metadata:
  name: autoauth-ssl-cert
  namespace: agentic-app
spec:
  domains:
    - autoauth.ikshealth.com
```

### 17.2 Internal Service Communication

```
All internal services communicate via Kubernetes DNS:
  http://api-server.agentic-app.svc.cluster.local:80
  http://control-plane.agentic-app.svc.cluster.local:80
  http://browser-agent.agentic-app.svc.cluster.local:80
  http://planner.agentic-app.svc.cluster.local:80
  http://n8n.agentic-app.svc.cluster.local:5678

Short form (within same namespace):
  http://api-server:80
  http://control-plane:80
  http://browser-agent:80

No TLS on internal traffic (within GKE cluster VPC — trusted network).
Add mTLS in Phase 2 hardening if compliance requires it.
```

---

## 18. Monitoring & Alerting Design

### 18.1 Cloud Monitoring Dashboards

```
Dashboard 1: AutoAuth Platform Overview
  Panels:
    - PA cases per hour (timeseries)
    - Cases by status (pie chart)
    - Average submission time (gauge)
    - Active browser sessions (number)
    - Pub/Sub queue depth - Topic #1 and #2 (timeseries)

Dashboard 2: Infrastructure Health
  Panels:
    - GKE node CPU/Memory utilization per pool
    - Pod restarts per service (last 24h)
    - Cloud SQL connections used vs. limit
    - Redis memory utilization
    - Cloud SQL disk usage

Dashboard 3: LLM Cost Tracking
  Panels:
    - Gemini API cost per day (bar chart)
    - Cost per case (histogram)
    - Token usage breakdown (input vs. output)

Dashboard 4: Error Rates
  Panels:
    - HTTP 5xx errors per service (timeseries)
    - Recipe failure rate per portal (bar chart)
    - HITL intervention rate (timeseries)
    - Dead letter message count (timeseries)
```

### 18.2 Alerting Policies

```
Alert 1: Pub/Sub Queue Depth High
  Condition: undelivered_message_count > 100 for 5 minutes
  Severity: WARNING
  Action: Notify #autoauth-ops Slack channel

Alert 2: Pod CrashLoopBackOff
  Condition: container restart count > 3 in 10 minutes
  Severity: CRITICAL
  Action: PagerDuty + Slack

Alert 3: Redis Worker Pool Empty
  Condition: Custom metric autoauth/redis/idle_workers == 0 for 2 minutes
  Severity: WARNING
  Action: Slack notification

Alert 4: Dead Letter Messages
  Condition: dead_letter_message_count > 0
  Severity: WARNING
  Action: Slack + email

Alert 5: Cloud SQL Connection Limit Near
  Condition: database/postgresql/num_backends > 150
  Severity: WARNING
  Action: Slack

Alert 6: GKE Node Memory High
  Condition: kubernetes.io/node/memory/used_bytes > 85% for 5 min
  Severity: WARNING
  Action: Slack

Alert 7: LLM Cost Spike
  Condition: billing.cost_since_last_invoice > $500
  Severity: WARNING
  Action: Email to niranjansai.k@ikshealth.com

Alert 8: Certificate Expiry
  Condition: SSL cert expires in < 30 days
  Severity: WARNING
  Action: Email (Google-managed certs auto-renew, this is a safety net)
```

### 18.3 Log-Based Metrics

```
Metric 1: pa_submission_success_rate
  Log filter: resource.type="k8s_container" AND
              jsonPayload.event="case_completed" AND
              jsonPayload.outcome="APPROVED"

Metric 2: pa_submission_failure_rate
  Log filter: resource.type="k8s_container" AND
              jsonPayload.event="case_failed"

Metric 3: hitl_intervention_count
  Log filter: resource.type="k8s_container" AND
              jsonPayload.event="hitl_requested"

Metric 4: recipe_step_failure
  Log filter: resource.type="k8s_container" AND
              jsonPayload.event="recipe_step_failed"

Custom alert on metric 4:
  Condition: recipe_step_failure by portal_id > 5 in 10 minutes
  → Indicates a portal changed its UI → recipe needs update
```

### 18.4 Structured Log Format

```json
// All services emit logs in this JSON format
{
  "timestamp": "2026-09-03T10:00:00.000Z",
  "severity": "INFO",             // DEBUG/INFO/WARNING/ERROR/CRITICAL
  "service": "browser-agent",
  "pod_id": "browser-agent-abc123",
  "case_ref_id": "CASE-2026-001-001",
  "batch_id": "BATCH-2026-001",
  "portal_id": "availity",
  "event": "recipe_step_completed",
  "step_name": "fill_member_id",
  "duration_ms": 245,
  "trace_id": "abc123def456",     // Propagated across services
  "message": "Filled member ID field successfully"
}
```

---

## 19. Security Hardening Checklist

### 19.1 GKE Security Hardening

```
[x] Enable Workload Identity on cluster
[x] Enable Binary Authorization (only signed images from Artifact Registry)
[x] Enable Shielded GKE Nodes (Secure Boot + Integrity Monitoring)
[x] Enable Network Policy (Calico) — restrict pod-to-pod communication
[x] Disable legacy metadata API (v1beta1)
[x] Enable master authorized networks (restrict control plane access)
[x] Enable private nodes (no public IPs on worker nodes)
[x] Enable audit logging (all GKE API server actions logged)
[x] Set resource requests and limits on ALL containers
[x] Run containers as non-root user
[x] Use read-only root filesystem where possible
[x] Drop all Linux capabilities, add back only what's needed

Network Policies (Calico):
  api-server:
    → Allow ingress from: GKE Ingress LB
    → Allow egress to: Cloud SQL proxy, Redis, Pub/Sub (GCP)
    → Deny all other

  browser-agent:
    → Allow ingress from: control-plane only
    → Allow egress to: internet (payer portals), GCP APIs
    → Deny: ingress from internet

  control-plane:
    → Allow ingress from: api-server, planner, N8N
    → Allow egress to: browser-agent, tracking-agent, Redis, Pub/Sub
```

### 19.2 Application Security Hardening

```
[x] JWT tokens: HS256, 60-minute expiry, no sensitive data in payload
[x] Passwords: bcrypt with cost factor 12
[x] Input validation: Pydantic models on all API endpoints
[x] SQL injection: SQLAlchemy ORM (parameterized queries only, no raw SQL)
[x] XSS: React auto-escapes by default; no dangerouslySetInnerHTML
[x] CORS: Restrict to known origins (autoauth.ikshealth.com only)
[x] Rate limiting: 100 req/min per IP on api-server (via GKE Ingress annotation)
[x] No secrets in logs: log filtering middleware strips credential fields
[x] HTTPS only: HTTP → HTTPS redirect at ingress level
[x] Dependency scanning: Dependabot / pip-audit in CI pipeline
[x] Container image scanning: Artifact Registry vulnerability scanning
[x] OWASP Top 10: Verified in security testing phase
```

### 19.3 PHI / HIPAA Considerations

```
AutoAuth processes PHI (Protected Health Information):
  - Patient names, DOB, member IDs
  - Diagnosis codes, procedure codes
  - Provider NPIs

Protections:
[x] Data encrypted at rest: Cloud SQL (AES-256), GCS (AES-256), Redis (AES-256)
[x] Data encrypted in transit: TLS 1.2+ everywhere
[x] PHI never logged in plaintext: log sanitizer middleware
[x] PHI stored in JSONB (PostgreSQL) — not in log tables
[x] Access controlled: JWT + role-based access on API
[x] Audit trail: all case status changes logged with user/timestamp
[x] Data retention: configurable per customer contract
[x] Business Associate Agreement (BAA): required with GCP (Google Cloud HIPAA BAA)
[x] VPC isolation: no PHI data traverses public internet (Cloud SQL private IP)
```

---

## 20. Local Development Environment

### 20.1 docker-compose.yaml

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: autoauth
      POSTGRES_USER: autoauth_app
      POSTGRES_PASSWORD: localpassword123
    ports:
      - "5433:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./common/db_layer/init.sql:/docker-entrypoint-initdb.d/init.sql
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U autoauth_app -d autoauth"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    command: redis-server --notify-keyspace-events KEx --save 60 1
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  n8n:
    image: n8nio/n8n:latest
    ports:
      - "5678:5678"
    environment:
      - N8N_HOST=localhost
      - N8N_PORT=5678
      - N8N_PROTOCOL=http
      - WEBHOOK_URL=http://localhost:5678/
      - N8N_ENCRYPTION_KEY=local-dev-encryption-key
    volumes:
      - n8n_data:/home/node/.n8n

  api-server:
    build:
      context: .
      dockerfile: api-server/Dockerfile
    ports:
      - "8000:8000"
    environment:
      - ENVIRONMENT=local
      - DB_HOST=postgres
      - DB_PORT=5432
      - DB_NAME=autoauth
      - DB_USER=autoauth_app
      - DB_PASSWORD=localpassword123
      - DB_SCHEMA=iks_schema
      - REDIS_HOST=redis
      - REDIS_PORT=6379
      - REDIS_SSL=false
      - JWT_SECRET=local-dev-jwt-secret-change-in-prod
      - PUBSUB_TOPIC_PRIOR_AUTH_AGENT_REQUESTS=prior-auth-agent-requests
      - GOOGLE_CLOUD_PROJECT=autoauth-dev
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./api-server/app:/app/app      # Hot reload in dev
      - ./common:/common
    command: uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

  planner:
    build:
      context: .
      dockerfile: planner/Dockerfile
    ports:
      - "8001:8001"
    environment:
      - ENVIRONMENT=local
      - DB_HOST=postgres
      - REDIS_HOST=redis
      - PRIOR_AUTH_SUBMISSION_WEBHOOK_URL=http://n8n:5678/webhook/preauth
      - PUBSUB_SUBSCRIPTION_PRIOR_AUTH_AGENT_REQUESTS=prior-auth-agent-request-sub-dev
      - GOOGLE_CLOUD_PROJECT=autoauth-dev
      - GOOGLE_APPLICATION_CREDENTIALS=/secrets/gcp-sa.json
    volumes:
      - ./local-secrets/gcp-sa.json:/secrets/gcp-sa.json:ro
    depends_on:
      - api-server

  control-plane:
    build:
      context: .
      dockerfile: control-plane/Dockerfile
    ports:
      - "8080:8000"
    environment:
      - ENVIRONMENT=local
      - DB_HOST=postgres
      - REDIS_HOST=redis
      - TRIGGER_PRIOR_AUTH_SUBMISSION_AGENT=http://n8n:5678/webhook/agents
      - PUBSUB_SUBSRIPTION_BROWSER_AGENT_REQUESTS=prior-auth-browser-agent-request-sub-dev
      - KEYSPACE_NOTIFICATION_ENABLED=true
    depends_on:
      - redis

  browser-agent:
    build:
      context: .
      dockerfile: browser-agent/Dockerfile
    ports:
      - "8081:8081"
    environment:
      - ENVIRONMENT=local
      - REDIS_HOST=redis
      - PLAYWRIGHT_EXECUTION_ENGINE=yes
      - RECIPE_SOURCE=file
      - COMP_WEBHOOK_URL=http://n8n:5678/webhook/completed
      - HITL_WEBHOOK_URL=http://n8n:5678/webhook/hitl
      - MFA_WEBHOOK_URL=http://n8n:5678/webhook/mfa
      - STATUS_CAPTURE_WEBHOOK_URL=http://n8n:5678/webhook/status-capture
      - SUMMARY_WEBHOOK_URL=http://n8n:5678/webhook/summary
      - API_SERVER_URL=http://api-server:8000
      - LLM_MODEL=gemini-2.5-pro
      - GOOGLE_API_KEY=${GOOGLE_API_KEY}     # From .env file
      - CAPSOLVER_API_KEY=${CAPSOLVER_API_KEY}
    depends_on:
      - redis
    privileged: true                         # Required for Xvfb

  tracking-agent:
    build:
      context: .
      dockerfile: tracking-agent/Dockerfile
    ports:
      - "8083:8080"
    environment:
      - ENVIRONMENT=local
      - REDIS_HOST=redis
    depends_on:
      - redis

  frontend:
    build:
      context: ui/
      dockerfile: Dockerfile
    ports:
      - "3000:80"
    environment:
      - VITE_API_URL=http://localhost:8000

volumes:
  postgres_data:
  redis_data:
  n8n_data:
```

### 20.2 Local Setup Steps

```bash
# 1. Clone repository
git clone https://github.com/ikshealth/autoauth-agent.git
cd autoauth-agent

# 2. Create .env file for sensitive local config
cat > .env << EOF
GOOGLE_API_KEY=your_gemini_api_key_here
CAPSOLVER_API_KEY=your_capsolver_api_key_here
EOF

# 3. Install common library in editable mode
pip install -e common/

# 4. Start infrastructure only (DB, Redis, N8N)
docker compose up postgres redis n8n -d

# 5. Wait for postgres, run migrations
docker compose run --rm api-server alembic upgrade head

# 6. Start all services
docker compose up -d

# 7. Verify all services healthy
docker compose ps

# 8. Seed test data
python scripts/seed_test_data.py

# 9. Access dashboard
open http://localhost:3000

# 10. Access N8N workflows
open http://localhost:5678
```

---

## 21. Environment Promotion Strategy

### 21.1 Environment Configuration Differences

```
                    local          dev              uat              prod
──────────────────────────────────────────────────────────────────────────────────
GCP Project        autoauth-dev   autoauth-dev     autoauth-uat     autoauth-prod
PostgreSQL         docker (5433)  Cloud SQL dev    Cloud SQL uat    Cloud SQL prod
Redis              docker (6379)  Memorystore dev  Memorystore uat  Memorystore prod
Pub/Sub            GCP emulator   Real GCP dev     Real GCP uat     Real GCP prod
Secret Manager     Local files    GCP dev          GCP uat          GCP prod
KEDA               N/A            Installed        Installed        Installed
Payer Portals      Mock/sandbox   Sandbox          Sandbox          Real portals
Replicas           1              1                1–2              2–6 (autoscale)
DB Schema          iks_schema_dev iks_schema_dev   iks_schema_uat   iks_schema
```

### 21.2 Promotion Workflow

```
Feature branch → PR review → merge to develop
  ↓ Cloud Build triggers automatically
  → Build + test + deploy to DEV
  → Integration tests run automatically
  → Slack notification: "DEV deployment succeeded"

develop → PR to release/v{version}
  ↓ Manual approval by Tech Lead
  → Build + test + deploy to UAT
  → UAT regression tests run
  → Clinical team performs UAT
  → Sign-off required from Product Owner

release/v{version} → PR to main
  ↓ Manual approval by TWO reviewers (including Tech Lead)
  → Build + test + deploy to PROD
  → Smoke tests run automatically
  → Monitor for 30 minutes
  → Slack: "PROD deployment v{version} complete"
  → Tag git commit as v{version}
```

---

## 22. Disaster Recovery Design

### 22.1 Recovery Time / Recovery Point Objectives

```
Component          RTO (target)    RPO (target)    Strategy
──────────────────────────────────────────────────────────────────────────
GKE Services       < 5 minutes     N/A             Multi-zone deployment + HPA
Cloud SQL          < 15 minutes    < 1 hour        HA + automated failover + PITR
Redis              < 5 minutes     < 1 hour (RDB)  HA (primary + replica)
Pub/Sub            < 1 minute      Zero            GCP-managed, 7-day retention
N8N                < 10 minutes    < 1 hour        StatefulSet + PVC backup
GCS Buckets        < 1 minute      Zero            GCP-managed, versioned
In-flight cases    < 30 minutes    Zero            Redis heartbeat recovery
```

### 22.2 Backup Strategy

```
PostgreSQL:
  → Automated daily backup at 2 AM UTC (Cloud SQL managed)
  → Point-in-time recovery enabled (7-day transaction log retention)
  → Cross-region backup copy: us-east1 (for prod only)

Redis:
  → RDB snapshot every 1 hour
  → Replica in separate zone (Memorystore HA)
  → Redis Streams are ephemeral — log persistence is in PostgreSQL

N8N workflows:
  → Export workflow JSON weekly → store in GCS autoauth-backups bucket
  → Manual trigger: Admin can re-import from backup

GCS Documents:
  → Versioning enabled on buckets
  → 30 daily backup copies retained
```

### 22.3 In-Flight Case Recovery

```
Scenario: GKE cluster goes down mid-processing

Recovery:
  1. GKE auto-repairs and restores pods (< 5 min typically)
  2. browser-agent pods restart → re-register in Redis worker pool
  3. control-plane restarts → ExpiredEventConsumer detects all in-flight cases
     (their Redis heartbeat keys all expired during outage)
  4. For each expired in-flight case:
     → Mark status = CRASHED in PostgreSQL
     → Re-publish to Pub/Sub Topic #2 (if retry_count < 3)
  5. Cases automatically re-processed when pods are healthy

Manual recovery (if automated recovery fails):
  → Admin calls: GET /api/v1/clear_all_pools (reset Redis worker pool)
  → Re-submit batch via API (duplicate detection by case_ref_id)
```

---

## 23. Step-by-Step Infrastructure Setup Runbook

### Phase A: One-Time GCP Setup (Dev & Prod)

```bash
# Step 1: Set variables
export PROJECT_ID="autoauth-prod"
export REGION="us-central1"
export CLUSTER_NAME="autoauth-cluster-prod"

# Step 2: Create GCP project and set billing
gcloud projects create $PROJECT_ID
gcloud beta billing projects link $PROJECT_ID --billing-account=BILLING_ACCOUNT_ID

# Step 3: Enable required APIs (see Section 2.3)
gcloud services enable container.googleapis.com ...

# Step 4: Create VPC
gcloud compute networks create autoauth-vpc-prod \
  --subnet-mode=custom \
  --bgp-routing-mode=regional

gcloud compute networks subnets create gke-subnet \
  --network=autoauth-vpc-prod \
  --region=$REGION \
  --range=10.0.1.0/24 \
  --secondary-range=pods-range=10.1.0.0/16,services-range=10.2.0.0/20

# Step 5: Create Cloud NAT
gcloud compute routers create autoauth-router-prod \
  --network=autoauth-vpc-prod \
  --region=$REGION

gcloud compute routers nats create autoauth-nat-prod \
  --router=autoauth-router-prod \
  --region=$REGION \
  --auto-allocate-nat-external-ips \
  --nat-all-subnet-ip-ranges

# Step 6: Create Artifact Registry
gcloud artifacts repositories create autoauth-repo \
  --repository-format=docker \
  --location=$REGION \
  --description="AutoAuth Docker images"

# Step 7: Create GKE cluster
gcloud container clusters create $CLUSTER_NAME \
  --region=$REGION \
  --network=autoauth-vpc-prod \
  --subnetwork=gke-subnet \
  --cluster-secondary-range-name=pods-range \
  --services-secondary-range-name=services-range \
  --enable-private-nodes \
  --master-ipv4-cidr=172.16.0.0/28 \
  --enable-ip-alias \
  --workload-pool=$PROJECT_ID.svc.id.goog \
  --enable-shielded-nodes \
  --release-channel=regular \
  --no-enable-basic-auth \
  --enable-network-policy

# Step 8: Add browser-agent node pool
gcloud container node-pools create browser-agent-pool \
  --cluster=$CLUSTER_NAME \
  --region=$REGION \
  --machine-type=n2-standard-8 \
  --disk-size=200GB \
  --disk-type=pd-ssd \
  --num-nodes=1 \
  --enable-autoscaling \
  --min-nodes=1 \
  --max-nodes=6 \
  --node-taints=dedicated=browser-agent:NoSchedule \
  --node-labels=pool=browser-agent

# Step 9: Enable VPC peering for Cloud SQL and Redis
gcloud compute addresses create google-managed-services-autoauth-vpc \
  --global \
  --purpose=VPC_PEERING \
  --prefix-length=16 \
  --network=autoauth-vpc-prod

gcloud services vpc-peerings connect \
  --service=servicenetworking.googleapis.com \
  --ranges=google-managed-services-autoauth-vpc \
  --network=autoauth-vpc-prod

# Step 10: Create Cloud SQL (PostgreSQL)
gcloud sql instances create autoauth-db-prod \
  --database-version=POSTGRES_16 \
  --region=$REGION \
  --tier=db-custom-4-16384 \
  --availability-type=REGIONAL \
  --no-assign-ip \
  --network=autoauth-vpc-prod \
  --storage-type=SSD \
  --storage-size=100GB \
  --storage-auto-increase \
  --backup-start-time=02:00 \
  --enable-point-in-time-recovery \
  --retained-backups-count=30 \
  --retained-transaction-log-days=7

# Step 11: Create Redis (Memorystore)
gcloud redis instances create autoauth-redis-prod \
  --region=$REGION \
  --tier=standard \
  --size=4 \
  --redis-version=redis_7_0 \
  --network=autoauth-vpc-prod \
  --enable-auth \
  --transit-encryption-mode=SERVER_AUTHENTICATION

# Step 12: Create Pub/Sub topics and subscriptions
gcloud pubsub topics create prior-auth-agent-requests
gcloud pubsub topics create prior-auth-browser-agent-requests
gcloud pubsub topics create prior-auth-agent-requests-dlq
gcloud pubsub topics create prior-auth-browser-agent-requests-dlq

gcloud pubsub subscriptions create prior-auth-agent-request-sub-prod \
  --topic=prior-auth-agent-requests \
  --ack-deadline=600 \
  --message-retention-duration=7d \
  --dead-letter-topic=prior-auth-agent-requests-dlq \
  --max-delivery-attempts=5

gcloud pubsub subscriptions create prior-auth-browser-agent-request-sub-prod \
  --topic=prior-auth-browser-agent-requests \
  --ack-deadline=600 \
  --message-retention-duration=7d \
  --dead-letter-topic=prior-auth-browser-agent-requests-dlq \
  --max-delivery-attempts=5

# Step 13: Create Secrets (initial setup — values filled manually)
for secret in \
  "autoauth-prod-redis-auth-password" \
  "autoauth-prod-db-app-password" \
  "autoauth-prod-db-migration-password" \
  "autoauth-prod-app-jwt-secret" \
  "autoauth-prod-app-capsolver-api-key" \
  "autoauth-prod-app-n8n-webhook-secret" \
  "autoauth-prod-app-gemini-api-key"; do
  gcloud secrets create $secret --replication-policy=automatic
  echo "Created secret: $secret — fill value manually"
done

# Step 14: Create Cloud Storage bucket
gsutil mb -l $REGION -b on gs://autoauth-pa-documents-prod
gsutil versioning set on gs://autoauth-pa-documents-prod
gsutil lifecycle set bucket-lifecycle.json gs://autoauth-pa-documents-prod

# Step 15: Set up Workload Identity for each service (see Section 11.3)
# Repeat for each service...

# Step 16: Connect kubectl to cluster
gcloud container clusters get-credentials $CLUSTER_NAME --region=$REGION

# Step 17: Create namespace
kubectl create namespace agentic-app
kubectl label namespace agentic-app environment=prod

# Step 18: Install KEDA
helm repo add kedacore https://kedacore.github.io/charts && helm repo update
helm install keda kedacore/keda --namespace keda --create-namespace

# Step 19: Install Secrets Store CSI driver
helm repo add secrets-store-csi-driver https://kubernetes-sigs.github.io/secrets-store-csi-driver/charts
helm install csi-secrets-store secrets-store-csi-driver/secrets-store-csi-driver --namespace kube-system
kubectl apply -f https://raw.githubusercontent.com/GoogleCloudPlatform/secrets-store-csi-driver-provider-gcp/main/deploy/provider-gcp-plugin.yaml

# Step 20: Run DB migrations (first time)
kubectl apply -f k8s/migration-job.yaml
kubectl wait --for=condition=complete job/db-migration --timeout=120s -n agentic-app

echo "✅ Infrastructure setup complete"
```

---

*Document Status: DRAFT — Awaiting review before infrastructure provisioning begins.*
*Previous Document: [01_Requirements_and_System_Design.md](01_Requirements_and_System_Design.md)*
*Next Document: [03_API_Contracts_OpenAPI.md](03_API_Contracts_OpenAPI.md)*
