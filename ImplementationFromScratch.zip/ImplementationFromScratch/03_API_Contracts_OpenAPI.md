# AutoAuth Agent — API Contracts (OpenAPI 3.0 Specifications)
**Phase 1 | Weeks 1–2**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0
**Prerequisite:** [01_Requirements_and_System_Design.md](01_Requirements_and_System_Design.md)

---

## Table of Contents

1. [Overview & Design Principles](#1-overview--design-principles)
2. [Shared Models & Standards](#2-shared-models--standards)
3. [Service 1: api-server (Public API)](#3-service-1-api-server-public-api)
4. [Service 2: planner (Internal)](#4-service-2-planner-internal)
5. [Service 3: control-plane (Internal)](#5-service-3-control-plane-internal)
6. [Service 4: browser-agent (Internal)](#6-service-4-browser-agent-internal)
7. [Service 5: tracking-agent (Internal)](#7-service-5-tracking-agent-internal)
8. [Webhook Contracts (N8N)](#8-webhook-contracts-n8n)
9. [SSE Event Contracts](#9-sse-event-contracts)
10. [Error Handling Standard](#10-error-handling-standard)
11. [Versioning Strategy](#11-versioning-strategy)
12. [Inter-Service Call Map](#12-inter-service-call-map)

---

## 1. Overview & Design Principles

### 1.1 API Design Rules

```
1. REST over HTTP/1.1 for all service-to-service and external calls.
2. JSON request and response bodies (Content-Type: application/json).
3. Snake_case for all JSON field names.
4. ISO 8601 for all timestamps (e.g., 2026-09-03T10:00:00Z).
5. UUIDs (v4) for all resource identifiers.
6. Pagination via ?page=1&limit=50 (1-indexed pages).
7. Consistent error envelope: { error_code, message, details? }.
8. HTTP status codes strictly per RFC 9110.
9. Idempotency: POST /prior-auths is idempotent by case_ref_id.
10. All public endpoints require Authorization: Bearer {jwt_token}.
11. Internal endpoints (within GKE cluster) are unauthenticated — rely on network policy.
12. Soft deletes only — no hard DELETE on case/batch data.
```

### 1.2 HTTP Status Code Usage

```
200 OK              → Successful GET / successful PATCH (returns body)
201 Created         → Successful POST that created a resource
202 Accepted        → Request accepted for async processing
204 No Content      → Successful DELETE or PATCH with no return body
400 Bad Request     → Invalid input / validation failure
401 Unauthorized    → Missing or invalid JWT token
403 Forbidden       → Valid token but insufficient role
404 Not Found       → Resource does not exist
409 Conflict        → Duplicate resource / state conflict
422 Unprocessable   → Well-formed but semantically invalid (Pydantic)
429 Too Many Req.   → Rate limit exceeded
500 Internal Error  → Unexpected server error (never expose stack traces)
503 Unavailable     → Service temporarily unavailable (use for health failures)
```

---

## 2. Shared Models & Standards

### 2.1 Common Schemas

```yaml
# ----- SHARED SCHEMAS USED ACROSS ALL SERVICES -----

CaseStatus:
  type: string
  enum:
    - PENDING
    - PLANNING
    - QUEUED
    - IN_PROGRESS
    - HITL_WAIT
    - MFA_WAIT
    - SUBMITTED
    - APPROVED
    - DENIED
    - PENDING_INFO
    - CRASHED
    - FAILED
    - CANCELLED

ErrorResponse:
  type: object
  required: [error_code, message]
  properties:
    error_code:
      type: string
      example: "VALIDATION_ERROR"
    message:
      type: string
      example: "member_id is required"
    details:
      type: object
      description: "Additional context (field errors, etc.)"
      example:
        field: "patient_data.member_id"
        constraint: "required"
    trace_id:
      type: string
      description: "Request trace ID for log correlation"
      example: "abc123def456"

PaginationMeta:
  type: object
  properties:
    page:
      type: integer
      example: 1
    limit:
      type: integer
      example: 50
    total:
      type: integer
      example: 247
    total_pages:
      type: integer
      example: 5

PatientData:
  type: object
  required:
    - first_name
    - last_name
    - date_of_birth
    - member_id
  properties:
    first_name:
      type: string
      example: "Jane"
    last_name:
      type: string
      example: "Doe"
    date_of_birth:
      type: string
      format: date
      example: "1985-04-23"
    member_id:
      type: string
      example: "UHC1234567890"
    group_id:
      type: string
      example: "GRP-98765"
    plan_name:
      type: string
      example: "UnitedHealthcare Choice Plus"
    subscriber_first_name:
      type: string
    subscriber_last_name:
      type: string
    subscriber_date_of_birth:
      type: string
      format: date
    relationship_to_subscriber:
      type: string
      enum: [SELF, SPOUSE, CHILD, OTHER]
      example: "SELF"
    address:
      type: object
      properties:
        street: { type: string }
        city:   { type: string }
        state:  { type: string }
        zip:    { type: string }
    phone:
      type: string
      example: "555-867-5309"

ClinicalData:
  type: object
  required:
    - procedure_codes
    - diagnosis_codes
    - rendering_npi
    - facility_npi
    - start_date_of_service
  properties:
    procedure_codes:
      type: array
      items:
        type: object
        properties:
          code:        { type: string, example: "70553" }
          description: { type: string, example: "MRI brain w/ contrast" }
          modifier:    { type: string, example: "26" }
      minItems: 1
    diagnosis_codes:
      type: array
      items:
        type: string
      example: ["G35", "R51.9"]
      minItems: 1
    rendering_npi:
      type: string
      pattern: '^[0-9]{10}$'
      example: "1234567890"
    rendering_provider_name:
      type: string
      example: "Dr. Sarah Smith"
    facility_npi:
      type: string
      pattern: '^[0-9]{10}$'
      example: "0987654321"
    facility_name:
      type: string
      example: "City Medical Center"
    start_date_of_service:
      type: string
      format: date
      example: "2026-10-01"
    end_date_of_service:
      type: string
      format: date
      example: "2026-10-01"
    place_of_service:
      type: string
      example: "11"
    quantity:
      type: integer
      example: 1
    urgency:
      type: string
      enum: [ROUTINE, URGENT, EMERGENCY]
      default: ROUTINE
    clinical_notes_url:
      type: string
      description: "GCS URL for clinical notes PDF to upload"
      example: "gs://autoauth-pa-documents-prod/pa-documents/CASE-001/notes.pdf"
    supporting_documents:
      type: array
      items:
        type: object
        properties:
          document_type: { type: string, example: "lab_results" }
          url:           { type: string }
```

---

## 3. Service 1: api-server (Public API)

**Base URL:** `https://autoauth.ikshealth.com/api/v1`
**Auth:** JWT Bearer token (except `/auth/*` and `/health`)

```yaml
openapi: "3.0.3"
info:
  title: "AutoAuth Agent — API Server"
  description: |
    External-facing REST API for the AutoAuth Agent platform.
    Handles batch PA ingestion, authentication, dashboard data,
    recipe management, and portal credential management.
  version: "1.0.0"
  contact:
    name: "AutoAuth Engineering"
    email: "niranjansai.k@ikshealth.com"

servers:
  - url: "https://autoauth.ikshealth.com/api/v1"
    description: Production
  - url: "https://uat.autoauth.ikshealth.com/api/v1"
    description: UAT
  - url: "http://localhost:8000/api/v1"
    description: Local Development

security:
  - BearerAuth: []

components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT

  schemas:
    # (Shared schemas from Section 2 apply here)

    UserRegisterRequest:
      type: object
      required: [email, password, full_name]
      properties:
        email:
          type: string
          format: email
          example: "clinician@hospital.org"
        password:
          type: string
          minLength: 10
          description: "Min 10 chars, must include uppercase, lowercase, digit, symbol"
          example: "Secur3Pass!"
        full_name:
          type: string
          example: "Jane Smith"
        role:
          type: string
          enum: [ADMIN, OPERATOR, VIEWER]
          default: VIEWER

    UserRegisterResponse:
      type: object
      properties:
        user_id:
          type: string
          format: uuid
        email:
          type: string
        full_name:
          type: string
        role:
          type: string
        created_at:
          type: string
          format: date-time

    LoginRequest:
      type: object
      required: [email, password]
      properties:
        email:
          type: string
          format: email
        password:
          type: string

    LoginResponse:
      type: object
      properties:
        access_token:
          type: string
          description: "JWT token — include in Authorization: Bearer {token}"
        token_type:
          type: string
          example: "bearer"
        expires_in:
          type: integer
          description: "Seconds until token expires"
          example: 3600
        user:
          type: object
          properties:
            user_id:  { type: string, format: uuid }
            email:    { type: string }
            full_name:{ type: string }
            role:     { type: string }

    PACase:
      type: object
      required: [case_ref_id, patient_data, clinical_data]
      properties:
        case_ref_id:
          type: string
          description: "Unique case reference ID — must be unique across all batches"
          example: "CASE-2026-09-001-001"
          maxLength: 255
        patient_data:
          $ref: '#/components/schemas/PatientData'
        clinical_data:
          $ref: '#/components/schemas/ClinicalData'

    BatchSubmitRequest:
      type: object
      required: [batch_id, portal_id, cases]
      properties:
        batch_id:
          type: string
          description: "Unique batch identifier from caller's system"
          example: "BATCH-2026-09-001"
          maxLength: 255
        portal_id:
          type: string
          description: "Target payer portal identifier"
          example: "availity"
        cases:
          type: array
          items:
            $ref: '#/components/schemas/PACase'
          minItems: 1
          maxItems: 100
          description: "List of PA cases to submit. All cases in a batch target the same portal."
        priority:
          type: string
          enum: [NORMAL, HIGH, URGENT]
          default: NORMAL
        metadata:
          type: object
          description: "Caller-defined metadata — stored but not processed"
          additionalProperties: true

    BatchSubmitResponse:
      type: object
      properties:
        batch_id:
          type: string
          example: "BATCH-2026-09-001"
        case_count:
          type: integer
          example: 10
        status:
          type: string
          example: "accepted"
        accepted_cases:
          type: array
          items:
            type: string
          description: "List of case_ref_ids accepted"
        rejected_cases:
          type: array
          items:
            type: object
            properties:
              case_ref_id: { type: string }
              reason:      { type: string }
          description: "Cases rejected due to validation errors or duplicates"
        created_at:
          type: string
          format: date-time

    CaseDetail:
      type: object
      properties:
        case_ref_id:         { type: string }
        batch_id:            { type: string }
        portal_id:           { type: string }
        status:              { $ref: '#/components/schemas/CaseStatus' }
        outcome:
          type: string
          enum: [APPROVED, DENIED, PENDING, PENDING_INFO, ERROR]
          nullable: true
        pa_reference_number:
          type: string
          nullable: true
          example: "PA-UHC-2026-123456"
        outcome_details:
          type: string
          nullable: true
        retry_count:
          type: integer
          example: 0
        created_at:          { type: string, format: date-time }
        updated_at:          { type: string, format: date-time }
        submitted_at:        { type: string, format: date-time, nullable: true }
        completed_at:        { type: string, format: date-time, nullable: true }
        vnc_url:
          type: string
          nullable: true
          description: "Live VNC viewer URL (only present when status=IN_PROGRESS)"
          example: "https://autoauth.ikshealth.com/vnc/CASE-2026-09-001-001"

    CaseStatusUpdateRequest:
      type: object
      properties:
        status:
          $ref: '#/components/schemas/CaseStatus'
        outcome:
          type: string
          enum: [APPROVED, DENIED, PENDING, PENDING_INFO, ERROR]
        pa_reference_number:
          type: string
        outcome_details:
          type: string

    PortalRecipeResponse:
      type: object
      properties:
        portal_id:    { type: string }
        portal_name:  { type: string }
        version:      { type: string }
        recipe_yaml:  { type: string, description: "Raw YAML content of the recipe" }
        source:       { type: string, enum: [db, file], description: "Where the recipe was loaded from" }
        updated_at:   { type: string, format: date-time }

    PortalSecretRequest:
      type: object
      required: [portal_id, credential_alias, username, password]
      properties:
        portal_id:         { type: string }
        credential_alias:  { type: string, example: "availity-primary" }
        username:          { type: string }
        password:          { type: string, format: password }
        service_account:   { type: string, description: "For MFA SIM card credentials", nullable: true }

    RunVolumeResponse:
      type: object
      properties:
        period:
          type: string
          example: "2026-09-01/2026-09-03"
        group_by:
          type: string
          enum: [hour, day, week, month]
        data:
          type: array
          items:
            type: object
            properties:
              period_start: { type: string, format: date-time }
              total:        { type: integer }
              approved:     { type: integer }
              denied:       { type: integer }
              pending:      { type: integer }
              failed:       { type: integer }
              in_progress:  { type: integer }
        totals:
          type: object
          properties:
            total:    { type: integer }
            approved: { type: integer }
            denied:   { type: integer }
            pending:  { type: integer }
            failed:   { type: integer }

    LLMCostResponse:
      type: object
      properties:
        period:    { type: string }
        total_cost_usd: { type: number, format: float, example: 12.45 }
        breakdown:
          type: array
          items:
            type: object
            properties:
              date:           { type: string, format: date }
              model_name:     { type: string }
              call_type:      { type: string }
              total_cost_usd: { type: number }
              total_tokens:   { type: integer }

    PayerPromptRequest:
      type: object
      required: [portal_id, prompt_type, prompt_text]
      properties:
        portal_id:   { type: string }
        prompt_type: { type: string, enum: [system, extraction, summary] }
        prompt_text: { type: string }
        model_name:  { type: string, example: "gemini-2.5-pro" }

    HITLTask:
      type: object
      properties:
        task_id:        { type: string, format: uuid }
        case_ref_id:    { type: string }
        task_type:      { type: string, enum: [HITL, MFA] }
        status:         { type: string, enum: [PENDING, RESOLVED, EXPIRED] }
        message:        { type: string }
        screenshot_url: { type: string, nullable: true }
        resolution:     { type: string, nullable: true }
        created_at:     { type: string, format: date-time }
        resolved_at:    { type: string, format: date-time, nullable: true }

paths:

  # ─────────────────────────────────────────────────
  # AUTHENTICATION
  # ─────────────────────────────────────────────────

  /auth/register:
    post:
      tags: [Authentication]
      summary: "Register a new dashboard user"
      description: "Creates a new user account. Requires ADMIN role to create ADMIN/OPERATOR users."
      security: []                # No auth for first admin — restrict via network in prod
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/UserRegisterRequest'
            example:
              email: "clinician@hospital.org"
              password: "Secur3Pass!"
              full_name: "Jane Smith"
              role: "OPERATOR"
      responses:
        '201':
          description: "User created"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/UserRegisterResponse'
        '409':
          description: "Email already registered"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              example:
                error_code: "EMAIL_ALREADY_EXISTS"
                message: "A user with this email already exists"
        '422':
          description: "Validation error"

  /auth/login:
    post:
      tags: [Authentication]
      summary: "Login and receive JWT token"
      security: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/LoginRequest'
            example:
              email: "clinician@hospital.org"
              password: "Secur3Pass!"
      responses:
        '200':
          description: "Login successful"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/LoginResponse'
        '401':
          description: "Invalid credentials"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              example:
                error_code: "INVALID_CREDENTIALS"
                message: "Email or password is incorrect"

  # ─────────────────────────────────────────────────
  # PRIOR AUTH CASES
  # ─────────────────────────────────────────────────

  /agentic-platform/prior-auths:
    post:
      tags: [Prior Auth]
      summary: "Submit a batch of prior authorization requests"
      description: |
        Accepts a batch of PA cases for a single portal. Each case is validated,
        persisted to the database, and published to GCP Pub/Sub for processing.

        **Idempotency:** If a case_ref_id already exists and is in a terminal state
        (APPROVED/DENIED/FAILED), it is rejected with a 409. If it is in PENDING state
        (never processed), it is accepted and re-queued. This allows safe retries.

        **Processing:** Cases are processed asynchronously. The response confirms
        acceptance — not completion. Poll GET /prior-auths/requests for status.
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/BatchSubmitRequest'
            example:
              batch_id: "BATCH-2026-09-001"
              portal_id: "availity"
              cases:
                - case_ref_id: "CASE-2026-09-001-001"
                  patient_data:
                    first_name: "Jane"
                    last_name: "Doe"
                    date_of_birth: "1985-04-23"
                    member_id: "UHC1234567890"
                    group_id: "GRP-98765"
                    relationship_to_subscriber: "SELF"
                  clinical_data:
                    procedure_codes:
                      - code: "70553"
                        description: "MRI brain with contrast"
                    diagnosis_codes: ["G35"]
                    rendering_npi: "1234567890"
                    rendering_provider_name: "Dr. Sarah Smith"
                    facility_npi: "0987654321"
                    facility_name: "City Medical Center"
                    start_date_of_service: "2026-10-01"
                    urgency: "ROUTINE"
      responses:
        '201':
          description: "Batch accepted for processing"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/BatchSubmitResponse'
              example:
                batch_id: "BATCH-2026-09-001"
                case_count: 1
                status: "accepted"
                accepted_cases: ["CASE-2026-09-001-001"]
                rejected_cases: []
                created_at: "2026-09-03T10:00:00Z"
        '400':
          description: "Invalid request (missing required fields)"
        '401':
          description: "Unauthorized"
        '404':
          description: "portal_id not found"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              example:
                error_code: "PORTAL_NOT_FOUND"
                message: "No portal configured for id: availity"
        '422':
          description: "Validation error (malformed JSON or field constraints)"

  /agentic-platform/prior-auths/requests:
    get:
      tags: [Prior Auth]
      summary: "List all prior authorization cases"
      description: "Returns a paginated list of PA cases with optional filters."
      parameters:
        - name: status
          in: query
          schema:
            $ref: '#/components/schemas/CaseStatus'
          description: "Filter by case status"
        - name: portal_id
          in: query
          schema:
            type: string
          description: "Filter by portal"
        - name: batch_id
          in: query
          schema:
            type: string
          description: "Filter by batch"
        - name: from
          in: query
          schema:
            type: string
            format: date-time
          description: "Filter cases created after this timestamp"
          example: "2026-09-01T00:00:00Z"
        - name: to
          in: query
          schema:
            type: string
            format: date-time
          description: "Filter cases created before this timestamp"
          example: "2026-09-03T23:59:59Z"
        - name: page
          in: query
          schema:
            type: integer
            default: 1
            minimum: 1
        - name: limit
          in: query
          schema:
            type: integer
            default: 50
            minimum: 1
            maximum: 200
        - name: sort_by
          in: query
          schema:
            type: string
            enum: [created_at, updated_at, status]
            default: created_at
        - name: sort_dir
          in: query
          schema:
            type: string
            enum: [asc, desc]
            default: desc
      responses:
        '200':
          description: "List of PA cases"
          content:
            application/json:
              schema:
                type: object
                properties:
                  cases:
                    type: array
                    items:
                      $ref: '#/components/schemas/CaseDetail'
                  pagination:
                    $ref: '#/components/schemas/PaginationMeta'

  /agentic-platform/prior-auths/{case_ref_id}:
    get:
      tags: [Prior Auth]
      summary: "Get a single PA case by reference ID"
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
          example: "CASE-2026-09-001-001"
      responses:
        '200':
          description: "Case details"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/CaseDetail'
        '404':
          description: "Case not found"

  /agentic-platform/prior-auths/{case_ref_id}/status:
    patch:
      tags: [Prior Auth]
      summary: "Update a case status (internal use — called by browser-agent via N8N)"
      description: "Updates the case status and outcome fields. Used by browser-agent after submission."
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CaseStatusUpdateRequest'
            example:
              status: "APPROVED"
              outcome: "APPROVED"
              pa_reference_number: "PA-UHC-2026-123456"
              outcome_details: "Approved for 1 unit of CPT 70553"
      responses:
        '200':
          description: "Status updated"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/CaseDetail'
        '404':
          description: "Case not found"
        '409':
          description: "Invalid status transition"

  /agentic-platform/prior-auths/{case_ref_id}/cancel:
    post:
      tags: [Prior Auth]
      summary: "Cancel a pending or in-progress case"
      description: "Cancels a case if it hasn't been submitted yet. Cases in SUBMITTED/APPROVED/DENIED cannot be cancelled."
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Case cancelled"
        '409':
          description: "Cannot cancel — case already in terminal state"

  # ─────────────────────────────────────────────────
  # RECIPES
  # ─────────────────────────────────────────────────

  /agentic-platform/prior-auths/recipes/{portal_id}:
    get:
      tags: [Recipes]
      summary: "Get the portal recipe for a given portal"
      description: |
        Returns the YAML recipe for a payer portal. Called by browser-agent at session start.
        Checks the database first; falls back to bundled YAML files if not found in DB.
        Response is LRU-cached in the browser-agent for the session duration.
      security: []               # Internal endpoint — no JWT (network policy restricts access)
      parameters:
        - name: portal_id
          in: path
          required: true
          schema:
            type: string
          example: "availity"
      responses:
        '200':
          description: "Portal recipe"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/PortalRecipeResponse'
        '404':
          description: "No recipe found for this portal"

    put:
      tags: [Recipes]
      summary: "Create or update a portal recipe"
      description: "Uploads or updates a recipe YAML for a portal. ADMIN role required."
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [portal_id, recipe_yaml]
              properties:
                portal_id:   { type: string }
                recipe_yaml: { type: string, description: "Full YAML content" }
                version:     { type: string, example: "1.1" }
      responses:
        '200':
          description: "Recipe updated"
        '201':
          description: "Recipe created"

  # ─────────────────────────────────────────────────
  # PORTAL CREDENTIALS (Secrets)
  # ─────────────────────────────────────────────────

  /portal-secret:
    post:
      tags: [Portal Credentials]
      summary: "Register portal credentials in GCP Secret Manager"
      description: "Stores username/password in Secret Manager and records the reference in the DB. ADMIN role required."
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/PortalSecretRequest'
      responses:
        '201':
          description: "Credentials registered"
          content:
            application/json:
              schema:
                type: object
                properties:
                  credential_id:    { type: string, format: uuid }
                  credential_alias: { type: string }
                  secret_path:      { type: string }

  /portal-secret/{portal_id}:
    get:
      tags: [Portal Credentials]
      summary: "List registered credentials for a portal (metadata only — no secrets returned)"
      parameters:
        - name: portal_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Credential metadata list"
          content:
            application/json:
              schema:
                type: array
                items:
                  type: object
                  properties:
                    credential_id:    { type: string, format: uuid }
                    credential_alias: { type: string }
                    is_active:        { type: boolean }
                    created_at:       { type: string, format: date-time }

    delete:
      tags: [Portal Credentials]
      summary: "Deactivate a credential (does not delete from Secret Manager)"
      parameters:
        - name: portal_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '204':
          description: "Credential deactivated"

  # ─────────────────────────────────────────────────
  # DASHBOARD
  # ─────────────────────────────────────────────────

  /dashboard/run-volume:
    get:
      tags: [Dashboard]
      summary: "Get PA submission run volume over time"
      parameters:
        - name: from
          in: query
          required: true
          schema:
            type: string
            format: date
          example: "2026-09-01"
        - name: to
          in: query
          required: true
          schema:
            type: string
            format: date
          example: "2026-09-03"
        - name: group_by
          in: query
          schema:
            type: string
            enum: [hour, day, week, month]
            default: day
        - name: portal_id
          in: query
          schema:
            type: string
          description: "Filter to specific portal"
      responses:
        '200':
          description: "Run volume data"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/RunVolumeResponse'

  /dashboard/llm-cost:
    get:
      tags: [Dashboard]
      summary: "Get LLM API cost breakdown"
      parameters:
        - name: from
          in: query
          schema:
            type: string
            format: date
          example: "2026-09-01"
        - name: to
          in: query
          schema:
            type: string
            format: date
          example: "2026-09-03"
        - name: portal_id
          in: query
          schema:
            type: string
      responses:
        '200':
          description: "LLM cost data"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/LLMCostResponse'

  /dashboard/case-stats:
    get:
      tags: [Dashboard]
      summary: "Get aggregate case statistics (counts by status)"
      responses:
        '200':
          description: "Case stats"
          content:
            application/json:
              schema:
                type: object
                properties:
                  total:        { type: integer }
                  by_status:
                    type: object
                    additionalProperties:
                      type: integer
                    example:
                      APPROVED: 145
                      DENIED: 23
                      IN_PROGRESS: 8
                      PENDING: 5
                      FAILED: 2
                  by_portal:
                    type: object
                    additionalProperties:
                      type: integer
                    example:
                      availity: 100
                      navinet: 73

  # ─────────────────────────────────────────────────
  # PAYER PROMPTS
  # ─────────────────────────────────────────────────

  /payer-prompts/{portal_id}:
    get:
      tags: [Payer Prompts]
      summary: "Get LLM prompt overrides for a portal"
      parameters:
        - name: portal_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Payer prompts"
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/PayerPromptRequest'

    put:
      tags: [Payer Prompts]
      summary: "Create or update LLM prompt override for a portal"
      parameters:
        - name: portal_id
          in: path
          required: true
          schema:
            type: string
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/PayerPromptRequest'
      responses:
        '200':
          description: "Prompt updated"
        '201':
          description: "Prompt created"

  # ─────────────────────────────────────────────────
  # HITL (for dashboard visibility)
  # ─────────────────────────────────────────────────

  /hitl/tasks:
    get:
      tags: [HITL]
      summary: "List HITL tasks (for dashboard — operator view)"
      parameters:
        - name: status
          in: query
          schema:
            type: string
            enum: [PENDING, RESOLVED, EXPIRED]
          description: "Default: PENDING"
        - name: limit
          in: query
          schema:
            type: integer
            default: 50
      responses:
        '200':
          description: "HITL task list"
          content:
            application/json:
              schema:
                type: object
                properties:
                  tasks:
                    type: array
                    items:
                      $ref: '#/components/schemas/HITLTask'
                  total: { type: integer }

  # ─────────────────────────────────────────────────
  # SSE ALERTS
  # ─────────────────────────────────────────────────

  /alert-sse:
    get:
      tags: [Alerts]
      summary: "Server-Sent Events stream for real-time alerts"
      description: |
        Opens a persistent SSE connection. Events are pushed when:
        - A case status changes
        - A HITL task is created (agent needs help)
        - A case completes (approved/denied)
        - A pod crash is detected
        
        Client must handle reconnection (EventSource API does this automatically).
      responses:
        '200':
          description: "SSE stream (text/event-stream)"
          content:
            text/event-stream:
              schema:
                type: string
                description: "SSE format: event: {type}\\ndata: {JSON}\\n\\n"
              example: |
                event: case_status_change
                data: {"case_ref_id":"CASE-001","status":"APPROVED","portal_id":"availity"}

                event: hitl_required
                data: {"case_ref_id":"CASE-002","task_id":"uuid","message":"Unexpected popup detected"}

  # ─────────────────────────────────────────────────
  # SYSTEM
  # ─────────────────────────────────────────────────

  /health:
    get:
      tags: [System]
      summary: "Health check"
      security: []
      responses:
        '200':
          description: "Service healthy"
          content:
            application/json:
              schema:
                type: object
                properties:
                  status:   { type: string, example: "ok" }
                  db:       { type: string, example: "ok" }
                  redis:    { type: string, example: "ok" }
                  pubsub:   { type: string, example: "ok" }
                  version:  { type: string, example: "1.0.0" }
        '503':
          description: "Service unhealthy"
          content:
            application/json:
              schema:
                type: object
                properties:
                  status: { type: string, example: "degraded" }
                  db:     { type: string, example: "error: connection refused" }
                  redis:  { type: string, example: "ok" }
```

---

## 4. Service 2: planner (Internal)

**Base URL:** `http://planner.agentic-app.svc.cluster.local:8001/api/v1`
**Auth:** None (internal network policy restricts access)

```yaml
openapi: "3.0.3"
info:
  title: "AutoAuth Agent — Planner Service"
  version: "1.0.0"

paths:

  /agentic-platform/prior-auths/planner-preauth:
    post:
      tags: [Pre-Auth Planning]
      summary: "Manually trigger pre-auth planning for a single case"
      description: |
        Directly triggers the N8N submission webhook for a case.
        Normally called by the PlannerConsumer (Pub/Sub), but exposed as
        an HTTP endpoint for manual re-triggering or testing.
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [case_ref_id, portal_id]
              properties:
                case_ref_id:
                  type: string
                  example: "CASE-2026-09-001-001"
                portal_id:
                  type: string
                  example: "availity"
                batch_id:
                  type: string
                  example: "BATCH-2026-09-001"
                force:
                  type: boolean
                  default: false
                  description: "If true, bypass deduplication cache and re-trigger even if already processing"
      responses:
        '202':
          description: "Pre-auth planning triggered"
          content:
            application/json:
              schema:
                type: object
                properties:
                  case_ref_id:    { type: string }
                  triggered:      { type: boolean }
                  n8n_webhook:    { type: string }
                  from_cache:     { type: boolean, description: "True if case was already cached (dedup hit)" }
        '404':
          description: "Case not found in database"
        '409':
          description: "Case already in a terminal state"

  /retrigger/{case_ref_id}:
    post:
      tags: [Retrigger]
      summary: "Re-trigger a failed or expired case"
      description: |
        Re-queues a case that is in FAILED, CRASHED, or PENDING state.
        Increments retry_count. Cases with retry_count >= 3 are not re-triggered.
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      requestBody:
        content:
          application/json:
            schema:
              type: object
              properties:
                reason:
                  type: string
                  description: "Why this case is being re-triggered"
                  example: "Pod crashed during execution"
      responses:
        '202':
          description: "Case re-queued"
          content:
            application/json:
              schema:
                type: object
                properties:
                  case_ref_id:  { type: string }
                  retry_count:  { type: integer }
                  status:       { type: string, example: "PENDING" }
        '409':
          description: "Max retries exceeded or case not in retriggerable state"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              example:
                error_code: "MAX_RETRIES_EXCEEDED"
                message: "Case has already been retried 3 times"

  /handle-mfa/{case_ref_id}:
    post:
      tags: [MFA]
      summary: "Submit OTP for an MFA-blocked case"
      description: |
        Called by the ADK chatbot when an operator provides an OTP.
        Forwards the OTP to the browser-agent that is waiting on this case.
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [otp]
              properties:
                otp:
                  type: string
                  description: "One-time password from the operator"
                  example: "483921"
                  minLength: 4
                  maxLength: 10
      responses:
        '200':
          description: "OTP delivered to browser-agent"
          content:
            application/json:
              schema:
                type: object
                properties:
                  case_ref_id: { type: string }
                  delivered:   { type: boolean }
        '404':
          description: "No active MFA session for this case"
        '410':
          description: "MFA session expired"

  /sse/cases/{case_ref_id}/logs:
    get:
      tags: [SSE]
      summary: "Stream live case logs via SSE"
      description: "Streams log entries from Redis Streams for a specific case in real time."
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
        - name: since_id
          in: query
          schema:
            type: string
          description: "Redis Stream entry ID to start reading from (0-0 for all)"
          default: "0-0"
      responses:
        '200':
          description: "SSE log stream"
          content:
            text/event-stream:
              schema:
                type: string
              example: |
                event: log_entry
                data: {"stream_id":"1693737600000-0","level":"INFO","step":"fill_member_id","message":"Filled member ID","timestamp":"2026-09-03T10:00:00Z"}

                event: log_entry
                data: {"stream_id":"1693737601000-0","level":"INFO","step":"click_next","message":"Clicked Next button"}

  /sync-case-logs/{case_ref_id}:
    post:
      tags: [Logs]
      summary: "Flush Redis stream logs to PostgreSQL for a case"
      description: "Moves all log entries from Redis Stream into prior_auth_case_logs table. Called after case completion."
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Logs synced"
          content:
            application/json:
              schema:
                type: object
                properties:
                  case_ref_id:    { type: string }
                  entries_synced: { type: integer }

  /health:
    get:
      tags: [System]
      summary: "Health check"
      responses:
        '200':
          description: "Healthy"
          content:
            application/json:
              schema:
                type: object
                properties:
                  status:      { type: string, example: "ok" }
                  pubsub:      { type: string, example: "ok" }
                  redis:       { type: string, example: "ok" }
                  consumer:    { type: string, example: "running" }
```

---

## 5. Service 3: control-plane (Internal)

**Base URL:** `http://control-plane.agentic-app.svc.cluster.local:8080/api/v1`
**Auth:** None (internal network policy)

```yaml
openapi: "3.0.3"
info:
  title: "AutoAuth Agent — Control Plane"
  version: "1.0.0"

paths:

  /sessions:
    post:
      tags: [Sessions]
      summary: "Create a browser session on an available worker"
      description: |
        Called by the ControlPlaneSessionConsumer when a new case arrives.
        Selects an idle browser-agent worker from Redis, marks it busy,
        calls browser-agent POST /sessions, then stores session metadata.
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [case_ref_id, portal_id]
              properties:
                case_ref_id:
                  type: string
                portal_id:
                  type: string
                execution_mode:
                  type: string
                  enum: [recipe, llm]
                  default: recipe
                  description: "Execution mode for the browser agent"
                patient_data:
                  $ref: '#/components/schemas/PatientData'
                clinical_data:
                  $ref: '#/components/schemas/ClinicalData'
                credential_key:
                  type: string
                  description: "Secret Manager key for portal credentials"
                  example: "autoauth/prod/portal/availity-username"
      responses:
        '201':
          description: "Session created"
          content:
            application/json:
              schema:
                type: object
                properties:
                  session_id:   { type: string }
                  case_ref_id:  { type: string }
                  pod_id:       { type: string }
                  pod_ip:       { type: string }
                  vnc_url:      { type: string, description: "VNC viewer URL via control-plane proxy" }
                  display_slot: { type: integer }
        '503':
          description: "No idle workers available"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              example:
                error_code: "NO_WORKERS_AVAILABLE"
                message: "All browser-agent workers are busy. Request will be retried via Pub/Sub."

    get:
      tags: [Sessions]
      summary: "List all active workers and their sessions"
      description: "Returns the state of all browser-agent pods in the Redis worker pool."
      responses:
        '200':
          description: "Worker list"
          content:
            application/json:
              schema:
                type: object
                properties:
                  workers:
                    type: array
                    items:
                      type: object
                      properties:
                        pod_id:           { type: string }
                        pod_ip:           { type: string }
                        pool_status:      { type: string, enum: [idle, busy, cooling] }
                        active_sessions:  { type: integer }
                        max_slots:        { type: integer }
                        heartbeat_age_s:  { type: integer, description: "Seconds since last heartbeat" }
                  totals:
                    type: object
                    properties:
                      idle:    { type: integer }
                      busy:    { type: integer }
                      cooling: { type: integer }
                      total:   { type: integer }

  /sessions/{case_ref_id}:
    delete:
      tags: [Sessions]
      summary: "Terminate a session and release the worker back to idle pool"
      description: |
        Calls DELETE /sessions/{session_id} on the browser-agent pod to
        kill the browser, VNC, and Xvfb processes. Then moves the worker
        from BUSY back to COOLING → IDLE in Redis.
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '204':
          description: "Session terminated"
        '404':
          description: "No active session found for this case"

  /sessions/{case_ref_id}/vnc/vnc.html:
    get:
      tags: [VNC]
      summary: "Proxy — serve noVNC viewer HTML for a case's session"
      description: "Fetches the noVNC HTML from the browser-agent pod and returns it. For dashboard embedding."
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "noVNC HTML page"
          content:
            text/html:
              schema:
                type: string

  /sessions/{case_ref_id}/vnc/{path}:
    get:
      tags: [VNC]
      summary: "Proxy — serve noVNC static assets (JS, CSS, images)"
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
        - name: path
          in: path
          required: true
          schema:
            type: string
          description: "Asset path relative to noVNC root"
      responses:
        '200':
          description: "Static asset"

  /sessions/{case_ref_id}/vnc/websockify:
    get:
      tags: [VNC]
      summary: "WebSocket proxy — relay VNC WebSocket traffic to browser-agent"
      description: |
        Upgrades to WebSocket. Proxies all frames between the dashboard browser
        and the websockify process inside the browser-agent pod.
        The dashboard uses this to display the live browser session via noVNC.
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '101':
          description: "WebSocket upgrade"

  /clear-all-pools:
    post:
      tags: [Admin]
      summary: "DANGER — Clear all Redis worker pools"
      description: |
        **Use with extreme caution.** Removes all entries from idle/busy/cooling
        Redis sets. Used for emergency recovery when Redis state is corrupted.
        Will cause in-flight cases to lose their worker references.
      requestBody:
        content:
          application/json:
            schema:
              type: object
              required: [confirm]
              properties:
                confirm:
                  type: string
                  enum: ["YES_CLEAR_ALL_POOLS"]
                  description: "Must be exactly 'YES_CLEAR_ALL_POOLS' to confirm"
      responses:
        '200':
          description: "Pools cleared"
          content:
            application/json:
              schema:
                type: object
                properties:
                  cleared_keys: { type: integer }
                  message:      { type: string }

  /hitl/tasks:
    get:
      tags: [HITL]
      summary: "List pending HITL tasks (control-plane view)"
      parameters:
        - name: status
          in: query
          schema:
            type: string
            enum: [PENDING, RESOLVED, EXPIRED]
          default: PENDING
      responses:
        '200':
          description: "HITL task list"

  /hitl/{task_id}/resolve:
    post:
      tags: [HITL]
      summary: "Mark a HITL task as resolved"
      description: "Called by the dashboard when an operator has manually intervened."
      parameters:
        - name: task_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                resolution:
                  type: string
                  description: "What the operator did"
                  example: "Closed unexpected popup, portal is now ready"
      responses:
        '200':
          description: "Task resolved"

  /hitl/{task_id}/resume:
    post:
      tags: [HITL]
      summary: "Signal the browser-agent to resume after HITL resolution"
      description: "Calls POST /hitl/resume/{case_ref_id} on the relevant browser-agent pod."
      parameters:
        - name: task_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      responses:
        '200':
          description: "Resume signal sent to browser-agent"
        '404':
          description: "Task not found or no active session for this case"

  /tracking/sessions:
    post:
      tags: [Tracking]
      summary: "Create a tracking session (post-submission status check)"
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [case_ref_id, portal_id, pa_reference_number]
              properties:
                case_ref_id:          { type: string }
                portal_id:            { type: string }
                pa_reference_number:  { type: string }
                credential_key:       { type: string }
      responses:
        '201':
          description: "Tracking session created"
          content:
            application/json:
              schema:
                type: object
                properties:
                  tracking_session_id: { type: string }
                  pod_id:              { type: string }

  /tracking/sessions/{case_ref_id}:
    delete:
      tags: [Tracking]
      summary: "Terminate a tracking session"
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '204':
          description: "Tracking session terminated"

  /health:
    get:
      tags: [System]
      summary: "Health check"
      responses:
        '200':
          description: "Healthy"
          content:
            application/json:
              schema:
                type: object
                properties:
                  status:       { type: string }
                  redis:        { type: string }
                  consumer:     { type: string }
                  idle_workers: { type: integer }
```

---

## 6. Service 4: browser-agent (Internal)

**Base URL:** `http://{pod-ip}:8081/api/v1`
**Auth:** None (accessed directly by IP from control-plane — within cluster)

```yaml
openapi: "3.0.3"
info:
  title: "AutoAuth Agent — Browser Agent"
  version: "1.0.0"
  description: |
    Internal service running on each browser-agent pod. Manages browser
    sessions (Playwright + Xvfb + VNC) and executes prior auth recipes.

paths:

  /sessions:
    post:
      tags: [Sessions]
      summary: "Create a browser session on this pod"
      description: |
        Allocates a display slot, launches Xvfb, x11vnc, websockify, and
        a Playwright browser instance. Returns session metadata including ports.
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [case_ref_id, portal_id]
              properties:
                case_ref_id:
                  type: string
                portal_id:
                  type: string
                display_slot:
                  type: integer
                  minimum: 1
                  maximum: 5
                  description: "Requested slot (1–5). If omitted, auto-assigned."
      responses:
        '201':
          description: "Session created"
          content:
            application/json:
              schema:
                type: object
                properties:
                  session_id:
                    type: string
                    description: "Unique session ID for this browser instance"
                  case_ref_id:  { type: string }
                  display_slot: { type: integer }
                  display_num:  { type: integer, example: 11, description: "Xvfb display number (:11)" }
                  vnc_port:     { type: integer, example: 5911 }
                  web_port:     { type: integer, example: 6081, description: "websockify HTTP port" }
                  vnc_url:      { type: string, example: "http://10.1.2.3:6081/vnc.html" }
        '409':
          description: "All display slots occupied (max 5 sessions per pod)"
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ErrorResponse'
              example:
                error_code: "NO_DISPLAY_SLOTS"
                message: "All 5 display slots are occupied on this pod"

    get:
      tags: [Sessions]
      summary: "List active sessions on this pod"
      responses:
        '200':
          description: "Active sessions"
          content:
            application/json:
              schema:
                type: object
                properties:
                  sessions:
                    type: array
                    items:
                      type: object
                      properties:
                        session_id:   { type: string }
                        case_ref_id:  { type: string }
                        display_slot: { type: integer }
                        status:       { type: string, enum: [active, running, completed, error] }
                        started_at:   { type: string, format: date-time }
                  active_count: { type: integer }
                  max_slots:    { type: integer, example: 5 }

  /sessions/{session_id}:
    delete:
      tags: [Sessions]
      summary: "Terminate a session and clean up all processes"
      description: |
        Kills the Playwright browser, Xvfb, x11vnc, and websockify processes
        for the given session. Frees the display slot for reuse.
      parameters:
        - name: session_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '204':
          description: "Session terminated"
        '404':
          description: "Session not found"

  /drain:
    post:
      tags: [Sessions]
      summary: "Signal pod to stop accepting new sessions (graceful shutdown)"
      description: "Called by preStop hook during KEDA scale-down. Sets a drain flag; existing sessions complete normally."
      responses:
        '200':
          description: "Drain signal accepted"
          content:
            application/json:
              schema:
                type: object
                properties:
                  draining:         { type: boolean, example: true }
                  active_sessions:  { type: integer }

  /agents:
    post:
      tags: [Agents]
      summary: "Start the automation agent for a session"
      description: |
        Starts either RecipeRunner (deterministic) or LLM Agent (Gemini-driven)
        in a background thread/task. Returns immediately with agent_id.
        
        The agent runs asynchronously and calls the N8N completion webhook when done.
        Monitor status via GET /agents/{agent_id}/status or Redis log stream.
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [case_ref_id, session_id, portal_id]
              properties:
                case_ref_id:
                  type: string
                session_id:
                  type: string
                portal_id:
                  type: string
                execution_mode:
                  type: string
                  enum: [recipe, llm]
                  default: recipe
                patient_data:
                  $ref: '#/components/schemas/PatientData'
                clinical_data:
                  $ref: '#/components/schemas/ClinicalData'
                credential_key:
                  type: string
                  description: "GCP Secret Manager key prefix for portal credentials"
                  example: "autoauth/prod/portal/availity"
                payer_prompt_override:
                  type: string
                  nullable: true
                  description: "Custom LLM system prompt (LLM mode only)"
      responses:
        '202':
          description: "Agent started"
          content:
            application/json:
              schema:
                type: object
                properties:
                  agent_id:       { type: string }
                  case_ref_id:    { type: string }
                  session_id:     { type: string }
                  execution_mode: { type: string }
                  status:         { type: string, example: "running" }
                  started_at:     { type: string, format: date-time }
        '404':
          description: "Session not found"
        '409':
          description: "Agent already running for this session"

  /agents/{agent_id}/status:
    get:
      tags: [Agents]
      summary: "Get current agent execution status"
      parameters:
        - name: agent_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Agent status"
          content:
            application/json:
              schema:
                type: object
                properties:
                  agent_id:         { type: string }
                  case_ref_id:      { type: string }
                  status:           { type: string, enum: [running, paused, completed, failed, stopped] }
                  current_step:     { type: string, nullable: true, description: "Name of the step currently executing" }
                  steps_completed:  { type: integer }
                  total_steps:      { type: integer, nullable: true }
                  execution_mode:   { type: string }
                  started_at:       { type: string, format: date-time }
                  elapsed_seconds:  { type: integer }
                  last_error:       { type: string, nullable: true }

  /agents/{agent_id}/stop:
    post:
      tags: [Agents]
      summary: "Stop a running agent immediately"
      description: "Sets a stop flag. RecipeRunner checks this between steps and exits gracefully."
      parameters:
        - name: agent_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Stop signal sent"

  /agents/{agent_id}/pause:
    post:
      tags: [Agents]
      summary: "Pause a running agent (for debugging)"
      parameters:
        - name: agent_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Agent paused"

  /agents/{agent_id}/resume:
    post:
      tags: [Agents]
      summary: "Resume a paused agent"
      parameters:
        - name: agent_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Agent resumed"

  /hitl/mfa/{case_ref_id}:
    post:
      tags: [HITL]
      summary: "Deliver OTP to the agent waiting for MFA"
      description: |
        Called by the ADK chatbot handler (planner) when an operator provides an OTP.
        Puts the OTP into the asyncio.Queue that RecipeRunner is blocked on.
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [otp]
              properties:
                otp:
                  type: string
                  description: "One-time password entered by the operator"
                  example: "483921"
      responses:
        '200':
          description: "OTP delivered to waiting agent"
          content:
            application/json:
              schema:
                type: object
                properties:
                  case_ref_id: { type: string }
                  delivered:   { type: boolean }
        '404':
          description: "No agent waiting for MFA on this case"
        '410':
          description: "MFA wait expired (agent timed out)"

  /hitl/resume/{case_ref_id}:
    post:
      tags: [HITL]
      summary: "Resume a HITL-paused agent after operator intervention"
      description: |
        Called by control-plane after operator marks HITL task as resolved.
        Sets the threading.Event that RecipeRunner is blocked on.
      parameters:
        - name: case_ref_id
          in: path
          required: true
          schema:
            type: string
      requestBody:
        content:
          application/json:
            schema:
              type: object
              properties:
                resolution_note:
                  type: string
                  description: "What the operator did (for logging)"
      responses:
        '200':
          description: "Resume signal delivered"
        '404':
          description: "No agent paused for HITL on this case"

  /health:
    get:
      tags: [System]
      summary: "Health check"
      responses:
        '200':
          description: "Healthy"
          content:
            application/json:
              schema:
                type: object
                properties:
                  status:           { type: string, example: "ok" }
                  redis:            { type: string, example: "ok" }
                  active_sessions:  { type: integer }
                  display_slots:
                    type: object
                    properties:
                      total:     { type: integer, example: 5 }
                      in_use:    { type: integer, example: 2 }
                      available: { type: integer, example: 3 }
                  pool_status:      { type: string, enum: [idle, busy, draining] }
                  draining:         { type: boolean }
```

---

## 7. Service 5: tracking-agent (Internal)

**Base URL:** `http://{pod-ip}:8083/api/v1`
**Auth:** None (internal)

```yaml
openapi: "3.0.3"
info:
  title: "AutoAuth Agent — Tracking Agent"
  version: "1.0.0"

paths:

  /sessions:
    post:
      tags: [Tracking Sessions]
      summary: "Create a tracking browser session"
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [case_ref_id, portal_id, pa_reference_number]
              properties:
                case_ref_id:          { type: string }
                portal_id:            { type: string }
                pa_reference_number:  { type: string, example: "PA-UHC-2026-123456" }
                credential_key:       { type: string }
      responses:
        '201':
          description: "Tracking session created"
          content:
            application/json:
              schema:
                type: object
                properties:
                  session_id:   { type: string }
                  case_ref_id:  { type: string }
                  display_slot: { type: integer }
                  status:       { type: string, example: "created" }

  /sessions/{session_id}:
    delete:
      tags: [Tracking Sessions]
      summary: "Terminate a tracking session"
      parameters:
        - name: session_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '204':
          description: "Session terminated"

  /sessions/{session_id}/status:
    get:
      tags: [Tracking Sessions]
      summary: "Get tracking result for a session"
      description: |
        Returns the PA status as extracted from the payer portal.
        Populated after the tracking agent completes its run.
      parameters:
        - name: session_id
          in: path
          required: true
          schema:
            type: string
      responses:
        '200':
          description: "Tracking result"
          content:
            application/json:
              schema:
                type: object
                properties:
                  session_id:          { type: string }
                  case_ref_id:         { type: string }
                  pa_reference_number: { type: string }
                  portal_status:
                    type: string
                    description: "Raw status string from portal"
                    example: "Approved"
                  normalized_status:
                    type: string
                    enum: [APPROVED, DENIED, PENDING, PENDING_INFO, NOT_FOUND]
                    example: "APPROVED"
                  checked_at:          { type: string, format: date-time }
                  screenshot_url:      { type: string, nullable: true }

  /profile-cleanup:
    post:
      tags: [Maintenance]
      summary: "Clean up stale browser profiles on this pod"
      description: "Removes Chromium profile directories for sessions that no longer exist."
      responses:
        '200':
          description: "Cleanup result"
          content:
            application/json:
              schema:
                type: object
                properties:
                  profiles_removed: { type: integer }
                  bytes_freed:      { type: integer }

  /health:
    get:
      tags: [System]
      summary: "Health check"
      responses:
        '200':
          description: "Healthy"
          content:
            application/json:
              schema:
                type: object
                properties:
                  status:          { type: string }
                  active_sessions: { type: integer }
                  pool_status:     { type: string }
```

---

## 8. Webhook Contracts (N8N)

All webhooks are `POST` requests. N8N receives these at `http://n8n:5678/webhook/{path}`.
All payloads include `X-AutoAuth-Signature` header (HMAC-SHA256).

```yaml
# ── Webhook 1: PA Submission (planner → N8N) ──────────────────────────────
POST /webhook/preauth
Content-Type: application/json
X-AutoAuth-Signature: {hmac_sha256_hex}

Request body:
  type: object
  required: [case_ref_id, portal_id]
  properties:
    case_ref_id:    { type: string }
    batch_id:       { type: string }
    portal_id:      { type: string }
    priority:       { type: string, enum: [NORMAL, HIGH, URGENT] }
    patient_data:   { $ref: PatientData }
    clinical_data:  { $ref: ClinicalData }
    credential_key: { type: string }
    timestamp:      { type: string, format: date-time }

Expected N8N response:
  200 OK
  { "accepted": true, "workflow_id": "uuid" }

# ── Webhook 2: Agent Trigger (control-plane → N8N) ────────────────────────
POST /webhook/agents
Content-Type: application/json

Request body:
  type: object
  required: [case_ref_id, session_id, browser_agent_url]
  properties:
    case_ref_id:       { type: string }
    session_id:        { type: string }
    browser_agent_url: { type: string, description: "http://{pod-ip}:8081" }
    execution_mode:    { type: string, enum: [recipe, llm] }
    portal_id:         { type: string }
    patient_data:      { $ref: PatientData }
    clinical_data:     { $ref: ClinicalData }
    credential_key:    { type: string }

Expected N8N response:
  200 OK
  { "triggered": true }

# ── Webhook 3: HITL Request (browser-agent → N8N) ─────────────────────────
POST /webhook/hitl
Content-Type: application/json

Request body:
  type: object
  required: [case_ref_id, task_type, message]
  properties:
    case_ref_id:    { type: string }
    task_id:        { type: string, format: uuid }
    task_type:      { type: string, enum: [HITL, MFA] }
    message:        { type: string, description: "Human-readable description of what's needed" }
    screenshot_url: { type: string, nullable: true }
    portal_id:      { type: string }
    step_name:      { type: string, description: "Which recipe step triggered HITL" }
    vnc_url:        { type: string, description: "VNC viewer URL for operator to watch" }
    timestamp:      { type: string, format: date-time }

# ── Webhook 4: MFA Request (browser-agent → N8N) ──────────────────────────
POST /webhook/mfa
Content-Type: application/json

Request body:
  type: object
  required: [case_ref_id, portal_id]
  properties:
    case_ref_id:           { type: string }
    portal_id:             { type: string }
    mfa_type:              { type: string, enum: [SMS, EMAIL, AUTHENTICATOR_APP, PHONE_CALL] }
    credential_alias:      { type: string, description: "Which credential is being used" }
    otp_input_selector:    { type: string, description: "CSS selector where OTP should be typed" }
    timeout_seconds:       { type: integer, default: 300 }
    timestamp:             { type: string, format: date-time }

# ── Webhook 5: Completion (browser-agent → N8N) ───────────────────────────
POST /webhook/completed
Content-Type: application/json

Request body:
  type: object
  required: [case_ref_id, outcome]
  properties:
    case_ref_id:           { type: string }
    session_id:            { type: string }
    outcome:               { type: string, enum: [APPROVED, DENIED, PENDING_INFO, SUBMITTED, ERROR] }
    pa_reference_number:   { type: string, nullable: true }
    outcome_details:       { type: string, nullable: true }
    screenshot_url:        { type: string, nullable: true }
    execution_mode:        { type: string, enum: [recipe, llm] }
    steps_completed:       { type: integer }
    duration_seconds:      { type: integer }
    timestamp:             { type: string, format: date-time }

# ── Webhook 6: Log Summary (browser-agent → N8N) ──────────────────────────
POST /webhook/summary
Content-Type: application/json

Request body:
  type: object
  required: [case_ref_id, summary_text]
  properties:
    case_ref_id:      { type: string }
    summary_text:     { type: string, description: "LLM-generated summary of the agent's actions" }
    model_used:       { type: string, example: "gemini-1.5-flash" }
    tokens_used:      { type: integer }
    cost_usd:         { type: number }
    period_start:     { type: string, format: date-time }
    period_end:       { type: string, format: date-time }
    timestamp:        { type: string, format: date-time }

# ── Webhook 7: Status Capture (browser-agent / control-plane → N8N) ────────
POST /webhook/status-capture
Content-Type: application/json

Request body:
  type: object
  required: [case_ref_id, status]
  properties:
    case_ref_id:   { type: string }
    status:        { $ref: CaseStatus }
    reason:        { type: string, nullable: true, description: "Why the status changed" }
    source:        { type: string, enum: [browser_agent, control_plane, planner] }
    retry:         { type: boolean, default: false }
    timestamp:     { type: string, format: date-time }
```

---

## 9. SSE Event Contracts

All SSE events follow the format: `event: {type}\ndata: {JSON}\n\n`

```
Event: case_status_change
  Fired: Whenever a case changes status
  Data:
    case_ref_id:  string
    old_status:   CaseStatus
    new_status:   CaseStatus
    portal_id:    string
    timestamp:    ISO 8601

Event: hitl_required
  Fired: When agent pauses and needs human intervention
  Data:
    case_ref_id:    string
    task_id:        uuid
    task_type:      "HITL" | "MFA"
    message:        string
    vnc_url:        string
    screenshot_url: string | null
    timestamp:      ISO 8601

Event: case_completed
  Fired: When a case reaches APPROVED/DENIED/PENDING_INFO
  Data:
    case_ref_id:           string
    outcome:               "APPROVED" | "DENIED" | "PENDING_INFO" | "ERROR"
    pa_reference_number:   string | null
    portal_id:             string
    duration_seconds:      integer
    timestamp:             ISO 8601

Event: pod_crash_detected
  Fired: When control-plane detects a worker pod crash
  Data:
    pod_id:              string
    affected_case_refs:  string[]
    recovery_action:     "retrying" | "failed_max_retries"
    timestamp:           ISO 8601

Event: heartbeat
  Fired: Every 30 seconds (keep-alive to prevent SSE connection timeout)
  Data:
    active_workers:   integer
    pending_cases:    integer
    timestamp:        ISO 8601
```

---

## 10. Error Handling Standard

### 10.1 Error Response Envelope

```json
{
  "error_code": "PORTAL_NOT_FOUND",
  "message": "No portal configured for id: availity-test",
  "details": {
    "portal_id": "availity-test",
    "available_portals": ["availity", "navinet", "carecore"]
  },
  "trace_id": "abc123def456ghi789"
}
```

### 10.2 Standard Error Codes

```
AUTH_001  → TOKEN_MISSING        (no Authorization header)
AUTH_002  → TOKEN_EXPIRED        (JWT expired)
AUTH_003  → TOKEN_INVALID        (malformed JWT)
AUTH_004  → INSUFFICIENT_ROLE    (valid token, wrong role)
AUTH_005  → INVALID_CREDENTIALS  (login: wrong email/password)
AUTH_006  → EMAIL_ALREADY_EXISTS (register: duplicate email)

CASE_001  → CASE_NOT_FOUND
CASE_002  → CASE_ALREADY_EXISTS  (duplicate case_ref_id in terminal state)
CASE_003  → INVALID_STATUS_TRANSITION
CASE_004  → MAX_RETRIES_EXCEEDED
CASE_005  → CASE_NOT_CANCELLABLE

PORTAL_001 → PORTAL_NOT_FOUND
PORTAL_002 → RECIPE_NOT_FOUND
PORTAL_003 → CREDENTIAL_NOT_FOUND

WORKER_001 → NO_WORKERS_AVAILABLE
WORKER_002 → NO_DISPLAY_SLOTS    (all 5 slots occupied on pod)
WORKER_003 → AGENT_ALREADY_RUNNING

HITL_001  → NO_MFA_SESSION       (no agent waiting for OTP)
HITL_002  → MFA_EXPIRED          (OTP wait timed out)
HITL_003  → NO_HITL_SESSION      (no agent paused for HITL)

VALIDATION_ERROR → Pydantic validation failure (field-level details in `details`)
INTERNAL_ERROR   → Unexpected server error (500)
RATE_LIMITED     → Too many requests (429)
```

### 10.3 Validation Error Format (422)

```json
{
  "error_code": "VALIDATION_ERROR",
  "message": "Request validation failed",
  "details": {
    "fields": [
      {
        "field": "patient_data.member_id",
        "error": "field required"
      },
      {
        "field": "clinical_data.rendering_npi",
        "error": "string does not match regex '^[0-9]{10}$'"
      }
    ]
  },
  "trace_id": "xyz789"
}
```

---

## 11. Versioning Strategy

```
Current version: v1
URL prefix: /api/v1/

Version increment triggers:
  Patch (1.0.x): Bug fixes — no contract changes
  Minor (1.x.0): Additive changes — new optional fields, new endpoints
  Major (x.0.0): Breaking changes — removed fields, changed field types, removed endpoints

Breaking change policy:
  → New major version (v2) deployed alongside v1
  → v1 deprecated with 6-month notice
  → Deprecation header added: Deprecation: true, Sunset: 2027-03-01
  → Both versions run concurrently during migration period

Backwards-compatible changes (no version bump):
  → Adding optional fields to response bodies
  → Adding new optional query parameters
  → Adding new endpoints
  → Relaxing validation constraints

Non-backwards-compatible changes (require v2):
  → Removing fields from responses
  → Renaming fields
  → Changing field types
  → Changing required to optional or vice versa (in requests)
  → Changing HTTP method for an endpoint
  → Changing URL structure
```

---

## 12. Inter-Service Call Map

```
SERVICE DEPENDENCY GRAPH — who calls whom

External Client
  └──► api-server
         │
         │ Pub/Sub publish (Topic #1)
         ▼
       [GCP Pub/Sub Topic #1]
         │
         │ Pub/Sub subscribe
         ▼
       planner
         │
         │ POST /webhook/preauth
         ▼
        N8N
         │
         │ Pub/Sub publish (Topic #2)
         ▼
       [GCP Pub/Sub Topic #2]
         │
         │ Pub/Sub subscribe
         ▼
       control-plane
         │                           │
         │ POST /sessions            │ POST /sessions (tracking)
         ▼                           ▼
       browser-agent              tracking-agent
         │
         ├── GET /recipes/{id}     ──► api-server
         ├── PATCH /status         ──► api-server (via N8N)
         │
         ├── POST /webhook/hitl    ──► N8N
         ├── POST /webhook/mfa     ──► N8N
         ├── POST /webhook/completed ► N8N
         ├── POST /webhook/summary ──► N8N
         └── POST /webhook/status  ──► N8N
                                        │
         N8N ──────────────────────────►│
                │                       │
                │ POST /handle-mfa ──► planner
                │ POST /hitl/resume ─► control-plane ──► browser-agent
                └─ PATCH /status ───► api-server

CALL SUMMARY TABLE:
┌────────────────┬─────────────────────────────────────────────────────────┐
│ Caller         │ Calls                                                   │
├────────────────┼─────────────────────────────────────────────────────────┤
│ api-server     │ GCP Pub/Sub (publish Topic #1)                          │
│ planner        │ N8N /webhook/preauth, api-server /recipes, GCP Pub/Sub  │
│ control-plane  │ browser-agent /sessions, tracking-agent /sessions       │
│                │ GCP Pub/Sub (subscribe Topic #2)                        │
│ browser-agent  │ api-server /recipes/{id}, N8N (5 webhooks)              │
│                │ GCP Secret Manager, GCP Cloud Storage, Vertex AI        │
│ tracking-agent │ GCP Secret Manager, N8N /webhook/status-capture         │
│ N8N            │ browser-agent /agents, planner /handle-mfa,             │
│                │ control-plane /hitl/resume, api-server /status          │
└────────────────┴─────────────────────────────────────────────────────────┘
```

---

*Document Status: DRAFT — OpenAPI specs to be exported as separate .yaml files per service before Sprint 1 begins.*
*Previous: [02_Infrastructure_and_Security_Design.md](02_Infrastructure_and_Security_Design.md)*
*Next: [04_Database_Schema_Design.md](04_Database_Schema_Design.md)*
