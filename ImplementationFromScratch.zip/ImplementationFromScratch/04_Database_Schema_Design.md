# AutoAuth Agent — Database Schema Design
**Phase 1 | Weeks 1–2**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0
**Prerequisite:** [01_Requirements_and_System_Design.md](01_Requirements_and_System_Design.md)

---

## Table of Contents

1. [Design Principles](#1-design-principles)
2. [Entity Relationship Diagram (ERD)](#2-entity-relationship-diagram-erd)
3. [Table Inventory](#3-table-inventory)
4. [Full DDL — All Tables](#4-full-ddl--all-tables)
5. [Indexes Design](#5-indexes-design)
6. [Constraints & Business Rules](#6-constraints--business-rules)
7. [Alembic Migration Files](#7-alembic-migration-files)
8. [SQLAlchemy ORM Models](#8-sqlalchemy-orm-models)
9. [Seed Data Scripts](#9-seed-data-scripts)
10. [Key Query Patterns](#10-key-query-patterns)
11. [Partitioning Strategy](#11-partitioning-strategy)
12. [Data Retention Policy](#12-data-retention-policy)

---

## 1. Design Principles

```
1.  Schema name: iks_schema (all tables live in this schema)
2.  Primary keys: UUID v4 (gen_random_uuid()) — portable, no sequence conflicts in multi-region
3.  All tables have: id (UUID PK), created_at (TIMESTAMPTZ), updated_at (TIMESTAMPTZ)
4.  updated_at auto-updated via trigger (never rely on application to set it)
5.  Soft deletes: is_active / is_deleted flag — never hard DELETE business records
6.  JSONB for flexible nested data (patient_data, clinical_data) — avoids wide sparse tables
7.  TIMESTAMPTZ for all timestamps (timezone-aware, stored as UTC)
8.  VARCHAR over TEXT where max length is known
9.  Enums as VARCHAR with CHECK constraints — easier to ALTER than PostgreSQL ENUM types
10. Foreign keys enforced at DB level — no orphaned records
11. Naming: snake_case, prefixed by domain (prior_auth_*, agentic_platform_*)
12. No stored procedures — all business logic in application layer
13. pg_stat_statements enabled for query performance monitoring
14. Connection pooling: handled by SQLAlchemy (not PgBouncer, for initial release)
```

---

## 2. Entity Relationship Diagram (ERD)

```
┌──────────────────────────────────────────────────────────────────────────────────────────────┐
│                              iks_schema  —  Entity Relationship Diagram                      │
│                                                                                              │
│   ┌──────────────────┐           ┌──────────────────────┐                                   │
│   │  prior_auth_     │  1      * │  prior_auth_         │                                   │
│   │  payer           │◄──────────│  portal              │                                   │
│   │  ──────────────  │           │  ──────────────────  │                                   │
│   │  PK id           │           │  PK id               │                                   │
│   │  payer_name      │           │  FK payer_id         │                                   │
│   │  payer_code      │           │  portal_name         │                                   │
│   │  is_active       │           │  portal_id (slug)    │                                   │
│   └──────────────────┘           │  base_url            │                                   │
│                                  │  is_active           │                                   │
│                                  └──────┬───────────────┘                                   │
│                                         │ 1                                                  │
│                        ┌────────────────┼────────────────┐                                  │
│                        │ *              │ *              │ *                                 │
│               ┌────────▼─────────┐  ┌──▼───────────┐  ┌─▼───────────────────┐             │
│               │  prior_auth_     │  │ prior_auth_  │  │  prior_auth_        │             │
│               │  portal_         │  │ portal_      │  │  payer_prompt       │             │
│               │  credential      │  │ recipe       │  │  ──────────────     │             │
│               │  ─────────────   │  │ ──────────── │  │  PK id              │             │
│               │  PK id           │  │  PK id       │  │  FK portal_id       │             │
│               │  FK portal_id    │  │  FK portal_id│  │  prompt_type        │             │
│               │  credential_alias│  │  version     │  │  prompt_text        │             │
│               │  username_secret │  │  recipe_yaml │  │  model_name         │             │
│               │  password_secret │  │  is_active   │  │  is_active          │             │
│               └──────────────────┘  └──────────────┘  └─────────────────────┘             │
│                                                                                              │
│   ┌─────────────────────┐           ┌──────────────────────┐                               │
│   │  agentic_platform_  │ 1       * │  prior_auth_         │                               │
│   │  user               │◄──────────│  batch_request       │                               │
│   │  ─────────────────  │           │  ───────────────────  │                               │
│   │  PK id              │           │  PK id               │                               │
│   │  email              │           │  batch_id (ext ref)  │                               │
│   │  hashed_password    │           │  FK portal_id        │                               │
│   │  full_name          │           │  FK payer_id         │                               │
│   │  role               │           │  FK submitted_by     │                               │
│   │  is_active          │           │  total_cases         │                               │
│   └─────────────────────┘           │  status              │                               │
│                                     └──────────┬───────────┘                               │
│                                                │ 1                                          │
│                                                │ *                                          │
│                              ┌─────────────────▼──────────────────────────┐                │
│                              │          prior_auth_case_request            │                │
│                              │          ─────────────────────────────────  │                │
│                              │  PK  id                                     │                │
│                              │  UK  case_ref_id                            │                │
│                              │  FK  batch_id                               │                │
│                              │  FK  portal_id                              │                │
│                              │  FK  payer_id                               │                │
│                              │       patient_data (JSONB)                  │                │
│                              │       clinical_data (JSONB)                 │                │
│                              │       status                                │                │
│                              │       outcome                               │                │
│                              │       pa_reference_number                   │                │
│                              │       retry_count                           │                │
│                              └──────────┬──────────────────────────────────┘                │
│                                         │ 1                                                  │
│          ┌──────────────────────────────┼───────────────────────────────────────┐           │
│          │ *                            │ *                    │ *              │ *          │
│ ┌────────▼──────────┐  ┌───────────────▼────────┐  ┌─────────▼──────┐  ┌──────▼────────┐  │
│ │ prior_auth_       │  │ prior_auth_            │  │ prior_auth_   │  │ prior_auth_   │  │
│ │ agent_session     │  │ hitl_task              │  │ case_logs     │  │ tracking_     │  │
│ │ ────────────────  │  │ ─────────────────────  │  │ ──────────── │  │ session       │  │
│ │ PK id             │  │  PK id                 │  │  PK id        │  │  ──────────── │  │
│ │ FK case_ref_id    │  │  FK case_ref_id        │  │  FK case_ref_id│  │  PK id       │  │
│ │ pod_id            │  │  FK resolved_by (user) │  │  log_level    │  │  FK case_ref  │  │
│ │ pod_ip            │  │  task_type             │  │  step_name    │  │  pod_id       │  │
│ │ session_id        │  │  status                │  │  message      │  │  status       │  │
│ │ display_slot      │  │  message               │  │  metadata     │  │  pa_ref_num   │  │
│ │ vnc_port          │  │  screenshot_url        │  │  created_at   │  │              │  │
│ │ web_port          │  │  resolution            │  └───────────────┘  └──────────────┘  │
│ │ status            │  └────────────────────────┘                                         │
│ └───────────────────┘                                                                       │
│                                                                                              │
│ ┌──────────────────────────────────┐      ┌────────────────────────────────┐                │
│ │  agentic_platform_               │  *   │  agentic_platform_             │                │
│ │  ai_model_pricing                │◄─────│  request_cost                  │                │
│ │  ───────────────────────────     │  1   │  ────────────────────────────  │                │
│ │  PK id                           │      │  PK id                         │                │
│ │  model_name (UK)                 │      │  FK case_ref_id                │                │
│ │  input_cost_per_1k               │      │  FK model_name                 │                │
│ │  output_cost_per_1k              │      │  input_tokens                  │                │
│ │  effective_from                  │      │  output_tokens                 │                │
│ └──────────────────────────────────┘      │  total_cost_usd                │                │
│                                           │  call_type                     │                │
│ ┌────────────────────────────────┐        └────────────────────────────────┘                │
│ │  prior_auth_                   │                                                          │
│ │  planner_agent_status          │                                                          │
│ │  ──────────────────────────    │                                                          │
│ │  PK id                         │                                                          │
│ │  FK case_ref_id (UK)           │                                                          │
│ │  planning_status               │                                                          │
│ │  n8n_workflow_id               │                                                          │
│ │  trigger_count                 │                                                          │
│ └────────────────────────────────┘                                                          │
│                                                                                              │
│ ┌────────────────────────────────┐   ┌────────────────────────────────┐                    │
│ │  agentic_platform_alert        │   │  prior_auth_login_session       │                    │
│ │  ──────────────────────────    │   │  ──────────────────────────     │                    │
│ │  PK id                         │   │  PK id                          │                    │
│ │  FK case_ref_id (nullable)     │   │  FK batch_id                    │                    │
│ │  alert_type                    │   │  FK portal_id                   │                    │
│ │  severity                      │   │  FK credential_id               │                    │
│ │  message                       │   │  session_id (browser-agent)     │                    │
│ │  is_read                       │   │  login_status                   │                    │
│ │  created_at                    │   │  created_at                     │                    │
│ └────────────────────────────────┘   └────────────────────────────────┘                    │
└──────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Table Inventory

```
Domain: Payer & Portal Configuration
  prior_auth_payer                    Insurance payer master data
  prior_auth_portal                   Web portal per payer
  prior_auth_portal_credential        GCP Secret Manager credential references
  prior_auth_portal_recipe            Portal YAML recipes stored in DB
  prior_auth_payer_prompt             Per-payer LLM prompt overrides

Domain: Batch & Case
  prior_auth_batch_request            One batch per API call
  prior_auth_case_request             Individual PA case (central table)

Domain: Agent Execution
  prior_auth_agent_session            Browser agent session lifecycle
  prior_auth_tracking_session         Tracking agent session lifecycle
  prior_auth_planner_agent_status     Planner processing state per case
  prior_auth_login_session            Shared login session for batch reuse

Domain: HITL & Intervention
  prior_auth_hitl_task                Human-in-the-loop intervention tasks

Domain: Logging & Audit
  prior_auth_case_logs                Structured agent action logs per case

Domain: Cost Tracking
  agentic_platform_ai_model_pricing   LLM model cost config
  agentic_platform_request_cost       Per-case LLM call cost records

Domain: User & Auth
  agentic_platform_user               Dashboard user accounts
  agentic_platform_agent              Registered agent pod entities

Domain: Alerts
  agentic_platform_alert              System alerts for dashboard SSE

Total: 18 tables
```

---

## 4. Full DDL — All Tables

```sql
-- ============================================================
-- SETUP
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";    -- For fuzzy text search on logs

-- Schema
CREATE SCHEMA IF NOT EXISTS iks_schema;
SET search_path TO iks_schema, public;

-- Auto-update updated_at trigger function (shared by all tables)
CREATE OR REPLACE FUNCTION iks_schema.trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Helper: apply updated_at trigger to any table
-- Usage: SELECT iks_schema.apply_updated_at_trigger('table_name');
CREATE OR REPLACE FUNCTION iks_schema.apply_updated_at_trigger(p_table_name TEXT)
RETURNS void AS $$
BEGIN
  EXECUTE format(
    'CREATE TRIGGER set_updated_at
     BEFORE UPDATE ON iks_schema.%I
     FOR EACH ROW EXECUTE FUNCTION iks_schema.trigger_set_updated_at()',
    p_table_name
  );
END;
$$ LANGUAGE plpgsql;


-- ============================================================
-- DOMAIN: PAYER & PORTAL CONFIGURATION
-- ============================================================

-- Table 1: prior_auth_payer
-- Insurance companies / payers master data
CREATE TABLE iks_schema.prior_auth_payer (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    payer_name      VARCHAR(255) NOT NULL,
    payer_code      VARCHAR(100) NOT NULL,   -- Unique short code: "UHC", "AETNA", "CIGNA"
    payer_type      VARCHAR(50)  NOT NULL DEFAULT 'COMMERCIAL',
                                             -- COMMERCIAL, MEDICARE, MEDICAID, TRICARE
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    metadata        JSONB,                   -- Payer-specific config (phone numbers, addresses)
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_payer_code UNIQUE (payer_code),
    CONSTRAINT ck_payer_type CHECK (payer_type IN ('COMMERCIAL','MEDICARE','MEDICAID','TRICARE','OTHER'))
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_payer');

COMMENT ON TABLE  iks_schema.prior_auth_payer            IS 'Insurance payer master data';
COMMENT ON COLUMN iks_schema.prior_auth_payer.payer_code IS 'Short unique code identifying the payer (e.g. UHC, AETNA)';


-- Table 2: prior_auth_portal
-- Payer web portals (one payer can have multiple portals)
CREATE TABLE iks_schema.prior_auth_portal (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    payer_id        UUID        NOT NULL REFERENCES iks_schema.prior_auth_payer(id) ON DELETE RESTRICT,
    portal_name     VARCHAR(255) NOT NULL,
    portal_id       VARCHAR(100) NOT NULL,   -- Slug used in API: "availity", "navinet"
    base_url        VARCHAR(500),
    login_url       VARCHAR(500),
    is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
    supports_recipe BOOLEAN     NOT NULL DEFAULT TRUE,   -- Has a YAML recipe
    supports_llm    BOOLEAN     NOT NULL DEFAULT FALSE,  -- Supports LLM fallback
    notes           TEXT,                               -- Manual notes for operators
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_portal_slug UNIQUE (portal_id)
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_portal');

COMMENT ON TABLE  iks_schema.prior_auth_portal          IS 'Payer web portals for PA submission';
COMMENT ON COLUMN iks_schema.prior_auth_portal.portal_id IS 'URL-safe slug used as identifier in API calls';


-- Table 3: prior_auth_portal_credential
-- GCP Secret Manager credential references (not the actual secrets)
CREATE TABLE iks_schema.prior_auth_portal_credential (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    portal_id           UUID        NOT NULL REFERENCES iks_schema.prior_auth_portal(id) ON DELETE RESTRICT,
    credential_alias    VARCHAR(255) NOT NULL,    -- Human-readable name: "availity-primary"
    username_secret_path VARCHAR(500) NOT NULL,   -- GCP Secret Manager path
    password_secret_path VARCHAR(500) NOT NULL,   -- GCP Secret Manager path
    mfa_service_account  VARCHAR(500),            -- Optional: for MFA SIM card setup
    priority            INTEGER     NOT NULL DEFAULT 1,  -- Lower = preferred credential
    is_active           BOOLEAN     NOT NULL DEFAULT TRUE,
    last_used_at        TIMESTAMPTZ,
    failure_count       INTEGER     NOT NULL DEFAULT 0,  -- Increment on login failure
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_portal_alias UNIQUE (portal_id, credential_alias),
    CONSTRAINT ck_priority_positive CHECK (priority > 0)
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_portal_credential');


-- Table 4: prior_auth_portal_recipe
-- YAML recipes stored in DB (alternative to bundled YAML files)
CREATE TABLE iks_schema.prior_auth_portal_recipe (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    portal_id       UUID        NOT NULL REFERENCES iks_schema.prior_auth_portal(id) ON DELETE RESTRICT,
    version         VARCHAR(20)  NOT NULL DEFAULT '1.0',
    recipe_yaml     TEXT        NOT NULL,               -- Full YAML content
    recipe_hash     VARCHAR(64)  NOT NULL,              -- SHA-256 of recipe_yaml for cache validation
    is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
    deployed_by     VARCHAR(255),                       -- Email of who deployed this recipe
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_portal_recipe_version UNIQUE (portal_id, version)
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_portal_recipe');

COMMENT ON TABLE iks_schema.prior_auth_portal_recipe IS 'YAML portal recipes stored in DB. Active recipe served to browser-agent.';


-- Table 5: prior_auth_payer_prompt
-- Per-payer LLM system prompt overrides
CREATE TABLE iks_schema.prior_auth_payer_prompt (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    portal_id       UUID        NOT NULL REFERENCES iks_schema.prior_auth_portal(id) ON DELETE CASCADE,
    prompt_type     VARCHAR(50)  NOT NULL,  -- "system", "extraction", "summary"
    prompt_text     TEXT        NOT NULL,
    model_name      VARCHAR(100) NOT NULL DEFAULT 'gemini-2.5-pro',
    is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
    created_by      UUID        REFERENCES iks_schema.agentic_platform_user(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_portal_prompt_type UNIQUE (portal_id, prompt_type),
    CONSTRAINT ck_prompt_type CHECK (prompt_type IN ('system','extraction','summary','page_context'))
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_payer_prompt');


-- ============================================================
-- DOMAIN: USER & AUTH
-- (defined before batch/case because batch references user)
-- ============================================================

-- Table 6: agentic_platform_user
-- Dashboard user accounts
CREATE TABLE iks_schema.agentic_platform_user (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    email           VARCHAR(255) NOT NULL,
    hashed_password VARCHAR(500) NOT NULL,   -- bcrypt (cost factor 12)
    full_name       VARCHAR(255) NOT NULL,
    role            VARCHAR(50)  NOT NULL DEFAULT 'VIEWER',
    is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
    last_login_at   TIMESTAMPTZ,
    failed_login_count INTEGER  NOT NULL DEFAULT 0,
    locked_until    TIMESTAMPTZ,             -- Account lockout after N failed attempts
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_user_email UNIQUE (email),
    CONSTRAINT ck_user_role  CHECK (role IN ('ADMIN','OPERATOR','VIEWER'))
);

SELECT iks_schema.apply_updated_at_trigger('agentic_platform_user');


-- ============================================================
-- DOMAIN: BATCH & CASE
-- ============================================================

-- Table 7: prior_auth_batch_request
-- One batch per API call (groups related cases)
CREATE TABLE iks_schema.prior_auth_batch_request (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id        VARCHAR(255) NOT NULL,   -- External batch ID from caller's system
    portal_id       UUID        NOT NULL REFERENCES iks_schema.prior_auth_portal(id) ON DELETE RESTRICT,
    payer_id        UUID        NOT NULL REFERENCES iks_schema.prior_auth_payer(id) ON DELETE RESTRICT,
    submitted_by    UUID        REFERENCES iks_schema.agentic_platform_user(id),
    total_cases     INTEGER     NOT NULL,
    accepted_cases  INTEGER     NOT NULL DEFAULT 0,
    rejected_cases  INTEGER     NOT NULL DEFAULT 0,
    status          VARCHAR(50)  NOT NULL DEFAULT 'PENDING',
    priority        VARCHAR(20)  NOT NULL DEFAULT 'NORMAL',
    metadata        JSONB,                   -- Caller-supplied metadata
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at    TIMESTAMPTZ,             -- When all cases reached terminal state

    CONSTRAINT uq_batch_id   UNIQUE (batch_id),
    CONSTRAINT ck_batch_status   CHECK (status IN ('PENDING','IN_PROGRESS','COMPLETED','PARTIALLY_COMPLETED','FAILED')),
    CONSTRAINT ck_batch_priority CHECK (priority IN ('NORMAL','HIGH','URGENT')),
    CONSTRAINT ck_total_cases    CHECK (total_cases > 0)
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_batch_request');

COMMENT ON TABLE iks_schema.prior_auth_batch_request IS 'Groups PA cases submitted in one API call';


-- Table 8: prior_auth_case_request  ← CENTRAL TABLE
-- Individual PA case (one row per patient per procedure)
CREATE TABLE iks_schema.prior_auth_case_request (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id         VARCHAR(255) NOT NULL,  -- External case ID (caller's system)
    batch_id            UUID        REFERENCES iks_schema.prior_auth_batch_request(id) ON DELETE RESTRICT,
    portal_id           UUID        NOT NULL REFERENCES iks_schema.prior_auth_portal(id),
    payer_id            UUID        NOT NULL REFERENCES iks_schema.prior_auth_payer(id),

    -- Clinical & Patient payload (JSONB for schema flexibility)
    patient_data        JSONB       NOT NULL,
    clinical_data       JSONB       NOT NULL,

    -- Status lifecycle
    status              VARCHAR(50)  NOT NULL DEFAULT 'PENDING',
    previous_status     VARCHAR(50),                          -- Last status before current (for debugging)
    status_changed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Outcome
    outcome             VARCHAR(50),
    pa_reference_number VARCHAR(255),                        -- PA approval/denial ref from payer
    outcome_details     TEXT,
    outcome_raw         TEXT,                                -- Raw text extracted from portal confirmation page

    -- Retry tracking
    retry_count         INTEGER     NOT NULL DEFAULT 0,
    max_retries         INTEGER     NOT NULL DEFAULT 3,
    last_retry_at       TIMESTAMPTZ,
    last_error          TEXT,                               -- Last error message for debugging

    -- Timestamps
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    queued_at           TIMESTAMPTZ,
    started_at          TIMESTAMPTZ,
    submitted_at        TIMESTAMPTZ,
    completed_at        TIMESTAMPTZ,

    CONSTRAINT uq_case_ref_id UNIQUE (case_ref_id),
    CONSTRAINT ck_case_status CHECK (status IN (
        'PENDING','PLANNING','QUEUED','IN_PROGRESS',
        'HITL_WAIT','MFA_WAIT',
        'SUBMITTED','APPROVED','DENIED','PENDING_INFO',
        'CRASHED','FAILED','CANCELLED'
    )),
    CONSTRAINT ck_case_outcome CHECK (outcome IS NULL OR outcome IN (
        'APPROVED','DENIED','PENDING','PENDING_INFO','SUBMITTED','ERROR'
    )),
    CONSTRAINT ck_retry_count CHECK (retry_count >= 0),
    CONSTRAINT ck_max_retries CHECK (max_retries >= 0)
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_case_request');

COMMENT ON TABLE  iks_schema.prior_auth_case_request             IS 'Central table: one row per PA case. All agent activity references this.';
COMMENT ON COLUMN iks_schema.prior_auth_case_request.patient_data IS 'JSONB: {first_name,last_name,dob,member_id,group_id,...}';
COMMENT ON COLUMN iks_schema.prior_auth_case_request.clinical_data IS 'JSONB: {procedure_codes[],diagnosis_codes[],npi,facility_npi,...}';


-- ============================================================
-- DOMAIN: AGENT EXECUTION
-- ============================================================

-- Table 9: prior_auth_agent_session
-- Browser agent session lifecycle (one per case per attempt)
CREATE TABLE iks_schema.prior_auth_agent_session (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) NOT NULL REFERENCES iks_schema.prior_auth_case_request(case_ref_id)
                                ON DELETE RESTRICT,
    attempt_number  INTEGER     NOT NULL DEFAULT 1,  -- Increments with each retry
    pod_id          VARCHAR(255),                    -- K8s pod name: browser-agent-abc123
    pod_ip          VARCHAR(50),
    pod_port        INTEGER     DEFAULT 8081,
    session_id      VARCHAR(255) NOT NULL,           -- Browser-agent's session UUID
    display_slot    INTEGER,
    display_num     INTEGER,                         -- Xvfb display (:10, :11, etc.)
    vnc_port        INTEGER,
    web_port        INTEGER,
    vnc_url         VARCHAR(500),                    -- Full noVNC URL
    execution_mode  VARCHAR(20)  NOT NULL DEFAULT 'recipe',
    status          VARCHAR(50)  NOT NULL DEFAULT 'CREATING',
    steps_completed INTEGER     NOT NULL DEFAULT 0,
    total_steps     INTEGER,
    last_step_name  VARCHAR(255),
    started_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at        TIMESTAMPTZ,
    duration_seconds INTEGER,

    CONSTRAINT uq_agent_session_id UNIQUE (session_id),
    CONSTRAINT ck_agent_session_status CHECK (status IN (
        'CREATING','ACTIVE','RUNNING','HITL_WAIT','MFA_WAIT',
        'COMPLETING','COMPLETED','FAILED','CRASHED','STOPPED'
    )),
    CONSTRAINT ck_execution_mode CHECK (execution_mode IN ('recipe','llm'))
);

COMMENT ON TABLE iks_schema.prior_auth_agent_session IS 'Browser session lifecycle per case attempt. One row per retry attempt.';


-- Table 10: prior_auth_tracking_session
-- Post-submission status tracking sessions
CREATE TABLE iks_schema.prior_auth_tracking_session (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id         VARCHAR(255) NOT NULL REFERENCES iks_schema.prior_auth_case_request(case_ref_id),
    pa_reference_number VARCHAR(255) NOT NULL,
    pod_id              VARCHAR(255),
    pod_ip              VARCHAR(50),
    session_id          VARCHAR(255),
    status              VARCHAR(50)  NOT NULL DEFAULT 'PENDING',
    portal_status       VARCHAR(255),   -- Raw status string from portal
    normalized_status   VARCHAR(50),    -- APPROVED/DENIED/PENDING/PENDING_INFO/NOT_FOUND
    check_count         INTEGER     NOT NULL DEFAULT 0,
    next_check_at       TIMESTAMPTZ,
    screenshot_url      VARCHAR(1000),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at        TIMESTAMPTZ,

    CONSTRAINT ck_tracking_status CHECK (status IN (
        'PENDING','IN_PROGRESS','COMPLETED','FAILED'
    )),
    CONSTRAINT ck_norm_status CHECK (normalized_status IS NULL OR normalized_status IN (
        'APPROVED','DENIED','PENDING','PENDING_INFO','NOT_FOUND','ERROR'
    ))
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_tracking_session');


-- Table 11: prior_auth_planner_agent_status
-- Planner service processing state per case
CREATE TABLE iks_schema.prior_auth_planner_agent_status (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id         VARCHAR(255) NOT NULL REFERENCES iks_schema.prior_auth_case_request(case_ref_id),
    planning_status     VARCHAR(50)  NOT NULL DEFAULT 'RECEIVED',
    n8n_workflow_id     VARCHAR(255),   -- N8N execution ID (for tracing)
    trigger_count       INTEGER     NOT NULL DEFAULT 0,  -- How many times N8N was triggered
    dedup_cache_hit     BOOLEAN     NOT NULL DEFAULT FALSE,
    one_session_batch   BOOLEAN     NOT NULL DEFAULT FALSE,
    notes               TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_planner_case UNIQUE (case_ref_id),
    CONSTRAINT ck_planning_status CHECK (planning_status IN (
        'RECEIVED','DEDUP_SKIPPED','TRIGGERING','TRIGGERED','FAILED'
    ))
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_planner_agent_status');


-- Table 12: prior_auth_login_session
-- Shared login session per batch (ONE_SESSION_PER_BATCH mode)
CREATE TABLE iks_schema.prior_auth_login_session (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id        UUID        NOT NULL REFERENCES iks_schema.prior_auth_batch_request(id),
    portal_id       UUID        NOT NULL REFERENCES iks_schema.prior_auth_portal(id),
    credential_id   UUID        REFERENCES iks_schema.prior_auth_portal_credential(id),
    browser_session_id VARCHAR(255),              -- Session ID on the browser-agent pod
    pod_ip          VARCHAR(50),
    login_status    VARCHAR(50)  NOT NULL DEFAULT 'PENDING',
    logged_in_at    TIMESTAMPTZ,
    expires_at      TIMESTAMPTZ,
    cases_processed INTEGER     NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_login_session_batch_portal UNIQUE (batch_id, portal_id),
    CONSTRAINT ck_login_status CHECK (login_status IN (
        'PENDING','LOGGING_IN','ACTIVE','EXPIRED','FAILED'
    ))
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_login_session');

COMMENT ON TABLE iks_schema.prior_auth_login_session IS 'Tracks shared browser sessions for ONE_SESSION_PER_BATCH mode.';


-- ============================================================
-- DOMAIN: HITL & INTERVENTION
-- ============================================================

-- Table 13: prior_auth_hitl_task
-- Human-in-the-loop intervention tasks
CREATE TABLE iks_schema.prior_auth_hitl_task (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) NOT NULL REFERENCES iks_schema.prior_auth_case_request(case_ref_id),
    task_type       VARCHAR(20)  NOT NULL,   -- HITL or MFA
    status          VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    message         TEXT        NOT NULL,    -- What the agent needs help with
    screenshot_url  VARCHAR(1000),
    vnc_url         VARCHAR(500),
    step_name       VARCHAR(255),            -- Which recipe step triggered this
    portal_id       VARCHAR(100),            -- Denormalized for quick access
    resolution      TEXT,                   -- What the operator did
    resolved_by     UUID        REFERENCES iks_schema.agentic_platform_user(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at     TIMESTAMPTZ,
    expires_at      TIMESTAMPTZ,             -- Auto-expire HITL after N minutes

    CONSTRAINT ck_hitl_type   CHECK (task_type IN ('HITL','MFA')),
    CONSTRAINT ck_hitl_status CHECK (status IN ('PENDING','RESOLVED','EXPIRED','CANCELLED'))
);

SELECT iks_schema.apply_updated_at_trigger('prior_auth_hitl_task');

COMMENT ON TABLE iks_schema.prior_auth_hitl_task IS 'HITL and MFA intervention tasks. Created when agent needs human help.';


-- ============================================================
-- DOMAIN: LOGGING & AUDIT
-- ============================================================

-- Table 14: prior_auth_case_logs
-- Structured agent action logs (partitioned by created_at for performance)
CREATE TABLE iks_schema.prior_auth_case_logs (
    id              UUID        NOT NULL DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) NOT NULL,   -- Not FK — too many inserts for FK overhead
    session_id      VARCHAR(255),            -- Browser agent session this log belongs to
    log_level       VARCHAR(10)  NOT NULL DEFAULT 'INFO',
    step_name       VARCHAR(255),
    action_type     VARCHAR(50),             -- navigate, fill, click, etc.
    message         TEXT        NOT NULL,
    metadata        JSONB,                   -- {selector, value, duration_ms, screenshot_url}
    trace_id        VARCHAR(100),            -- Distributed trace ID
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT ck_log_level CHECK (log_level IN ('DEBUG','INFO','WARN','ERROR','CRITICAL')),
    PRIMARY KEY (id, created_at)             -- Composite PK for partitioning
) PARTITION BY RANGE (created_at);

-- Monthly partitions (create for current + next 3 months at setup time)
CREATE TABLE iks_schema.prior_auth_case_logs_2026_09
    PARTITION OF iks_schema.prior_auth_case_logs
    FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');

CREATE TABLE iks_schema.prior_auth_case_logs_2026_10
    PARTITION OF iks_schema.prior_auth_case_logs
    FOR VALUES FROM ('2026-10-01') TO ('2026-11-01');

CREATE TABLE iks_schema.prior_auth_case_logs_2026_11
    PARTITION OF iks_schema.prior_auth_case_logs
    FOR VALUES FROM ('2026-11-01') TO ('2026-12-01');

CREATE TABLE iks_schema.prior_auth_case_logs_2026_12
    PARTITION OF iks_schema.prior_auth_case_logs
    FOR VALUES FROM ('2026-12-01') TO ('2027-01-01');

COMMENT ON TABLE iks_schema.prior_auth_case_logs IS 'Partitioned log table. Each partition covers one calendar month.';


-- ============================================================
-- DOMAIN: COST TRACKING
-- ============================================================

-- Table 15: agentic_platform_ai_model_pricing
-- LLM model pricing configuration
CREATE TABLE iks_schema.agentic_platform_ai_model_pricing (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    model_name          VARCHAR(255) NOT NULL,
    provider            VARCHAR(100) NOT NULL DEFAULT 'google',
    input_cost_per_1k   NUMERIC(12,8) NOT NULL,   -- USD per 1K input tokens
    output_cost_per_1k  NUMERIC(12,8) NOT NULL,   -- USD per 1K output tokens
    context_window      INTEGER,                  -- Max context window in tokens
    is_active           BOOLEAN     NOT NULL DEFAULT TRUE,
    effective_from      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    effective_to        TIMESTAMPTZ,              -- NULL = currently active
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_model_effective UNIQUE (model_name, effective_from)
);

SELECT iks_schema.apply_updated_at_trigger('agentic_platform_ai_model_pricing');


-- Table 16: agentic_platform_request_cost
-- Per-case LLM API call cost records
CREATE TABLE iks_schema.agentic_platform_request_cost (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255) NOT NULL,   -- No FK for insert performance
    session_id      VARCHAR(255),
    model_name      VARCHAR(255) NOT NULL,
    call_type       VARCHAR(100) NOT NULL,   -- "browser_agent", "log_summary", "page_extract"
    input_tokens    INTEGER     NOT NULL DEFAULT 0,
    output_tokens   INTEGER     NOT NULL DEFAULT 0,
    total_tokens    INTEGER     GENERATED ALWAYS AS (input_tokens + output_tokens) STORED,
    total_cost_usd  NUMERIC(14,8),
    duration_ms     INTEGER,
    success         BOOLEAN     NOT NULL DEFAULT TRUE,
    error_message   TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT ck_cost_call_type CHECK (call_type IN (
        'browser_agent','log_summary','page_extract','chatbot','planning'
    )),
    CONSTRAINT ck_tokens_positive CHECK (input_tokens >= 0 AND output_tokens >= 0)
);

COMMENT ON TABLE iks_schema.agentic_platform_request_cost IS 'LLM API cost per call, linked to case_ref_id for cost attribution.';


-- ============================================================
-- DOMAIN: AGENT REGISTRATION
-- ============================================================

-- Table 17: agentic_platform_agent
-- Registered agent pod entities (browser-agent, tracking-agent pods)
CREATE TABLE iks_schema.agentic_platform_agent (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_type      VARCHAR(50)  NOT NULL,   -- "browser_agent", "tracking_agent"
    pod_id          VARCHAR(255) NOT NULL,
    pod_ip          VARCHAR(50),
    pod_port        INTEGER,
    max_sessions    INTEGER     NOT NULL DEFAULT 5,
    status          VARCHAR(50)  NOT NULL DEFAULT 'IDLE',
    last_heartbeat  TIMESTAMPTZ,
    registered_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deregistered_at TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_agent_pod_id UNIQUE (pod_id),
    CONSTRAINT ck_agent_type   CHECK (agent_type IN ('browser_agent','tracking_agent')),
    CONSTRAINT ck_agent_status CHECK (status IN ('IDLE','BUSY','COOLING','DRAINING','OFFLINE'))
);

SELECT iks_schema.apply_updated_at_trigger('agentic_platform_agent');


-- ============================================================
-- DOMAIN: ALERTS
-- ============================================================

-- Table 18: agentic_platform_alert
-- System alerts surfaced to dashboard via SSE
CREATE TABLE iks_schema.agentic_platform_alert (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    case_ref_id     VARCHAR(255),           -- Nullable — some alerts are system-wide
    alert_type      VARCHAR(100) NOT NULL,
    severity        VARCHAR(20)  NOT NULL DEFAULT 'INFO',
    title           VARCHAR(255) NOT NULL,
    message         TEXT        NOT NULL,
    metadata        JSONB,
    is_read         BOOLEAN     NOT NULL DEFAULT FALSE,
    is_resolved     BOOLEAN     NOT NULL DEFAULT FALSE,
    read_by         UUID        REFERENCES iks_schema.agentic_platform_user(id),
    read_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ,

    CONSTRAINT ck_alert_severity CHECK (severity IN ('INFO','WARNING','ERROR','CRITICAL')),
    CONSTRAINT ck_alert_type CHECK (alert_type IN (
        'CASE_STATUS_CHANGE','HITL_REQUIRED','CASE_COMPLETED','POD_CRASH',
        'DEAD_LETTER_MESSAGE','WORKER_POOL_EMPTY','RECIPE_FAILURE','SYSTEM'
    ))
);

COMMENT ON TABLE iks_schema.agentic_platform_alert IS 'Alerts surfaced to dashboard. Streamed via SSE to connected clients.';
```

---

## 5. Indexes Design

```sql
-- ============================================================
-- INDEXES — grouped by table, ordered by query priority
-- ============================================================

-- prior_auth_case_request (most queried table — index heavily)
CREATE INDEX idx_case_status
    ON iks_schema.prior_auth_case_request (status)
    WHERE status NOT IN ('APPROVED','DENIED','FAILED','CANCELLED');
    -- Partial index: exclude terminal states for active-case queries

CREATE INDEX idx_case_portal_id
    ON iks_schema.prior_auth_case_request (portal_id);

CREATE INDEX idx_case_batch_id
    ON iks_schema.prior_auth_case_request (batch_id);

CREATE INDEX idx_case_payer_id
    ON iks_schema.prior_auth_case_request (payer_id);

CREATE INDEX idx_case_created_at
    ON iks_schema.prior_auth_case_request (created_at DESC);

CREATE INDEX idx_case_updated_at
    ON iks_schema.prior_auth_case_request (updated_at DESC);

CREATE INDEX idx_case_outcome
    ON iks_schema.prior_auth_case_request (outcome)
    WHERE outcome IS NOT NULL;

CREATE INDEX idx_case_status_portal
    ON iks_schema.prior_auth_case_request (status, portal_id);
    -- Composite: dashboard filter by status + portal

CREATE INDEX idx_case_submitted_at
    ON iks_schema.prior_auth_case_request (submitted_at)
    WHERE submitted_at IS NOT NULL;

-- prior_auth_batch_request
CREATE INDEX idx_batch_status
    ON iks_schema.prior_auth_batch_request (status);

CREATE INDEX idx_batch_portal_id
    ON iks_schema.prior_auth_batch_request (portal_id);

CREATE INDEX idx_batch_created_at
    ON iks_schema.prior_auth_batch_request (created_at DESC);

-- prior_auth_agent_session
CREATE INDEX idx_agent_session_case_ref
    ON iks_schema.prior_auth_agent_session (case_ref_id);

CREATE INDEX idx_agent_session_pod_id
    ON iks_schema.prior_auth_agent_session (pod_id)
    WHERE pod_id IS NOT NULL;

CREATE INDEX idx_agent_session_status
    ON iks_schema.prior_auth_agent_session (status)
    WHERE status IN ('ACTIVE','RUNNING','HITL_WAIT','MFA_WAIT');

-- prior_auth_hitl_task
CREATE INDEX idx_hitl_case_ref
    ON iks_schema.prior_auth_hitl_task (case_ref_id);

CREATE INDEX idx_hitl_status
    ON iks_schema.prior_auth_hitl_task (status)
    WHERE status = 'PENDING';   -- Partial: only pending tasks queried frequently

CREATE INDEX idx_hitl_created_at
    ON iks_schema.prior_auth_hitl_task (created_at DESC);

-- prior_auth_case_logs (per-partition index — PostgreSQL creates automatically)
CREATE INDEX idx_logs_case_ref
    ON iks_schema.prior_auth_case_logs (case_ref_id, created_at DESC);

CREATE INDEX idx_logs_session
    ON iks_schema.prior_auth_case_logs (session_id)
    WHERE session_id IS NOT NULL;

CREATE INDEX idx_logs_level
    ON iks_schema.prior_auth_case_logs (log_level)
    WHERE log_level IN ('ERROR','CRITICAL');  -- Only query errors frequently

-- agentic_platform_request_cost
CREATE INDEX idx_cost_case_ref
    ON iks_schema.agentic_platform_request_cost (case_ref_id);

CREATE INDEX idx_cost_created_at
    ON iks_schema.agentic_platform_request_cost (created_at DESC);

CREATE INDEX idx_cost_model_name
    ON iks_schema.agentic_platform_request_cost (model_name, created_at DESC);

-- agentic_platform_alert
CREATE INDEX idx_alert_is_read
    ON iks_schema.agentic_platform_alert (is_read, created_at DESC)
    WHERE is_read = FALSE;

CREATE INDEX idx_alert_case_ref
    ON iks_schema.agentic_platform_alert (case_ref_id)
    WHERE case_ref_id IS NOT NULL;

-- prior_auth_portal_credential
CREATE INDEX idx_credential_portal_active
    ON iks_schema.prior_auth_portal_credential (portal_id, priority)
    WHERE is_active = TRUE;

-- prior_auth_planner_agent_status
CREATE INDEX idx_planner_status
    ON iks_schema.prior_auth_planner_agent_status (planning_status);

-- prior_auth_tracking_session
CREATE INDEX idx_tracking_case_ref
    ON iks_schema.prior_auth_tracking_session (case_ref_id);

-- agentic_platform_user
CREATE INDEX idx_user_email
    ON iks_schema.agentic_platform_user (lower(email));
    -- Case-insensitive email lookup
```

---

## 6. Constraints & Business Rules

```sql
-- ============================================================
-- ADDITIONAL CONSTRAINTS & BUSINESS RULES
-- ============================================================

-- Rule: cannot have retry_count > max_retries
-- Enforced at application layer (not DB — max_retries is mutable)
-- But add a check for sanity:
ALTER TABLE iks_schema.prior_auth_case_request
    ADD CONSTRAINT ck_retry_not_exceed_max
    CHECK (retry_count <= max_retries + 1);   -- +1 allows one over (triggers FAILED)

-- Rule: completed_at must be set only after submitted_at
-- Deferred to application — hard to express in SQL without stored proc

-- Rule: HITL expires_at defaults to 60 minutes from creation
-- Set via application on insert; documented here as business rule
-- Default: expires_at = created_at + INTERVAL '60 minutes'
ALTER TABLE iks_schema.prior_auth_hitl_task
    ALTER COLUMN expires_at SET DEFAULT NOW() + INTERVAL '60 minutes';

-- Rule: MFA expires_at defaults to 5 minutes
-- Application sets this: expires_at = created_at + INTERVAL '5 minutes' WHERE task_type='MFA'

-- Rule: cost records should have non-negative cost
ALTER TABLE iks_schema.agentic_platform_request_cost
    ADD CONSTRAINT ck_cost_non_negative
    CHECK (total_cost_usd IS NULL OR total_cost_usd >= 0);

-- Rule: Alert expires_at defaults to 24 hours
ALTER TABLE iks_schema.agentic_platform_alert
    ALTER COLUMN expires_at SET DEFAULT NOW() + INTERVAL '24 hours';

-- View: active cases (commonly queried)
CREATE OR REPLACE VIEW iks_schema.v_active_cases AS
SELECT
    c.case_ref_id,
    c.status,
    c.portal_id,
    c.batch_id,
    p.portal_id as portal_slug,
    p.portal_name,
    pay.payer_name,
    c.created_at,
    c.updated_at,
    c.started_at,
    c.patient_data->>'first_name' || ' ' || c.patient_data->>'last_name' as patient_name,
    c.patient_data->>'member_id' as member_id,
    s.pod_ip,
    s.vnc_url,
    s.display_slot
FROM iks_schema.prior_auth_case_request c
JOIN iks_schema.prior_auth_portal p ON c.portal_id = p.id
JOIN iks_schema.prior_auth_payer pay ON c.payer_id = pay.id
LEFT JOIN iks_schema.prior_auth_agent_session s
    ON s.case_ref_id = c.case_ref_id AND s.status IN ('ACTIVE','RUNNING','HITL_WAIT','MFA_WAIT')
WHERE c.status NOT IN ('APPROVED','DENIED','FAILED','CANCELLED');

-- View: today's run volume
CREATE OR REPLACE VIEW iks_schema.v_run_volume_today AS
SELECT
    p.portal_id as portal_slug,
    COUNT(*) as total,
    COUNT(*) FILTER (WHERE c.outcome = 'APPROVED')     as approved,
    COUNT(*) FILTER (WHERE c.outcome = 'DENIED')       as denied,
    COUNT(*) FILTER (WHERE c.status = 'IN_PROGRESS')   as in_progress,
    COUNT(*) FILTER (WHERE c.status IN ('PENDING','PLANNING','QUEUED')) as pending,
    COUNT(*) FILTER (WHERE c.status IN ('FAILED','CRASHED'))           as failed,
    AVG(EXTRACT(EPOCH FROM (c.completed_at - c.started_at)))::INTEGER as avg_duration_seconds
FROM iks_schema.prior_auth_case_request c
JOIN iks_schema.prior_auth_portal p ON c.portal_id = p.id
WHERE c.created_at >= CURRENT_DATE
GROUP BY p.portal_id;
```

---

## 7. Alembic Migration Files

### 7.1 Project Structure

```
common/db_layer/
├── alembic.ini
├── alembic/
│   ├── env.py
│   ├── script.py.mako
│   └── versions/
│       ├── 0001_initial_schema.py
│       ├── 0002_add_portal_recipe_table.py
│       ├── 0003_add_login_session.py
│       ├── 0004_add_tracking_session.py
│       ├── 0005_add_alert_table.py
│       ├── 0006_add_agent_registration.py
│       ├── 0007_add_views.py
│       └── 0008_seed_ai_model_pricing.py
```

### 7.2 alembic.ini

```ini
[alembic]
script_location = alembic
file_template = %%(rev)s_%%(slug)s
prepend_sys_path = .
version_path_separator = os
sqlalchemy.url = postgresql://%(DB_USER)s:%(DB_PASSWORD)s@%(DB_HOST)s:%(DB_PORT)s/%(DB_NAME)s

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level = WARN
handlers = console
qualname =

[logger_sqlalchemy]
level = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level = INFO
handlers =
qualname = alembic

[handler_console]
class = StreamHandler
args = (sys.stderr,)
level = NOTSET
formatter = generic

[formatter_generic]
format = %(levelname)-5.5s [%(name)s] %(message)s
datefmt = %H:%M:%S
```

### 7.3 alembic/env.py

```python
import os
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context

config = context.config

# Override sqlalchemy.url from environment variables
db_url = (
    f"postgresql://{os.environ['DB_USER']}:{os.environ['DB_PASSWORD']}"
    f"@{os.environ.get('DB_HOST','localhost')}:{os.environ.get('DB_PORT','5432')}"
    f"/{os.environ.get('DB_NAME','autoauth')}"
)
config.set_main_option("sqlalchemy.url", db_url)

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Import all ORM models so autogenerate can detect them
from common.db_layer.orm_models import *  # noqa: F401, F403
from common.db_layer.db_config import Base

target_metadata = Base.metadata

def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        include_schemas=True,
        version_table_schema="iks_schema",
    )
    with context.begin_transaction():
        context.run_migrations()

def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            include_schemas=True,
            version_table_schema="iks_schema",
        )
        with context.begin_transaction():
            context.run_migrations()

if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
```

### 7.4 Migration: 0001_initial_schema.py

```python
"""Initial schema — all core tables

Revision ID: 0001
Revises: (none)
Create Date: 2026-09-03
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID, JSONB, TIMESTAMPTZ

revision = '0001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Extensions
    op.execute("CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\"")
    op.execute("CREATE EXTENSION IF NOT EXISTS pg_stat_statements")
    op.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")

    # Schema
    op.execute("CREATE SCHEMA IF NOT EXISTS iks_schema")

    # updated_at trigger function
    op.execute("""
        CREATE OR REPLACE FUNCTION iks_schema.trigger_set_updated_at()
        RETURNS TRIGGER AS $$
        BEGIN
          NEW.updated_at = NOW();
          RETURN NEW;
        END;
        $$ LANGUAGE plpgsql
    """)

    # --- prior_auth_payer ---
    op.create_table(
        'prior_auth_payer',
        sa.Column('id',         UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('payer_name', sa.String(255), nullable=False),
        sa.Column('payer_code', sa.String(100), nullable=False),
        sa.Column('payer_type', sa.String(50),  nullable=False, server_default='COMMERCIAL'),
        sa.Column('is_active',  sa.Boolean(),   nullable=False, server_default='true'),
        sa.Column('metadata',   JSONB),
        sa.Column('created_at', TIMESTAMPTZ(),  nullable=False, server_default=sa.text("NOW()")),
        sa.Column('updated_at', TIMESTAMPTZ(),  nullable=False, server_default=sa.text("NOW()")),
        sa.UniqueConstraint('payer_code', name='uq_payer_code'),
        sa.CheckConstraint("payer_type IN ('COMMERCIAL','MEDICARE','MEDICAID','TRICARE','OTHER')",
                          name='ck_payer_type'),
        schema='iks_schema'
    )
    op.execute("""
        CREATE TRIGGER set_updated_at BEFORE UPDATE ON iks_schema.prior_auth_payer
        FOR EACH ROW EXECUTE FUNCTION iks_schema.trigger_set_updated_at()
    """)

    # --- agentic_platform_user (before tables that reference it) ---
    op.create_table(
        'agentic_platform_user',
        sa.Column('id',                 UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('email',              sa.String(255), nullable=False),
        sa.Column('hashed_password',    sa.String(500), nullable=False),
        sa.Column('full_name',          sa.String(255), nullable=False),
        sa.Column('role',               sa.String(50),  nullable=False, server_default='VIEWER'),
        sa.Column('is_active',          sa.Boolean(),   nullable=False, server_default='true'),
        sa.Column('last_login_at',      TIMESTAMPTZ()),
        sa.Column('failed_login_count', sa.Integer(),   nullable=False, server_default='0'),
        sa.Column('locked_until',       TIMESTAMPTZ()),
        sa.Column('created_at',         TIMESTAMPTZ(),  nullable=False, server_default=sa.text("NOW()")),
        sa.Column('updated_at',         TIMESTAMPTZ(),  nullable=False, server_default=sa.text("NOW()")),
        sa.UniqueConstraint('email', name='uq_user_email'),
        sa.CheckConstraint("role IN ('ADMIN','OPERATOR','VIEWER')", name='ck_user_role'),
        schema='iks_schema'
    )
    op.execute("""
        CREATE TRIGGER set_updated_at BEFORE UPDATE ON iks_schema.agentic_platform_user
        FOR EACH ROW EXECUTE FUNCTION iks_schema.trigger_set_updated_at()
    """)

    # --- prior_auth_portal ---
    op.create_table(
        'prior_auth_portal',
        sa.Column('id',              UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('payer_id',        UUID(as_uuid=True), nullable=False),
        sa.Column('portal_name',     sa.String(255), nullable=False),
        sa.Column('portal_id',       sa.String(100), nullable=False),
        sa.Column('base_url',        sa.String(500)),
        sa.Column('login_url',       sa.String(500)),
        sa.Column('is_active',       sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('supports_recipe', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('supports_llm',    sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('notes',           sa.Text()),
        sa.Column('created_at',      TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('updated_at',      TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.ForeignKeyConstraint(['payer_id'], ['iks_schema.prior_auth_payer.id'],
                               name='fk_portal_payer', ondelete='RESTRICT'),
        sa.UniqueConstraint('portal_id', name='uq_portal_slug'),
        schema='iks_schema'
    )
    op.execute("""
        CREATE TRIGGER set_updated_at BEFORE UPDATE ON iks_schema.prior_auth_portal
        FOR EACH ROW EXECUTE FUNCTION iks_schema.trigger_set_updated_at()
    """)

    # --- prior_auth_portal_credential ---
    op.create_table(
        'prior_auth_portal_credential',
        sa.Column('id',                   UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('portal_id',            UUID(as_uuid=True), nullable=False),
        sa.Column('credential_alias',     sa.String(255), nullable=False),
        sa.Column('username_secret_path', sa.String(500), nullable=False),
        sa.Column('password_secret_path', sa.String(500), nullable=False),
        sa.Column('mfa_service_account',  sa.String(500)),
        sa.Column('priority',             sa.Integer(), nullable=False, server_default='1'),
        sa.Column('is_active',            sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('last_used_at',         TIMESTAMPTZ()),
        sa.Column('failure_count',        sa.Integer(), nullable=False, server_default='0'),
        sa.Column('created_at',           TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('updated_at',           TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.ForeignKeyConstraint(['portal_id'], ['iks_schema.prior_auth_portal.id'],
                               name='fk_credential_portal', ondelete='RESTRICT'),
        sa.UniqueConstraint('portal_id', 'credential_alias', name='uq_portal_alias'),
        sa.CheckConstraint('priority > 0', name='ck_priority_positive'),
        schema='iks_schema'
    )
    op.execute("""
        CREATE TRIGGER set_updated_at BEFORE UPDATE ON iks_schema.prior_auth_portal_credential
        FOR EACH ROW EXECUTE FUNCTION iks_schema.trigger_set_updated_at()
    """)

    # --- prior_auth_batch_request ---
    op.create_table(
        'prior_auth_batch_request',
        sa.Column('id',             UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('batch_id',       sa.String(255), nullable=False),
        sa.Column('portal_id',      UUID(as_uuid=True), nullable=False),
        sa.Column('payer_id',       UUID(as_uuid=True), nullable=False),
        sa.Column('submitted_by',   UUID(as_uuid=True)),
        sa.Column('total_cases',    sa.Integer(), nullable=False),
        sa.Column('accepted_cases', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('rejected_cases', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('status',         sa.String(50), nullable=False, server_default='PENDING'),
        sa.Column('priority',       sa.String(20), nullable=False, server_default='NORMAL'),
        sa.Column('metadata',       JSONB()),
        sa.Column('created_at',     TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('updated_at',     TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('completed_at',   TIMESTAMPTZ()),
        sa.ForeignKeyConstraint(['portal_id'],    ['iks_schema.prior_auth_portal.id'],
                               name='fk_batch_portal', ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['payer_id'],     ['iks_schema.prior_auth_payer.id'],
                               name='fk_batch_payer',  ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['submitted_by'], ['iks_schema.agentic_platform_user.id'],
                               name='fk_batch_user'),
        sa.UniqueConstraint('batch_id', name='uq_batch_id'),
        sa.CheckConstraint("status IN ('PENDING','IN_PROGRESS','COMPLETED','PARTIALLY_COMPLETED','FAILED')",
                          name='ck_batch_status'),
        sa.CheckConstraint("priority IN ('NORMAL','HIGH','URGENT')", name='ck_batch_priority'),
        sa.CheckConstraint('total_cases > 0', name='ck_total_cases'),
        schema='iks_schema'
    )
    op.execute("""
        CREATE TRIGGER set_updated_at BEFORE UPDATE ON iks_schema.prior_auth_batch_request
        FOR EACH ROW EXECUTE FUNCTION iks_schema.trigger_set_updated_at()
    """)

    # --- prior_auth_case_request (CENTRAL TABLE) ---
    op.create_table(
        'prior_auth_case_request',
        sa.Column('id',                 UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('case_ref_id',        sa.String(255), nullable=False),
        sa.Column('batch_id',           UUID(as_uuid=True)),
        sa.Column('portal_id',          UUID(as_uuid=True), nullable=False),
        sa.Column('payer_id',           UUID(as_uuid=True), nullable=False),
        sa.Column('patient_data',       JSONB(), nullable=False),
        sa.Column('clinical_data',      JSONB(), nullable=False),
        sa.Column('status',             sa.String(50), nullable=False, server_default='PENDING'),
        sa.Column('previous_status',    sa.String(50)),
        sa.Column('status_changed_at',  TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('outcome',            sa.String(50)),
        sa.Column('pa_reference_number',sa.String(255)),
        sa.Column('outcome_details',    sa.Text()),
        sa.Column('outcome_raw',        sa.Text()),
        sa.Column('retry_count',        sa.Integer(), nullable=False, server_default='0'),
        sa.Column('max_retries',        sa.Integer(), nullable=False, server_default='3'),
        sa.Column('last_retry_at',      TIMESTAMPTZ()),
        sa.Column('last_error',         sa.Text()),
        sa.Column('created_at',         TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('updated_at',         TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('queued_at',          TIMESTAMPTZ()),
        sa.Column('started_at',         TIMESTAMPTZ()),
        sa.Column('submitted_at',       TIMESTAMPTZ()),
        sa.Column('completed_at',       TIMESTAMPTZ()),
        sa.ForeignKeyConstraint(['batch_id'],  ['iks_schema.prior_auth_batch_request.id'],
                               name='fk_case_batch',  ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['portal_id'], ['iks_schema.prior_auth_portal.id'],
                               name='fk_case_portal'),
        sa.ForeignKeyConstraint(['payer_id'],  ['iks_schema.prior_auth_payer.id'],
                               name='fk_case_payer'),
        sa.UniqueConstraint('case_ref_id', name='uq_case_ref_id'),
        sa.CheckConstraint(
            "status IN ('PENDING','PLANNING','QUEUED','IN_PROGRESS','HITL_WAIT','MFA_WAIT',"
            "'SUBMITTED','APPROVED','DENIED','PENDING_INFO','CRASHED','FAILED','CANCELLED')",
            name='ck_case_status'),
        sa.CheckConstraint('retry_count >= 0', name='ck_retry_count'),
        schema='iks_schema'
    )
    op.execute("""
        CREATE TRIGGER set_updated_at BEFORE UPDATE ON iks_schema.prior_auth_case_request
        FOR EACH ROW EXECUTE FUNCTION iks_schema.trigger_set_updated_at()
    """)

    # Indexes for prior_auth_case_request
    op.create_index('idx_case_status',     'prior_auth_case_request', ['status'],     schema='iks_schema')
    op.create_index('idx_case_portal_id',  'prior_auth_case_request', ['portal_id'],  schema='iks_schema')
    op.create_index('idx_case_batch_id',   'prior_auth_case_request', ['batch_id'],   schema='iks_schema')
    op.create_index('idx_case_created_at', 'prior_auth_case_request', [sa.text('created_at DESC')],
                    schema='iks_schema')

    # --- remaining tables (HITL, logs, costs, agent sessions) ---
    op.create_table(
        'prior_auth_hitl_task',
        sa.Column('id',             UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('case_ref_id',    sa.String(255), nullable=False),
        sa.Column('task_type',      sa.String(20),  nullable=False),
        sa.Column('status',         sa.String(20),  nullable=False, server_default='PENDING'),
        sa.Column('message',        sa.Text(),      nullable=False),
        sa.Column('screenshot_url', sa.String(1000)),
        sa.Column('vnc_url',        sa.String(500)),
        sa.Column('step_name',      sa.String(255)),
        sa.Column('portal_id',      sa.String(100)),
        sa.Column('resolution',     sa.Text()),
        sa.Column('resolved_by',    UUID(as_uuid=True)),
        sa.Column('created_at',     TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('updated_at',     TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('resolved_at',    TIMESTAMPTZ()),
        sa.Column('expires_at',     TIMESTAMPTZ(),
                  server_default=sa.text("NOW() + INTERVAL '60 minutes'")),
        sa.ForeignKeyConstraint(['case_ref_id'], ['iks_schema.prior_auth_case_request.case_ref_id'],
                               name='fk_hitl_case'),
        sa.ForeignKeyConstraint(['resolved_by'], ['iks_schema.agentic_platform_user.id'],
                               name='fk_hitl_user'),
        sa.CheckConstraint("task_type IN ('HITL','MFA')", name='ck_hitl_type'),
        sa.CheckConstraint("status IN ('PENDING','RESOLVED','EXPIRED','CANCELLED')",
                          name='ck_hitl_status'),
        schema='iks_schema'
    )
    op.execute("""
        CREATE TRIGGER set_updated_at BEFORE UPDATE ON iks_schema.prior_auth_hitl_task
        FOR EACH ROW EXECUTE FUNCTION iks_schema.trigger_set_updated_at()
    """)

    op.create_table(
        'prior_auth_agent_session',
        sa.Column('id',              UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('case_ref_id',     sa.String(255), nullable=False),
        sa.Column('attempt_number',  sa.Integer(), nullable=False, server_default='1'),
        sa.Column('pod_id',          sa.String(255)),
        sa.Column('pod_ip',          sa.String(50)),
        sa.Column('pod_port',        sa.Integer(), server_default='8081'),
        sa.Column('session_id',      sa.String(255), nullable=False),
        sa.Column('display_slot',    sa.Integer()),
        sa.Column('display_num',     sa.Integer()),
        sa.Column('vnc_port',        sa.Integer()),
        sa.Column('web_port',        sa.Integer()),
        sa.Column('vnc_url',         sa.String(500)),
        sa.Column('execution_mode',  sa.String(20), nullable=False, server_default='recipe'),
        sa.Column('status',          sa.String(50), nullable=False, server_default='CREATING'),
        sa.Column('steps_completed', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('total_steps',     sa.Integer()),
        sa.Column('last_step_name',  sa.String(255)),
        sa.Column('started_at',      TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('ended_at',        TIMESTAMPTZ()),
        sa.Column('duration_seconds',sa.Integer()),
        sa.ForeignKeyConstraint(['case_ref_id'], ['iks_schema.prior_auth_case_request.case_ref_id'],
                               name='fk_agent_session_case'),
        sa.UniqueConstraint('session_id', name='uq_agent_session_id'),
        schema='iks_schema'
    )

    op.create_table(
        'prior_auth_case_logs',
        sa.Column('id',          UUID(as_uuid=True), nullable=False,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('case_ref_id', sa.String(255), nullable=False),
        sa.Column('session_id',  sa.String(255)),
        sa.Column('log_level',   sa.String(10), nullable=False, server_default='INFO'),
        sa.Column('step_name',   sa.String(255)),
        sa.Column('action_type', sa.String(50)),
        sa.Column('message',     sa.Text(), nullable=False),
        sa.Column('metadata',    JSONB()),
        sa.Column('trace_id',    sa.String(100)),
        sa.Column('created_at',  TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.CheckConstraint("log_level IN ('DEBUG','INFO','WARN','ERROR','CRITICAL')",
                          name='ck_log_level'),
        postgresql_partition_by='RANGE (created_at)',
        schema='iks_schema'
    )
    # Create initial partitions
    op.execute("""
        CREATE TABLE iks_schema.prior_auth_case_logs_2026_09
            PARTITION OF iks_schema.prior_auth_case_logs
            FOR VALUES FROM ('2026-09-01') TO ('2026-10-01')
    """)
    op.execute("""
        CREATE TABLE iks_schema.prior_auth_case_logs_2026_10
            PARTITION OF iks_schema.prior_auth_case_logs
            FOR VALUES FROM ('2026-10-01') TO ('2026-11-01')
    """)

    op.create_table(
        'agentic_platform_ai_model_pricing',
        sa.Column('id',                  UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('model_name',          sa.String(255), nullable=False),
        sa.Column('provider',            sa.String(100), nullable=False, server_default='google'),
        sa.Column('input_cost_per_1k',   sa.Numeric(12, 8), nullable=False),
        sa.Column('output_cost_per_1k',  sa.Numeric(12, 8), nullable=False),
        sa.Column('context_window',      sa.Integer()),
        sa.Column('is_active',           sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('effective_from',      TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('effective_to',        TIMESTAMPTZ()),
        sa.Column('created_at',          TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('updated_at',          TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.UniqueConstraint('model_name', 'effective_from', name='uq_model_effective'),
        schema='iks_schema'
    )

    op.create_table(
        'agentic_platform_request_cost',
        sa.Column('id',            UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('case_ref_id',   sa.String(255), nullable=False),
        sa.Column('session_id',    sa.String(255)),
        sa.Column('model_name',    sa.String(255), nullable=False),
        sa.Column('call_type',     sa.String(100), nullable=False),
        sa.Column('input_tokens',  sa.Integer(), nullable=False, server_default='0'),
        sa.Column('output_tokens', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('total_cost_usd',sa.Numeric(14, 8)),
        sa.Column('duration_ms',   sa.Integer()),
        sa.Column('success',       sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('error_message', sa.Text()),
        sa.Column('created_at',    TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.CheckConstraint(
            "call_type IN ('browser_agent','log_summary','page_extract','chatbot','planning')",
            name='ck_cost_call_type'),
        schema='iks_schema'
    )

    op.create_table(
        'agentic_platform_alert',
        sa.Column('id',          UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column('case_ref_id', sa.String(255)),
        sa.Column('alert_type',  sa.String(100), nullable=False),
        sa.Column('severity',    sa.String(20),  nullable=False, server_default='INFO'),
        sa.Column('title',       sa.String(255), nullable=False),
        sa.Column('message',     sa.Text(),      nullable=False),
        sa.Column('metadata',    JSONB()),
        sa.Column('is_read',     sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('is_resolved', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('read_by',     UUID(as_uuid=True)),
        sa.Column('read_at',     TIMESTAMPTZ()),
        sa.Column('created_at',  TIMESTAMPTZ(), nullable=False, server_default=sa.text("NOW()")),
        sa.Column('expires_at',  TIMESTAMPTZ(),
                  server_default=sa.text("NOW() + INTERVAL '24 hours'")),
        sa.CheckConstraint("severity IN ('INFO','WARNING','ERROR','CRITICAL')",
                          name='ck_alert_severity'),
        schema='iks_schema'
    )

    # Remaining table indexes
    op.create_index('idx_hitl_status',        'prior_auth_hitl_task',    ['status'],     schema='iks_schema')
    op.create_index('idx_hitl_case_ref',      'prior_auth_hitl_task',    ['case_ref_id'],schema='iks_schema')
    op.create_index('idx_agent_session_case', 'prior_auth_agent_session',['case_ref_id'],schema='iks_schema')
    op.create_index('idx_logs_case_ref',      'prior_auth_case_logs',
                    [sa.text('case_ref_id'), sa.text('created_at DESC')],schema='iks_schema')
    op.create_index('idx_cost_case_ref',      'agentic_platform_request_cost',['case_ref_id'],schema='iks_schema')
    op.create_index('idx_cost_created_at',    'agentic_platform_request_cost',
                    [sa.text('created_at DESC')],schema='iks_schema')
    op.create_index('idx_alert_is_read',      'agentic_platform_alert',  ['is_read','created_at'],
                    schema='iks_schema')


def downgrade() -> None:
    # Drop in reverse dependency order
    for table in [
        'agentic_platform_alert', 'agentic_platform_request_cost',
        'agentic_platform_ai_model_pricing', 'prior_auth_case_logs',
        'prior_auth_agent_session', 'prior_auth_hitl_task',
        'prior_auth_case_request', 'prior_auth_batch_request',
        'prior_auth_portal_credential', 'prior_auth_portal',
        'agentic_platform_user', 'prior_auth_payer',
    ]:
        op.drop_table(table, schema='iks_schema')
    op.execute("DROP SCHEMA IF EXISTS iks_schema CASCADE")
```

### 7.5 Migration: 0008_seed_ai_model_pricing.py

```python
"""Seed AI model pricing data

Revision ID: 0008
Revises: 0007
"""
from alembic import op

revision = '0008'
down_revision = '0007'


def upgrade() -> None:
    op.execute("""
        INSERT INTO iks_schema.agentic_platform_ai_model_pricing
            (model_name, provider, input_cost_per_1k, output_cost_per_1k, context_window, is_active)
        VALUES
            ('gemini-2.5-pro',     'google', 0.00125, 0.01000, 1048576, true),
            ('gemini-2.0-flash',   'google', 0.00010, 0.00040, 1048576, true),
            ('gemini-1.5-pro',     'google', 0.00125, 0.00500, 2000000, true),
            ('gemini-1.5-flash',   'google', 0.000075, 0.000300, 1000000, true)
        ON CONFLICT (model_name, effective_from) DO NOTHING
    """)


def downgrade() -> None:
    op.execute("""
        DELETE FROM iks_schema.agentic_platform_ai_model_pricing
        WHERE model_name IN ('gemini-2.5-pro','gemini-2.0-flash','gemini-1.5-pro','gemini-1.5-flash')
    """)
```

---

## 8. SQLAlchemy ORM Models

```python
# common/db_layer/orm_models/base.py
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import MetaData

SCHEMA = "iks_schema"

# Use naming convention for auto-generated constraint names
convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

class Base(DeclarativeBase):
    metadata = MetaData(schema=SCHEMA, naming_convention=convention)
```

```python
# common/db_layer/orm_models/prior_auth_case.py
import uuid
from datetime import datetime
from sqlalchemy import String, Boolean, Integer, Text, Numeric, ForeignKey, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB, TIMESTAMPTZ
from .base import Base, SCHEMA


class PriorAuthPayer(Base):
    __tablename__ = "prior_auth_payer"
    __table_args__ = {"schema": SCHEMA}

    id:         Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), primary_key=True,
                                                    default=uuid.uuid4)
    payer_name: Mapped[str]        = mapped_column(String(255), nullable=False)
    payer_code: Mapped[str]        = mapped_column(String(100), nullable=False, unique=True)
    payer_type: Mapped[str]        = mapped_column(String(50),  nullable=False, default="COMMERCIAL")
    is_active:  Mapped[bool]       = mapped_column(Boolean(),   nullable=False, default=True)
    metadata_:  Mapped[dict | None]= mapped_column("metadata", JSONB(), nullable=True)
    created_at: Mapped[datetime]   = mapped_column(TIMESTAMPTZ(), nullable=False, default=datetime.utcnow)
    updated_at: Mapped[datetime]   = mapped_column(TIMESTAMPTZ(), nullable=False, default=datetime.utcnow,
                                                    onupdate=datetime.utcnow)

    portals:    Mapped[list["PriorAuthPortal"]] = relationship(back_populates="payer")


class PriorAuthPortal(Base):
    __tablename__ = "prior_auth_portal"
    __table_args__ = {"schema": SCHEMA}

    id:              Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), primary_key=True,
                                                         default=uuid.uuid4)
    payer_id:        Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True),
                                                         ForeignKey(f"{SCHEMA}.prior_auth_payer.id"),
                                                         nullable=False)
    portal_name:     Mapped[str]        = mapped_column(String(255), nullable=False)
    portal_id:       Mapped[str]        = mapped_column(String(100), nullable=False, unique=True)
    base_url:        Mapped[str | None] = mapped_column(String(500))
    login_url:       Mapped[str | None] = mapped_column(String(500))
    is_active:       Mapped[bool]       = mapped_column(Boolean(), default=True)
    supports_recipe: Mapped[bool]       = mapped_column(Boolean(), default=True)
    supports_llm:    Mapped[bool]       = mapped_column(Boolean(), default=False)
    notes:           Mapped[str | None] = mapped_column(Text())
    created_at:      Mapped[datetime]   = mapped_column(TIMESTAMPTZ(), default=datetime.utcnow)
    updated_at:      Mapped[datetime]   = mapped_column(TIMESTAMPTZ(), default=datetime.utcnow,
                                                         onupdate=datetime.utcnow)

    payer:           Mapped["PriorAuthPayer"]              = relationship(back_populates="portals")
    credentials:     Mapped[list["PriorAuthPortalCredential"]] = relationship(back_populates="portal")
    cases:           Mapped[list["PriorAuthCaseRequest"]]  = relationship(back_populates="portal")


class PriorAuthCaseRequest(Base):
    __tablename__ = "prior_auth_case_request"
    __table_args__ = (
        CheckConstraint(
            "status IN ('PENDING','PLANNING','QUEUED','IN_PROGRESS','HITL_WAIT','MFA_WAIT',"
            "'SUBMITTED','APPROVED','DENIED','PENDING_INFO','CRASHED','FAILED','CANCELLED')",
            name="ck_case_status"
        ),
        {"schema": SCHEMA}
    )

    id:                  Mapped[uuid.UUID]   = mapped_column(UUID(as_uuid=True), primary_key=True,
                                                              default=uuid.uuid4)
    case_ref_id:         Mapped[str]         = mapped_column(String(255), unique=True, nullable=False)
    batch_id:            Mapped[uuid.UUID | None] = mapped_column(
                                                UUID(as_uuid=True),
                                                ForeignKey(f"{SCHEMA}.prior_auth_batch_request.id"))
    portal_id:           Mapped[uuid.UUID]   = mapped_column(
                                                UUID(as_uuid=True),
                                                ForeignKey(f"{SCHEMA}.prior_auth_portal.id"),
                                                nullable=False)
    payer_id:            Mapped[uuid.UUID]   = mapped_column(
                                                UUID(as_uuid=True),
                                                ForeignKey(f"{SCHEMA}.prior_auth_payer.id"),
                                                nullable=False)
    patient_data:        Mapped[dict]        = mapped_column(JSONB(), nullable=False)
    clinical_data:       Mapped[dict]        = mapped_column(JSONB(), nullable=False)
    status:              Mapped[str]         = mapped_column(String(50), nullable=False, default="PENDING")
    previous_status:     Mapped[str | None]  = mapped_column(String(50))
    status_changed_at:   Mapped[datetime]    = mapped_column(TIMESTAMPTZ(), default=datetime.utcnow)
    outcome:             Mapped[str | None]  = mapped_column(String(50))
    pa_reference_number: Mapped[str | None]  = mapped_column(String(255))
    outcome_details:     Mapped[str | None]  = mapped_column(Text())
    outcome_raw:         Mapped[str | None]  = mapped_column(Text())
    retry_count:         Mapped[int]         = mapped_column(Integer(), default=0)
    max_retries:         Mapped[int]         = mapped_column(Integer(), default=3)
    last_retry_at:       Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())
    last_error:          Mapped[str | None]  = mapped_column(Text())
    created_at:          Mapped[datetime]    = mapped_column(TIMESTAMPTZ(), default=datetime.utcnow)
    updated_at:          Mapped[datetime]    = mapped_column(TIMESTAMPTZ(), default=datetime.utcnow,
                                                              onupdate=datetime.utcnow)
    queued_at:           Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())
    started_at:          Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())
    submitted_at:        Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())
    completed_at:        Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())

    portal:    Mapped["PriorAuthPortal"]          = relationship(back_populates="cases")
    sessions:  Mapped[list["PriorAuthAgentSession"]] = relationship(
                   back_populates="case",
                   foreign_keys="PriorAuthAgentSession.case_ref_id",
                   primaryjoin="PriorAuthCaseRequest.case_ref_id==PriorAuthAgentSession.case_ref_id")
    hitl_tasks: Mapped[list["PriorAuthHitlTask"]] = relationship(back_populates="case")
```

---

## 9. Seed Data Scripts

```python
# scripts/seed_test_data.py
"""Populates the database with test data for local development."""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from common.db_layer.orm_models import *

DATABASE_URL = (
    f"postgresql://autoauth_app:localpassword123"
    f"@localhost:5433/autoauth"
)

engine = create_engine(DATABASE_URL)

PAYERS = [
    {"payer_name": "UnitedHealth Group",  "payer_code": "UHC",    "payer_type": "COMMERCIAL"},
    {"payer_name": "Aetna",               "payer_code": "AETNA",  "payer_type": "COMMERCIAL"},
    {"payer_name": "Cigna",               "payer_code": "CIGNA",  "payer_type": "COMMERCIAL"},
    {"payer_name": "Blue Cross Blue Shield","payer_code": "BCBS",  "payer_type": "COMMERCIAL"},
    {"payer_name": "Humana",              "payer_code": "HUMANA", "payer_type": "COMMERCIAL"},
]

PORTALS = [
    {"payer_code": "UHC",   "portal_name": "Availity (UHC)",      "portal_id": "availity",
     "base_url": "https://apps.availity.com",  "supports_recipe": True},
    {"payer_code": "AETNA", "portal_name": "Navinet (Aetna)",      "portal_id": "navinet",
     "base_url": "https://www.navinet.net",    "supports_recipe": True},
    {"payer_code": "CIGNA", "portal_name": "CareCore (Cigna)",     "portal_id": "carecore",
     "base_url": "https://www.carecore.net",   "supports_recipe": True},
    {"payer_code": "BCBS",  "portal_name": "GIA Carelon (BCBS)",   "portal_id": "gia-carelon",
     "base_url": "https://provider.carelonmedical.com", "supports_recipe": True},
    {"payer_code": "HUMANA","portal_name": "Humana Provider Portal","portal_id": "humana",
     "base_url": "https://providerlocator.humana.com",  "supports_recipe": False,
     "supports_llm": True},
]

AI_MODELS = [
    {"model_name": "gemini-2.5-pro",   "input_cost_per_1k": 0.00125,  "output_cost_per_1k": 0.01000, "context_window": 1048576},
    {"model_name": "gemini-2.0-flash", "input_cost_per_1k": 0.00010,  "output_cost_per_1k": 0.00040, "context_window": 1048576},
    {"model_name": "gemini-1.5-flash", "input_cost_per_1k": 0.000075, "output_cost_per_1k": 0.000300,"context_window": 1000000},
]

def seed():
    with Session(engine) as session:
        # Seed payers
        payer_map = {}
        for p in PAYERS:
            existing = session.query(PriorAuthPayer).filter_by(payer_code=p["payer_code"]).first()
            if not existing:
                payer = PriorAuthPayer(**p)
                session.add(payer)
                session.flush()
                payer_map[p["payer_code"]] = payer.id
                print(f"  [+] Payer: {p['payer_name']}")
            else:
                payer_map[p["payer_code"]] = existing.id
                print(f"  [=] Payer exists: {p['payer_name']}")

        # Seed portals
        for p in PORTALS:
            existing = session.query(PriorAuthPortal).filter_by(portal_id=p["portal_id"]).first()
            if not existing:
                portal = PriorAuthPortal(
                    payer_id=payer_map[p["payer_code"]],
                    portal_name=p["portal_name"],
                    portal_id=p["portal_id"],
                    base_url=p.get("base_url"),
                    supports_recipe=p.get("supports_recipe", True),
                    supports_llm=p.get("supports_llm", False),
                )
                session.add(portal)
                print(f"  [+] Portal: {p['portal_name']}")

        # Seed AI model pricing
        for m in AI_MODELS:
            existing = session.query(AgenticPlatformAiModelPricing).filter_by(
                model_name=m["model_name"]).first()
            if not existing:
                model = AgenticPlatformAiModelPricing(**m)
                session.add(model)
                print(f"  [+] Model pricing: {m['model_name']}")

        # Seed admin user
        existing_user = session.query(AgenticPlatformUser).filter_by(
            email="admin@autoauth.local").first()
        if not existing_user:
            import bcrypt
            hashed = bcrypt.hashpw(b"Admin@1234!", bcrypt.gensalt(12)).decode()
            admin = AgenticPlatformUser(
                email="admin@autoauth.local",
                hashed_password=hashed,
                full_name="Local Admin",
                role="ADMIN",
            )
            session.add(admin)
            print("  [+] Admin user: admin@autoauth.local / Admin@1234!")

        session.commit()
        print("\n✅ Seed data committed successfully.")

if __name__ == "__main__":
    print("Seeding database...")
    seed()
```

---

## 10. Key Query Patterns

```sql
-- ── Q1: Dashboard — active cases with VNC URL ─────────────────────────────
SELECT
    c.case_ref_id,
    c.status,
    p.portal_id AS portal_slug,
    p.portal_name,
    c.patient_data->>'member_id'   AS member_id,
    c.patient_data->>'first_name'  AS first_name,
    c.patient_data->>'last_name'   AS last_name,
    c.created_at,
    c.updated_at,
    s.vnc_url,
    h.task_type                     AS hitl_type,
    h.message                       AS hitl_message
FROM iks_schema.prior_auth_case_request c
JOIN iks_schema.prior_auth_portal p ON c.portal_id = p.id
LEFT JOIN iks_schema.prior_auth_agent_session s
    ON s.case_ref_id = c.case_ref_id
    AND s.status IN ('ACTIVE','RUNNING','HITL_WAIT','MFA_WAIT')
LEFT JOIN iks_schema.prior_auth_hitl_task h
    ON h.case_ref_id = c.case_ref_id AND h.status = 'PENDING'
WHERE c.status NOT IN ('APPROVED','DENIED','FAILED','CANCELLED')
ORDER BY c.updated_at DESC
LIMIT 50;

-- ── Q2: Run volume by day for a date range ────────────────────────────────
SELECT
    DATE_TRUNC('day', c.created_at AT TIME ZONE 'UTC') AS period_start,
    COUNT(*)                                            AS total,
    COUNT(*) FILTER (WHERE c.outcome = 'APPROVED')     AS approved,
    COUNT(*) FILTER (WHERE c.outcome = 'DENIED')       AS denied,
    COUNT(*) FILTER (WHERE c.status = 'IN_PROGRESS')   AS in_progress,
    COUNT(*) FILTER (WHERE c.status IN ('FAILED','CRASHED')) AS failed
FROM iks_schema.prior_auth_case_request c
WHERE c.created_at >= '2026-09-01'::TIMESTAMPTZ
  AND c.created_at <  '2026-09-08'::TIMESTAMPTZ
GROUP BY 1
ORDER BY 1;

-- ── Q3: LLM cost by portal for a period ──────────────────────────────────
SELECT
    p.portal_id AS portal_slug,
    p.portal_name,
    SUM(rc.total_cost_usd)  AS total_cost_usd,
    SUM(rc.input_tokens)    AS total_input_tokens,
    SUM(rc.output_tokens)   AS total_output_tokens,
    COUNT(DISTINCT rc.case_ref_id) AS case_count,
    AVG(rc.total_cost_usd)  AS avg_cost_per_call
FROM iks_schema.agentic_platform_request_cost rc
JOIN iks_schema.prior_auth_case_request c ON rc.case_ref_id = c.case_ref_id
JOIN iks_schema.prior_auth_portal p       ON c.portal_id = p.id
WHERE rc.created_at >= '2026-09-01'::TIMESTAMPTZ
  AND rc.created_at <  '2026-10-01'::TIMESTAMPTZ
GROUP BY p.portal_id, p.portal_name
ORDER BY total_cost_usd DESC;

-- ── Q4: Pending HITL tasks for operator dashboard ─────────────────────────
SELECT
    h.id            AS task_id,
    h.case_ref_id,
    h.task_type,
    h.message,
    h.screenshot_url,
    h.vnc_url,
    h.step_name,
    h.created_at,
    h.expires_at,
    EXTRACT(EPOCH FROM (h.expires_at - NOW()))::INTEGER AS seconds_until_expiry,
    c.patient_data->>'member_id' AS member_id,
    p.portal_name
FROM iks_schema.prior_auth_hitl_task h
JOIN iks_schema.prior_auth_case_request c ON h.case_ref_id = c.case_ref_id
JOIN iks_schema.prior_auth_portal p       ON c.portal_id = p.id
WHERE h.status = 'PENDING'
ORDER BY h.task_type = 'MFA' DESC,   -- MFA tasks first (shorter timeout)
         h.created_at ASC;           -- Oldest first

-- ── Q5: Case logs for a specific case (descending) ────────────────────────
SELECT
    l.id,
    l.log_level,
    l.step_name,
    l.action_type,
    l.message,
    l.metadata,
    l.created_at
FROM iks_schema.prior_auth_case_logs l
WHERE l.case_ref_id = 'CASE-2026-09-001-001'
ORDER BY l.created_at DESC
LIMIT 100;

-- ── Q6: Find in-flight cases for a crashed pod ────────────────────────────
SELECT
    s.case_ref_id,
    s.session_id,
    s.started_at,
    c.status,
    c.retry_count
FROM iks_schema.prior_auth_agent_session s
JOIN iks_schema.prior_auth_case_request c ON s.case_ref_id = c.case_ref_id
WHERE s.pod_id = 'browser-agent-abc123'
  AND s.status IN ('ACTIVE','RUNNING','HITL_WAIT','MFA_WAIT');

-- ── Q7: Batch completion check ────────────────────────────────────────────
SELECT
    b.batch_id,
    b.total_cases,
    COUNT(c.id)                                          AS processed,
    COUNT(*) FILTER (WHERE c.outcome = 'APPROVED')      AS approved,
    COUNT(*) FILTER (WHERE c.outcome = 'DENIED')        AS denied,
    COUNT(*) FILTER (WHERE c.status = 'FAILED')         AS failed,
    COUNT(*) FILTER (WHERE c.status NOT IN
        ('APPROVED','DENIED','FAILED','CANCELLED'))      AS still_active
FROM iks_schema.prior_auth_batch_request b
LEFT JOIN iks_schema.prior_auth_case_request c ON c.batch_id = b.id
WHERE b.batch_id = 'BATCH-2026-09-001'
GROUP BY b.batch_id, b.total_cases;

-- ── Q8: Cases eligible for retry ─────────────────────────────────────────
SELECT
    case_ref_id,
    status,
    retry_count,
    max_retries,
    last_error,
    updated_at
FROM iks_schema.prior_auth_case_request
WHERE status IN ('CRASHED','FAILED')
  AND retry_count < max_retries
ORDER BY updated_at ASC;
```

---

## 11. Partitioning Strategy

```sql
-- prior_auth_case_logs is partitioned by RANGE (created_at) monthly.
-- A cron job (or pg_partman) creates next month's partition in advance.

-- Partition management script (run monthly via K8s CronJob)
-- Creates partition for upcoming month + drops partitions older than 6 months

CREATE OR REPLACE PROCEDURE iks_schema.manage_log_partitions()
LANGUAGE plpgsql AS $$
DECLARE
    next_month     DATE := DATE_TRUNC('month', NOW()) + INTERVAL '1 month';
    next_next      DATE := next_month + INTERVAL '1 month';
    old_month      DATE := DATE_TRUNC('month', NOW()) - INTERVAL '6 months';
    partition_name TEXT;
BEGIN
    -- Create next month partition (idempotent)
    partition_name := 'prior_auth_case_logs_' || TO_CHAR(next_month, 'YYYY_MM');
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables
        WHERE schemaname = 'iks_schema' AND tablename = partition_name
    ) THEN
        EXECUTE FORMAT(
            'CREATE TABLE iks_schema.%I PARTITION OF iks_schema.prior_auth_case_logs
             FOR VALUES FROM (%L) TO (%L)',
            partition_name, next_month, next_next
        );
        RAISE NOTICE 'Created partition: %', partition_name;
    END IF;

    -- Drop old partition (older than 6 months) — data already synced to PostgreSQL case_logs
    partition_name := 'prior_auth_case_logs_' || TO_CHAR(old_month, 'YYYY_MM');
    IF EXISTS (
        SELECT 1 FROM pg_tables
        WHERE schemaname = 'iks_schema' AND tablename = partition_name
    ) THEN
        EXECUTE FORMAT('DROP TABLE iks_schema.%I', partition_name);
        RAISE NOTICE 'Dropped old partition: %', partition_name;
    END IF;
END;
$$;

-- K8s CronJob: runs on the 25th of each month at 2 AM UTC
-- apiVersion: batch/v1
-- kind: CronJob
-- spec:
--   schedule: "0 2 25 * *"
--   jobTemplate:
--     spec:
--       template:
--         spec:
--           containers:
--             - name: partition-manager
--               image: postgres:16-alpine
--               command: ["psql", "-c", "CALL iks_schema.manage_log_partitions()"]
```

---

## 12. Data Retention Policy

```
Table                           Retention       Method
──────────────────────────────────────────────────────────────────────────────
prior_auth_case_request         7 years         Soft delete (status=CANCELLED)
                                                Hard delete after 7 years via job
prior_auth_batch_request        7 years         Soft delete
prior_auth_agent_session        1 year          Hard delete rows older than 1 year
prior_auth_case_logs            6 months        Partitioned — drop old partition
prior_auth_hitl_task            2 years         Hard delete after 2 years
agentic_platform_request_cost   3 years         Hard delete after 3 years
agentic_platform_alert          30 days         Hard delete is_resolved=true OR expired
prior_auth_tracking_session     1 year          Hard delete
prior_auth_planner_agent_status 1 year          Hard delete
agentic_platform_user           Active users    Soft delete (is_active=false)

Retention enforcement:
  → Monthly K8s CronJob runs DELETE queries for each retention rule
  → Wrapped in transactions with LIMIT 1000 to avoid long-running deletes
  → Partition drop handles prior_auth_case_logs (see Section 11)

HIPAA note:
  → prior_auth_case_request retains 7 years per HIPAA minimum
  → patient_data and clinical_data are JSONB — not separately deletable
  → Full row retained; JSONB fields could be nulled on request (right to erasure)
  → Document retention policy in BAA with each customer
```

---

*Document Status: DRAFT*
*Previous: [03_API_Contracts_OpenAPI.md](03_API_Contracts_OpenAPI.md)*
*Next: [05_Recipe_Engine_and_Portal_Specification.md](05_Recipe_Engine_and_Portal_Specification.md)*
