# AutoAuth Agent — Recipe Engine & Portal Specification
**Phase 1 | Weeks 1–2**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0
**Prerequisite:** [04_Database_Schema_Design.md](04_Database_Schema_Design.md)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Recipe YAML Top-Level Schema](#2-recipe-yaml-top-level-schema)
3. [Value Resolution — `resolve_value()`](#3-value-resolution--resolve_value)
4. [All 14 Action Types — Full Specification](#4-all-14-action-types--full-specification)
5. [Control Flow — `foreach`](#5-control-flow--foreach)
6. [Recipe Execution Engine — Internal Flow](#6-recipe-execution-engine--internal-flow)
7. [Error Handling & Retry Logic](#7-error-handling--retry-logic)
8. [Dropdown Matching — `pick_option()`](#8-dropdown-matching--pick_option)
9. [Recipe Validation Rules](#9-recipe-validation-rules)
10. [Complete Portal Recipes](#10-complete-portal-recipes)
11. [LLM Agent Mode](#11-llm-agent-mode)
12. [Recipe Authoring Guide](#12-recipe-authoring-guide)
13. [Recipe CI Validation](#13-recipe-ci-validation)

---

## 1. Overview

The Recipe Engine is the deterministic execution core of the `browser-agent` service. It reads a portal-specific YAML recipe, interprets each step, and drives a Playwright browser to complete a Prior Authorization submission on a payer portal.

```
Execution modes controlled by PLAYWRIGHT_EXECUTION_ENGINE env var:
  ┌───────────────────────────────────────────────────────────────┐
  │  PLAYWRIGHT_EXECUTION_ENGINE=yes  →  Recipe Engine (YAML)     │
  │  PLAYWRIGHT_EXECUTION_ENGINE=no   →  LLM Agent (browser-use)  │
  └───────────────────────────────────────────────────────────────┘

Recipe Engine advantages:         LLM Agent advantages:
  • Deterministic execution          • No recipe required
  • No LLM cost per step             • Handles UI variations
  • Fast (no inference latency)      • Self-corrects on unexpected UI
  • Auditable step-by-step logs      • Works on new portals immediately
  • No hallucination risk

Default: Recipe Engine (yes).
LLM Agent used for: new portals without a recipe, fallback on recipe failure.
```

---

## 2. Recipe YAML Top-Level Schema

```yaml
# Schema version — bump on breaking changes
version: "1.0"

# Portal identifier — must match prior_auth_portal.portal_id in DB
portal_id: "availity"

# Human-readable name
portal_name: "Availity Provider Portal"

# Base URL used for relative path navigation
base_url: "https://apps.availity.com"

# Recipe format version (separate from schema version)
recipe_version: "2.3.1"

# Author and last-update tracking (informational only)
author: "niranjansai.k@ikshealth.com"
updated_at: "2026-09-01"

# Default timeout (milliseconds) applied to all steps unless overridden
default_timeout_ms: 30000

# Default wait after navigation (milliseconds)
default_nav_wait_ms: 2000

# Maximum number of foreach iterations before abort (safety cap)
foreach_max_iterations: 200

# Whether this portal requires CAPTCHA solving (triggers Capsolver)
requires_captcha: false

# Whether this portal uses MFA (OTP via SMS/email)
requires_mfa: false

# Credentials section — resolved at runtime via Secret Manager
credentials:
  username_field: "username"          # Key in case payload / credential store
  password_field: "password"
  credential_source: "secret_manager" # Always "secret_manager" — never hardcoded

# Steps: ordered list of actions to execute
steps:
  - id: "step_navigate_login"
    action: navigate
    url: "https://apps.availity.com/availity/web/public.elegant.login"
    wait_ms: 3000

  - id: "step_fill_username"
    action: fill
    selector: "#username"
    value: "{{credentials.username}}"

  # ... more steps ...

# Optional: extraction schema for pulling PA reference number from confirmation page
extraction:
  pa_reference_number:
    selector: ".confirmation-number"
    attribute: "text"        # text | innerText | value | data-attr-name
    regex: "Auth #: (\\w+)"  # Optional: capture group 1 extracted
    required: true
```

---

## 3. Value Resolution — `resolve_value()`

Every `value:` field in a recipe step is a template string. The engine resolves it at runtime before acting.

### 3.1 Template Syntax

```
{{source.field_name}}
```

| Source prefix      | Resolves from                                      | Example                           |
|--------------------|----------------------------------------------------|------------------------------------|
| `patient`          | `case_request.patient_data` JSONB                  | `{{patient.member_id}}`            |
| `clinical`         | `case_request.clinical_data` JSONB                 | `{{clinical.procedure_codes.0}}`   |
| `credentials`      | GCP Secret Manager (loaded at session start)       | `{{credentials.username}}`         |
| `env`              | Environment variables (non-secret config only)     | `{{env.PORTAL_REGION}}`            |
| `context`          | Runtime context (set by previous extract steps)    | `{{context.authorization_number}}` |
| `static`           | Literal string (no resolution needed)              | `{{static.INPATIENT}}`             |
| `computed`         | Python expression evaluated at runtime             | `{{computed.today_plus_30}}`       |

### 3.2 Nested Field Access

```yaml
# Access nested JSONB: clinical_data.diagnosis_codes[0]
value: "{{clinical.diagnosis_codes.0}}"

# Access first procedure code
value: "{{clinical.procedure_codes.0}}"

# Access provider NPI
value: "{{clinical.rendering_npi}}"
```

### 3.3 Computed Values

```python
# Computed values available in resolve_value():
COMPUTED_VALUES = {
    "today":          lambda: date.today().strftime("%m/%d/%Y"),
    "today_iso":      lambda: date.today().isoformat(),
    "today_plus_30":  lambda: (date.today() + timedelta(days=30)).strftime("%m/%d/%Y"),
    "today_plus_90":  lambda: (date.today() + timedelta(days=90)).strftime("%m/%d/%Y"),
    "today_plus_365": lambda: (date.today() + timedelta(days=365)).strftime("%m/%d/%Y"),
    "timestamp":      lambda: datetime.utcnow().isoformat(),
}
```

### 3.4 Resolution Algorithm

```python
def resolve_value(template: str, context: RecipeContext) -> str:
    """
    Resolves {{source.field}} templates in a value string.
    Supports multiple templates in one string: "{{patient.first_name}} {{patient.last_name}}"
    """
    import re

    def replace_match(match: re.Match) -> str:
        expression = match.group(1).strip()          # e.g. "patient.member_id"
        parts = expression.split(".", maxsplit=1)
        source = parts[0]
        field  = parts[1] if len(parts) > 1 else ""

        if source == "patient":
            return _get_nested(context.patient_data, field)
        elif source == "clinical":
            return _get_nested(context.clinical_data, field)
        elif source == "credentials":
            return context.credentials.get(field, "")
        elif source == "env":
            return os.environ.get(field, "")
        elif source == "context":
            return context.runtime_vars.get(field, "")
        elif source == "static":
            return field
        elif source == "computed":
            fn = COMPUTED_VALUES.get(field)
            return fn() if fn else ""
        else:
            raise RecipeValueError(f"Unknown template source: {source}")

    pattern = r"\{\{([^}]+)\}\}"
    return re.sub(pattern, replace_match, template)


def _get_nested(data: dict, path: str) -> str:
    """Traverse dot-separated path; supports integer index for lists."""
    parts = path.split(".")
    current = data
    for part in parts:
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except (IndexError, ValueError):
                return ""
        elif isinstance(current, dict):
            current = current.get(part, "")
        else:
            return str(current)
    return str(current) if current is not None else ""
```

---

## 4. All 14 Action Types — Full Specification

### 4.1 `navigate`

Navigate the browser to a URL.

```yaml
- id: "step_go_to_login"
  action: navigate
  url: "https://apps.availity.com/login"   # Supports {{template}} syntax
  wait_ms: 3000                             # Wait after navigation (overrides default)
  wait_for: "networkidle"                  # networkidle | load | domcontentloaded | selector
  wait_for_selector: "#main-content"       # Used when wait_for: selector
  timeout_ms: 30000
```

**Implementation notes:**
- `wait_for: networkidle` — waits until no network requests for 500ms
- Always use `wait_for: networkidle` after a form submission that triggers a page load
- For SPAs that update without full navigation, use `wait_for: selector` instead

---

### 4.2 `fill`

Type a value into an input field (clears existing content first).

```yaml
- id: "step_fill_member_id"
  action: fill
  selector: "#member-id-input"             # CSS selector or XPath
  value: "{{patient.member_id}}"
  clear_first: true                        # Default: true — clears before filling
  press_enter: false                       # Optional: press Enter after filling
  tab_after: false                         # Optional: press Tab after filling
  timeout_ms: 10000
  optional: false                          # If true, skip if selector not found
```

**Implementation notes:**
- Uses Playwright `locator.fill()` which dispatches input events
- Set `press_enter: true` for autocomplete fields that trigger on Enter
- Set `tab_after: true` for date fields that commit on Tab

---

### 4.3 `click`

Click an element.

```yaml
- id: "step_click_submit"
  action: click
  selector: "button[type='submit']"
  wait_after_ms: 1000                      # Wait after click (default: 500)
  wait_for_navigation: true               # Wait for page navigation after click
  timeout_ms: 15000
  force: false                             # Force click even if element not visible
  button: "left"                           # left | right | middle
  optional: false
```

---

### 4.4 `click_path`

Click through a series of selectors in sequence. Used for multi-step menu navigation.

```yaml
- id: "step_navigate_menu"
  action: click_path
  path:
    - selector: "#main-menu"
      wait_ms: 500
    - selector: "a[href='/prior-auth']"
      wait_ms: 800
    - selector: "#start-new-request"
      wait_ms: 1000
  timeout_ms: 30000
```

**Implementation notes:**
- Each element in `path` is clicked in order
- Individual `wait_ms` gives the portal time to render intermediate menu states
- Aborts on first selector not found

---

### 4.5 `type_and_pick`

Type into an autocomplete/typeahead input and select a matching option from the dropdown.

```yaml
- id: "step_select_procedure"
  action: type_and_pick
  selector: "#procedure-search"           # The input field
  value: "{{clinical.procedure_codes.0}}" # Text to type (e.g., "27447")
  dropdown_selector: ".autocomplete-results li"  # Dropdown options selector
  match_strategy: "contains"             # exact | contains | starts_with | fuzzy
  pick_index: 0                          # If multiple matches, pick nth (0-indexed)
  clear_first: true
  wait_for_dropdown_ms: 2000             # Time to wait for dropdown to appear
  timeout_ms: 20000
```

---

### 4.6 `select_if_mismatch`

Select a dropdown option — but only if the current value doesn't already match.

```yaml
- id: "step_select_state"
  action: select_if_mismatch
  selector: "#state-dropdown"
  value: "{{patient.state}}"             # e.g., "California" or "CA"
  match_strategy: "exact"               # exact | contains | starts_with | fuzzy
  use_pick_option: true                 # Use pick_option() for fuzzy matching
  timeout_ms: 10000
  optional: false
```

**Why `select_if_mismatch`?** Some portals pre-populate dropdowns based on earlier inputs. Re-selecting the same value triggers unwanted change events. This action reads the current selected value first and skips if already correct.

---

### 4.7 `select_row`

Select a row in a search results table (used after searching for a patient/member).

```yaml
- id: "step_select_member_row"
  action: select_row
  table_selector: "table.member-results"
  row_selector: "tbody tr"
  match_column: 2                        # 1-indexed column to match against
  match_value: "{{patient.member_id}}"
  match_strategy: "contains"
  action_selector: "td:last-child a"     # Element to click within the matched row
  fallback: "first"                      # first | fail — if no exact match
  timeout_ms: 20000
```

**Implementation notes:**
- Scans each `row_selector` element, reads text of column `match_column`
- Clicks `action_selector` within the matched row
- `fallback: first` — if member ID not found, click first row (common when search returns one result)

---

### 4.8 `foreach`

Loop over a list of values and execute nested steps for each iteration.

```yaml
- id: "step_add_procedure_codes"
  action: foreach
  items: "{{clinical.procedure_codes}}"  # Resolves to a list from clinical_data
  as: "procedure_code"                   # Variable name for current item
  index_as: "idx"                        # Optional: current iteration index (0-based)
  max_iterations: 20                     # Safety cap
  steps:
    - id: "click_add_code"
      action: click
      selector: "#add-procedure-btn"

    - id: "fill_code"
      action: fill
      selector: "#procedure-code-input"
      value: "{{context.procedure_code}}"   # Access loop variable via context

    - id: "click_save_code"
      action: click
      selector: "#save-code-btn"
      wait_after_ms: 500

  # Optional: run these steps only on the first iteration
  first_iteration_only:
    - id: "open_section"
      action: click
      selector: "#procedures-section"
```

**Implementation notes:**
- `items` resolves to a Python list via `resolve_value()`
- Loop variable is injected into `context.runtime_vars` as `context.{as}`
- `index_as` injects `context.{index_as}` (string "0", "1", ...)
- Nested steps have full access to all value resolution sources

---

### 4.9 `wait`

Explicit wait — for element visibility, network idle, or fixed duration.

```yaml
# Wait for element to appear
- id: "step_wait_for_confirmation"
  action: wait
  wait_for: "selector"
  selector: ".confirmation-message"
  timeout_ms: 60000

# Wait for fixed duration
- id: "step_wait_2_seconds"
  action: wait
  wait_for: "duration"
  duration_ms: 2000

# Wait for network idle
- id: "step_wait_network"
  action: wait
  wait_for: "networkidle"
  timeout_ms: 30000
```

---

### 4.10 `upload`

Upload a file to a portal file input.

```yaml
- id: "step_upload_clinical_docs"
  action: upload
  selector: "input[type='file']"
  file_source: "gcs"                     # gcs | base64 | local
  gcs_bucket: "{{env.DOCUMENT_BUCKET}}"
  gcs_path: "{{clinical.document_path}}"
  local_temp_dir: "/tmp/autoauth_uploads"
  accepted_types: [".pdf", ".jpg", ".png"]
  timeout_ms: 60000
```

**Implementation notes:**
- `file_source: gcs` — downloads from GCS to local temp dir before upload
- GCS download uses Workload Identity (no API key)
- Temp file deleted after upload completes

---

### 4.11 `mfa`

Pause execution and wait for an OTP code from the operator via the MFA channel.

```yaml
- id: "step_handle_mfa"
  action: mfa
  prompt: "Enter the OTP code sent to the portal's registered phone number"
  input_selector: "#otp-input"           # Where to type the OTP
  submit_selector: "#verify-btn"         # Button to click after entering OTP
  timeout_seconds: 300                   # How long to wait for operator (default: 300s)
  screenshot: true                       # Capture screenshot to help operator
```

**Implementation — MFA flow:**
```
1. Take screenshot, save to GCS
2. Insert prior_auth_hitl_task (task_type=MFA) in DB
3. POST N8N MFA webhook (case_ref_id, screenshot_url, timeout_seconds)
4. asyncio.Queue.get(timeout=timeout_seconds)  ← blocks here
5. Operator submits OTP via ADK chatbot or dashboard
6. POST /hitl/mfa/{case_ref_id} → puts OTP in queue
7. fill(input_selector, otp_value)
8. click(submit_selector)
```

---

### 4.12 `hitl`

Pause execution for a human to take over the browser session (unexpected UI state, complex page, etc.).

```yaml
- id: "step_handle_unexpected_popup"
  action: hitl
  message: "An unexpected popup appeared. Please dismiss it and click Continue."
  screenshot: true
  vnc_url_template: true                # Include VNC URL in notification
  timeout_seconds: 600                  # 10 minutes for operator
  auto_expire_action: "fail"            # fail | continue | retry_step
```

**Implementation — HITL flow:**
```
1. Take screenshot, save to GCS
2. Insert prior_auth_hitl_task (task_type=HITL) in DB
3. POST N8N HITL webhook (case_ref_id, screenshot_url, vnc_url, message)
4. threading.Event.wait(timeout=timeout_seconds)  ← blocks here
5. Dashboard shows VNC viewer; operator interacts directly with browser
6. Operator clicks "Resolved" in dashboard
7. POST /hitl/resume/{case_ref_id} → sets threading.Event
8. Recipe continues from next step
```

---

### 4.13 `extract`

Extract a value from the page and store it in the runtime context for use in later steps.

```yaml
- id: "step_extract_auth_number"
  action: extract
  extractions:
    - name: "authorization_number"      # Stored as context.authorization_number
      selector: ".auth-ref-number"
      attribute: "text"                 # text | innerText | value | data-{attr}
      regex: "Auth #:\\s*(\\w+)"        # Optional: apply regex, use capture group 1
      required: true

    - name: "approval_date"
      selector: "#approval-date"
      attribute: "value"
      required: false
      default: ""

  # After extraction, optionally persist to DB
  persist:
    pa_reference_number: "{{context.authorization_number}}"
    outcome: "SUBMITTED"
```

**Implementation notes:**
- `persist` values update `prior_auth_case_request` columns
- `required: true` raises `RecipeExtractionError` if selector not found or empty
- `regex` captures group 1; use `(...)` in the pattern

---

### 4.14 `assert_visible`

Assert that an element is visible on the page. Fails the recipe if assertion is not met.

```yaml
- id: "step_assert_success_page"
  action: assert_visible
  selector: ".submission-success"
  message: "Expected submission success confirmation but not found"
  timeout_ms: 15000
  negate: false                          # If true: assert element is NOT visible
  screenshot_on_failure: true
```

**Implementation notes:**
- Used to verify the portal reached an expected state after a submission
- `negate: true` — useful to confirm error dialogs are gone after dismissal
- `screenshot_on_failure` saves page screenshot to GCS before raising the error

---

## 5. Control Flow — `foreach`

The `foreach` action is the only looping construct. It handles the common case of adding multiple procedure codes, diagnosis codes, or service dates.

### 5.1 Loop Variable Access

```yaml
steps:
  - id: "add_diagnosis_codes"
    action: foreach
    items: "{{clinical.diagnosis_codes}}"
    as: "diag_code"
    index_as: "diag_idx"
    steps:
      - id: "fill_diag"
        action: fill
        selector: "#diagnosis-{{context.diag_idx}}"   # Use index in selector
        value: "{{context.diag_code}}"
```

### 5.2 Nested foreach (two-level)

```yaml
- id: "add_service_dates"
  action: foreach
  items: "{{clinical.service_lines}}"
  as: "service_line"
  steps:
    - id: "fill_from_date"
      action: fill
      selector: "#from-date"
      value: "{{context.service_line.from_date}}"    # Object field access

    - id: "fill_to_date"
      action: fill
      selector: "#to-date"
      value: "{{context.service_line.to_date}}"

    - id: "add_codes_for_line"
      action: foreach
      items: "{{context.service_line.procedure_codes}}"
      as: "proc_code"
      steps:
        - action: fill
          selector: "#proc-code-input"
          value: "{{context.proc_code}}"
```

---

## 6. Recipe Execution Engine — Internal Flow

```
browser-agent receives: POST /agents
  → {case_ref_id, portal_id, session_id, patient_data, clinical_data, credentials}

RecipeRunner.__init__():
  1. Load recipe: api-server GET /recipes/{portal_id}  (LRU cached, hash-busted)
  2. Validate recipe schema (pydantic)
  3. Build RecipeContext: {patient_data, clinical_data, credentials, runtime_vars={}}

RecipeRunner.run():
  For each step in recipe.steps:
    a. log_step_start(step.id, step.action)         → Redis Stream
    b. Resolve all template values in step fields
    c. Execute action handler (dispatch by step.action)
    d. On success: log_step_complete(), steps_completed++
    e. On RecipeActionError:
         i.  Take screenshot → GCS
         ii. Log error with screenshot URL
         iii. Raise to caller (triggers retry logic in SessionRunner)

  After all steps complete:
    f. Run extraction block (if defined)
    g. Call persist() → update prior_auth_case_request (pa_reference_number, outcome)
    h. POST completion webhook → N8N COMPLETED_WEBHOOK_URL
    i. POST status capture webhook → N8N STATUS_CAPTURE_WEBHOOK_URL (optional)

  On any unhandled exception:
    j. Capture screenshot, log CRITICAL
    k. Update case status → CRASHED
    l. Return pod to cooling pool
```

---

## 7. Error Handling & Retry Logic

### 7.1 Error Hierarchy

```python
class RecipeError(Exception):
    """Base class for all recipe errors."""

class RecipeActionError(RecipeError):
    """A specific step failed (selector not found, timeout, etc.)."""
    step_id: str
    action: str
    screenshot_url: str | None

class RecipeExtractionError(RecipeError):
    """Required extraction target not found on page."""
    field_name: str

class RecipeValueError(RecipeError):
    """Template resolution failed (unknown source, missing field)."""
    template: str

class RecipeTimeoutError(RecipeActionError):
    """Playwright timeout waiting for selector or navigation."""

class RecipeValidationError(RecipeError):
    """Recipe YAML schema is invalid."""
```

### 7.2 Per-Step Retry

```yaml
# Optional retry config on any step
- id: "step_click_submit"
  action: click
  selector: "#submit-btn"
  retry:
    max_attempts: 3
    delay_ms: 1000
    on_errors: ["RecipeTimeoutError", "RecipeActionError"]
```

### 7.3 Case-Level Retry

```python
# In SessionRunner (control-plane / browser-agent):
# When a RecipeActionError propagates out of RecipeRunner.run():

async def handle_recipe_failure(case_ref_id: str, error: RecipeError):
    case = db.get_case(case_ref_id)
    if case.retry_count < case.max_retries:
        case.retry_count += 1
        case.status = "PENDING"
        case.last_error = str(error)
        case.last_retry_at = now()
        db.save(case)
        # Republish to Pub/Sub Topic #1 → triggers planner again
        pubsub.publish(TOPIC_1, case_ref_id=case_ref_id, retry=True)
    else:
        case.status = "FAILED"
        case.outcome = "ERROR"
        case.last_error = str(error)
        db.save(case)
        # Notify N8N completed webhook with failure
        n8n.post_completed(case_ref_id, success=False)
```

---

## 8. Dropdown Matching — `pick_option()`

Portals use many inconsistent dropdown formats. `pick_option()` provides flexible matching.

```python
def pick_option(
    options: list[str],          # All option texts from the dropdown
    target: str,                 # Value to match (resolved from template)
    strategy: str = "fuzzy",     # exact | contains | starts_with | fuzzy
) -> str | None:
    """
    Returns the best matching option text, or None if no match found.
    Used by select_if_mismatch, type_and_pick, and select_row.
    """
    target_clean = target.strip().upper()

    if strategy == "exact":
        for opt in options:
            if opt.strip().upper() == target_clean:
                return opt
        return None

    if strategy == "contains":
        for opt in options:
            if target_clean in opt.strip().upper():
                return opt
        return None

    if strategy == "starts_with":
        for opt in options:
            if opt.strip().upper().startswith(target_clean):
                return opt
        return None

    if strategy == "fuzzy":
        # Priority 1: exact match
        for opt in options:
            if opt.strip().upper() == target_clean:
                return opt
        # Priority 2: target contained in option
        for opt in options:
            if target_clean in opt.strip().upper():
                return opt
        # Priority 3: option contained in target
        for opt in options:
            if opt.strip().upper() in target_clean:
                return opt
        # Priority 4: Levenshtein distance <= 3
        best = None
        best_dist = float("inf")
        for opt in options:
            dist = _levenshtein(target_clean, opt.strip().upper())
            if dist < best_dist and dist <= 3:
                best_dist = dist
                best = opt
        return best

    return None
```

---

## 9. Recipe Validation Rules

The recipe YAML is validated by a Pydantic model at load time.

```python
from pydantic import BaseModel, field_validator, model_validator
from typing import Literal, Any

class RecipeStep(BaseModel):
    id: str
    action: Literal[
        "navigate", "fill", "click", "click_path", "type_and_pick",
        "select_if_mismatch", "select_row", "foreach", "wait",
        "upload", "mfa", "hitl", "extract", "assert_visible"
    ]
    # Common optional fields
    timeout_ms: int = 30000
    optional: bool = False
    screenshot_on_failure: bool = False

    # Action-specific fields (all optional at model level, validated by action)
    url: str | None = None
    selector: str | None = None
    value: str | None = None
    wait_ms: int | None = None
    steps: list["RecipeStep"] | None = None
    extractions: list[dict] | None = None
    path: list[dict] | None = None
    items: str | None = None

    @model_validator(mode="after")
    def validate_required_fields(self):
        REQUIRED = {
            "navigate":          ["url"],
            "fill":              ["selector", "value"],
            "click":             ["selector"],
            "click_path":        ["path"],
            "type_and_pick":     ["selector", "value", "dropdown_selector"],
            "select_if_mismatch":["selector", "value"],
            "select_row":        ["table_selector", "match_column", "match_value"],
            "foreach":           ["items", "steps"],
            "wait":              ["wait_for"],
            "upload":            ["selector", "file_source"],
            "mfa":               ["input_selector"],
            "hitl":              ["message"],
            "extract":           ["extractions"],
            "assert_visible":    ["selector"],
        }
        for field in REQUIRED.get(self.action, []):
            if getattr(self, field, None) is None:
                raise ValueError(f"Action '{self.action}' requires field '{field}' (step: {self.id})")
        return self


class RecipeSchema(BaseModel):
    version: str
    portal_id: str
    portal_name: str
    base_url: str
    recipe_version: str
    steps: list[RecipeStep]
    default_timeout_ms: int = 30000
    default_nav_wait_ms: int = 2000
    foreach_max_iterations: int = 200
    requires_captcha: bool = False
    requires_mfa: bool = False
    extraction: dict | None = None
    credentials: dict | None = None

    @field_validator("portal_id")
    @classmethod
    def portal_id_slug(cls, v: str) -> str:
        import re
        if not re.match(r'^[a-z0-9-]+$', v):
            raise ValueError(f"portal_id must be lowercase slug, got: {v!r}")
        return v

    @field_validator("steps")
    @classmethod
    def steps_not_empty(cls, v: list) -> list:
        if not v:
            raise ValueError("Recipe must have at least one step")
        return v
```

**Validation rules enforced:**

| Rule | Description |
|------|-------------|
| No duplicate step IDs | `step.id` must be unique within the recipe |
| Required fields present | Each action type has mandatory fields (see table above) |
| Template syntax valid | `{{source.field}}` — source must be one of 7 known prefixes |
| foreach depth ≤ 2 | Nested foreach only allowed 2 levels deep |
| portal_id format | Lowercase alphanumeric with hyphens only |
| timeout_ms range | Must be 1000–300000 (1s–5min) |
| selector not empty | CSS selectors cannot be empty string |

---

## 10. Complete Portal Recipes

### 10.1 Availity — Full Recipe

```yaml
version: "1.0"
portal_id: "availity"
portal_name: "Availity Provider Portal"
base_url: "https://apps.availity.com"
recipe_version: "1.0.0"
author: "niranjansai.k@ikshealth.com"
updated_at: "2026-09-01"
default_timeout_ms: 30000
default_nav_wait_ms: 2000
requires_captcha: false
requires_mfa: false

credentials:
  username_field: "username"
  password_field: "password"
  credential_source: "secret_manager"

steps:
  # ─── AUTHENTICATION ────────────────────────────────────────
  - id: "navigate_login"
    action: navigate
    url: "https://apps.availity.com/availity/web/public.elegant.login"
    wait_ms: 3000
    wait_for: "networkidle"

  - id: "fill_username"
    action: fill
    selector: "#username"
    value: "{{credentials.username}}"
    timeout_ms: 15000

  - id: "fill_password"
    action: fill
    selector: "#password"
    value: "{{credentials.password}}"

  - id: "click_login"
    action: click
    selector: "button[type='submit']"
    wait_for_navigation: true
    wait_after_ms: 3000

  - id: "wait_for_dashboard"
    action: wait
    wait_for: "selector"
    selector: ".dashboard-container, #welcome-banner"
    timeout_ms: 20000

  # ─── NAVIGATE TO PA ────────────────────────────────────────
  - id: "navigate_to_pa"
    action: navigate
    url: "https://apps.availity.com/availity/web/prior-authorization"
    wait_for: "networkidle"
    wait_ms: 2000

  - id: "click_new_request"
    action: click
    selector: "button[data-test='new-prior-auth-btn'], button:has-text('New Request')"
    wait_after_ms: 1500

  # ─── PAYER / PLAN SELECTION ────────────────────────────────
  - id: "select_payer"
    action: type_and_pick
    selector: "#payer-search-input"
    value: "{{patient.payer_name}}"
    dropdown_selector: ".payer-option"
    match_strategy: "fuzzy"
    wait_for_dropdown_ms: 2000

  - id: "select_plan"
    action: select_if_mismatch
    selector: "#plan-select"
    value: "{{patient.plan_name}}"
    match_strategy: "contains"
    optional: true

  # ─── PROVIDER INFORMATION ──────────────────────────────────
  - id: "fill_requesting_npi"
    action: fill
    selector: "#requesting-provider-npi"
    value: "{{clinical.requesting_npi}}"

  - id: "fill_facility_npi"
    action: fill
    selector: "#facility-npi"
    value: "{{clinical.facility_npi}}"
    optional: true

  - id: "fill_provider_tax_id"
    action: fill
    selector: "#tax-id"
    value: "{{clinical.tax_id}}"
    optional: true

  # ─── PATIENT INFORMATION ───────────────────────────────────
  - id: "fill_member_id"
    action: fill
    selector: "#member-id"
    value: "{{patient.member_id}}"

  - id: "click_search_member"
    action: click
    selector: "#search-member-btn, button:has-text('Search')"
    wait_after_ms: 2000

  - id: "select_member_row"
    action: select_row
    table_selector: "#member-results-table"
    row_selector: "tbody tr"
    match_column: 2
    match_value: "{{patient.member_id}}"
    match_strategy: "contains"
    action_selector: "td:last-child button, td:last-child a"
    fallback: "first"
    timeout_ms: 15000

  # ─── SERVICE INFORMATION ───────────────────────────────────
  - id: "select_service_type"
    action: select_if_mismatch
    selector: "#service-type-select"
    value: "{{clinical.service_type}}"
    match_strategy: "fuzzy"

  - id: "fill_from_date"
    action: fill
    selector: "#service-from-date"
    value: "{{clinical.from_date}}"
    tab_after: true

  - id: "fill_to_date"
    action: fill
    selector: "#service-to-date"
    value: "{{clinical.to_date}}"
    tab_after: true
    optional: true

  - id: "fill_units"
    action: fill
    selector: "#units-requested"
    value: "{{clinical.units_requested}}"
    optional: true

  # ─── PROCEDURE CODES (loop) ────────────────────────────────
  - id: "add_procedure_codes"
    action: foreach
    items: "{{clinical.procedure_codes}}"
    as: "proc_code"
    max_iterations: 20
    first_iteration_only:
      - id: "click_open_procedures"
        action: click
        selector: "#add-procedure-section"
        optional: true
        wait_after_ms: 500
    steps:
      - id: "type_procedure_code"
        action: type_and_pick
        selector: "#procedure-code-input"
        value: "{{context.proc_code}}"
        dropdown_selector: ".procedure-code-option"
        match_strategy: "starts_with"
        wait_for_dropdown_ms: 1500

      - id: "click_add_procedure"
        action: click
        selector: "#add-procedure-btn, button:has-text('Add')"
        wait_after_ms: 800

  # ─── DIAGNOSIS CODES (loop) ────────────────────────────────
  - id: "add_diagnosis_codes"
    action: foreach
    items: "{{clinical.diagnosis_codes}}"
    as: "diag_code"
    max_iterations: 10
    steps:
      - id: "fill_diag_code"
        action: type_and_pick
        selector: "#diagnosis-code-input"
        value: "{{context.diag_code}}"
        dropdown_selector: ".diagnosis-code-option"
        match_strategy: "starts_with"
        wait_for_dropdown_ms: 1500

      - id: "click_add_diag"
        action: click
        selector: "#add-diagnosis-btn"
        wait_after_ms: 800

  # ─── CLINICAL NOTES ────────────────────────────────────────
  - id: "fill_clinical_notes"
    action: fill
    selector: "#clinical-notes, #additional-info"
    value: "{{clinical.notes}}"
    optional: true

  # ─── REVIEW & SUBMIT ───────────────────────────────────────
  - id: "click_review"
    action: click
    selector: "button:has-text('Review'), #review-btn"
    wait_for_navigation: true
    wait_after_ms: 2000

  - id: "assert_review_page"
    action: assert_visible
    selector: ".review-page, #review-section"
    message: "Expected review page after clicking Review button"
    screenshot_on_failure: true

  - id: "click_submit"
    action: click
    selector: "button:has-text('Submit'), button[type='submit']"
    wait_for_navigation: true
    wait_after_ms: 3000

  # ─── CONFIRMATION ──────────────────────────────────────────
  - id: "assert_confirmation"
    action: assert_visible
    selector: ".confirmation-page, .success-message, #confirmation"
    message: "Submission confirmation page not found"
    timeout_ms: 30000
    screenshot_on_failure: true

  - id: "extract_auth_reference"
    action: extract
    extractions:
      - name: "authorization_number"
        selector: ".reference-number, #auth-ref-number, [data-test='auth-number']"
        attribute: "text"
        regex: "(\\w{6,20})"
        required: true

      - name: "submission_status"
        selector: ".status-badge, .confirmation-status"
        attribute: "text"
        required: false
        default: "SUBMITTED"

    persist:
      pa_reference_number: "{{context.authorization_number}}"
      outcome: "SUBMITTED"
      submitted_at: "{{computed.timestamp}}"

extraction:
  pa_reference_number:
    selector: ".reference-number"
    attribute: "text"
    required: true
```

---

### 10.2 Navinet — Abbreviated Recipe

```yaml
version: "1.0"
portal_id: "navinet"
portal_name: "NaviNet Open"
base_url: "https://navinet.net"
recipe_version: "1.0.0"
default_timeout_ms: 45000
requires_mfa: true

steps:
  - id: "navigate_login"
    action: navigate
    url: "https://navinet.net/navinet/showLogin.do"
    wait_ms: 3000

  - id: "fill_username"
    action: fill
    selector: "#loginName"
    value: "{{credentials.username}}"

  - id: "fill_password"
    action: fill
    selector: "#password"
    value: "{{credentials.password}}"

  - id: "click_login"
    action: click
    selector: "#loginBtn"
    wait_for_navigation: true

  - id: "handle_mfa_if_required"
    action: mfa
    prompt: "NaviNet has sent an OTP. Please provide the code."
    input_selector: "#otpCode"
    submit_selector: "#verifyBtn"
    timeout_seconds: 300
    screenshot: true

  - id: "navigate_pa_module"
    action: click_path
    path:
      - selector: "#realtimeTab"
        wait_ms: 1000
      - selector: "a[href*='priorAuth']"
        wait_ms: 1500
      - selector: "#startNewRequest"
        wait_ms: 1000

  # ... (patient search, procedure entry, submit flow) ...

  - id: "extract_reference"
    action: extract
    extractions:
      - name: "authorization_number"
        selector: ".authorizationNumber"
        attribute: "innerText"
        required: true
    persist:
      pa_reference_number: "{{context.authorization_number}}"
      outcome: "SUBMITTED"
```

---

### 10.3 CareCore — Abbreviated Recipe

```yaml
version: "1.0"
portal_id: "carecore"
portal_name: "CareCore Provider Portal"
base_url: "https://www.carecore.net"
recipe_version: "1.0.0"
default_timeout_ms: 30000
requires_captcha: true     # CareCore sometimes presents CAPTCHA

steps:
  - id: "navigate_login"
    action: navigate
    url: "https://www.carecore.net/login"

  - id: "fill_credentials"
    action: fill
    selector: "#username"
    value: "{{credentials.username}}"

  - id: "fill_password"
    action: fill
    selector: "#password"
    value: "{{credentials.password}}"

  # CAPTCHA handled automatically by Capsolver integration (transparent to recipe)
  - id: "click_login"
    action: click
    selector: "#loginButton"
    wait_for_navigation: true
    wait_after_ms: 2000

  - id: "navigate_new_request"
    action: navigate
    url: "https://www.carecore.net/priorAuth/new"
    wait_for: "networkidle"

  # ... (form filling steps) ...

  - id: "wait_for_hitl_if_needed"
    action: hitl
    message: "CareCore portal requires human verification. Please complete the step shown in VNC."
    screenshot: true
    timeout_seconds: 600
    auto_expire_action: "fail"
```

---

## 11. LLM Agent Mode

When `PLAYWRIGHT_EXECUTION_ENGINE=no` or the recipe fails with `RecipeActionError` after max retries, the browser-agent switches to LLM mode.

### 11.1 Architecture

```
browser-use library
  ├── BrowserAgent (main loop)
  │     ├── CustomGoogleChat (Gemini via Vertex AI)
  │     ├── Playwright page access
  │     └── Action space: click, fill, navigate, extract, scroll, ...
  └── Task: natural language description of what to do
```

### 11.2 System Prompt Structure

```
[SYSTEM]
You are an AI agent completing a Prior Authorization (PA) submission on {portal_name}.
Your goal: submit a PA request for patient {patient_name} (Member ID: {member_id}).
Procedure codes: {procedure_codes}.
Diagnosis codes: {diagnosis_codes}.

Rules:
1. NEVER log or capture credentials — they are handled separately.
2. If a CAPTCHA appears, call the captcha_solver tool.
3. If you encounter an unexpected dialog, call the hitl tool.
4. If MFA is needed, call the request_mfa tool.
5. After successful submission, call the extract_pa_reference tool.
6. If you cannot complete the task after 5 attempts, call abort_task.

[PORTAL-SPECIFIC PROMPT — from prior_auth_payer_prompt table]
{payer_specific_context}
```

### 11.3 Custom Tools for browser-use

```python
class CaptchaSolverTool:
    """Calls Capsolver API to solve visible CAPTCHA."""
    name = "captcha_solver"

class RequestHitlTool:
    """Pauses agent and requests human intervention."""
    name = "request_hitl"

class RequestMfaTool:
    """Pauses agent and requests OTP from operator."""
    name = "request_mfa"

class ExtractPaReferenceTool:
    """Extracts and saves the PA reference number from the confirmation."""
    name = "extract_pa_reference"

class AbortTaskTool:
    """Terminates the agent run and marks case as FAILED."""
    name = "abort_task"
```

---

## 12. Recipe Authoring Guide

### Step 1 — Start with a manual run

Open the target portal in a browser with DevTools open. Complete the PA flow manually while noting:
- Exact CSS selectors for every input (prefer `id` > `data-test` > `class`)
- Dropdown option text formats
- Whether page loads or SPA updates after each action
- Any MFA / CAPTCHA pages

### Step 2 — Write the YAML skeleton

```yaml
# Template: start from this skeleton
version: "1.0"
portal_id: "new-portal"
portal_name: "New Portal Name"
base_url: "https://portal.example.com"
recipe_version: "0.1.0"
default_timeout_ms: 30000

steps:
  - id: "step_1"
    action: navigate
    url: "{{base_url}}/login"
```

### Step 3 — Test with the recipe runner CLI

```bash
# Run recipe against a test case (local docker-compose environment)
python -m browser_agent.tools.recipe_runner \
  --portal availity \
  --case-ref TEST-001 \
  --dry-run       # Dry run: resolves values, validates steps, but doesn't click

python -m browser_agent.tools.recipe_runner \
  --portal availity \
  --case-ref TEST-001 \
  --headful       # Opens visible browser window
```

### Step 4 — Handle edge cases

Common issues and fixes:

| Issue | Fix |
|-------|-----|
| Selector not found | Check for `iframe` — wrap with `wait_for_frame` first |
| Dropdown options differ | Adjust `match_strategy` from `exact` to `fuzzy` |
| Page load slow | Increase `wait_ms` or change `wait_for` to `networkidle` |
| MFA appears unexpectedly | Add `mfa` step with `optional: true` after login |
| Form resets after tab | Add `tab_after: false` and use click to advance |
| Dynamic ID attributes | Use attribute selectors: `input[name='memberId']` |

### Step 5 — Upload recipe to DB

```bash
# Upload via API
curl -X PUT https://api.autoauth.internal/api/v1/recipes/availity \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"recipe_yaml\": \"$(cat recipes/availity.yaml | python3 -c 'import sys,json; print(json.dumps(sys.stdin.read()))')\"}"
```

---

## 13. Recipe CI Validation

A GitHub Actions / Cloud Build step validates every recipe on PR.

```yaml
# .cloudbuild/validate-recipes.yaml
steps:
  - name: python:3.12
    id: validate_recipes
    entrypoint: bash
    args:
      - -c
      - |
        pip install -q pydantic pyyaml
        python scripts/validate_recipes.py recipes/

# scripts/validate_recipes.py
import sys
import yaml
from pathlib import Path
from browser_agent.engine.recipe_schema import RecipeSchema

errors = []
for recipe_file in Path("recipes").glob("*.yaml"):
    try:
        raw = yaml.safe_load(recipe_file.read_text())
        RecipeSchema(**raw)
        print(f"  ✓  {recipe_file.name}")
    except Exception as e:
        errors.append(f"  ✗  {recipe_file.name}: {e}")
        print(errors[-1])

if errors:
    print(f"\n{len(errors)} recipe(s) failed validation.")
    sys.exit(1)
else:
    print(f"\nAll recipes valid.")
```

**Validation checks run in CI:**
1. Schema validation (Pydantic)
2. No duplicate step IDs
3. All `{{template}}` references use valid source prefixes
4. `foreach` depth ≤ 2
5. Required action fields present
6. `selector` fields non-empty
7. `portal_id` slug format
8. `timeout_ms` within bounds

---

*Document Status: DRAFT*
*Previous: [04_Database_Schema_Design.md](04_Database_Schema_Design.md)*
*Next: [06_CICD_and_Deployment_Guide.md](06_CICD_and_Deployment_Guide.md)*
