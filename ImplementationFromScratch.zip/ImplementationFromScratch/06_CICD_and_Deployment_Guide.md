# AutoAuth Agent — CI/CD & Deployment Guide
**Phase 1 | Weeks 3–4 / Phase 2 | Weeks 7–8**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0
**Prerequisite:** [02_Infrastructure_and_Security_Design.md](02_Infrastructure_and_Security_Design.md)

---

## Table of Contents

1. [CI/CD Overview](#1-cicd-overview)
2. [Repository Structure](#2-repository-structure)
3. [Dockerfiles](#3-dockerfiles)
4. [Cloud Build — Per-Service Pipelines](#4-cloud-build--per-service-pipelines)
5. [Artifact Registry](#5-artifact-registry)
6. [Kubernetes Manifests](#6-kubernetes-manifests)
7. [KEDA Autoscaling](#7-keda-autoscaling)
8. [Helm Chart Structure](#8-helm-chart-structure)
9. [Environment Promotion Workflow](#9-environment-promotion-workflow)
10. [Blue/Green Deployment](#10-bluegreen-deployment)
11. [Database Migration Job](#11-database-migration-job)
12. [Rollback Procedures](#12-rollback-procedures)
13. [Secrets & Config Management](#13-secrets--config-management)
14. [Monitoring & Alerting Setup](#14-monitoring--alerting-setup)
15. [Local Development Stack](#15-local-development-stack)
16. [On-Call Runbook](#16-on-call-runbook)

---

## 1. CI/CD Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          CI/CD Pipeline Flow                                │
│                                                                             │
│   Developer                                                                 │
│      │  git push / PR                                                       │
│      ▼                                                                      │
│   GitHub ──────────────────► Cloud Build Trigger                           │
│                              (per-service trigger, branch filter)           │
│                                      │                                      │
│              ┌───────────────────────┼──────────────────────┐              │
│              │                       │                       │              │
│           Lint &               Unit Tests              Build Image          │
│           Format                (pytest)               (Docker)             │
│           (ruff)                    │                       │              │
│                                     │                       │              │
│                              ┌──────┴──────────────────────►│              │
│                              │    All pass?                  ▼              │
│                              │                    Artifact Registry         │
│                              │                    (GCP, per env tag)        │
│                              │                               │              │
│                              └──────────────────────────────►│              │
│                                                              │              │
│                          ┌───────────────────────────────────┘             │
│                          │   Deploy trigger (main branch only)             │
│                          ▼                                                  │
│                    kubectl apply / helm upgrade                             │
│                    ┌──────────────────────────┐                            │
│                    │  dev namespace           │  ← auto on every push      │
│                    │  uat namespace           │  ← auto on main merge      │
│                    │  prod namespace          │  ← manual approval gate    │
│                    └──────────────────────────┘                            │
│                          │                                                  │
│                    Alembic migration Job (pre-deploy)                       │
│                    Smoke tests (post-deploy)                                │
│                    Rollback if smoke tests fail                             │
└─────────────────────────────────────────────────────────────────────────────┘

Triggers:
  • Any branch push     → lint + test only
  • PR to main         → lint + test + build (no deploy)
  • Merge to main      → lint + test + build + deploy to dev + deploy to uat
  • Tag v*.*.*         → deploy to prod (after manual approval in Cloud Build)
```

---

## 2. Repository Structure

```
autoauthagent/
├── .cloudbuild/                    # Cloud Build configuration
│   ├── cloudbuild-api-server.yaml
│   ├── cloudbuild-planner.yaml
│   ├── cloudbuild-control-plane.yaml
│   ├── cloudbuild-browser-agent.yaml
│   ├── cloudbuild-tracking-agent.yaml
│   ├── cloudbuild-frontend.yaml
│   └── cloudbuild-common.yaml      # For the common/ library
│
├── k8s/                            # Raw Kubernetes manifests
│   ├── base/                       # Kustomize base configs
│   │   ├── namespace.yaml
│   │   ├── api-server/
│   │   ├── planner/
│   │   ├── control-plane/
│   │   ├── browser-agent/
│   │   ├── tracking-agent/
│   │   ├── frontend/
│   │   ├── n8n/
│   │   └── keda/
│   └── overlays/
│       ├── dev/
│       ├── uat/
│       └── prod/
│
├── helm/                           # Helm chart (alternative to raw manifests)
│   └── autoauth/
│       ├── Chart.yaml
│       ├── values.yaml
│       ├── values-dev.yaml
│       ├── values-uat.yaml
│       ├── values-prod.yaml
│       └── templates/
│
├── api-server/
│   ├── Dockerfile
│   ├── pyproject.toml
│   └── src/
│
├── planner/
│   ├── Dockerfile
│   └── src/
│
├── control-plane/
│   ├── Dockerfile
│   └── src/
│
├── browser-agent/
│   ├── Dockerfile                  # Standard (recipe-only) image
│   ├── Dockerfile.llm              # + browser-use + heavier deps
│   └── src/
│
├── tracking-agent/
│   ├── Dockerfile
│   └── src/
│
├── frontend/
│   ├── Dockerfile
│   └── src/
│
├── common/                         # Shared library (not deployed independently)
│   ├── pyproject.toml
│   └── src/
│       └── common/
│           ├── db_layer/
│           ├── redis_layer/
│           ├── pubsub_layer/
│           ├── secret/
│           └── logs/
│
├── scripts/
│   ├── validate_recipes.py
│   ├── seed_test_data.py
│   ├── create_partitions.sql
│   └── smoke_test.sh
│
├── docker-compose.yaml             # Local development stack
├── docker-compose.override.yaml   # Developer overrides (gitignored)
└── pyproject.toml                  # Monorepo root config (ruff, black, pytest)
```

---

## 3. Dockerfiles

### 3.1 Standard Service Dockerfile (api-server / planner / control-plane / tracking-agent)

```dockerfile
# api-server/Dockerfile
FROM python:3.12-slim AS builder

WORKDIR /build

# Install build dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Copy and install common library first (for layer caching)
COPY common/ /build/common/
RUN pip install --no-cache-dir /build/common/

# Copy and install service dependencies
COPY api-server/pyproject.toml api-server/
RUN pip install --no-cache-dir api-server/[prod]

# Copy service source
COPY api-server/src/ /app/src/

# ─── Runtime stage ───────────────────────────────────────────
FROM python:3.12-slim AS runtime

RUN apt-get update && apt-get install -y --no-install-recommends \
    libpq5 \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Non-root user
RUN groupadd -r appuser && useradd -r -g appuser appuser

# Copy installed packages from builder
COPY --from=builder /usr/local/lib/python3.12/site-packages /usr/local/lib/python3.12/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin
COPY --from=builder /app /app

WORKDIR /app
USER appuser

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=15s --retries=3 \
    CMD curl -f http://localhost:8080/health || exit 1

EXPOSE 8080
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8080", \
     "--workers", "2", "--loop", "uvloop", "--http", "httptools"]
```

---

### 3.2 Browser-Agent Dockerfile (VNC + Playwright)

```dockerfile
# browser-agent/Dockerfile
FROM python:3.12-slim AS builder

WORKDIR /build

RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc libpq-dev \
    && rm -rf /var/lib/apt/lists/*

COPY common/ /build/common/
RUN pip install --no-cache-dir /build/common/

COPY browser-agent/pyproject.toml browser-agent/
RUN pip install --no-cache-dir browser-agent/[prod]

# Install Playwright browsers (downloads Chromium)
RUN playwright install chromium
RUN playwright install-deps chromium

# ─── Runtime stage ───────────────────────────────────────────
FROM python:3.12-slim AS runtime

# VNC / X11 / browser dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    # X virtual framebuffer
    xvfb \
    # VNC server
    x11vnc \
    # WebSocket proxy for noVNC
    websockify \
    # Chromium system dependencies (auto-resolved by playwright install-deps)
    libnss3 libnspr4 libatk1.0-0 libatk-bridge2.0-0 libcups2 \
    libdrm2 libdbus-1-3 libxkbcommon0 libxcomposite1 libxdamage1 \
    libxfixes3 libxrandr2 libgbm1 libasound2 libatspi2.0-0 \
    libx11-xcb1 libxcb-dri3-0 \
    # Utilities
    curl wget unzip \
    # psql for health check
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# noVNC (web VNC client)
RUN wget -q https://github.com/novnc/noVNC/archive/refs/tags/v1.4.0.tar.gz \
    -O /tmp/novnc.tar.gz \
    && tar -xzf /tmp/novnc.tar.gz -C /opt \
    && mv /opt/noVNC-1.4.0 /opt/novnc \
    && rm /tmp/novnc.tar.gz

# Non-root user with X access
RUN groupadd -r appuser && useradd -r -g appuser -G video appuser

# Copy installed packages from builder
COPY --from=builder /usr/local/lib/python3.12/site-packages /usr/local/lib/python3.12/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin
# Playwright browser binaries
COPY --from=builder /root/.cache/ms-playwright /home/appuser/.cache/ms-playwright
RUN chown -R appuser:appuser /home/appuser/.cache

COPY --from=builder /app /app

WORKDIR /app
USER appuser

HEALTHCHECK --interval=30s --timeout=10s --start-period=30s --retries=3 \
    CMD curl -f http://localhost:8081/health || exit 1

EXPOSE 8081
# VNC ports: 5900-5910 (allocated per display slot)
# WebSocket ports: 6080-6090

CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8081", \
     "--workers", "1", "--loop", "uvloop"]
```

---

### 3.3 Frontend Dockerfile (React/Vite — nginx)

```dockerfile
# frontend/Dockerfile
FROM node:20-alpine AS builder

WORKDIR /app
COPY frontend/package*.json ./
RUN npm ci --omit=dev

COPY frontend/ .
RUN npm run build                    # Outputs to /app/dist

# ─── Runtime stage ───────────────────────────────────────────
FROM nginx:1.25-alpine AS runtime

# Custom nginx config (SPA routing + API proxy)
COPY frontend/nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=builder /app/dist /usr/share/nginx/html

HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
    CMD wget -q -O- http://localhost:80/health || exit 1

EXPOSE 80
```

```nginx
# frontend/nginx.conf
server {
    listen 80;
    root /usr/share/nginx/html;
    index index.html;

    # SPA routing — send all paths to index.html
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Health endpoint for K8s probe
    location /health {
        return 200 "ok";
        add_header Content-Type text/plain;
    }

    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header Referrer-Policy strict-origin-when-cross-origin;
    add_header Content-Security-Policy "default-src 'self'; connect-src 'self' https://api.autoauth.ikshealth.com wss://api.autoauth.ikshealth.com; img-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'";

    gzip on;
    gzip_types text/plain text/css application/json application/javascript;
}
```

---

## 4. Cloud Build — Per-Service Pipelines

### 4.1 Root cloudbuild.yaml (dispatches to per-service builds)

```yaml
# cloudbuild.yaml  (root — triggered on push to any branch)
steps:
  # Determine which services changed using git diff
  - name: "gcr.io/cloud-builders/git"
    id: detect_changes
    entrypoint: bash
    args:
      - -c
      - |
        CHANGED=$(git diff --name-only HEAD~1 HEAD)
        echo "$CHANGED" > /workspace/changed_files.txt
        echo "Changed files:"
        cat /workspace/changed_files.txt

  # Trigger per-service build if relevant files changed
  - name: "gcr.io/cloud-builders/gcloud"
    id: trigger_api_server
    entrypoint: bash
    args:
      - -c
      - |
        if grep -qE "^(api-server|common)/" /workspace/changed_files.txt; then
          gcloud builds submit \
            --config=.cloudbuild/cloudbuild-api-server.yaml \
            --substitutions=_ENV=$_ENV,_IMAGE_TAG=$SHORT_SHA \
            --no-source
        else
          echo "No api-server changes — skipping."
        fi

  - name: "gcr.io/cloud-builders/gcloud"
    id: trigger_browser_agent
    entrypoint: bash
    args:
      - -c
      - |
        if grep -qE "^(browser-agent|common)/" /workspace/changed_files.txt; then
          gcloud builds submit \
            --config=.cloudbuild/cloudbuild-browser-agent.yaml \
            --substitutions=_ENV=$_ENV,_IMAGE_TAG=$SHORT_SHA \
            --no-source
        fi

  # ... similar for planner, control-plane, tracking-agent, frontend ...

substitutions:
  _ENV: dev
  _REGION: us-central1

options:
  logging: CLOUD_LOGGING_ONLY
```

---

### 4.2 Per-Service Build: api-server

```yaml
# .cloudbuild/cloudbuild-api-server.yaml
steps:
  # ─── Step 1: Lint ────────────────────────────────────────────
  - name: "python:3.12-slim"
    id: lint
    entrypoint: bash
    args:
      - -c
      - |
        pip install -q ruff black
        ruff check api-server/src/ common/src/
        black --check api-server/src/ common/src/
    waitFor: ["-"]

  # ─── Step 2: Unit Tests ──────────────────────────────────────
  - name: "python:3.12-slim"
    id: unit_tests
    entrypoint: bash
    env:
      - "DB_HOST=127.0.0.1"
      - "DB_PORT=5432"
      - "DB_USER=test"
      - "DB_PASSWORD=test"
      - "DB_NAME=autoauth_test"
      - "REDIS_HOST=127.0.0.1"
    args:
      - -c
      - |
        pip install -q pytest pytest-cov pytest-asyncio
        pip install -q ./common/ ./api-server/
        pytest api-server/tests/ \
          --cov=api-server/src \
          --cov-report=xml:/workspace/coverage-api-server.xml \
          --cov-fail-under=75 \
          -v
    waitFor: ["-"]

  # ─── Step 3: Build Docker Image ──────────────────────────────
  - name: "gcr.io/cloud-builders/docker"
    id: build_image
    args:
      - build
      - -f api-server/Dockerfile
      - --build-context common=./common
      - -t ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/api-server:${_IMAGE_TAG}
      - -t ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/api-server:latest-${_ENV}
      - --cache-from ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/api-server:cache
      - .
    waitFor: [lint, unit_tests]

  # ─── Step 4: Trivy Security Scan ─────────────────────────────
  - name: "aquasec/trivy:latest"
    id: security_scan
    args:
      - image
      - --exit-code 1
      - --severity HIGH,CRITICAL
      - --ignore-unfixed
      - ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/api-server:${_IMAGE_TAG}
    waitFor: [build_image]

  # ─── Step 5: Push to Artifact Registry ───────────────────────
  - name: "gcr.io/cloud-builders/docker"
    id: push_image
    args:
      - push
      - --all-tags
      - ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/api-server
    waitFor: [security_scan]

  # ─── Step 6: Deploy to Dev (main branch only) ────────────────
  - name: "gcr.io/cloud-builders/kubectl"
    id: deploy_dev
    args:
      - set image
      - deployment/api-server
      - api-server=${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/api-server:${_IMAGE_TAG}
      - -n agentic-app-dev
    env:
      - "CLOUDSDK_COMPUTE_REGION=${_REGION}"
      - "CLOUDSDK_CONTAINER_CLUSTER=autoauth-cluster-dev"
    waitFor: [push_image]

  # ─── Step 7: Smoke Test ──────────────────────────────────────
  - name: "curlimages/curl:latest"
    id: smoke_test_dev
    entrypoint: sh
    args:
      - -c
      - |
        sleep 20   # Wait for rollout
        curl -f https://api-dev.autoauth.ikshealth.com/health || exit 1
        echo "Smoke test passed."
    waitFor: [deploy_dev]

images:
  - ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/api-server:${_IMAGE_TAG}
  - ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/api-server:latest-${_ENV}

substitutions:
  _ENV: dev
  _REGION: us-central1
  _IMAGE_TAG: $SHORT_SHA

options:
  logging: CLOUD_LOGGING_ONLY
  machineType: E2_HIGHCPU_8

timeout: "1200s"
```

---

### 4.3 Per-Service Build: browser-agent (heavier build)

```yaml
# .cloudbuild/cloudbuild-browser-agent.yaml
steps:
  - name: "python:3.12-slim"
    id: lint
    entrypoint: bash
    args:
      - -c
      - |
        pip install -q ruff
        ruff check browser-agent/src/
    waitFor: ["-"]

  - name: "python:3.12-slim"
    id: unit_tests
    entrypoint: bash
    args:
      - -c
      - |
        pip install -q pytest pytest-asyncio pytest-mock
        pip install -q ./common/ ./browser-agent/[test]
        # Recipe engine tests (mock Playwright — no real browser needed)
        pytest browser-agent/tests/unit/ -v --timeout=60
    waitFor: ["-"]

  # Browser-agent image takes longer to build (Playwright + noVNC)
  - name: "gcr.io/cloud-builders/docker"
    id: build_image
    args:
      - build
      - -f browser-agent/Dockerfile
      - -t ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/browser-agent:${_IMAGE_TAG}
      - -t ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/browser-agent:latest-${_ENV}
      - --cache-from ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/browser-agent:cache
      - .
    waitFor: [lint, unit_tests]

  - name: "aquasec/trivy:latest"
    id: security_scan
    args:
      - image
      - --exit-code 1
      - --severity CRITICAL        # Only CRITICAL for browser-agent (many HIGH from Chrome)
      - --ignore-unfixed
      - ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/browser-agent:${_IMAGE_TAG}
    waitFor: [build_image]

  - name: "gcr.io/cloud-builders/docker"
    id: push_image
    args:
      - push
      - --all-tags
      - ${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/browser-agent
    waitFor: [security_scan]

  # browser-agent deploys via KEDA — just update the Deployment image
  - name: "gcr.io/cloud-builders/kubectl"
    id: deploy_dev
    args:
      - set image
      - deployment/browser-agent
      - browser-agent=${_REGION}-docker.pkg.dev/${PROJECT_ID}/autoauth/browser-agent:${_IMAGE_TAG}
      - -n agentic-app-dev
    env:
      - "CLOUDSDK_COMPUTE_REGION=${_REGION}"
      - "CLOUDSDK_CONTAINER_CLUSTER=autoauth-cluster-dev"
    waitFor: [push_image]

options:
  machineType: E2_HIGHCPU_16     # Larger machine for Playwright download
  logging: CLOUD_LOGGING_ONLY

timeout: "2400s"                  # 40 min — Playwright install takes time
```

---

## 5. Artifact Registry

```bash
# Create Artifact Registry repository (run once per environment)
gcloud artifacts repositories create autoauth \
  --repository-format=docker \
  --location=us-central1 \
  --description="AutoAuth Agent container images" \
  --project=$PROJECT_ID

# Grant Cloud Build service account push access
gcloud artifacts repositories add-iam-policy-binding autoauth \
  --location=us-central1 \
  --member="serviceAccount:${PROJECT_NUMBER}@cloudbuild.gserviceaccount.com" \
  --role="roles/artifactregistry.writer"

# Grant GKE node service account pull access
gcloud artifacts repositories add-iam-policy-binding autoauth \
  --location=us-central1 \
  --member="serviceAccount:autoauth-gke-node@${PROJECT_ID}.iam.gserviceaccount.com" \
  --role="roles/artifactregistry.reader"
```

**Image naming convention:**
```
us-central1-docker.pkg.dev/{project_id}/autoauth/{service}:{tag}

Tags:
  {SHORT_SHA}          → immutable, identifies the exact commit
  latest-dev           → mutable pointer to last dev build
  latest-uat           → mutable pointer to last UAT build
  latest-prod          → mutable pointer to last prod build
  v1.2.3               → semantic version tag for releases
```

---

## 6. Kubernetes Manifests

### 6.1 Namespace & RBAC

```yaml
# k8s/base/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: agentic-app
  labels:
    app.kubernetes.io/managed-by: kubectl
    environment: prod
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: autoauth-ksa
  namespace: agentic-app
  annotations:
    iam.gke.io/gcp-service-account: autoauth-workload@PROJECT_ID.iam.gserviceaccount.com
```

---

### 6.2 api-server Deployment

```yaml
# k8s/base/api-server/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-server
  namespace: agentic-app
  labels:
    app: api-server
    version: "1.0.0"
spec:
  replicas: 2
  revisionHistoryLimit: 3
  selector:
    matchLabels:
      app: api-server
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0          # Zero-downtime: always keep all replicas up
      maxSurge: 1
  template:
    metadata:
      labels:
        app: api-server
      annotations:
        cluster-autoscaler.kubernetes.io/safe-to-evict: "true"
    spec:
      serviceAccountName: autoauth-ksa
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
        fsGroup: 1000
        seccompProfile:
          type: RuntimeDefault
      terminationGracePeriodSeconds: 30
      containers:
        - name: api-server
          image: us-central1-docker.pkg.dev/PROJECT_ID/autoauth/api-server:IMAGE_TAG
          ports:
            - containerPort: 8080
              name: http
          resources:
            requests:
              cpu: "250m"
              memory: "512Mi"
            limits:
              cpu: "1000m"
              memory: "1Gi"
          env:
            - name: APP_ENV
              value: "prod"
            - name: LOG_LEVEL
              value: "INFO"
            - name: DB_HOST
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: host
            - name: DB_PORT
              value: "5432"
            - name: DB_NAME
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: dbname
            - name: DB_USER
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: username
            - name: DB_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: password
            - name: REDIS_HOST
              valueFrom:
                secretKeyRef:
                  name: redis-credentials
                  key: host
            - name: REDIS_PORT
              value: "6379"
            - name: REDIS_AUTH
              valueFrom:
                secretKeyRef:
                  name: redis-credentials
                  key: auth_string
            - name: JWT_SECRET_KEY
              valueFrom:
                secretKeyRef:
                  name: app-secrets
                  key: jwt_secret_key
            - name: GCP_PROJECT_ID
              valueFrom:
                fieldRef:
                  fieldPath: metadata.annotations['gcp-project-id']
          readinessProbe:
            httpGet:
              path: /health
              port: 8080
            initialDelaySeconds: 10
            periodSeconds: 10
            failureThreshold: 3
          livenessProbe:
            httpGet:
              path: /health
              port: 8080
            initialDelaySeconds: 30
            periodSeconds: 30
            failureThreshold: 3
          lifecycle:
            preStop:
              exec:
                command: ["/bin/sh", "-c", "sleep 5"]   # Drain before shutdown
      affinity:
        podAntiAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            - labelSelector:
                matchLabels:
                  app: api-server
              topologyKey: kubernetes.io/hostname   # One per node
---
apiVersion: v1
kind: Service
metadata:
  name: api-server
  namespace: agentic-app
spec:
  selector:
    app: api-server
  ports:
    - port: 80
      targetPort: 8080
      name: http
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: api-server-hpa
  namespace: agentic-app
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: api-server
  minReplicas: 2
  maxReplicas: 6
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80
```

---

### 6.3 browser-agent Deployment

```yaml
# k8s/base/browser-agent/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: browser-agent
  namespace: agentic-app
  labels:
    app: browser-agent
spec:
  replicas: 1                      # KEDA controls actual replica count
  revisionHistoryLimit: 3
  selector:
    matchLabels:
      app: browser-agent
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0
      maxSurge: 1
  template:
    metadata:
      labels:
        app: browser-agent
    spec:
      serviceAccountName: autoauth-ksa
      # browser-agent must run on the browser-agent node pool (tainted)
      tolerations:
        - key: "workload-type"
          operator: "Equal"
          value: "browser-agent"
          effect: "NoSchedule"
      nodeSelector:
        workload-type: "browser-agent"
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
      terminationGracePeriodSeconds: 120   # Longer — active sessions may be running
      containers:
        - name: browser-agent
          image: us-central1-docker.pkg.dev/PROJECT_ID/autoauth/browser-agent:IMAGE_TAG
          ports:
            - containerPort: 8081
              name: http
          resources:
            requests:
              cpu: "500m"
              memory: "2Gi"
            limits:
              cpu: "2000m"
              memory: "4Gi"
          env:
            - name: APP_ENV
              value: "prod"
            - name: MAX_SESSIONS
              value: "5"
            - name: PLAYWRIGHT_EXECUTION_ENGINE
              value: "yes"
            - name: CAPSOLVER_API_KEY
              valueFrom:
                secretKeyRef:
                  name: app-secrets
                  key: capsolver_api_key
            - name: DB_HOST
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: host
            - name: REDIS_HOST
              valueFrom:
                secretKeyRef:
                  name: redis-credentials
                  key: host
            - name: REDIS_AUTH
              valueFrom:
                secretKeyRef:
                  name: redis-credentials
                  key: auth_string
            - name: GCP_PROJECT_ID
              value: "PROJECT_ID"
            - name: DOCUMENT_BUCKET
              value: "autoauth-documents-prod"
            - name: LOG_LEVEL
              value: "INFO"
          readinessProbe:
            httpGet:
              path: /health
              port: 8081
            initialDelaySeconds: 20
            periodSeconds: 15
          livenessProbe:
            httpGet:
              path: /health
              port: 8081
            initialDelaySeconds: 60
            periodSeconds: 30
          lifecycle:
            preStop:
              exec:
                # Drain: stop accepting new sessions, wait for active ones to finish
                command: ["/bin/sh", "-c",
                  "curl -s -X POST http://localhost:8081/drain && sleep 60"]
```

---

### 6.4 Ingress (GKE Managed Certificate + Cloud Load Balancer)

```yaml
# k8s/base/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: autoauth-ingress
  namespace: agentic-app
  annotations:
    kubernetes.io/ingress.class: "gce"
    kubernetes.io/ingress.global-static-ip-name: "autoauth-ingress-ip"
    networking.gke.io/managed-certificates: "autoauth-cert"
    networking.gke.io/v1beta1.FrontendConfig: "autoauth-frontend-config"
spec:
  rules:
    - host: api.autoauth.ikshealth.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: api-server
                port:
                  number: 80
    - host: app.autoauth.ikshealth.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: frontend
                port:
                  number: 80
---
apiVersion: networking.gke.io/v1
kind: ManagedCertificate
metadata:
  name: autoauth-cert
  namespace: agentic-app
spec:
  domains:
    - api.autoauth.ikshealth.com
    - app.autoauth.ikshealth.com
---
apiVersion: networking.gke.io/v1beta1
kind: FrontendConfig
metadata:
  name: autoauth-frontend-config
  namespace: agentic-app
spec:
  redirectToHttps:
    enabled: true
    responseCodeName: MOVED_PERMANENTLY_DEFAULT
  sslPolicy: autoauth-ssl-policy
```

---

### 6.5 PodDisruptionBudget

```yaml
# k8s/base/pdb.yaml
# api-server: at least 1 replica always available
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: api-server-pdb
  namespace: agentic-app
spec:
  minAvailable: 1
  selector:
    matchLabels:
      app: api-server
---
# browser-agent: allow disruption only when idle
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: browser-agent-pdb
  namespace: agentic-app
spec:
  maxUnavailable: 1
  selector:
    matchLabels:
      app: browser-agent
```

---

## 7. KEDA Autoscaling

```yaml
# k8s/base/keda/scaledobject-browser-agent.yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: browser-agent-scaledobject
  namespace: agentic-app
spec:
  scaleTargetRef:
    name: browser-agent
  pollingInterval: 15        # Check queue depth every 15 seconds
  cooldownPeriod: 300        # Wait 5 min before scaling down (sessions may linger)
  minReplicaCount: 1         # Always keep 1 pod warm
  maxReplicaCount: 6         # Hard limit — 6 pods × 5 sessions = 30 concurrent PAs
  triggers:
    - type: gcp-pubsub
      authenticationRef:
        name: keda-gcp-auth
      metadata:
        subscriptionName: "prior-auth-submission-sub"
        # Scale up when queue has 3+ undelivered messages
        # (Each pod handles ~5 concurrent sessions)
        value: "3"
        activationValue: "1"
        credentialsFromEnv: "GOOGLE_APPLICATION_CREDENTIALS"
---
apiVersion: keda.sh/v1alpha1
kind: TriggerAuthentication
metadata:
  name: keda-gcp-auth
  namespace: agentic-app
spec:
  podIdentity:
    provider: gcp        # Uses Workload Identity — no static credentials
```

**Scaling table:**

| Queue Depth | Target Replicas | Total Capacity |
|-------------|-----------------|----------------|
| 0           | 1 (minimum)     | 5 sessions     |
| 1–2         | 1               | 5 sessions     |
| 3–7         | 2               | 10 sessions    |
| 8–12        | 3               | 15 sessions    |
| 13–17       | 4               | 20 sessions    |
| 18–22       | 5               | 25 sessions    |
| 23+         | 6 (maximum)     | 30 sessions    |

---

## 8. Helm Chart Structure

```
helm/autoauth/
├── Chart.yaml
├── values.yaml           # Shared defaults
├── values-dev.yaml       # Dev overrides
├── values-uat.yaml       # UAT overrides
├── values-prod.yaml      # Prod overrides
└── templates/
    ├── _helpers.tpl
    ├── namespace.yaml
    ├── serviceaccount.yaml
    ├── api-server/
    │   ├── deployment.yaml
    │   ├── service.yaml
    │   └── hpa.yaml
    ├── planner/
    │   ├── deployment.yaml
    │   └── service.yaml
    ├── control-plane/
    │   ├── deployment.yaml
    │   └── service.yaml
    ├── browser-agent/
    │   ├── deployment.yaml
    │   ├── service.yaml
    │   └── scaledobject.yaml
    ├── tracking-agent/
    │   ├── deployment.yaml
    │   └── service.yaml
    ├── frontend/
    │   ├── deployment.yaml
    │   └── service.yaml
    ├── n8n/
    │   ├── statefulset.yaml
    │   ├── service.yaml
    │   └── pvc.yaml
    ├── ingress.yaml
    ├── pdb.yaml
    ├── db-migration-job.yaml
    └── secrets/
        ├── db-credentials.yaml
        ├── redis-credentials.yaml
        └── app-secrets.yaml
```

```yaml
# helm/autoauth/Chart.yaml
apiVersion: v2
name: autoauth
description: AutoAuth Agent — Prior Authorization Automation Platform
type: application
version: 1.0.0
appVersion: "1.0.0"
maintainers:
  - name: Niranjan Sai Koppisetti
    email: niranjansai.k@ikshealth.com
```

```yaml
# helm/autoauth/values.yaml  (shared defaults)
global:
  region: us-central1
  project_id: ""           # Set per environment
  environment: ""          # dev | uat | prod
  imageTag: latest

apiServer:
  replicas: 2
  image: api-server
  resources:
    requests:
      cpu: 250m
      memory: 512Mi
    limits:
      cpu: 1000m
      memory: 1Gi
  hpa:
    minReplicas: 2
    maxReplicas: 6

planner:
  replicas: 1
  image: planner
  resources:
    requests:
      cpu: 250m
      memory: 512Mi

controlPlane:
  replicas: 1
  image: control-plane

browserAgent:
  replicas: 1             # KEDA manages this
  maxSessions: 5
  image: browser-agent
  executionEngine: "yes"  # yes = recipe, no = llm
  keda:
    minReplicas: 1
    maxReplicas: 6
    queueThreshold: "3"
    cooldownPeriod: 300
  resources:
    requests:
      cpu: 500m
      memory: 2Gi
    limits:
      cpu: 2000m
      memory: 4Gi

trackingAgent:
  replicas: 1
  image: tracking-agent

frontend:
  replicas: 2
  image: frontend

n8n:
  enabled: true
  webhookUrl: ""          # Set per environment
  persistence:
    size: 5Gi
```

```yaml
# helm/autoauth/values-prod.yaml
global:
  project_id: autoauth-prod-12345
  environment: prod
  imageTag: ""            # Must be set at deploy time — never use latest in prod

apiServer:
  replicas: 3
  hpa:
    minReplicas: 3
    maxReplicas: 8

browserAgent:
  maxSessions: 5
  keda:
    minReplicas: 2        # Keep 2 pods warm in prod
    maxReplicas: 6

n8n:
  webhookUrl: "https://n8n.autoauth.ikshealth.com"
```

---

## 9. Environment Promotion Workflow

```
Branch Strategy:
  feature/*   →  Developer feature branches
  main        →  Integration branch (deploys to dev + uat automatically)
  v*.*.*      →  Production release tags (deploys to prod after manual approval)

Promotion Flow:
  1. Developer pushes feature/* branch
     → Cloud Build: lint + test ONLY (no deploy)

  2. PR merged to main
     → Cloud Build: lint + test + build + push image
     → Auto-deploy to dev namespace
     → Run smoke tests on dev
     → Auto-deploy to uat namespace
     → Run smoke tests on uat
     → Notify Slack #deployments channel

  3. Release Manager tags a release: git tag v1.2.3 && git push --tags
     → Cloud Build: build + push image with semver tag
     → Open manual approval gate in Cloud Build console
     → Approval required from: Engineering Lead OR Project Manager
     → After approval: run Alembic migration job in prod
     → Blue/green deploy to prod
     → Run smoke tests on prod
     → Notify Slack #releases channel
```

```bash
# Release script: scripts/release.sh
#!/bin/bash
set -e

VERSION=$1
if [ -z "$VERSION" ]; then
  echo "Usage: ./scripts/release.sh v1.2.3"
  exit 1
fi

echo "Creating release $VERSION..."

# Ensure main is up to date
git checkout main && git pull

# Update version in pyproject.toml files
sed -i "s/version = \".*\"/version = \"${VERSION#v}\"/" */pyproject.toml

# Commit version bump
git add -A
git commit -m "chore: bump version to $VERSION"

# Tag
git tag -a "$VERSION" -m "Release $VERSION"
git push origin main "$VERSION"

echo "Release $VERSION tagged and pushed."
echo "Cloud Build will now build and await prod approval."
```

---

## 10. Blue/Green Deployment

For production releases, we use a blue/green strategy to achieve zero-downtime deployments and instant rollback.

```
Before deployment:
  Ingress → Service (selector: color=blue) → Blue Pods (current version)

During deployment:
  1. Deploy new "green" version alongside blue (different label: color=green)
  2. Run smoke tests against green pods directly (bypass ingress)
  3. If smoke tests pass: update ingress to point to green
  4. If smoke tests fail: keep ingress on blue, delete green, done

After deployment:
  Ingress → Service (selector: color=green) → Green Pods (new version)
  Blue pods still running (for 15-minute rollback window)
  After 15 minutes: delete blue pods
```

```bash
# scripts/deploy-prod.sh
#!/bin/bash
set -e

NEW_TAG=$1
SERVICE=$2   # api-server | browser-agent | all

REGION="us-central1"
CLUSTER="autoauth-cluster-prod"
NAMESPACE="agentic-app"
REGISTRY="$REGION-docker.pkg.dev/autoauth-prod/autoauth"

# Get current color
CURRENT_COLOR=$(kubectl get service $SERVICE -n $NAMESPACE \
  -o jsonpath='{.spec.selector.color}')
NEW_COLOR=$([[ "$CURRENT_COLOR" == "blue" ]] && echo "green" || echo "blue")

echo "Deploying $SERVICE:$NEW_TAG as $NEW_COLOR (current: $CURRENT_COLOR)"

# Step 1: Deploy new version with new color label
kubectl set image deployment/$SERVICE-$NEW_COLOR \
  $SERVICE=$REGISTRY/$SERVICE:$NEW_TAG \
  -n $NAMESPACE

# Wait for new pods to be ready
kubectl rollout status deployment/$SERVICE-$NEW_COLOR \
  -n $NAMESPACE --timeout=300s

# Step 2: Smoke test against new color (directly via pod IP)
NEW_POD=$(kubectl get pod -n $NAMESPACE \
  -l "app=$SERVICE,color=$NEW_COLOR" \
  -o jsonpath='{.items[0].metadata.name}')
kubectl exec $NEW_POD -n $NAMESPACE -- curl -sf http://localhost:8080/health

# Step 3: Switch ingress / service selector to new color
kubectl patch service $SERVICE -n $NAMESPACE \
  -p "{\"spec\":{\"selector\":{\"color\":\"$NEW_COLOR\"}}}"

echo "$SERVICE switched to $NEW_COLOR ($NEW_TAG)"
echo "Blue pods still running. Run 'kubectl delete deployment/$SERVICE-$CURRENT_COLOR' to clean up."

# Step 4: Auto-cleanup blue after 15 minutes (run in background)
(sleep 900 && kubectl delete deployment/$SERVICE-$CURRENT_COLOR -n $NAMESPACE \
  && echo "$CURRENT_COLOR pods deleted.") &
```

---

## 11. Database Migration Job

```yaml
# k8s/base/db-migration-job.yaml
# This job runs BEFORE each deployment and exits 0 on success.
# If it fails, the deployment is aborted.
apiVersion: batch/v1
kind: Job
metadata:
  name: db-migration-JOB_ID
  namespace: agentic-app
  labels:
    app: db-migration
spec:
  ttlSecondsAfterFinished: 3600   # Clean up after 1 hour
  backoffLimit: 0                  # No retries — migration must succeed on first try
  template:
    metadata:
      labels:
        app: db-migration
    spec:
      serviceAccountName: autoauth-ksa
      restartPolicy: Never
      containers:
        - name: alembic-migrate
          image: us-central1-docker.pkg.dev/PROJECT_ID/autoauth/api-server:IMAGE_TAG
          command:
            - python
            - -m
            - alembic
            - -c
            - /app/src/alembic.ini
            - upgrade
            - head
          env:
            - name: DB_HOST
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: host
            - name: DB_USER
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: username
            - name: DB_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: password
            - name: DB_NAME
              valueFrom:
                secretKeyRef:
                  name: db-credentials
                  key: dbname
            - name: DB_PORT
              value: "5432"
```

```bash
# scripts/run-migration.sh
#!/bin/bash
set -e

IMAGE_TAG=$1
ENV=$2        # dev | uat | prod
NAMESPACE="agentic-app-$ENV"
CLUSTER="autoauth-cluster-$ENV"

# Generate unique job name
JOB_NAME="db-migration-$(date +%Y%m%d%H%M%S)"

# Apply migration job
sed "s/db-migration-JOB_ID/$JOB_NAME/g; s/IMAGE_TAG/$IMAGE_TAG/g" \
  k8s/base/db-migration-job.yaml | \
  kubectl apply -n $NAMESPACE -f -

echo "Waiting for migration job $JOB_NAME to complete..."

# Wait up to 5 minutes
kubectl wait job/$JOB_NAME -n $NAMESPACE \
  --for=condition=complete \
  --timeout=300s

echo "Migration completed successfully."

# Show migration output
kubectl logs job/$JOB_NAME -n $NAMESPACE
```

---

## 12. Rollback Procedures

### 12.1 Immediate Rollback (< 5 minutes)

```bash
# Option A: kubectl rollout undo (reverts to previous ReplicaSet)
kubectl rollout undo deployment/api-server -n agentic-app
kubectl rollout status deployment/api-server -n agentic-app

# Option B: Pin to a known good image tag
kubectl set image deployment/api-server \
  api-server=us-central1-docker.pkg.dev/PROJECT_ID/autoauth/api-server:LAST_GOOD_TAG \
  -n agentic-app

# Verify
kubectl rollout status deployment/api-server -n agentic-app
curl -f https://api.autoauth.ikshealth.com/health
```

### 12.2 Blue/Green Rollback (instant)

```bash
# Switch ingress back to blue (the previous version still running)
kubectl patch service api-server -n agentic-app \
  -p '{"spec":{"selector":{"color":"blue"}}}'

# Verify traffic is back on blue
kubectl get endpoints api-server -n agentic-app

echo "Rolled back to blue. Green pods still running for investigation."
```

### 12.3 Database Rollback

```bash
# Revert ONE migration
alembic downgrade -1

# Revert to a specific revision
alembic downgrade 0007    # Revision ID

# View migration history
alembic history --verbose

# CRITICAL: Never downgrade if the migration added columns with NOT NULL.
# Instead: add the column back as nullable in a new migration.
```

### 12.4 Rollback Decision Matrix

| Scenario | Action | Time to Recovery |
|----------|--------|-----------------|
| New image crashes on startup | `kubectl rollout undo` | < 2 min |
| New image passes health but has bug | Blue/green switch back to blue | < 30 sec |
| Migration broke DB schema | Alembic downgrade + image rollback | 10–30 min |
| N8N workflow broken | Restore workflow from N8N backup | 15–30 min |
| Recipe YAML bug | PUT updated recipe via API (hot fix) | < 5 min |
| Entire cluster down | GKE node pool rebuild from Terraform | 20–40 min |

---

## 13. Secrets & Config Management

### 13.1 Secret Manager Naming Convention

```
autoauth/{env}/{category}/{name}

Examples:
  autoauth/prod/db/host
  autoauth/prod/db/username
  autoauth/prod/db/password
  autoauth/prod/redis/host
  autoauth/prod/redis/auth_string
  autoauth/prod/app/jwt_secret_key
  autoauth/prod/app/capsolver_api_key
  autoauth/prod/app/n8n_webhook_secret
  autoauth/prod/portals/availity/username        ← per-portal credentials
  autoauth/prod/portals/availity/password
  autoauth/prod/portals/navinet/username
  autoauth/prod/portals/navinet/password
```

### 13.2 Secret Store CSI Driver (inject secrets as files/env at pod startup)

```yaml
# k8s/base/secrets/secret-provider-class.yaml
apiVersion: secrets-store.csi.x-k8s.io/v1
kind: SecretProviderClass
metadata:
  name: autoauth-secrets
  namespace: agentic-app
spec:
  provider: gcp
  parameters:
    secrets: |
      - resourceName: "projects/PROJECT_ID/secrets/autoauth-prod-db-host/versions/latest"
        fileName: "db_host"
      - resourceName: "projects/PROJECT_ID/secrets/autoauth-prod-db-password/versions/latest"
        fileName: "db_password"
      - resourceName: "projects/PROJECT_ID/secrets/autoauth-prod-redis-auth/versions/latest"
        fileName: "redis_auth"
      - resourceName: "projects/PROJECT_ID/secrets/autoauth-prod-app-jwt-secret/versions/latest"
        fileName: "jwt_secret"
  secretObjects:
    - secretName: db-credentials
      type: Opaque
      data:
        - objectName: db_host
          key: host
        - objectName: db_password
          key: password
    - secretName: redis-credentials
      type: Opaque
      data:
        - objectName: redis_auth
          key: auth_string
    - secretName: app-secrets
      type: Opaque
      data:
        - objectName: jwt_secret
          key: jwt_secret_key
```

### 13.3 Rotating Secrets

```bash
# Rotate JWT secret (triggers pod restart to pick up new secret)
gcloud secrets versions add autoauth-prod-app-jwt-secret \
  --data-file=<(python3 -c "import secrets; print(secrets.token_hex(64))")

# Verify new version is active
gcloud secrets versions list autoauth-prod-app-jwt-secret

# Rolling restart pods to pick up new secret (CSI driver auto-syncs, but restart accelerates)
kubectl rollout restart deployment/api-server -n agentic-app
```

---

## 14. Monitoring & Alerting Setup

### 14.1 Cloud Monitoring Dashboards

```bash
# Create dashboards via gcloud / Terraform
# Four dashboards:

# 1. Case Volume & Outcomes (primary ops dashboard)
#    - Cases per hour by status
#    - Success rate by portal
#    - Average processing time per case
#    - Active cases count

# 2. Browser Agent Health
#    - Active sessions per pod
#    - KEDA replica count
#    - HITL tasks open
#    - Pod crash rate

# 3. LLM Cost Tracking
#    - Cost per day by model
#    - Cost per portal
#    - Token usage trends

# 4. Infrastructure Health
#    - GKE node CPU/memory
#    - Cloud SQL connections and CPU
#    - Redis memory usage
#    - Pub/Sub message age
```

### 14.2 Alerting Policies

```yaml
# Key alerts (create via Terraform or gcloud):

alerts:
  - name: "Pub/Sub message age > 10 minutes"
    condition: pubsub_subscription_oldest_unacked_message_age > 600
    threshold: WARNING
    channel: slack-ops

  - name: "Case FAILED rate > 20% in 10 min window"
    condition: rate(case_status_transitions{to="FAILED"}[10m]) > 0.2
    threshold: CRITICAL
    channel: pagerduty

  - name: "HITL tasks open > 15"
    condition: hitl_open_tasks > 15
    threshold: WARNING
    channel: slack-ops

  - name: "browser-agent pod crash"
    condition: pod_restarts{app="browser-agent"} > 1 in 5m
    threshold: CRITICAL
    channel: pagerduty

  - name: "Cloud SQL CPU > 80% for 5 minutes"
    condition: cloudsql_cpu_utilization > 0.8 for 5m
    threshold: WARNING
    channel: slack-ops

  - name: "Redis memory > 85%"
    condition: redis_memory_usage_ratio > 0.85
    threshold: WARNING
    channel: slack-ops

  - name: "api-server error rate > 5% (non-400 errors)"
    condition: rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) > 0.05
    threshold: WARNING
    channel: slack-ops

  - name: "Dead letter queue has messages"
    condition: pubsub_subscription_num_undelivered_messages{subscription="*-dead-letter"} > 0
    threshold: WARNING
    channel: slack-ops
```

### 14.3 Structured Log Format

```python
# All services log in this JSON format for Cloud Logging
{
    "severity": "INFO",             # DEBUG|INFO|WARNING|ERROR|CRITICAL
    "timestamp": "2026-09-01T12:00:00.000Z",
    "service": "api-server",
    "version": "1.0.0",
    "trace_id": "abc123def456",
    "case_ref_id": "CASE-001",     # When applicable
    "session_id": "sess-xyz",      # When applicable
    "message": "Case status updated to IN_PROGRESS",
    "labels": {
        "portal_id": "availity",
        "pod_id": "api-server-abc123"
    }
}
```

---

## 15. Local Development Stack

```yaml
# docker-compose.yaml
version: "3.9"

services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: autoauth_app
      POSTGRES_PASSWORD: localpassword123
      POSTGRES_DB: autoauth
    ports:
      - "5433:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U autoauth_app"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7.2-alpine
    command: >
      redis-server
      --requirepass localredispass
      --notify-keyspace-events KEA
    ports:
      - "6380:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "-a", "localredispass", "ping"]
      interval: 10s

  n8n:
    image: n8nio/n8n:latest
    environment:
      - N8N_BASIC_AUTH_ACTIVE=true
      - N8N_BASIC_AUTH_USER=admin
      - N8N_BASIC_AUTH_PASSWORD=admin
      - N8N_PORT=5678
      - WEBHOOK_URL=http://localhost:5678
      - DB_TYPE=postgresdb
      - DB_POSTGRESDB_HOST=postgres
      - DB_POSTGRESDB_PORT=5432
      - DB_POSTGRESDB_DATABASE=autoauth
      - DB_POSTGRESDB_USER=autoauth_app
      - DB_POSTGRESDB_PASSWORD=localpassword123
      - DB_POSTGRESDB_SCHEMA=n8n_schema
    ports:
      - "5678:5678"
    volumes:
      - n8n_data:/home/node/.n8n
    depends_on:
      postgres:
        condition: service_healthy

  pubsub-emulator:
    image: gcr.io/google.com/cloudsdktool/cloud-sdk:latest
    command: gcloud beta emulators pubsub start --host-port=0.0.0.0:8085 --project=local-dev
    ports:
      - "8085:8085"

  api-server:
    build:
      context: .
      dockerfile: api-server/Dockerfile
    environment:
      - APP_ENV=local
      - DB_HOST=postgres
      - DB_PORT=5432
      - DB_USER=autoauth_app
      - DB_PASSWORD=localpassword123
      - DB_NAME=autoauth
      - REDIS_HOST=redis
      - REDIS_PORT=6379
      - REDIS_AUTH=localredispass
      - JWT_SECRET_KEY=local-jwt-secret-32-chars-minimum
      - PUBSUB_EMULATOR_HOST=pubsub-emulator:8085
      - GCP_PROJECT_ID=local-dev
      - LOG_LEVEL=DEBUG
      - PRIOR_AUTH_SUBMISSION_TOPIC=prior-auth-submission-topic
    ports:
      - "8080:8080"
    volumes:
      - ./api-server/src:/app/src    # Hot reload in dev
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy

  planner:
    build:
      context: .
      dockerfile: planner/Dockerfile
    environment:
      - APP_ENV=local
      - DB_HOST=postgres
      - REDIS_HOST=redis
      - REDIS_AUTH=localredispass
      - PUBSUB_EMULATOR_HOST=pubsub-emulator:8085
      - GCP_PROJECT_ID=local-dev
      - N8N_SUBMISSION_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-submission
      - ONE_SESSION_PER_BATCH=false
      - LOG_LEVEL=DEBUG
    ports:
      - "8082:8082"
    depends_on:
      - api-server
      - pubsub-emulator

  control-plane:
    build:
      context: .
      dockerfile: control-plane/Dockerfile
    environment:
      - APP_ENV=local
      - DB_HOST=postgres
      - REDIS_HOST=redis
      - REDIS_AUTH=localredispass
      - LOG_LEVEL=DEBUG
    ports:
      - "8083:8083"
    depends_on:
      - planner

  browser-agent:
    build:
      context: .
      dockerfile: browser-agent/Dockerfile
    environment:
      - APP_ENV=local
      - DB_HOST=postgres
      - REDIS_HOST=redis
      - REDIS_AUTH=localredispass
      - PLAYWRIGHT_EXECUTION_ENGINE=yes
      - MAX_SESSIONS=2
      - API_SERVER_URL=http://api-server:8080
      - CONTROL_PLANE_URL=http://control-plane:8083
      - LOG_LEVEL=DEBUG
      - CAPSOLVER_API_KEY=local-test-key
    ports:
      - "8081:8081"
      - "5900-5910:5900-5910"    # VNC ports
      - "6080-6090:6080-6090"    # WebSocket ports
    shm_size: 2gb                 # Required for Chromium
    depends_on:
      - control-plane

  tracking-agent:
    build:
      context: .
      dockerfile: tracking-agent/Dockerfile
    environment:
      - APP_ENV=local
      - DB_HOST=postgres
      - REDIS_HOST=redis
      - REDIS_AUTH=localredispass
      - LOG_LEVEL=DEBUG
    ports:
      - "8084:8084"

  frontend:
    build:
      context: .
      dockerfile: frontend/Dockerfile
    environment:
      - VITE_API_URL=http://localhost:8080
    ports:
      - "3000:80"
    depends_on:
      - api-server

volumes:
  postgres_data:
  redis_data:
  n8n_data:
```

```bash
# scripts/dev-start.sh — start the local stack
#!/bin/bash
set -e

echo "Starting AutoAuth local development stack..."

# Start infrastructure first
docker compose up -d postgres redis pubsub-emulator
echo "Waiting for infrastructure..."
sleep 10

# Run database migrations
docker compose run --rm api-server \
  python -m alembic -c src/alembic.ini upgrade head
echo "Migrations applied."

# Seed test data
docker compose run --rm api-server \
  python scripts/seed_test_data.py
echo "Test data seeded."

# Start all services
docker compose up -d
echo ""
echo "Stack started!"
echo "  API Server:     http://localhost:8080"
echo "  Frontend:       http://localhost:3000"
echo "  N8N:            http://localhost:5678  (admin/admin)"
echo "  Control Plane:  http://localhost:8083"
echo "  Browser Agent:  http://localhost:8081"
echo "  VNC (noVNC):    http://localhost:6080"
echo ""
echo "Logs: docker compose logs -f api-server browser-agent"
```

---

## 16. On-Call Runbook

### 16.1 Cases Stuck in QUEUED / IN_PROGRESS

```bash
# 1. Check queue depth
gcloud pubsub subscriptions describe prior-auth-submission-sub \
  --format="value(numUndeliveredMessages)"

# 2. Check KEDA replica count
kubectl get scaledobject browser-agent-scaledobject -n agentic-app

# 3. Check browser-agent pod status
kubectl get pods -n agentic-app -l app=browser-agent

# 4. Check Redis worker pools
redis-cli -h $REDIS_HOST -a $REDIS_AUTH SMEMBERS prior_auth_submission_idle_worker_set
redis-cli -h $REDIS_HOST -a $REDIS_AUTH SMEMBERS prior_auth_submission_busy_worker_set

# 5. If pool is empty (no idle workers), check if pods are healthy
# If pods are healthy but pool is empty, manually register:
kubectl exec -it deploy/control-plane -n agentic-app -- \
  curl -X POST http://localhost:8083/internal/reinitialize-worker-pool

# 6. Force-move stuck cases back to PENDING
psql $DATABASE_URL -c "
  UPDATE iks_schema.prior_auth_case_request
  SET status='PENDING', last_error='Manual reset by on-call'
  WHERE status IN ('QUEUED','IN_PROGRESS')
    AND updated_at < NOW() - INTERVAL '30 minutes';
"
```

### 16.2 Pod Crash (browser-agent)

```bash
# 1. Check crash reason
kubectl describe pod <crashed-pod> -n agentic-app
kubectl logs <crashed-pod> -n agentic-app --previous

# 2. Find cases that were running on crashed pod
psql $DATABASE_URL -c "
  SELECT s.case_ref_id, s.started_at, c.status, c.retry_count
  FROM iks_schema.prior_auth_agent_session s
  JOIN iks_schema.prior_auth_case_request c ON s.case_ref_id = c.case_ref_id
  WHERE s.pod_id = '<crashed-pod>'
    AND s.status IN ('RUNNING','ACTIVE','HITL_WAIT','MFA_WAIT');
"

# 3. ExpiredEventConsumer should auto-recover these cases (within 90s)
# If not recovered, manually trigger:
kubectl exec -it deploy/control-plane -n agentic-app -- \
  curl -X POST http://localhost:8083/internal/recover-crashed-pod \
  -d '{"pod_id":"<crashed-pod>"}'
```

### 16.3 Dead Letter Queue Has Messages

```bash
# Pull a message from DLQ to inspect
gcloud pubsub subscriptions pull prior-auth-submission-dead-letter-sub \
  --max-messages=1 --auto-ack=false

# Inspect message, fix root cause, then republish to main topic
gcloud pubsub topics publish prior-auth-submission-topic \
  --message='{"case_ref_id":"CASE-001","retry":true}'

# Drain the DLQ after fixing
gcloud pubsub subscriptions seek prior-auth-submission-dead-letter-sub \
  --time=$(date -u +%Y-%m-%dT%H:%M:%SZ)
```

### 16.4 HITL Tasks Expiring

```bash
# Find all expired/expiring HITL tasks
psql $DATABASE_URL -c "
  SELECT h.case_ref_id, h.task_type, h.created_at, h.expires_at,
         EXTRACT(EPOCH FROM (h.expires_at - NOW()))::INTEGER AS seconds_remaining
  FROM iks_schema.prior_auth_hitl_task h
  WHERE h.status = 'PENDING'
  ORDER BY h.expires_at ASC;
"

# Auto-expire tasks past their deadline (run by control-plane, but manual trigger:)
kubectl exec -it deploy/control-plane -n agentic-app -- \
  curl -X POST http://localhost:8083/internal/expire-hitl-tasks
```

### 16.5 N8N Webhook Failures

```bash
# Check N8N workflow execution history
kubectl exec -it sts/n8n -n agentic-app -- \
  curl -s http://localhost:5678/api/v1/executions?status=error \
  -H "X-N8N-API-KEY: $N8N_API_KEY"

# Check N8N pod logs
kubectl logs sts/n8n -n agentic-app --tail=100

# Restart N8N (it will reconnect webhook listeners)
kubectl rollout restart statefulset/n8n -n agentic-app

# If N8N is down and cases are not being triggered,
# manually trigger the planner endpoint:
curl -X POST https://api.autoauth.ikshealth.com/api/v1/retrigger/CASE-001 \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

---

*Document Status: DRAFT*
*Previous: [05_Recipe_Engine_and_Portal_Specification.md](05_Recipe_Engine_and_Portal_Specification.md)*
*Next: Development Phase documents (common library, api-server, planner, control-plane, browser-agent, tracking-agent)*
