# AutoAuth Agent — Common Library Implementation
**Phase 2 | Weeks 5–6**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0
**Prerequisite:** [04_Database_Schema_Design.md](04_Database_Schema_Design.md)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Package Structure](#2-package-structure)
3. [pyproject.toml](#3-pyprojecttoml)
4. [db_layer — Database Layer](#4-db_layer--database-layer)
5. [redis_layer — Redis Layer](#5-redis_layer--redis-layer)
6. [pubsub_layer — Google Pub/Sub Layer](#6-pubsub_layer--google-pubsub-layer)
7. [secret — GCP Secret Manager](#7-secret--gcp-secret-manager)
8. [logs — Structured Logging](#8-logs--structured-logging)
9. [Unit Tests](#9-unit-tests)

---

## 1. Overview

`common/` is a Python package shared by all five services. It is installed as a local dependency via `pip install -e ./common/`. It is never deployed independently — it is baked into each service's Docker image.

**Layers:**

| Module | Responsibility |
|--------|---------------|
| `db_layer` | SQLAlchemy session factory, base repository, all ORM models |
| `redis_layer` | Redis connection, worker pool ops, credential pool, stream logging |
| `pubsub_layer` | Pub/Sub publisher, base consumer, consumer thread |
| `secret` | GCP Secret Manager client, credential loading |
| `logs` | Structured JSON logger, trace context, PHI redaction |

**Design rules:**
- No business logic — only infrastructure primitives
- Every class is independently unit-testable with mocks
- No circular imports between layers
- All GCP clients use Application Default Credentials (Workload Identity in GKE, local `gcloud auth` in dev)
- All secrets fetched at startup and cached — never re-fetched per request

---

## 2. Package Structure

```
common/
├── pyproject.toml
├── src/
│   └── common/
│       ├── __init__.py
│       ├── db_layer/
│       │   ├── __init__.py
│       │   ├── db_config.py          # Engine, session factory
│       │   ├── base_repository.py    # Generic CRUD base class
│       │   ├── unit_of_work.py       # Unit of Work pattern
│       │   └── orm_models/
│       │       ├── __init__.py       # Re-exports all models
│       │       ├── base.py           # DeclarativeBase
│       │       ├── payer_portal.py   # Payer, Portal, Credential, Recipe, Prompt
│       │       ├── case.py           # BatchRequest, CaseRequest
│       │       ├── agent.py          # AgentSession, TrackingSession, PlannerStatus, LoginSession
│       │       ├── hitl.py           # HitlTask
│       │       ├── logs.py           # CaseLogs
│       │       ├── cost.py           # AiModelPricing, RequestCost
│       │       ├── user.py           # User, Agent (pod registration)
│       │       └── alert.py          # Alert
│       ├── redis_layer/
│       │   ├── __init__.py
│       │   ├── redis_config.py       # Connection manager
│       │   ├── worker_pool.py        # Idle/busy/cooling pool operations
│       │   ├── credential_pool.py    # Per-portal credential round-robin
│       │   ├── stream_logger.py      # Redis Streams log publisher
│       │   └── keyspace.py           # Keyspace notification listener
│       ├── pubsub_layer/
│       │   ├── __init__.py
│       │   ├── publisher.py          # Typed Pub/Sub publisher
│       │   ├── base_consumer.py      # Pull-based consumer base class
│       │   └── consumer_thread.py    # Thread wrapper for consumers
│       ├── secret/
│       │   ├── __init__.py
│       │   └── secret_manager.py     # GCP Secret Manager client
│       └── logs/
│           ├── __init__.py
│           ├── logger.py             # Structured JSON logger
│           ├── phi_redactor.py       # PHI field redaction
│           └── trace_context.py      # Trace ID propagation
└── tests/
    ├── test_db_layer.py
    ├── test_redis_layer.py
    ├── test_pubsub_layer.py
    ├── test_secret.py
    └── test_logs.py
```

---

## 3. pyproject.toml

```toml
# common/pyproject.toml
[build-system]
requires = ["setuptools>=68", "wheel"]
build-backend = "setuptools.backends.legacy:build"

[project]
name = "autoauth-common"
version = "1.0.0"
description = "AutoAuth Agent shared library"
requires-python = ">=3.12"
dependencies = [
    # Database
    "sqlalchemy>=2.0.36",
    "alembic>=1.13.3",
    "psycopg2-binary>=2.9.9",
    # Redis
    "redis>=5.0.8",
    # GCP
    "google-cloud-pubsub>=2.22.0",
    "google-cloud-secret-manager>=2.20.0",
    # Async
    "anyio>=4.4.0",
    # Validation
    "pydantic>=2.8.2",
    "pydantic-settings>=2.4.0",
    # Utilities
    "python-dotenv>=1.0.1",
    "structlog>=24.4.0",
]

[project.optional-dependencies]
test = [
    "pytest>=8.3",
    "pytest-asyncio>=0.23",
    "pytest-mock>=3.14",
    "fakeredis>=2.24",
    "pytest-cov>=5.0",
]

[tool.setuptools.packages.find]
where = ["src"]

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
```

---

## 4. db_layer — Database Layer

### 4.1 db_config.py

```python
# common/src/common/db_layer/db_config.py
import os
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool
from common.logs import get_logger

logger = get_logger(__name__)


def _build_database_url() -> str:
    user     = os.environ["DB_USER"]
    password = os.environ["DB_PASSWORD"]
    host     = os.environ["DB_HOST"]
    port     = os.environ.get("DB_PORT", "5432")
    name     = os.environ["DB_NAME"]
    return f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{name}"


def create_db_engine():
    url = _build_database_url()
    engine = create_engine(
        url,
        poolclass=QueuePool,
        pool_size=10,           # Persistent connections
        max_overflow=20,        # Burst connections
        pool_timeout=30,        # Seconds to wait for a connection
        pool_recycle=1800,      # Recycle connections every 30 min (avoids stale)
        pool_pre_ping=True,     # Ping before each use (detect dead connections)
        echo=os.environ.get("DB_ECHO", "false").lower() == "true",
    )

    # Log slow queries (> 1 second)
    @event.listens_for(engine, "before_cursor_execute")
    def before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
        import time
        conn.info.setdefault("query_start_time", []).append(time.monotonic())

    @event.listens_for(engine, "after_cursor_execute")
    def after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
        import time
        total = time.monotonic() - conn.info["query_start_time"].pop()
        if total > 1.0:
            logger.warning("slow_query", duration_seconds=round(total, 3),
                           statement=statement[:200])

    logger.info("db_engine_created", host=os.environ["DB_HOST"],
                dbname=os.environ["DB_NAME"])
    return engine


# Module-level singletons (created once at service startup)
_engine = None
_SessionFactory = None


def get_engine():
    global _engine
    if _engine is None:
        _engine = create_db_engine()
    return _engine


def get_session_factory() -> sessionmaker:
    global _SessionFactory
    if _SessionFactory is None:
        _SessionFactory = sessionmaker(
            bind=get_engine(),
            expire_on_commit=False,    # Don't re-query after commit
            autoflush=False,
            autocommit=False,
        )
    return _SessionFactory


def get_session() -> Session:
    """Returns a new session. Caller must close it."""
    return get_session_factory()()
```

---

### 4.2 base_repository.py

```python
# common/src/common/db_layer/base_repository.py
from __future__ import annotations
import uuid
from typing import TypeVar, Generic, Type
from sqlalchemy.orm import Session
from sqlalchemy import select, update

from common.db_layer.orm_models.base import Base

T = TypeVar("T", bound=Base)


class BaseRepository(Generic[T]):
    """
    Generic repository providing standard CRUD operations.
    All service-specific repositories extend this class.
    """

    def __init__(self, session: Session, model: Type[T]):
        self._session = session
        self._model = model

    def get_by_id(self, record_id: uuid.UUID) -> T | None:
        return self._session.get(self._model, record_id)

    def get_all(self, limit: int = 100, offset: int = 0) -> list[T]:
        stmt = select(self._model).limit(limit).offset(offset)
        return list(self._session.scalars(stmt))

    def add(self, entity: T) -> T:
        self._session.add(entity)
        self._session.flush()    # Get ID without committing
        return entity

    def add_all(self, entities: list[T]) -> list[T]:
        self._session.add_all(entities)
        self._session.flush()
        return entities

    def delete(self, entity: T) -> None:
        self._session.delete(entity)

    def exists(self, record_id: uuid.UUID) -> bool:
        return self.get_by_id(record_id) is not None
```

---

### 4.3 unit_of_work.py

```python
# common/src/common/db_layer/unit_of_work.py
from __future__ import annotations
from contextlib import contextmanager
from typing import Generator
from sqlalchemy.orm import Session

from common.db_layer.db_config import get_session_factory
from common.logs import get_logger

logger = get_logger(__name__)


class UnitOfWork:
    """
    Context manager that wraps a database transaction.
    Commits on clean exit, rolls back on any exception.

    Usage:
        with UnitOfWork() as uow:
            case = uow.session.get(PriorAuthCaseRequest, case_id)
            case.status = "IN_PROGRESS"
            # Commits automatically on __exit__
    """

    def __init__(self):
        self._session_factory = get_session_factory()
        self.session: Session | None = None

    def __enter__(self) -> "UnitOfWork":
        self.session = self._session_factory()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if exc_type is not None:
            self.rollback()
            logger.error("uow_rolled_back", exc_type=str(exc_type), exc=str(exc_val))
            return False    # Re-raise exception
        try:
            self.commit()
        except Exception:
            self.rollback()
            raise
        finally:
            self.close()
        return False

    def commit(self) -> None:
        self.session.commit()

    def rollback(self) -> None:
        self.session.rollback()

    def close(self) -> None:
        if self.session:
            self.session.close()
            self.session = None


@contextmanager
def db_transaction() -> Generator[Session, None, None]:
    """
    Convenience context manager for one-off transactions.

    Usage:
        with db_transaction() as session:
            session.add(new_entity)
    """
    with UnitOfWork() as uow:
        yield uow.session
```

---

### 4.4 ORM Models

```python
# common/src/common/db_layer/orm_models/base.py
import uuid
from datetime import datetime
from sqlalchemy import MetaData
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID, TIMESTAMPTZ

SCHEMA = "iks_schema"

convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(schema=SCHEMA, naming_convention=convention)

    # All tables get these three columns automatically
    id:         Mapped[uuid.UUID] = mapped_column(
                    UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    created_at: Mapped[datetime]  = mapped_column(
                    TIMESTAMPTZ(), nullable=False, default=datetime.utcnow)
    updated_at: Mapped[datetime]  = mapped_column(
                    TIMESTAMPTZ(), nullable=False, default=datetime.utcnow,
                    onupdate=datetime.utcnow)
```

```python
# common/src/common/db_layer/orm_models/case.py
import uuid
from datetime import datetime
from sqlalchemy import String, Boolean, Integer, Text, ForeignKey, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB, TIMESTAMPTZ
from .base import Base, SCHEMA


class PriorAuthBatchRequest(Base):
    __tablename__ = "prior_auth_batch_request"
    __table_args__ = (
        CheckConstraint(
            "status IN ('PENDING','IN_PROGRESS','COMPLETED','PARTIALLY_COMPLETED','FAILED')",
            name="ck_batch_status"),
        CheckConstraint("priority IN ('NORMAL','HIGH','URGENT')", name="ck_batch_priority"),
        {"schema": SCHEMA},
    )

    batch_id:       Mapped[str]           = mapped_column(String(255), unique=True, nullable=False)
    portal_id:      Mapped[uuid.UUID]     = mapped_column(
                        UUID(as_uuid=True), ForeignKey(f"{SCHEMA}.prior_auth_portal.id"),
                        nullable=False)
    payer_id:       Mapped[uuid.UUID]     = mapped_column(
                        UUID(as_uuid=True), ForeignKey(f"{SCHEMA}.prior_auth_payer.id"),
                        nullable=False)
    submitted_by:   Mapped[uuid.UUID | None] = mapped_column(
                        UUID(as_uuid=True), ForeignKey(f"{SCHEMA}.agentic_platform_user.id"))
    total_cases:    Mapped[int]           = mapped_column(Integer(), nullable=False)
    accepted_cases: Mapped[int]           = mapped_column(Integer(), default=0)
    rejected_cases: Mapped[int]           = mapped_column(Integer(), default=0)
    status:         Mapped[str]           = mapped_column(String(50), default="PENDING")
    priority:       Mapped[str]           = mapped_column(String(20), default="NORMAL")
    metadata_:      Mapped[dict | None]   = mapped_column("metadata", JSONB())
    completed_at:   Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())

    cases: Mapped[list["PriorAuthCaseRequest"]] = relationship(back_populates="batch")


class PriorAuthCaseRequest(Base):
    __tablename__ = "prior_auth_case_request"
    __table_args__ = (
        CheckConstraint(
            "status IN ('PENDING','PLANNING','QUEUED','IN_PROGRESS','HITL_WAIT','MFA_WAIT',"
            "'SUBMITTED','APPROVED','DENIED','PENDING_INFO','CRASHED','FAILED','CANCELLED')",
            name="ck_case_status"),
        {"schema": SCHEMA},
    )

    case_ref_id:         Mapped[str]           = mapped_column(String(255), unique=True, nullable=False)
    batch_id:            Mapped[uuid.UUID | None] = mapped_column(
                             UUID(as_uuid=True), ForeignKey(f"{SCHEMA}.prior_auth_batch_request.id"))
    portal_id:           Mapped[uuid.UUID]     = mapped_column(
                             UUID(as_uuid=True), ForeignKey(f"{SCHEMA}.prior_auth_portal.id"),
                             nullable=False)
    payer_id:            Mapped[uuid.UUID]     = mapped_column(
                             UUID(as_uuid=True), ForeignKey(f"{SCHEMA}.prior_auth_payer.id"),
                             nullable=False)
    patient_data:        Mapped[dict]          = mapped_column(JSONB(), nullable=False)
    clinical_data:       Mapped[dict]          = mapped_column(JSONB(), nullable=False)
    status:              Mapped[str]           = mapped_column(String(50), default="PENDING")
    previous_status:     Mapped[str | None]    = mapped_column(String(50))
    status_changed_at:   Mapped[datetime]      = mapped_column(TIMESTAMPTZ(), default=datetime.utcnow)
    outcome:             Mapped[str | None]    = mapped_column(String(50))
    pa_reference_number: Mapped[str | None]    = mapped_column(String(255))
    outcome_details:     Mapped[str | None]    = mapped_column(Text())
    outcome_raw:         Mapped[str | None]    = mapped_column(Text())
    retry_count:         Mapped[int]           = mapped_column(Integer(), default=0)
    max_retries:         Mapped[int]           = mapped_column(Integer(), default=3)
    last_retry_at:       Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())
    last_error:          Mapped[str | None]    = mapped_column(Text())
    queued_at:           Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())
    started_at:          Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())
    submitted_at:        Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())
    completed_at:        Mapped[datetime | None] = mapped_column(TIMESTAMPTZ())

    batch:        Mapped["PriorAuthBatchRequest | None"] = relationship(back_populates="cases")
    agent_sessions: Mapped[list["PriorAuthAgentSession"]] = relationship(
                       foreign_keys="PriorAuthAgentSession.case_ref_id",
                       primaryjoin="PriorAuthCaseRequest.case_ref_id==PriorAuthAgentSession.case_ref_id",
                       back_populates="case")
    hitl_tasks:   Mapped[list["PriorAuthHitlTask"]] = relationship(back_populates="case")
```

```python
# common/src/common/db_layer/orm_models/__init__.py
from .base import Base, SCHEMA
from .payer_portal import PriorAuthPayer, PriorAuthPortal, PriorAuthPortalCredential, PriorAuthPortalRecipe, PriorAuthPayerPrompt
from .case import PriorAuthBatchRequest, PriorAuthCaseRequest
from .agent import PriorAuthAgentSession, PriorAuthTrackingSession, PriorAuthPlannerAgentStatus, PriorAuthLoginSession
from .hitl import PriorAuthHitlTask
from .logs import PriorAuthCaseLog
from .cost import AgenticPlatformAiModelPricing, AgenticPlatformRequestCost
from .user import AgenticPlatformUser, AgenticPlatformAgent
from .alert import AgenticPlatformAlert

__all__ = [
    "Base", "SCHEMA",
    "PriorAuthPayer", "PriorAuthPortal", "PriorAuthPortalCredential",
    "PriorAuthPortalRecipe", "PriorAuthPayerPrompt",
    "PriorAuthBatchRequest", "PriorAuthCaseRequest",
    "PriorAuthAgentSession", "PriorAuthTrackingSession",
    "PriorAuthPlannerAgentStatus", "PriorAuthLoginSession",
    "PriorAuthHitlTask",
    "PriorAuthCaseLog",
    "AgenticPlatformAiModelPricing", "AgenticPlatformRequestCost",
    "AgenticPlatformUser", "AgenticPlatformAgent",
    "AgenticPlatformAlert",
]
```

---

## 5. redis_layer — Redis Layer

### 5.1 redis_config.py

```python
# common/src/common/redis_layer/redis_config.py
import os
import redis
from redis.backoff import ExponentialBackoff
from redis.retry import Retry
from common.logs import get_logger

logger = get_logger(__name__)

_redis_client: redis.Redis | None = None


def get_redis_client() -> redis.Redis:
    global _redis_client
    if _redis_client is None:
        _redis_client = _create_redis_client()
    return _redis_client


def _create_redis_client() -> redis.Redis:
    host     = os.environ["REDIS_HOST"]
    port     = int(os.environ.get("REDIS_PORT", "6379"))
    auth     = os.environ.get("REDIS_AUTH")
    use_tls  = os.environ.get("REDIS_TLS", "false").lower() == "true"
    db       = int(os.environ.get("REDIS_DB", "0"))

    client = redis.Redis(
        host=host,
        port=port,
        password=auth,
        db=db,
        ssl=use_tls,
        ssl_cert_reqs="required" if use_tls else None,
        decode_responses=True,          # Always return str, not bytes
        socket_timeout=5,
        socket_connect_timeout=5,
        socket_keepalive=True,
        socket_keepalive_options={},
        health_check_interval=30,       # Background ping every 30s
        retry=Retry(ExponentialBackoff(cap=10, base=0.5), retries=3),
        retry_on_error=[redis.ConnectionError, redis.TimeoutError],
        max_connections=20,
    )

    # Verify connection
    client.ping()
    logger.info("redis_connected", host=host, port=port, tls=use_tls)
    return client
```

---

### 5.2 worker_pool.py

```python
# common/src/common/redis_layer/worker_pool.py
"""
Redis-based worker pool for browser-agent and tracking-agent pods.
Three sets per pool type:
  {prefix}_idle_worker_set    → pods available to take work
  {prefix}_busy_worker_set    → pods currently processing
  {prefix}_cooling_worker_set → pods recovering after completion (cooling down)

Each set member is a JSON string:
  {"pod_ip": "10.0.1.5", "pod_port": 8081, "session_count": 2}
"""
import json
from dataclasses import dataclass, asdict
from common.redis_layer.redis_config import get_redis_client
from common.logs import get_logger

logger = get_logger(__name__)

# Set name prefixes
SUBMISSION_PREFIX = "prior_auth_submission"
TRACKING_PREFIX   = "prior_auth_tracking"


@dataclass
class WorkerInfo:
    pod_ip:        str
    pod_port:      int
    pod_id:        str
    session_count: int = 0
    max_sessions:  int = 5

    @classmethod
    def from_json(cls, raw: str) -> "WorkerInfo":
        return cls(**json.loads(raw))

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @property
    def is_full(self) -> bool:
        return self.session_count >= self.max_sessions


class WorkerPool:
    """
    Manages idle/busy/cooling sets for a specific agent type.
    All operations are atomic (Lua scripts or pipeline where needed).
    """

    def __init__(self, prefix: str):
        self._prefix = prefix
        self._idle   = f"{prefix}_idle_worker_set"
        self._busy   = f"{prefix}_busy_worker_set"
        self._cool   = f"{prefix}_cooling_worker_set"

    @property
    def _redis(self):
        return get_redis_client()

    # ── Registration ─────────────────────────────────────────────────
    def register_worker(self, worker: WorkerInfo) -> None:
        """Called by worker pod at startup. Adds to idle set."""
        pipe = self._redis.pipeline()
        pipe.srem(self._busy, worker.pod_id)
        pipe.srem(self._cool, worker.pod_id)
        pipe.hset(f"{self._prefix}_workers", worker.pod_id, worker.to_json())
        pipe.sadd(self._idle, worker.pod_id)
        pipe.execute()
        logger.info("worker_registered", prefix=self._prefix, pod_id=worker.pod_id)

    def deregister_worker(self, pod_id: str) -> None:
        """Called on pod shutdown."""
        pipe = self._redis.pipeline()
        pipe.srem(self._idle, pod_id)
        pipe.srem(self._busy, pod_id)
        pipe.srem(self._cool, pod_id)
        pipe.hdel(f"{self._prefix}_workers", pod_id)
        pipe.execute()
        logger.info("worker_deregistered", prefix=self._prefix, pod_id=pod_id)

    # ── Acquisition ──────────────────────────────────────────────────
    def acquire_worker(self) -> WorkerInfo | None:
        """
        Pop one idle worker, move to busy.
        Returns None if no idle workers.
        Atomic: SMOVE is O(1) and atomic in Redis.
        """
        # Get all idle worker IDs
        idle_ids = self._redis.smembers(self._idle)
        for pod_id in idle_ids:
            raw = self._redis.hget(f"{self._prefix}_workers", pod_id)
            if not raw:
                continue
            worker = WorkerInfo.from_json(raw)
            if not worker.is_full:
                # Move from idle to busy
                moved = self._redis.smove(self._idle, self._busy, pod_id)
                if moved:
                    logger.info("worker_acquired", prefix=self._prefix, pod_id=pod_id)
                    return worker
        return None

    def release_worker(self, pod_id: str, cool_down_seconds: int = 60) -> None:
        """
        Move from busy to cooling. After TTL, cooling → idle.
        Uses a Redis key with expiry to implement the cooling period.
        ExpiredEventConsumer handles the expiry → idle transition.
        """
        cool_key = f"{self._prefix}_cooling_{pod_id}"
        pipe = self._redis.pipeline()
        pipe.smove(self._busy, self._cool, pod_id)
        pipe.setex(cool_key, cool_down_seconds, pod_id)   # TTL triggers idle move
        pipe.execute()
        logger.info("worker_cooling", prefix=self._prefix, pod_id=pod_id,
                    seconds=cool_down_seconds)

    def promote_from_cooling(self, pod_id: str) -> None:
        """
        Called by ExpiredEventConsumer when cooling key expires.
        Moves worker from cooling → idle.
        """
        moved = self._redis.smove(self._cool, self._idle, pod_id)
        if moved:
            logger.info("worker_promoted_idle", prefix=self._prefix, pod_id=pod_id)

    def mark_crashed(self, pod_id: str) -> None:
        """Remove crashed pod from all sets."""
        self.deregister_worker(pod_id)
        logger.warning("worker_crashed_removed", prefix=self._prefix, pod_id=pod_id)

    # ── Inspection ───────────────────────────────────────────────────
    def get_pool_stats(self) -> dict:
        pipe = self._redis.pipeline()
        pipe.scard(self._idle)
        pipe.scard(self._busy)
        pipe.scard(self._cool)
        idle_count, busy_count, cool_count = pipe.execute()
        return {
            "idle": idle_count,
            "busy": busy_count,
            "cooling": cool_count,
            "total": idle_count + busy_count + cool_count,
        }

    def get_all_workers(self) -> list[WorkerInfo]:
        all_raw = self._redis.hgetall(f"{self._prefix}_workers")
        return [WorkerInfo.from_json(v) for v in all_raw.values()]

    def clear_all(self) -> None:
        """Admin operation: clear entire pool (use with caution)."""
        pipe = self._redis.pipeline()
        pipe.delete(self._idle, self._busy, self._cool,
                    f"{self._prefix}_workers")
        pipe.execute()
        logger.warning("worker_pool_cleared", prefix=self._prefix)


# Module-level pool instances
submission_pool = WorkerPool(SUBMISSION_PREFIX)
tracking_pool   = WorkerPool(TRACKING_PREFIX)
```

---

### 5.3 credential_pool.py

```python
# common/src/common/redis_layer/credential_pool.py
"""
Per-portal credential round-robin pool.
Each portal may have multiple credentials (primary + backup).
Redis sorted set: ZADD {portal_id}_creds {last_used_ts} {credential_id}
ZPOPMIN + ZADD gives round-robin with oldest-used-first selection.
"""
import time
import json
from dataclasses import dataclass
from common.redis_layer.redis_config import get_redis_client
from common.logs import get_logger

logger = get_logger(__name__)

CRED_KEY_PREFIX = "portal_credentials"
CRED_LOCK_TTL   = 300    # 5 minutes — max time a credential is considered "in-use"


@dataclass
class PortalCredential:
    credential_id: str
    portal_id:     str
    username:      str
    password:      str
    alias:         str


class CredentialPool:
    """Round-robin credential selection per portal."""

    @property
    def _redis(self):
        return get_redis_client()

    def _key(self, portal_id: str) -> str:
        return f"{CRED_KEY_PREFIX}:{portal_id}"

    def _lock_key(self, credential_id: str) -> str:
        return f"{CRED_KEY_PREFIX}:lock:{credential_id}"

    def add_credential(self, portal_id: str, credential_id: str) -> None:
        """Add or refresh a credential in the pool."""
        self._redis.zadd(self._key(portal_id), {credential_id: 0})
        logger.info("credential_added", portal_id=portal_id,
                    credential_id=credential_id)

    def acquire_credential(self, portal_id: str) -> str | None:
        """
        Get the least-recently-used credential for a portal.
        Returns credential_id or None if all credentials are locked.
        """
        pool_key = self._key(portal_id)
        members  = self._redis.zrange(pool_key, 0, -1, withscores=True)

        for credential_id, _ in members:
            lock_key = self._lock_key(credential_id)
            # Try to acquire lock (SET NX with TTL)
            locked = self._redis.set(lock_key, "1", nx=True, ex=CRED_LOCK_TTL)
            if locked:
                # Update score to current timestamp (moves to back of queue)
                self._redis.zadd(pool_key, {credential_id: time.time()})
                logger.info("credential_acquired", portal_id=portal_id,
                            credential_id=credential_id)
                return credential_id

        logger.warning("no_credentials_available", portal_id=portal_id)
        return None

    def release_credential(self, credential_id: str) -> None:
        """Release lock on a credential after use."""
        self._redis.delete(self._lock_key(credential_id))
        logger.info("credential_released", credential_id=credential_id)

    def mark_failed(self, portal_id: str, credential_id: str) -> None:
        """
        Mark a credential as failed — give it a very high score so
        it is selected last next time, giving others a chance.
        Does not remove it (admin must intervene).
        """
        self._redis.zadd(self._key(portal_id),
                         {credential_id: time.time() + 86400})
        self._redis.delete(self._lock_key(credential_id))
        logger.warning("credential_marked_failed", portal_id=portal_id,
                       credential_id=credential_id)

    def remove_credential(self, portal_id: str, credential_id: str) -> None:
        """Remove a credential from the pool entirely."""
        self._redis.zrem(self._key(portal_id), credential_id)
        self._redis.delete(self._lock_key(credential_id))
        logger.info("credential_removed", portal_id=portal_id,
                    credential_id=credential_id)

    def get_pool_size(self, portal_id: str) -> int:
        return self._redis.zcard(self._key(portal_id))


credential_pool = CredentialPool()
```

---

### 5.4 stream_logger.py

```python
# common/src/common/redis_layer/stream_logger.py
"""
Real-time log streaming to Redis Streams.
Key: stream:{case_ref_id}/logs
Clients (dashboard SSE) read from this stream for live log viewing.
Max stream length: 500 entries per case (MAXLEN ~500).
"""
import json
import threading
from datetime import datetime, timezone
from common.redis_layer.redis_config import get_redis_client
from common.logs import get_logger

logger = get_logger(__name__)

STREAM_KEY_TEMPLATE = "stream:{case_ref_id}/logs"
MAX_STREAM_LEN      = 500
STREAM_TTL_SECONDS  = 86400 * 2    # 2 days TTL on stream key


class RedisStreamLogger:
    """
    Publishes structured log entries to a Redis Stream for a specific case.
    Thread-safe: can be called from multiple threads within a session.
    """

    def __init__(self, case_ref_id: str, session_id: str | None = None):
        self.case_ref_id = case_ref_id
        self.session_id  = session_id
        self._stream_key = STREAM_KEY_TEMPLATE.format(case_ref_id=case_ref_id)
        self._lock       = threading.Lock()

    @property
    def _redis(self):
        return get_redis_client()

    def log(
        self,
        message:     str,
        level:       str = "INFO",
        step_name:   str | None = None,
        action_type: str | None = None,
        metadata:    dict | None = None,
    ) -> None:
        entry = {
            "case_ref_id": self.case_ref_id,
            "session_id":  self.session_id or "",
            "level":       level,
            "step_name":   step_name or "",
            "action_type": action_type or "",
            "message":     message,
            "metadata":    json.dumps(metadata or {}),
            "ts":          datetime.now(timezone.utc).isoformat(),
        }
        try:
            with self._lock:
                self._redis.xadd(
                    self._stream_key,
                    entry,
                    maxlen=MAX_STREAM_LEN,
                    approximate=True,
                )
                # Set TTL on first write (EXPIRE is idempotent)
                self._redis.expire(self._stream_key, STREAM_TTL_SECONDS)
        except Exception as e:
            # Stream logging failures must never crash the agent
            logger.warning("stream_log_failed", case_ref_id=self.case_ref_id,
                           error=str(e))

    def info(self, message: str, **kwargs) -> None:
        self.log(message, level="INFO", **kwargs)

    def warn(self, message: str, **kwargs) -> None:
        self.log(message, level="WARN", **kwargs)

    def error(self, message: str, **kwargs) -> None:
        self.log(message, level="ERROR", **kwargs)

    def debug(self, message: str, **kwargs) -> None:
        self.log(message, level="DEBUG", **kwargs)

    def read_logs(self, count: int = 100, last_id: str = "0") -> list[dict]:
        """Read entries from stream for SSE delivery."""
        entries = self._redis.xread(
            {self._stream_key: last_id}, count=count, block=0
        )
        if not entries:
            return []
        _, messages = entries[0]
        return [{"id": mid, **fields} for mid, fields in messages]
```

---

### 5.5 keyspace.py

```python
# common/src/common/redis_layer/keyspace.py
"""
Redis Keyspace Notification listener.
Listens for expired key events to detect pod cooling timeout
and heartbeat expiry (pod crash detection).

Requires Redis config: notify-keyspace-events KEA
"""
import threading
from typing import Callable
from common.redis_layer.redis_config import _create_redis_client
from common.logs import get_logger

logger = get_logger(__name__)

# Event channels
EXPIRED_CHANNEL  = "__keyevent@0__:expired"
KEYSPACE_CHANNEL = "__keyspace@0__:{key}"


class KeyspaceEventConsumer:
    """
    Subscribes to Redis keyspace events on a dedicated connection.
    Calls registered handlers when a key expires.

    Usage:
        consumer = KeyspaceEventConsumer()
        consumer.register_handler(
            pattern="prior_auth_submission_cooling_*",
            handler=on_cooling_expired
        )
        consumer.start()   # Non-blocking, runs in background thread
    """

    def __init__(self):
        self._handlers: list[tuple[str, Callable]] = []
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        # Separate connection — pubsub blocks the connection
        self._pubsub_client = _create_redis_client()

    def register_handler(self, pattern: str, handler: Callable[[str], None]) -> None:
        """
        Register a handler for expired keys matching a glob pattern.
        handler(key_name: str) -> None
        """
        self._handlers.append((pattern, handler))

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._listen_loop,
            name="KeyspaceEventConsumer",
            daemon=True,
        )
        self._thread.start()
        logger.info("keyspace_consumer_started")

    def stop(self) -> None:
        self._stop_event.set()
        logger.info("keyspace_consumer_stopped")

    def _listen_loop(self) -> None:
        pubsub = self._pubsub_client.pubsub()
        pubsub.psubscribe(EXPIRED_CHANNEL)
        logger.info("keyspace_subscribed", channel=EXPIRED_CHANNEL)

        while not self._stop_event.is_set():
            message = pubsub.get_message(timeout=1.0)
            if not message or message["type"] != "pmessage":
                continue
            key_name = message["data"]
            self._dispatch(key_name)

    def _dispatch(self, key_name: str) -> None:
        import fnmatch
        for pattern, handler in self._handlers:
            if fnmatch.fnmatch(key_name, pattern):
                try:
                    handler(key_name)
                except Exception as e:
                    logger.error("keyspace_handler_error", key=key_name,
                                 pattern=pattern, error=str(e))
```

---

## 6. pubsub_layer — Google Pub/Sub Layer

### 6.1 publisher.py

```python
# common/src/common/pubsub_layer/publisher.py
import json
import os
from datetime import datetime, timezone
from google.cloud import pubsub_v1
from google.api_core.exceptions import GoogleAPICallError
from common.logs import get_logger

logger = get_logger(__name__)

_publisher: pubsub_v1.PublisherClient | None = None


def get_publisher() -> pubsub_v1.PublisherClient:
    global _publisher
    if _publisher is None:
        _publisher = pubsub_v1.PublisherClient()
    return _publisher


def publish_message(
    topic_id:   str,
    data:       dict,
    attributes: dict | None = None,
) -> str:
    """
    Publish a JSON message to a Pub/Sub topic.
    Returns the message ID.
    Raises PubSubPublishError on failure.
    """
    project_id  = os.environ["GCP_PROJECT_ID"]
    topic_path  = get_publisher().topic_path(project_id, topic_id)

    payload = json.dumps({
        **data,
        "_published_at": datetime.now(timezone.utc).isoformat(),
    }).encode("utf-8")

    attrs = {
        "content_type": "application/json",
        **(attributes or {}),
    }

    try:
        future = get_publisher().publish(topic_path, payload, **attrs)
        message_id = future.result(timeout=10)
        logger.info("pubsub_published", topic=topic_id,
                    message_id=message_id, data_keys=list(data.keys()))
        return message_id
    except (GoogleAPICallError, TimeoutError) as e:
        logger.error("pubsub_publish_failed", topic=topic_id, error=str(e))
        raise


def publish_case_to_submission_queue(
    case_ref_id:  str,
    portal_id:    str,
    batch_id:     str | None = None,
    retry:        bool = False,
    priority:     str = "NORMAL",
) -> str:
    topic = os.environ.get("PRIOR_AUTH_SUBMISSION_TOPIC",
                           "prior-auth-submission-topic")
    return publish_message(
        topic_id=topic,
        data={
            "case_ref_id": case_ref_id,
            "portal_id":   portal_id,
            "batch_id":    batch_id,
            "retry":       retry,
            "priority":    priority,
        },
        attributes={"priority": priority},
    )
```

---

### 6.2 base_consumer.py

```python
# common/src/common/pubsub_layer/base_consumer.py
"""
Pull-based Pub/Sub consumer base class.
Each service creates one subclass per subscription.

Ack/Nack strategy:
  - On successful processing: ack immediately
  - On transient error (network, DB timeout): nack (message redelivered)
  - On permanent error (bad message format): ack + log error (avoid infinite loop)
  - On business error (case not found): ack + update case status to FAILED
"""
import json
import os
import time
from abc import ABC, abstractmethod
from typing import Any
from google.cloud import pubsub_v1
from google.api_core import retry as api_retry
from common.logs import get_logger

logger = get_logger(__name__)

TRANSIENT_EXCEPTIONS = (ConnectionError, TimeoutError, OSError)


class BaseConsumer(ABC):
    """
    Abstract base for Pub/Sub subscription consumers.
    Subclass and implement process_message().
    """

    def __init__(self, subscription_id: str, max_messages: int = 5):
        self._subscription_id  = subscription_id
        self._max_messages     = max_messages
        self._project_id       = os.environ["GCP_PROJECT_ID"]
        self._subscriber       = pubsub_v1.SubscriberClient()
        self._subscription_path = self._subscriber.subscription_path(
            self._project_id, subscription_id
        )
        self._running = False

    @abstractmethod
    def process_message(self, data: dict[str, Any], attributes: dict[str, str]) -> None:
        """
        Implement message processing logic here.
        Raise TransientError to nack and retry.
        Raise PermanentError to ack and skip.
        Any other exception: ack + log error.
        """
        ...

    def start_consuming(self) -> None:
        """
        Blocking pull loop. Runs until stop() is called.
        Call this in a thread (see ConsumerThread).
        """
        self._running = True
        logger.info("consumer_started", subscription=self._subscription_id)

        while self._running:
            try:
                response = self._subscriber.pull(
                    request={
                        "subscription": self._subscription_path,
                        "max_messages":  self._max_messages,
                    },
                    retry=api_retry.Retry(deadline=30),
                )
                if not response.received_messages:
                    time.sleep(0.5)
                    continue

                for msg in response.received_messages:
                    self._handle_message(msg)

            except Exception as e:
                logger.error("consumer_pull_error",
                             subscription=self._subscription_id, error=str(e))
                time.sleep(2)

    def stop(self) -> None:
        self._running = False
        logger.info("consumer_stopped", subscription=self._subscription_id)

    def _handle_message(self, received_msg) -> None:
        msg_id = received_msg.message.message_id
        try:
            raw   = received_msg.message.data.decode("utf-8")
            data  = json.loads(raw)
            attrs = dict(received_msg.message.attributes)

            logger.info("message_received", msg_id=msg_id,
                        subscription=self._subscription_id)

            self.process_message(data, attrs)

            # Ack on success
            self._subscriber.acknowledge(
                request={
                    "subscription": self._subscription_path,
                    "ack_ids":      [received_msg.ack_id],
                }
            )
            logger.info("message_acked", msg_id=msg_id)

        except TransientError as e:
            logger.warning("message_nacked_transient", msg_id=msg_id, error=str(e))
            # Do NOT ack — message redelivered after ack deadline

        except PermanentError as e:
            logger.error("message_acked_permanent_error", msg_id=msg_id, error=str(e))
            # Ack to prevent infinite retry, but log for investigation
            self._subscriber.acknowledge(
                request={
                    "subscription": self._subscription_path,
                    "ack_ids":      [received_msg.ack_id],
                }
            )

        except Exception as e:
            logger.error("message_processing_unexpected_error",
                         msg_id=msg_id, error=str(e), exc_info=True)
            # Ack to prevent DLQ overflow on bad messages
            try:
                self._subscriber.acknowledge(
                    request={
                        "subscription": self._subscription_path,
                        "ack_ids":      [received_msg.ack_id],
                    }
                )
            except Exception:
                pass


class TransientError(Exception):
    """Nack the message — it will be redelivered."""

class PermanentError(Exception):
    """Ack the message but log the error — do not retry."""
```

---

### 6.3 consumer_thread.py

```python
# common/src/common/pubsub_layer/consumer_thread.py
import threading
from common.pubsub_layer.base_consumer import BaseConsumer
from common.logs import get_logger

logger = get_logger(__name__)


class ConsumerThread:
    """
    Wraps a BaseConsumer in a daemon thread.
    Used by planner and control-plane to run consumers
    alongside the FastAPI server.

    Usage (in FastAPI lifespan):
        thread = ConsumerThread(MyConsumer("my-subscription"))
        thread.start()
        ...
        thread.stop()
    """

    def __init__(self, consumer: BaseConsumer, name: str | None = None):
        self._consumer = consumer
        self._thread   = threading.Thread(
            target=self._consumer.start_consuming,
            name=name or f"Consumer-{consumer._subscription_id}",
            daemon=True,
        )

    def start(self) -> None:
        self._thread.start()
        logger.info("consumer_thread_started", name=self._thread.name)

    def stop(self) -> None:
        self._consumer.stop()
        self._thread.join(timeout=10)
        logger.info("consumer_thread_stopped", name=self._thread.name)

    def is_alive(self) -> bool:
        return self._thread.is_alive()
```

---

## 7. secret — GCP Secret Manager

```python
# common/src/common/secret/secret_manager.py
"""
GCP Secret Manager client with in-process caching.
Secrets are fetched once at startup and cached for the process lifetime.
Cache is intentionally NOT refreshed during runtime — restart the pod to pick up new secrets.

Never log secret values — this module is PHI/credential adjacent.
"""
import os
from functools import lru_cache
from google.cloud import secretmanager
from common.logs import get_logger

logger = get_logger(__name__)

_client: secretmanager.SecretManagerServiceClient | None = None


def _get_client() -> secretmanager.SecretManagerServiceClient:
    global _client
    if _client is None:
        _client = secretmanager.SecretManagerServiceClient()
    return _client


@lru_cache(maxsize=256)
def get_secret(secret_id: str, version: str = "latest") -> str:
    """
    Fetch a secret value from GCP Secret Manager.
    Results are cached in-process (LRU cache, max 256 entries).

    secret_id format: "autoauth/prod/portals/availity/username"
    Internally converted to full resource name.
    """
    project_id   = os.environ["GCP_PROJECT_ID"]
    # Convert slash-separated ID to GCP resource name (replace / with - for secret name)
    secret_name  = secret_id.replace("/", "-")
    resource     = f"projects/{project_id}/secrets/{secret_name}/versions/{version}"

    try:
        response = _get_client().access_secret_version(request={"name": resource})
        value    = response.payload.data.decode("utf-8").strip()
        logger.info("secret_fetched", secret_id=secret_id, version=version)
        return value
    except Exception as e:
        logger.error("secret_fetch_failed", secret_id=secret_id, error=str(e))
        raise


def get_portal_credentials(portal_id: str) -> tuple[str, str]:
    """
    Fetch username + password for a portal from Secret Manager.
    Returns (username, password).
    Path convention: autoauth/{env}/portals/{portal_id}/username|password
    """
    env      = os.environ.get("APP_ENV", "prod")
    username = get_secret(f"autoauth/{env}/portals/{portal_id}/username")
    password = get_secret(f"autoauth/{env}/portals/{portal_id}/password")
    return username, password


def get_portal_credentials_by_path(
    username_path: str, password_path: str
) -> tuple[str, str]:
    """
    Fetch credentials using explicit Secret Manager paths.
    Used when credential paths are stored in prior_auth_portal_credential.
    """
    username = get_secret(username_path)
    password = get_secret(password_path)
    return username, password


def invalidate_cache() -> None:
    """Clear the secret cache — call this when secrets are rotated."""
    get_secret.cache_clear()
    logger.info("secret_cache_cleared")
```

---

## 8. logs — Structured Logging

### 8.1 logger.py

```python
# common/src/common/logs/logger.py
"""
Structured JSON logger for all AutoAuth services.
Uses structlog for consistent key-value JSON output.
All logs go to stdout → Cloud Logging picks them up.
"""
import logging
import os
import sys
import structlog
from common.logs.phi_redactor import redact_phi


def configure_logging() -> None:
    """
    Call once at service startup (in FastAPI lifespan or main()).
    Sets up structlog with JSON renderer for prod, pretty for local.
    """
    log_level_name = os.environ.get("LOG_LEVEL", "INFO").upper()
    log_level      = getattr(logging, log_level_name, logging.INFO)
    is_local       = os.environ.get("APP_ENV", "prod") == "local"

    shared_processors = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        _add_service_context,
        _redact_phi_processor,
    ]

    if is_local:
        # Pretty output for local development
        renderer = structlog.dev.ConsoleRenderer()
    else:
        # JSON output for Cloud Logging
        renderer = structlog.processors.JSONRenderer()

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processor=renderer,
        foreign_pre_chain=shared_processors,
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers = []
    root.addHandler(handler)
    root.setLevel(log_level)


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Return a bound logger for a module."""
    return structlog.get_logger(name)


def _add_service_context(logger, method_name, event_dict):
    event_dict["service"] = os.environ.get("SERVICE_NAME", "unknown")
    event_dict["env"]     = os.environ.get("APP_ENV", "prod")
    return event_dict


def _redact_phi_processor(logger, method_name, event_dict):
    """Strip PHI fields from log events before output."""
    return redact_phi(event_dict)
```

---

### 8.2 phi_redactor.py

```python
# common/src/common/logs/phi_redactor.py
"""
PHI/PII redaction for log events.
HIPAA requires that PHI is never logged in plaintext.
These field names are redacted wherever they appear in log events.
"""
import re
from typing import Any

# Field names that contain PHI — redacted from all log output
PHI_FIELDS = frozenset({
    "first_name", "last_name", "full_name", "patient_name",
    "date_of_birth", "dob", "birth_date",
    "ssn", "social_security_number",
    "member_id", "subscriber_id", "insurance_id",
    "phone", "phone_number", "fax",
    "email", "email_address",
    "address", "street", "city", "zip", "zip_code",
    "password", "secret", "token", "api_key", "auth",
    "username", "credential",
})

# Patterns to redact from string values regardless of field name
_REDACT_PATTERNS = [
    (re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),            "[SSN]"),      # SSN
    (re.compile(r'\b\d{10}\b'),                         "[NPI?]"),     # 10-digit (NPI/member ID)
    (re.compile(r'\b[A-Z]{3}\d{6,12}\b'),              "[MemberID?]"),# Member ID pattern
]

REDACTED = "[REDACTED]"


def redact_phi(event_dict: dict) -> dict:
    """
    Recursively redact PHI fields from a structlog event dict.
    Returns modified dict (in-place modification for performance).
    """
    for key, value in list(event_dict.items()):
        key_lower = key.lower()
        if key_lower in PHI_FIELDS:
            event_dict[key] = REDACTED
        elif isinstance(value, dict):
            event_dict[key] = redact_phi(value)
        elif isinstance(value, str):
            event_dict[key] = _redact_patterns(value)
        elif isinstance(value, list):
            event_dict[key] = [
                redact_phi(v) if isinstance(v, dict)
                else _redact_patterns(v) if isinstance(v, str)
                else v
                for v in value
            ]
    return event_dict


def _redact_patterns(text: str) -> str:
    """Apply regex redaction patterns to a string value."""
    for pattern, replacement in _REDACT_PATTERNS:
        text = pattern.sub(replacement, text)
    return text
```

---

### 8.3 trace_context.py

```python
# common/src/common/logs/trace_context.py
"""
Distributed trace ID propagation via structlog contextvars.
Sets trace_id on all log events within a request context.
"""
import uuid
import structlog
from contextvars import ContextVar

_trace_id_var: ContextVar[str] = ContextVar("trace_id", default="")


def set_trace_id(trace_id: str | None = None) -> str:
    """Set trace ID for the current async context. Generates one if not provided."""
    tid = trace_id or str(uuid.uuid4()).replace("-", "")[:16]
    _trace_id_var.set(tid)
    structlog.contextvars.bind_contextvars(trace_id=tid)
    return tid


def get_trace_id() -> str:
    return _trace_id_var.get()


def clear_trace_id() -> None:
    _trace_id_var.set("")
    structlog.contextvars.unbind_contextvars("trace_id")


# FastAPI middleware usage:
# class TraceMiddleware(BaseHTTPMiddleware):
#     async def dispatch(self, request: Request, call_next):
#         trace_id = request.headers.get("X-Trace-Id")
#         set_trace_id(trace_id)
#         response = await call_next(request)
#         response.headers["X-Trace-Id"] = get_trace_id()
#         return response
```

---

## 9. Unit Tests

### 9.1 test_db_layer.py

```python
# common/tests/test_db_layer.py
import pytest
import uuid
from unittest.mock import MagicMock, patch
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from common.db_layer.orm_models import Base, PriorAuthCaseRequest
from common.db_layer.unit_of_work import UnitOfWork


@pytest.fixture
def in_memory_engine():
    """SQLite in-memory engine for unit tests (schema-less, no migrations)."""
    engine = create_engine("sqlite:///:memory:", echo=False)
    Base.metadata.create_all(engine)
    return engine


@pytest.fixture
def session(in_memory_engine):
    factory = sessionmaker(bind=in_memory_engine)
    s = factory()
    yield s
    s.close()


def test_case_request_created(session):
    case = PriorAuthCaseRequest(
        case_ref_id="TEST-001",
        portal_id=uuid.uuid4(),
        payer_id=uuid.uuid4(),
        patient_data={"member_id": "M123", "first_name": "John"},
        clinical_data={"procedure_codes": ["27447"]},
    )
    session.add(case)
    session.commit()

    result = session.query(PriorAuthCaseRequest).filter_by(
        case_ref_id="TEST-001").first()
    assert result is not None
    assert result.status == "PENDING"
    assert result.retry_count == 0


def test_uow_rolls_back_on_exception():
    mock_session = MagicMock()
    with patch("common.db_layer.unit_of_work.get_session_factory",
               return_value=MagicMock(return_value=mock_session)):
        with pytest.raises(ValueError):
            with UnitOfWork():
                raise ValueError("test error")
        mock_session.rollback.assert_called_once()
```

---

### 9.2 test_redis_layer.py

```python
# common/tests/test_redis_layer.py
import pytest
import fakeredis
from unittest.mock import patch

from common.redis_layer.worker_pool import WorkerPool, WorkerInfo


@pytest.fixture
def fake_redis():
    return fakeredis.FakeRedis(decode_responses=True)


@pytest.fixture
def pool(fake_redis):
    with patch("common.redis_layer.worker_pool.get_redis_client",
               return_value=fake_redis):
        yield WorkerPool("test_prefix")


def test_register_and_acquire(pool, fake_redis):
    with patch("common.redis_layer.worker_pool.get_redis_client",
               return_value=fake_redis):
        worker = WorkerInfo(pod_ip="10.0.0.1", pod_port=8081,
                            pod_id="pod-abc", max_sessions=5)
        pool.register_worker(worker)

        stats = pool.get_pool_stats()
        assert stats["idle"] == 1

        acquired = pool.acquire_worker()
        assert acquired is not None
        assert acquired.pod_id == "pod-abc"

        stats = pool.get_pool_stats()
        assert stats["idle"] == 0
        assert stats["busy"] == 1


def test_acquire_returns_none_when_empty(pool, fake_redis):
    with patch("common.redis_layer.worker_pool.get_redis_client",
               return_value=fake_redis):
        result = pool.acquire_worker()
        assert result is None


def test_release_moves_to_cooling(pool, fake_redis):
    with patch("common.redis_layer.worker_pool.get_redis_client",
               return_value=fake_redis):
        worker = WorkerInfo(pod_ip="10.0.0.1", pod_port=8081,
                            pod_id="pod-abc", max_sessions=5)
        pool.register_worker(worker)
        pool.acquire_worker()
        pool.release_worker("pod-abc", cool_down_seconds=30)

        stats = pool.get_pool_stats()
        assert stats["busy"]    == 0
        assert stats["cooling"] == 1
```

---

### 9.3 test_logs.py

```python
# common/tests/test_logs.py
import pytest
from common.logs.phi_redactor import redact_phi


def test_phi_fields_redacted():
    event = {
        "message": "Processing case",
        "first_name": "John",
        "last_name": "Doe",
        "member_id": "M123456",
        "portal_id": "availity",    # Not PHI — should NOT be redacted
    }
    result = redact_phi(event)
    assert result["first_name"] == "[REDACTED]"
    assert result["last_name"]  == "[REDACTED]"
    assert result["member_id"]  == "[REDACTED]"
    assert result["portal_id"]  == "availity"      # Preserved
    assert result["message"]    == "Processing case"


def test_nested_phi_redacted():
    event = {
        "patient": {
            "first_name": "Jane",
            "dob": "1990-01-01",
        },
        "case_ref_id": "CASE-001",
    }
    result = redact_phi(event)
    assert result["patient"]["first_name"] == "[REDACTED]"
    assert result["patient"]["dob"]        == "[REDACTED]"
    assert result["case_ref_id"]           == "CASE-001"


def test_password_redacted():
    event = {"password": "SuperSecret123!", "username": "admin"}
    result = redact_phi(event)
    assert result["password"] == "[REDACTED]"
    assert result["username"] == "[REDACTED]"
```

---

*Document Status: DRAFT*
*Previous: [06_CICD_and_Deployment_Guide.md](06_CICD_and_Deployment_Guide.md)*
*Next: [08_API_Server_Implementation.md](08_API_Server_Implementation.md)*
