# AutoAuth Agent — API Server Implementation
**Phase 3 | Sprint 1 | Weeks 7–8**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0
**Prerequisite:** [07_Common_Library_Implementation.md](07_Common_Library_Implementation.md)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Project Structure](#2-project-structure)
3. [pyproject.toml](#3-pyprojecttoml)
4. [Configuration & Settings](#4-configuration--settings)
5. [Application Entry Point & Lifespan](#5-application-entry-point--lifespan)
6. [Middleware Stack](#6-middleware-stack)
7. [Authentication — JWT](#7-authentication--jwt)
8. [Routers](#8-routers)
9. [Services Layer](#9-services-layer)
10. [Background Tasks at Startup](#10-background-tasks-at-startup)
11. [Error Handling](#11-error-handling)
12. [Unit Tests](#12-unit-tests)

---

## 1. Overview

`api-server` is the external-facing FastAPI service. It is the only service exposed to the internet (via GKE Ingress). All other services communicate internally within the cluster.

**Responsibilities:**
- JWT authentication for dashboard users
- Batch ingestion endpoint (`POST /agentic-platform/prior-auths`) — validates, persists, publishes to Pub/Sub
- Case management (read, cancel, status)
- Recipe management (CRUD for portal YAML recipes)
- Portal credential management (CRUD referencing Secret Manager paths)
- Dashboard APIs (run volume, LLM cost, case stats)
- HITL task listing
- Server-Sent Events (SSE) for real-time alerts
- Health endpoint

**Does NOT do:**
- Browser automation (browser-agent)
- Pub/Sub consumption (planner)
- Worker pool management (control-plane)

---

## 2. Project Structure

```
api-server/
├── pyproject.toml
├── Dockerfile
└── src/
    ├── main.py                     # FastAPI app, lifespan
    ├── config.py                   # Pydantic Settings
    ├── dependencies.py             # FastAPI DI: get_db, get_current_user
    ├── middleware/
    │   ├── __init__.py
    │   ├── trace.py                # Trace ID injection middleware
    │   ├── cors.py                 # CORS settings
    │   └── request_logging.py     # Log every request/response
    ├── auth/
    │   ├── __init__.py
    │   ├── jwt_handler.py          # Token creation & verification
    │   ├── password.py             # bcrypt hash/verify
    │   └── router.py               # /auth/register, /auth/login
    ├── routers/
    │   ├── __init__.py
    │   ├── prior_auth.py           # Batch ingest + case management
    │   ├── recipes.py              # Recipe CRUD
    │   ├── portal_secrets.py       # Credential management
    │   ├── dashboard.py            # Analytics endpoints
    │   ├── hitl.py                 # HITL task listing
    │   ├── alerts.py               # SSE alert stream
    │   └── health.py               # /health
    ├── services/
    │   ├── __init__.py
    │   ├── case_service.py         # Business logic for case operations
    │   ├── batch_service.py        # Batch validation + creation
    │   ├── recipe_service.py       # Recipe fetch + store
    │   ├── credential_service.py   # Secret Manager CRUD wrapper
    │   └── dashboard_service.py    # Analytics queries
    └── schemas/
        ├── __init__.py
        ├── auth.py                 # RegisterRequest, LoginResponse, TokenData
        ├── prior_auth.py           # BatchIngestRequest, CaseResponse, etc.
        ├── recipe.py               # RecipeUpsertRequest, RecipeResponse
        ├── dashboard.py            # RunVolumeResponse, LLMCostResponse
        └── common.py               # PaginationMeta, ErrorResponse
```

---

## 3. pyproject.toml

```toml
[project]
name = "autoauth-api-server"
version = "1.0.0"
requires-python = ">=3.12"
dependencies = [
    "autoauth-common",              # Local common library
    "fastapi>=0.115.0",
    "uvicorn[standard]>=0.30.0",
    "pydantic>=2.8.2",
    "pydantic-settings>=2.4.0",
    "python-jose[cryptography]>=3.3.0",  # JWT
    "bcrypt>=4.2.0",
    "httpx>=0.27.0",                # Async HTTP client for inter-service calls
    "sse-starlette>=2.1.0",         # SSE support
]

[project.optional-dependencies]
prod = ["uvloop>=0.20.0", "httptools>=0.6.0"]
test = ["pytest>=8.3", "pytest-asyncio>=0.23", "httpx>=0.27.0",
        "pytest-mock>=3.14", "fakeredis>=2.24"]
```

---

## 4. Configuration & Settings

```python
# api-server/src/config.py
import os
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    # App
    app_env:      str = Field("prod", env="APP_ENV")
    service_name: str = Field("api-server", env="SERVICE_NAME")
    log_level:    str = Field("INFO", env="LOG_LEVEL")

    # Database (read from environment — values come from Secret Manager via CSI)
    db_host:     str = Field(..., env="DB_HOST")
    db_port:     int = Field(5432, env="DB_PORT")
    db_user:     str = Field(..., env="DB_USER")
    db_password: str = Field(..., env="DB_PASSWORD")
    db_name:     str = Field(..., env="DB_NAME")

    # Redis
    redis_host: str = Field(..., env="REDIS_HOST")
    redis_port: int = Field(6379, env="REDIS_PORT")
    redis_auth: str = Field("", env="REDIS_AUTH")
    redis_tls:  bool = Field(False, env="REDIS_TLS")

    # JWT
    jwt_secret_key:      str = Field(..., env="JWT_SECRET_KEY")
    jwt_algorithm:       str = Field("HS256", env="JWT_ALGORITHM")
    jwt_expire_minutes:  int = Field(60, env="JWT_EXPIRE_MINUTES")

    # GCP
    gcp_project_id:              str = Field(..., env="GCP_PROJECT_ID")
    prior_auth_submission_topic: str = Field(
        "prior-auth-submission-topic", env="PRIOR_AUTH_SUBMISSION_TOPIC")

    # CORS
    cors_origins: list[str] = Field(
        ["https://app.autoauth.ikshealth.com"],
        env="CORS_ORIGINS")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
```

---

## 5. Application Entry Point & Lifespan

```python
# api-server/src/main.py
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from common.logs.logger import configure_logging, get_logger
from common.db_layer.db_config import get_engine
from common.redis_layer.redis_config import get_redis_client

from config import get_settings
from middleware.trace import TraceMiddleware
from middleware.request_logging import RequestLoggingMiddleware
from routers import prior_auth, recipes, portal_secrets, dashboard, hitl, alerts, health
from auth.router import router as auth_router

os.environ.setdefault("SERVICE_NAME", "api-server")
configure_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Startup: verify all external connections.
    Shutdown: close connections gracefully.
    """
    settings = get_settings()
    logger.info("api_server_starting", env=settings.app_env)

    # Verify DB connection
    engine = get_engine()
    with engine.connect() as conn:
        conn.execute("SELECT 1")
    logger.info("db_connection_ok")

    # Verify Redis connection
    get_redis_client().ping()
    logger.info("redis_connection_ok")

    logger.info("api_server_ready")
    yield

    # Shutdown
    engine.dispose()
    logger.info("api_server_shutdown")


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="AutoAuth Agent — API Server",
        version="1.0.0",
        docs_url="/docs" if settings.app_env != "prod" else None,
        redoc_url=None,
        openapi_url="/openapi.json" if settings.app_env != "prod" else None,
        lifespan=lifespan,
    )

    # Middleware (order matters — outermost first)
    app.add_middleware(TraceMiddleware)
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["Authorization", "Content-Type", "X-Trace-Id"],
    )

    # Routers
    app.include_router(auth_router,      prefix="/api/v1")
    app.include_router(prior_auth.router, prefix="/api/v1")
    app.include_router(recipes.router,    prefix="/api/v1")
    app.include_router(portal_secrets.router, prefix="/api/v1")
    app.include_router(dashboard.router,  prefix="/api/v1")
    app.include_router(hitl.router,       prefix="/api/v1")
    app.include_router(alerts.router,     prefix="/api/v1")
    app.include_router(health.router)

    return app


app = create_app()
```

---

## 6. Middleware Stack

```python
# api-server/src/middleware/trace.py
import uuid
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from common.logs.trace_context import set_trace_id, get_trace_id


class TraceMiddleware(BaseHTTPMiddleware):
    """Inject trace ID from header or generate one. Attach to all logs in context."""

    async def dispatch(self, request: Request, call_next):
        trace_id = request.headers.get("X-Trace-Id") or str(uuid.uuid4())[:16]
        set_trace_id(trace_id)
        response = await call_next(request)
        response.headers["X-Trace-Id"] = get_trace_id()
        return response
```

```python
# api-server/src/middleware/request_logging.py
import time
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from common.logs.logger import get_logger

logger = get_logger("request")

# Skip logging for noisy health check endpoints
SKIP_PATHS = {"/health", "/metrics"}


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path in SKIP_PATHS:
            return await call_next(request)

        start = time.monotonic()
        response = await call_next(request)
        duration_ms = round((time.monotonic() - start) * 1000)

        logger.info(
            "http_request",
            method=request.method,
            path=request.url.path,
            status_code=response.status_code,
            duration_ms=duration_ms,
            client_ip=request.client.host if request.client else None,
        )
        return response
```

---

## 7. Authentication — JWT

### 7.1 jwt_handler.py

```python
# api-server/src/auth/jwt_handler.py
from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from config import get_settings
from common.logs.logger import get_logger

logger = get_logger(__name__)

TOKEN_TYPE = "Bearer"


def create_access_token(user_id: str, email: str, role: str) -> str:
    settings = get_settings()
    now      = datetime.now(timezone.utc)
    payload  = {
        "sub":   user_id,
        "email": email,
        "role":  role,
        "iat":   now,
        "exp":   now + timedelta(minutes=settings.jwt_expire_minutes),
        "type":  "access",
    }
    return jwt.encode(payload, settings.jwt_secret_key,
                      algorithm=settings.jwt_algorithm)


def decode_access_token(token: str) -> dict:
    settings = get_settings()
    try:
        payload = jwt.decode(token, settings.jwt_secret_key,
                             algorithms=[settings.jwt_algorithm])
        if payload.get("type") != "access":
            raise JWTError("Invalid token type")
        return payload
    except JWTError as e:
        logger.warning("jwt_decode_failed", error=str(e))
        raise
```

---

### 7.2 auth/router.py

```python
# api-server/src/auth/router.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from common.db_layer.orm_models import AgenticPlatformUser
from dependencies import get_db
from auth.jwt_handler import create_access_token
from auth.password import hash_password, verify_password
from schemas.auth import RegisterRequest, LoginRequest, TokenResponse
from common.logs.logger import get_logger
from datetime import datetime, timezone

logger = get_logger(__name__)
router = APIRouter(tags=["Authentication"])


@router.post("/auth/register", response_model=TokenResponse, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(AgenticPlatformUser).filter_by(
        email=payload.email.lower()).first()
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")

    user = AgenticPlatformUser(
        email=payload.email.lower(),
        hashed_password=hash_password(payload.password),
        full_name=payload.full_name,
        role="VIEWER",           # New users get minimum role; admin elevates manually
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = create_access_token(
        user_id=str(user.id),
        email=user.email,
        role=user.role,
    )
    logger.info("user_registered", email=user.email, role=user.role)
    return TokenResponse(access_token=token, token_type="Bearer",
                         expires_in=3600, role=user.role)


@router.post("/auth/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(AgenticPlatformUser).filter_by(
        email=payload.email.lower()).first()

    # Account lockout check
    if user and user.locked_until and user.locked_until > datetime.now(timezone.utc):
        raise HTTPException(status_code=423,
                            detail="Account temporarily locked. Try again later.")

    if not user or not verify_password(payload.password, user.hashed_password):
        # Increment failure counter
        if user:
            user.failed_login_count += 1
            if user.failed_login_count >= 5:
                from datetime import timedelta
                user.locked_until = datetime.now(timezone.utc) + timedelta(minutes=15)
            db.commit()
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is disabled")

    # Reset failure counter on success
    user.failed_login_count = 0
    user.locked_until       = None
    user.last_login_at      = datetime.now(timezone.utc)
    db.commit()

    token = create_access_token(
        user_id=str(user.id),
        email=user.email,
        role=user.role,
    )
    logger.info("user_login", email=user.email)
    return TokenResponse(access_token=token, token_type="Bearer",
                         expires_in=3600, role=user.role)
```

---

### 7.3 dependencies.py

```python
# api-server/src/dependencies.py
from typing import Annotated
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError
from sqlalchemy.orm import Session

from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import AgenticPlatformUser
from auth.jwt_handler import decode_access_token

security = HTTPBearer()


def get_db() -> Session:
    """FastAPI dependency: yields a DB session, closes after request."""
    factory = get_session_factory()
    session = factory()
    try:
        yield session
    finally:
        session.close()


def get_current_user(
    credentials: Annotated[HTTPAuthorizationCredentials, Depends(security)],
    db:          Session = Depends(get_db),
) -> AgenticPlatformUser:
    """FastAPI dependency: decodes JWT, returns current user."""
    try:
        payload = decode_access_token(credentials.credentials)
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = db.query(AgenticPlatformUser).filter_by(
        id=payload["sub"]).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User not found or inactive")
    return user


def require_role(*roles: str):
    """Dependency factory: ensures user has one of the required roles."""
    def _check(user: AgenticPlatformUser = Depends(get_current_user)):
        if user.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires role: {' or '.join(roles)}")
        return user
    return _check
```

---

## 8. Routers

### 8.1 prior_auth.py — Batch Ingest + Case Management

```python
# api-server/src/routers/prior_auth.py
import uuid
from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from common.db_layer.orm_models import AgenticPlatformUser
from dependencies import get_db, get_current_user
from services.batch_service import BatchService
from services.case_service import CaseService
from schemas.prior_auth import (
    BatchIngestRequest, BatchIngestResponse,
    CaseListResponse, CaseDetailResponse, CasePatchRequest,
)
from common.logs.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(tags=["Prior Authorization"])


@router.post(
    "/agentic-platform/prior-auths",
    response_model=BatchIngestResponse,
    status_code=202,
    summary="Ingest a batch of PA cases",
)
def ingest_batch(
    payload: BatchIngestRequest,
    db:      Session = Depends(get_db),
    user:    AgenticPlatformUser = Depends(get_current_user),
):
    """
    Accepts a batch of PA cases. Each case is validated, persisted,
    and published to Pub/Sub for async processing.
    Idempotent: duplicate case_ref_id is accepted (returns 202) but not reprocessed.
    """
    service  = BatchService(db)
    response = service.ingest_batch(payload, submitted_by=user.id)
    logger.info("batch_ingested", batch_id=payload.batch_id,
                total=payload.total_cases, accepted=response.accepted_count)
    return response


@router.get(
    "/prior-auths/requests",
    response_model=CaseListResponse,
    summary="List PA cases with filters",
)
def list_cases(
    db:        Session = Depends(get_db),
    user:      AgenticPlatformUser = Depends(get_current_user),
    status:    str | None = Query(None),
    portal_id: str | None = Query(None),
    batch_id:  str | None = Query(None),
    page:      int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    service = CaseService(db)
    return service.list_cases(
        status=status, portal_id=portal_id, batch_id=batch_id,
        page=page, page_size=page_size,
    )


@router.get(
    "/prior-auths/{case_ref_id}",
    response_model=CaseDetailResponse,
    summary="Get a specific PA case",
)
def get_case(
    case_ref_id: str,
    db:          Session = Depends(get_db),
    user:        AgenticPlatformUser = Depends(get_current_user),
):
    service = CaseService(db)
    case    = service.get_case(case_ref_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return case


@router.patch(
    "/prior-auths/{case_ref_id}",
    response_model=CaseDetailResponse,
    summary="Update case fields (admin only)",
)
def patch_case(
    case_ref_id: str,
    payload:     CasePatchRequest,
    db:          Session = Depends(get_db),
    user:        Annotated[AgenticPlatformUser,
                           Depends(require_role("ADMIN", "OPERATOR"))] = None,
):
    from dependencies import require_role
    service = CaseService(db)
    return service.patch_case(case_ref_id, payload)


@router.post(
    "/prior-auths/{case_ref_id}/cancel",
    status_code=200,
    summary="Cancel a pending case",
)
def cancel_case(
    case_ref_id: str,
    db:          Session = Depends(get_db),
    user:        Annotated[AgenticPlatformUser,
                           Depends(require_role("ADMIN", "OPERATOR"))] = None,
):
    from dependencies import require_role
    service = CaseService(db)
    service.cancel_case(case_ref_id)
    return {"message": f"Case {case_ref_id} cancelled"}
```

---

### 8.2 recipes.py

```python
# api-server/src/routers/recipes.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from dependencies import get_db, get_current_user, require_role
from common.db_layer.orm_models import AgenticPlatformUser
from services.recipe_service import RecipeService
from schemas.recipe import RecipeUpsertRequest, RecipeResponse

router = APIRouter(tags=["Recipes"])


@router.get("/recipes/{portal_id}", response_model=RecipeResponse,
            summary="Get active recipe for a portal")
def get_recipe(portal_id: str, db: Session = Depends(get_db)):
    """
    Called by browser-agent at session start to fetch portal recipe.
    No auth required — internal cluster call.
    Falls back to bundled YAML file if no DB recipe exists.
    """
    service = RecipeService(db)
    recipe  = service.get_active_recipe(portal_id)
    if not recipe:
        raise HTTPException(status_code=404,
                            detail=f"No recipe found for portal: {portal_id}")
    return recipe


@router.put("/recipes/{portal_id}", response_model=RecipeResponse,
            summary="Upload or update a portal recipe")
def upsert_recipe(
    portal_id: str,
    payload:   RecipeUpsertRequest,
    db:        Session = Depends(get_db),
    user:      AgenticPlatformUser = Depends(require_role("ADMIN", "OPERATOR")),
):
    """Validates YAML schema before saving. Deactivates previous active recipe."""
    service = RecipeService(db)
    return service.upsert_recipe(portal_id, payload, deployed_by=user.email)
```

---

### 8.3 alerts.py — SSE

```python
# api-server/src/routers/alerts.py
import asyncio
import json
from fastapi import APIRouter, Depends
from sse_starlette.sse import EventSourceResponse
from sqlalchemy.orm import Session

from dependencies import get_db, get_current_user
from common.db_layer.orm_models import AgenticPlatformUser, AgenticPlatformAlert
from common.logs.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(tags=["Alerts"])

# In-memory queue per connected client
# Production: use Redis Pub/Sub for multi-replica support
_alert_queues: list[asyncio.Queue] = []


@router.get("/alert-sse", summary="SSE stream for real-time dashboard alerts")
async def alert_sse(
    db:   Session = Depends(get_db),
    user: AgenticPlatformUser = Depends(get_current_user),
):
    """
    Server-Sent Events stream. Dashboard connects once and receives push alerts.
    Events: case_status_change, hitl_required, case_completed, pod_crash, heartbeat
    """
    queue: asyncio.Queue = asyncio.Queue()
    _alert_queues.append(queue)

    async def event_generator():
        try:
            # Send heartbeat every 30s to keep connection alive
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30)
                    yield {"event": event["type"], "data": json.dumps(event["data"])}
                except asyncio.TimeoutError:
                    yield {"event": "heartbeat", "data": json.dumps({"ts": "now"})}
        except asyncio.CancelledError:
            pass
        finally:
            _alert_queues.remove(queue)

    return EventSourceResponse(event_generator())


async def broadcast_alert(alert_type: str, data: dict) -> None:
    """
    Called by services to push alerts to all connected SSE clients.
    In multi-replica setups: replace with Redis Pub/Sub broadcast.
    """
    event = {"type": alert_type, "data": data}
    for queue in _alert_queues:
        try:
            queue.put_nowait(event)
        except asyncio.QueueFull:
            pass
    logger.info("alert_broadcast", alert_type=alert_type,
                clients=len(_alert_queues))
```

---

### 8.4 dashboard.py

```python
# api-server/src/routers/dashboard.py
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from datetime import date

from dependencies import get_db, get_current_user
from services.dashboard_service import DashboardService
from schemas.dashboard import RunVolumeResponse, LLMCostResponse, CaseStatsResponse

router = APIRouter(tags=["Dashboard"])


@router.get("/dashboard/run-volume", response_model=list[RunVolumeResponse])
def get_run_volume(
    db:         Session = Depends(get_db),
    _user=Depends(get_current_user),
    date_from:  date = Query(..., description="Start date (YYYY-MM-DD)"),
    date_to:    date = Query(..., description="End date (YYYY-MM-DD)"),
    portal_id:  str | None = Query(None),
    group_by:   str = Query("day", pattern="^(hour|day|week)$"),
):
    return DashboardService(db).get_run_volume(date_from, date_to, portal_id, group_by)


@router.get("/dashboard/llm-cost", response_model=LLMCostResponse)
def get_llm_cost(
    db:         Session = Depends(get_db),
    _user=Depends(get_current_user),
    date_from:  date = Query(...),
    date_to:    date = Query(...),
    portal_id:  str | None = Query(None),
):
    return DashboardService(db).get_llm_cost(date_from, date_to, portal_id)


@router.get("/dashboard/case-stats", response_model=CaseStatsResponse)
def get_case_stats(
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    """Real-time counts: pending, in_progress, hitl_wait, submitted today, etc."""
    return DashboardService(db).get_case_stats()
```

---

### 8.5 health.py

```python
# api-server/src/routers/health.py
from fastapi import APIRouter
from sqlalchemy import text
from common.db_layer.db_config import get_engine
from common.redis_layer.redis_config import get_redis_client

router = APIRouter(tags=["Health"])


@router.get("/health", include_in_schema=False)
def health_check():
    """
    Readiness + liveness check.
    Returns 200 only if DB and Redis are reachable.
    """
    checks = {}

    try:
        with get_engine().connect() as conn:
            conn.execute(text("SELECT 1"))
        checks["db"] = "ok"
    except Exception as e:
        checks["db"] = f"error: {str(e)[:50]}"

    try:
        get_redis_client().ping()
        checks["redis"] = "ok"
    except Exception as e:
        checks["redis"] = f"error: {str(e)[:50]}"

    all_ok = all(v == "ok" for v in checks.values())
    return {"status": "ok" if all_ok else "degraded", "checks": checks}
```

---

## 9. Services Layer

### 9.1 batch_service.py

```python
# api-server/src/services/batch_service.py
import uuid
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from common.db_layer.orm_models import (
    PriorAuthBatchRequest, PriorAuthCaseRequest, PriorAuthPortal, PriorAuthPayer
)
from common.pubsub_layer.publisher import publish_case_to_submission_queue
from schemas.prior_auth import BatchIngestRequest, BatchIngestResponse, CaseResult
from common.logs.logger import get_logger

logger = get_logger(__name__)


class BatchService:
    def __init__(self, db: Session):
        self._db = db

    def ingest_batch(
        self,
        payload: BatchIngestRequest,
        submitted_by: uuid.UUID,
    ) -> BatchIngestResponse:
        # 1. Resolve portal + payer
        portal = self._db.query(PriorAuthPortal).filter_by(
            portal_id=payload.portal_id, is_active=True).first()
        if not portal:
            raise ValueError(f"Portal not found or inactive: {payload.portal_id}")

        # 2. Create or fetch batch record (idempotent on batch_id)
        batch = self._db.query(PriorAuthBatchRequest).filter_by(
            batch_id=payload.batch_id).first()
        if not batch:
            batch = PriorAuthBatchRequest(
                batch_id=payload.batch_id,
                portal_id=portal.id,
                payer_id=portal.payer_id,
                submitted_by=submitted_by,
                total_cases=len(payload.cases),
                status="PENDING",
                priority=payload.priority or "NORMAL",
            )
            self._db.add(batch)
            self._db.flush()

        # 3. Process each case
        accepted, rejected = 0, 0
        case_results: list[CaseResult] = []

        for case_payload in payload.cases:
            result = self._ingest_case(case_payload, batch, portal)
            case_results.append(result)
            if result.accepted:
                accepted += 1
            else:
                rejected += 1

        batch.accepted_cases = accepted
        batch.rejected_cases = rejected
        if accepted > 0:
            batch.status = "IN_PROGRESS"
        self._db.commit()

        logger.info("batch_processed", batch_id=payload.batch_id,
                    accepted=accepted, rejected=rejected)

        return BatchIngestResponse(
            batch_id=payload.batch_id,
            accepted_count=accepted,
            rejected_count=rejected,
            cases=case_results,
        )

    def _ingest_case(self, case_payload, batch, portal) -> "CaseResult":
        from schemas.prior_auth import CaseResult

        # Check for duplicate
        existing = self._db.query(PriorAuthCaseRequest).filter_by(
            case_ref_id=case_payload.case_ref_id).first()
        if existing:
            logger.info("case_duplicate_skipped",
                        case_ref_id=case_payload.case_ref_id,
                        existing_status=existing.status)
            return CaseResult(
                case_ref_id=case_payload.case_ref_id,
                accepted=True,
                message="Already exists — not reprocessed",
                status=existing.status,
            )

        # Validate required patient fields
        required_patient = ["member_id", "first_name", "last_name", "date_of_birth"]
        missing = [f for f in required_patient if not case_payload.patient_data.get(f)]
        if missing:
            return CaseResult(
                case_ref_id=case_payload.case_ref_id,
                accepted=False,
                message=f"Missing required patient fields: {missing}",
            )

        # Persist case
        case = PriorAuthCaseRequest(
            case_ref_id=case_payload.case_ref_id,
            batch_id=batch.id,
            portal_id=portal.id,
            payer_id=portal.payer_id,
            patient_data=case_payload.patient_data,
            clinical_data=case_payload.clinical_data,
            status="PENDING",
            max_retries=case_payload.max_retries or 3,
        )
        self._db.add(case)
        self._db.flush()

        # Publish to Pub/Sub (triggers planner)
        try:
            publish_case_to_submission_queue(
                case_ref_id=case_payload.case_ref_id,
                portal_id=portal.portal_id,
                batch_id=batch.batch_id,
                priority=batch.priority,
            )
        except Exception as e:
            logger.error("pubsub_publish_failed",
                         case_ref_id=case_payload.case_ref_id, error=str(e))
            # Case is persisted — planner can pick it up via retry mechanism
            case.last_error = f"Pub/Sub publish failed: {str(e)}"

        return CaseResult(
            case_ref_id=case_payload.case_ref_id,
            accepted=True,
            message="Accepted for processing",
            status="PENDING",
        )
```

---

### 9.2 case_service.py

```python
# api-server/src/services/case_service.py
import uuid
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from sqlalchemy import select, func

from common.db_layer.orm_models import (
    PriorAuthCaseRequest, PriorAuthPortal, PriorAuthAgentSession, PriorAuthHitlTask
)
from schemas.prior_auth import (
    CaseDetailResponse, CaseListResponse, CasePatchRequest, PaginationMeta
)
from common.logs.logger import get_logger

logger = get_logger(__name__)


class CaseService:
    def __init__(self, db: Session):
        self._db = db

    def get_case(self, case_ref_id: str) -> CaseDetailResponse | None:
        case = self._db.query(PriorAuthCaseRequest).filter_by(
            case_ref_id=case_ref_id).first()
        if not case:
            return None

        # Enrich with session info (VNC URL)
        session = self._db.query(PriorAuthAgentSession).filter(
            PriorAuthAgentSession.case_ref_id == case_ref_id,
            PriorAuthAgentSession.status.in_(
                ["ACTIVE", "RUNNING", "HITL_WAIT", "MFA_WAIT"])).first()

        # Active HITL task
        hitl = self._db.query(PriorAuthHitlTask).filter(
            PriorAuthHitlTask.case_ref_id == case_ref_id,
            PriorAuthHitlTask.status == "PENDING").first()

        return CaseDetailResponse(
            case_ref_id=case.case_ref_id,
            status=case.status,
            outcome=case.outcome,
            pa_reference_number=case.pa_reference_number,
            retry_count=case.retry_count,
            last_error=case.last_error,
            created_at=case.created_at,
            updated_at=case.updated_at,
            started_at=case.started_at,
            submitted_at=case.submitted_at,
            vnc_url=session.vnc_url if session else None,
            hitl_task_type=hitl.task_type if hitl else None,
            hitl_message=hitl.message if hitl else None,
        )

    def list_cases(
        self,
        status:    str | None,
        portal_id: str | None,
        batch_id:  str | None,
        page:      int,
        page_size: int,
    ) -> CaseListResponse:
        query = self._db.query(PriorAuthCaseRequest)

        if status:
            query = query.filter(PriorAuthCaseRequest.status == status)
        if portal_id:
            portal = self._db.query(PriorAuthPortal).filter_by(
                portal_id=portal_id).first()
            if portal:
                query = query.filter(PriorAuthCaseRequest.portal_id == portal.id)
        if batch_id:
            query = query.filter(PriorAuthCaseRequest.batch_id.in_(
                self._db.query(
                    PriorAuthCaseRequest.batch_id
                ).filter_by(batch_id=batch_id).scalar_subquery()
            ))

        total   = query.count()
        offset  = (page - 1) * page_size
        cases   = query.order_by(
            PriorAuthCaseRequest.updated_at.desc()
        ).offset(offset).limit(page_size).all()

        return CaseListResponse(
            items=[self.get_case(c.case_ref_id) for c in cases],
            pagination=PaginationMeta(
                total=total, page=page, page_size=page_size,
                total_pages=(total + page_size - 1) // page_size,
            ),
        )

    def cancel_case(self, case_ref_id: str) -> None:
        case = self._db.query(PriorAuthCaseRequest).filter_by(
            case_ref_id=case_ref_id).first()
        if not case:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail="Case not found")
        if case.status in ("APPROVED", "DENIED", "FAILED", "CANCELLED"):
            from fastapi import HTTPException
            raise HTTPException(status_code=409,
                                detail=f"Cannot cancel case in status: {case.status}")

        case.previous_status  = case.status
        case.status           = "CANCELLED"
        case.status_changed_at = datetime.now(timezone.utc)
        self._db.commit()
        logger.info("case_cancelled", case_ref_id=case_ref_id)

    def patch_case(self, case_ref_id: str, payload: CasePatchRequest) -> CaseDetailResponse:
        case = self._db.query(PriorAuthCaseRequest).filter_by(
            case_ref_id=case_ref_id).first()
        if not case:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail="Case not found")

        for field, value in payload.model_dump(exclude_none=True).items():
            setattr(case, field, value)
        self._db.commit()
        return self.get_case(case_ref_id)
```

---

## 10. Background Tasks at Startup

```python
# api-server/src/services/credential_service.py
"""
At startup, loads all portal credentials from DB + Secret Manager
into the Redis credential pool so browser-agent can acquire them.
"""
import os
from sqlalchemy.orm import Session
from common.db_layer.orm_models import PriorAuthPortalCredential
from common.redis_layer.credential_pool import credential_pool
from common.secret.secret_manager import get_portal_credentials_by_path
from common.logs.logger import get_logger

logger = get_logger(__name__)


class CredentialService:

    def __init__(self, db: Session):
        self._db = db

    def initialize_credential_pool(self) -> None:
        """
        Called at api-server startup.
        Reads all active credentials from DB and adds them to Redis pool.
        Does NOT fetch the actual secret values — only credential IDs.
        Secret values fetched lazily by browser-agent from Secret Manager.
        """
        credentials = self._db.query(PriorAuthPortalCredential).filter_by(
            is_active=True).order_by(PriorAuthPortalCredential.priority).all()

        for cred in credentials:
            portal_id = str(cred.portal_id)
            credential_pool.add_credential(portal_id, str(cred.id))

        logger.info("credential_pool_initialized", count=len(credentials))

    def get_credential_secrets(self, credential_id: str) -> tuple[str, str]:
        """
        Fetch actual credential values from Secret Manager.
        Called by browser-agent at session start, not at pool init time.
        """
        cred = self._db.query(PriorAuthPortalCredential).get(credential_id)
        if not cred:
            raise ValueError(f"Credential not found: {credential_id}")
        return get_portal_credentials_by_path(
            cred.username_secret_path, cred.password_secret_path
        )
```

---

## 11. Error Handling

```python
# api-server/src/main.py  (add to create_app())
from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from pydantic import ValidationError

def _add_exception_handlers(app: FastAPI):

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(request: Request, exc: RequestValidationError):
        return JSONResponse(
            status_code=422,
            content={
                "error": {
                    "code": "VALIDATION_ERROR",
                    "message": "Request validation failed",
                    "details": exc.errors(),
                }
            },
        )

    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError):
        return JSONResponse(
            status_code=400,
            content={"error": {"code": "BAD_REQUEST", "message": str(exc)}},
        )

    @app.exception_handler(Exception)
    async def generic_error_handler(request: Request, exc: Exception):
        logger.error("unhandled_exception", path=request.url.path,
                     error=str(exc), exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"error": {"code": "INTERNAL_ERROR",
                               "message": "An internal error occurred"}},
        )
```

---

## 12. Unit Tests

```python
# api-server/tests/test_batch_service.py
import uuid
import pytest
from unittest.mock import MagicMock, patch
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from common.db_layer.orm_models import Base, PriorAuthPortal, PriorAuthPayer
from services.batch_service import BatchService
from schemas.prior_auth import BatchIngestRequest, CaseIngestPayload


@pytest.fixture
def db_session():
    engine  = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine)
    session = factory()

    # Seed portal + payer
    payer  = PriorAuthPayer(payer_name="Test Payer", payer_code="TEST")
    portal = PriorAuthPortal(payer_id=payer.id, portal_name="Test Portal",
                              portal_id="test-portal", is_active=True)
    session.add_all([payer, portal])
    session.commit()
    yield session
    session.close()


@pytest.fixture
def batch_service(db_session):
    return BatchService(db_session)


def test_ingest_batch_creates_cases(batch_service):
    payload = BatchIngestRequest(
        batch_id="BATCH-001",
        portal_id="test-portal",
        cases=[
            CaseIngestPayload(
                case_ref_id="CASE-001",
                patient_data={
                    "member_id": "M001", "first_name": "John",
                    "last_name": "Doe", "date_of_birth": "1990-01-01",
                },
                clinical_data={"procedure_codes": ["27447"]},
            )
        ],
    )

    with patch("services.batch_service.publish_case_to_submission_queue",
               return_value="msg-001"):
        response = batch_service.ingest_batch(payload, submitted_by=uuid.uuid4())

    assert response.accepted_count == 1
    assert response.rejected_count == 0


def test_duplicate_case_not_reprocessed(batch_service):
    payload = BatchIngestRequest(
        batch_id="BATCH-002",
        portal_id="test-portal",
        cases=[
            CaseIngestPayload(
                case_ref_id="CASE-DUP",
                patient_data={
                    "member_id": "M002", "first_name": "Jane",
                    "last_name": "Smith", "date_of_birth": "1985-06-15",
                },
                clinical_data={"procedure_codes": ["99213"]},
            )
        ],
    )

    with patch("services.batch_service.publish_case_to_submission_queue",
               return_value="msg-002"):
        # First ingest
        batch_service.ingest_batch(payload, submitted_by=uuid.uuid4())
        # Second ingest — same case_ref_id
        response = batch_service.ingest_batch(payload, submitted_by=uuid.uuid4())

    assert response.accepted_count == 1
    assert "Already exists" in response.cases[0].message


def test_missing_patient_fields_rejected(batch_service):
    payload = BatchIngestRequest(
        batch_id="BATCH-003",
        portal_id="test-portal",
        cases=[
            CaseIngestPayload(
                case_ref_id="CASE-BAD",
                patient_data={"member_id": "M003"},    # Missing first_name, etc.
                clinical_data={"procedure_codes": ["27447"]},
            )
        ],
    )

    with patch("services.batch_service.publish_case_to_submission_queue"):
        response = batch_service.ingest_batch(payload, submitted_by=uuid.uuid4())

    assert response.rejected_count == 1
    assert not response.cases[0].accepted
```

---

*Document Status: DRAFT*
*Previous: [07_Common_Library_Implementation.md](07_Common_Library_Implementation.md)*
*Next: [09_Planner_Implementation.md](09_Planner_Implementation.md)*
