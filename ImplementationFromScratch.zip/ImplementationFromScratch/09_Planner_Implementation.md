# AutoAuth Agent — Planner Service Implementation
**Phase 3 | Sprint 2 | Weeks 9–10**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0
**Prerequisite:** [08_API_Server_Implementation.md](08_API_Server_Implementation.md)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Project Structure](#2-project-structure)
3. [Configuration & Settings](#3-configuration--settings)
4. [Application Entry Point & Lifespan](#4-application-entry-point--lifespan)
5. [PlannerConsumer — Pub/Sub Message Handling](#5-plannerconsumer--pubsub-message-handling)
6. [Deduplication — InMemoryCache](#6-deduplication--inmemorycache)
7. [ONE_SESSION_PER_BATCH Logic](#7-one_session_per_batch-logic)
8. [N8N Webhook Trigger](#8-n8n-webhook-trigger)
9. [Planner API Endpoints](#9-planner-api-endpoints)
10. [MFA Handler](#10-mfa-handler)
11. [SSE Log Streaming](#11-sse-log-streaming)
12. [Unit Tests](#12-unit-tests)

---

## 1. Overview

The **planner** is an internal service (not publicly accessible) that sits between the api-server Pub/Sub publish and the N8N workflow execution. It is the decision-making layer before any browser session is created.

```
api-server
    │ publish (case_ref_id, portal_id, batch_id)
    ▼
Pub/Sub Topic #1 (prior-auth-submission-topic)
    │ pull
    ▼
planner (PlannerConsumer)
    │
    ├─► Deduplication check (InMemoryCache TTL)
    │       └─ Duplicate → ack + skip
    │
    ├─► ONE_SESSION_PER_BATCH check
    │       └─ First case in batch → create shared login session
    │       └─ Subsequent cases → wait for session to be ready
    │
    ├─► Update case status → PLANNING
    │
    ├─► Build N8N payload (case data + credentials + session info)
    │
    └─► POST N8N webhook (prior_auth_submission_webhook_url)
            │
            ▼
        N8N triggers control-plane → browser-agent → recipe/LLM execution
```

**Responsibilities:**
- Consume Pub/Sub Topic #1 messages
- Deduplicate messages (same case_ref_id published twice)
- Implement ONE_SESSION_PER_BATCH (reuse browser login session across batch cases)
- Trigger N8N workflow for each case
- Handle MFA OTP delivery (receives OTP from ADK chatbot, forwards to browser-agent)
- Expose SSE endpoint for real-time case log streaming (reads Redis Stream)
- Expose retrigger endpoint for manual or crash-recovery re-processing

---

## 2. Project Structure

```
planner/
├── pyproject.toml
├── Dockerfile
└── src/
    ├── main.py                       # FastAPI app, lifespan, consumer thread
    ├── config.py                     # Settings
    ├── consumer/
    │   ├── __init__.py
    │   ├── planner_consumer.py       # PlannerConsumer (BaseConsumer subclass)
    │   └── dedup_cache.py            # InMemoryCache with TTL
    ├── services/
    │   ├── __init__.py
    │   ├── n8n_trigger.py            # N8N webhook client
    │   ├── one_session_manager.py    # ONE_SESSION_PER_BATCH coordinator
    │   ├── case_updater.py           # Thin DB update helpers
    │   └── mfa_service.py            # MFA OTP queue management
    └── routers/
        ├── __init__.py
        ├── planner_router.py         # /planner-preauth, /retrigger, /handle-mfa
        ├── sse_router.py             # /sse/cases/{case_ref_id}/logs
        └── health.py
```

---

## 3. Configuration & Settings

```python
# planner/src/config.py
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    app_env:      str = Field("prod",    env="APP_ENV")
    service_name: str = Field("planner", env="SERVICE_NAME")
    log_level:    str = Field("INFO",    env="LOG_LEVEL")

    # Database
    db_host:     str = Field(..., env="DB_HOST")
    db_port:     int = Field(5432, env="DB_PORT")
    db_user:     str = Field(..., env="DB_USER")
    db_password: str = Field(..., env="DB_PASSWORD")
    db_name:     str = Field(..., env="DB_NAME")

    # Redis
    redis_host: str  = Field(..., env="REDIS_HOST")
    redis_port: int  = Field(6379, env="REDIS_PORT")
    redis_auth: str  = Field("",   env="REDIS_AUTH")
    redis_tls:  bool = Field(False, env="REDIS_TLS")

    # GCP / Pub/Sub
    gcp_project_id:             str = Field(..., env="GCP_PROJECT_ID")
    submission_subscription_id: str = Field(
        "prior-auth-submission-sub", env="SUBMISSION_SUBSCRIPTION_ID")
    submission_topic_id:        str = Field(
        "prior-auth-submission-topic", env="PRIOR_AUTH_SUBMISSION_TOPIC")

    # N8N Webhooks
    n8n_submission_webhook_url:   str = Field(..., env="N8N_SUBMISSION_WEBHOOK_URL")
    n8n_mfa_webhook_url:          str = Field(..., env="N8N_MFA_WEBHOOK_URL")
    n8n_webhook_secret:           str = Field(..., env="N8N_WEBHOOK_SECRET")

    # Control Plane (for session info lookup)
    control_plane_url: str = Field("http://control-plane:8083", env="CONTROL_PLANE_URL")

    # Feature flags
    one_session_per_batch: bool = Field(False, env="ONE_SESSION_PER_BATCH")

    # Deduplication TTL (seconds)
    dedup_ttl_seconds: int = Field(300, env="DEDUP_TTL_SECONDS")  # 5 minutes

    class Config:
        env_file = ".env"
        case_sensitive = False


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
```

---

## 4. Application Entry Point & Lifespan

```python
# planner/src/main.py
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI

from common.logs.logger import configure_logging, get_logger
from common.db_layer.db_config import get_engine
from common.redis_layer.redis_config import get_redis_client
from common.pubsub_layer.consumer_thread import ConsumerThread

from config import get_settings
from consumer.planner_consumer import PlannerConsumer
from routers.planner_router import router as planner_router
from routers.sse_router import router as sse_router
from routers.health import router as health_router

os.environ.setdefault("SERVICE_NAME", "planner")
configure_logging()
logger = get_logger(__name__)

_consumer_thread: ConsumerThread | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _consumer_thread
    settings = get_settings()
    logger.info("planner_starting", env=settings.app_env)

    # Verify connections
    with get_engine().connect() as conn:
        conn.execute("SELECT 1")
    get_redis_client().ping()
    logger.info("connections_ok")

    # Start Pub/Sub consumer in background thread
    consumer        = PlannerConsumer(settings.submission_subscription_id)
    _consumer_thread = ConsumerThread(consumer, name="PlannerConsumer")
    _consumer_thread.start()

    logger.info("planner_ready")
    yield

    # Shutdown
    if _consumer_thread:
        _consumer_thread.stop()
    get_engine().dispose()
    logger.info("planner_shutdown")


def create_app() -> FastAPI:
    app = FastAPI(
        title="AutoAuth Agent — Planner",
        version="1.0.0",
        docs_url=None,
        redoc_url=None,
        lifespan=lifespan,
    )
    app.include_router(planner_router, prefix="/api/v1")
    app.include_router(sse_router,     prefix="/api/v1")
    app.include_router(health_router)
    return app


app = create_app()
```

---

## 5. PlannerConsumer — Pub/Sub Message Handling

```python
# planner/src/consumer/planner_consumer.py
"""
Consumes messages from Pub/Sub Topic #1 (prior-auth-submission-topic).
Each message contains: {case_ref_id, portal_id, batch_id, retry, priority}

Processing pipeline per message:
  1. Deduplication check
  2. DB fetch + validation
  3. ONE_SESSION_PER_BATCH coordination (if enabled)
  4. Status update → PLANNING
  5. N8N webhook trigger
  6. Planner status record update
"""
from datetime import datetime, timezone
from typing import Any

from common.pubsub_layer.base_consumer import BaseConsumer, TransientError, PermanentError
from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import (
    PriorAuthCaseRequest, PriorAuthPlannerAgentStatus
)
from common.logs.logger import get_logger

from config import get_settings
from consumer.dedup_cache import DeduplicationCache
from services.n8n_trigger import N8NTriggerService
from services.one_session_manager import OneSessionManager
from services.case_updater import CaseUpdater

logger = get_logger(__name__)

# Module-level dedup cache (shared across all messages in this process)
_dedup_cache = DeduplicationCache()


class PlannerConsumer(BaseConsumer):
    """
    Pub/Sub consumer for the prior-auth submission topic.
    One instance runs as a daemon thread in the planner service.
    """

    def __init__(self, subscription_id: str):
        super().__init__(subscription_id, max_messages=5)
        self._settings        = get_settings()
        self._n8n             = N8NTriggerService()
        self._session_manager = OneSessionManager()

    def process_message(self, data: dict[str, Any], attributes: dict[str, str]) -> None:
        case_ref_id = data.get("case_ref_id")
        portal_id   = data.get("portal_id")
        batch_id    = data.get("batch_id")
        is_retry    = data.get("retry", False)

        if not case_ref_id or not portal_id:
            raise PermanentError(f"Message missing required fields: {data}")

        logger.info("planner_message_received",
                    case_ref_id=case_ref_id, portal_id=portal_id,
                    is_retry=is_retry)

        # ── Step 1: Deduplication ─────────────────────────────────
        if not is_retry and _dedup_cache.is_duplicate(case_ref_id):
            logger.info("planner_dedup_skip", case_ref_id=case_ref_id)
            self._record_planner_status(case_ref_id, "DEDUP_SKIPPED",
                                        dedup_cache_hit=True)
            return   # Ack and skip — message is a duplicate

        _dedup_cache.mark_seen(case_ref_id)

        # ── Step 2: Fetch case from DB ────────────────────────────
        with get_session_factory()() as session:
            case = session.query(PriorAuthCaseRequest).filter_by(
                case_ref_id=case_ref_id).first()

            if not case:
                raise PermanentError(f"Case not found in DB: {case_ref_id}")

            if case.status in ("CANCELLED", "APPROVED", "DENIED", "FAILED"):
                logger.info("planner_skip_terminal_case",
                            case_ref_id=case_ref_id, status=case.status)
                return

            # ── Step 3: ONE_SESSION_PER_BATCH coordination ────────
            shared_session_id = None
            if self._settings.one_session_per_batch and batch_id:
                shared_session_id = self._session_manager.get_or_wait_for_session(
                    batch_id=batch_id,
                    portal_id=portal_id,
                    case_ref_id=case_ref_id,
                )

            # ── Step 4: Update case status → PLANNING ─────────────
            CaseUpdater.set_status(session, case, "PLANNING")
            self._record_planner_status(
                case_ref_id, "TRIGGERING",
                one_session_batch=(shared_session_id is not None)
            )

            # Build full case payload for N8N
            n8n_payload = self._build_n8n_payload(
                case=case,
                portal_id=portal_id,
                shared_session_id=shared_session_id,
            )

        # ── Step 5: Trigger N8N (outside DB session) ──────────────
        try:
            workflow_id = self._n8n.trigger_submission(n8n_payload)
            self._record_planner_status(case_ref_id, "TRIGGERED",
                                        n8n_workflow_id=workflow_id)
            logger.info("planner_triggered",
                        case_ref_id=case_ref_id, workflow_id=workflow_id)
        except Exception as e:
            logger.error("planner_n8n_trigger_failed",
                         case_ref_id=case_ref_id, error=str(e))
            # Transient — nack so message is redelivered
            raise TransientError(f"N8N trigger failed: {e}") from e

    def _build_n8n_payload(
        self,
        case,
        portal_id: str,
        shared_session_id: str | None,
    ) -> dict:
        return {
            "case_ref_id":       case.case_ref_id,
            "portal_id":         portal_id,
            "batch_id":          str(case.batch_id) if case.batch_id else None,
            "patient_data":      case.patient_data,
            "clinical_data":     case.clinical_data,
            "retry_count":       case.retry_count,
            "shared_session_id": shared_session_id,
            "priority":          "NORMAL",
        }

    def _record_planner_status(
        self,
        case_ref_id:       str,
        status:            str,
        n8n_workflow_id:   str | None = None,
        dedup_cache_hit:   bool = False,
        one_session_batch: bool = False,
    ) -> None:
        try:
            with get_session_factory()() as session:
                record = session.query(PriorAuthPlannerAgentStatus).filter_by(
                    case_ref_id=case_ref_id).first()

                if record:
                    record.planning_status  = status
                    record.trigger_count    += 1
                    if n8n_workflow_id:
                        record.n8n_workflow_id = n8n_workflow_id
                else:
                    record = PriorAuthPlannerAgentStatus(
                        case_ref_id=case_ref_id,
                        planning_status=status,
                        n8n_workflow_id=n8n_workflow_id,
                        trigger_count=1,
                        dedup_cache_hit=dedup_cache_hit,
                        one_session_batch=one_session_batch,
                    )
                    session.add(record)
                session.commit()
        except Exception as e:
            # Non-critical — log and continue
            logger.warning("planner_status_record_failed",
                           case_ref_id=case_ref_id, error=str(e))
```

---

## 6. Deduplication — InMemoryCache

```python
# planner/src/consumer/dedup_cache.py
"""
In-process deduplication cache with TTL.
Prevents the same case_ref_id from being triggered twice
within a short window (e.g., if Pub/Sub redelivers an already-acked message
or api-server publishes a duplicate).

Thread-safe: uses threading.Lock.
Not distributed — each planner replica has its own cache.
This is acceptable because Pub/Sub subscriptions deliver each message
to ONE subscriber at a time (not broadcast).
"""
import time
import threading
from collections import OrderedDict
from common.logs.logger import get_logger

logger = get_logger(__name__)


class DeduplicationCache:
    """
    LRU-bounded in-memory cache with per-entry TTL.
    - Max 10,000 entries (prevents unbounded memory growth)
    - Default TTL: 300 seconds (5 minutes)
    - Thread-safe
    """

    def __init__(self, ttl_seconds: int = 300, max_size: int = 10_000):
        self._ttl     = ttl_seconds
        self._max     = max_size
        self._cache   = OrderedDict()   # {case_ref_id: expiry_timestamp}
        self._lock    = threading.Lock()

    def is_duplicate(self, case_ref_id: str) -> bool:
        """Return True if we've seen this case_ref_id within the TTL window."""
        with self._lock:
            entry = self._cache.get(case_ref_id)
            if entry is None:
                return False
            if time.monotonic() > entry:
                # Expired — remove stale entry
                del self._cache[case_ref_id]
                return False
            return True

    def mark_seen(self, case_ref_id: str) -> None:
        """Record that we processed this case_ref_id."""
        with self._lock:
            expiry = time.monotonic() + self._ttl
            self._cache[case_ref_id] = expiry
            self._cache.move_to_end(case_ref_id)   # LRU: most recent at end

            # Evict oldest if over max size
            while len(self._cache) > self._max:
                evicted, _ = self._cache.popitem(last=False)
                logger.debug("dedup_cache_evict", case_ref_id=evicted)

    def remove(self, case_ref_id: str) -> None:
        """Explicitly remove an entry (e.g., when retrigger is needed)."""
        with self._lock:
            self._cache.pop(case_ref_id, None)

    def size(self) -> int:
        with self._lock:
            return len(self._cache)

    def purge_expired(self) -> int:
        """Remove all expired entries. Call periodically to free memory."""
        now = time.monotonic()
        removed = 0
        with self._lock:
            expired = [k for k, v in self._cache.items() if now > v]
            for k in expired:
                del self._cache[k]
                removed += 1
        if removed:
            logger.debug("dedup_cache_purged", count=removed)
        return removed
```

---

## 7. ONE_SESSION_PER_BATCH Logic

```python
# planner/src/services/one_session_manager.py
"""
ONE_SESSION_PER_BATCH: When enabled, all cases in the same batch
share one authenticated browser session on the same browser-agent pod.

Flow:
  1. First case in batch → acquire a browser-agent pod → login → record session in Redis
  2. All subsequent cases → wait for session to be ACTIVE → reuse session_id
  3. control-plane sequences case processing within the shared session

Redis keys:
  batch_session:{batch_id}         → JSON {session_id, pod_ip, status}
  batch_session:{batch_id}_lock    → Distributed lock for first-case setup
"""
import json
import time
import threading
from common.redis_layer.redis_config import get_redis_client
from common.logs.logger import get_logger

logger = get_logger(__name__)

SESSION_KEY_TEMPLATE = "batch_session:{batch_id}"
LOCK_KEY_TEMPLATE    = "batch_session:{batch_id}_lock"
SESSION_TTL          = 7200    # 2 hours — max time a shared session lives
WAIT_TIMEOUT         = 120     # Seconds to wait for first case to log in
POLL_INTERVAL        = 2       # Seconds between poll attempts


class OneSessionManager:
    """
    Coordinates shared browser sessions across batch cases.
    """

    @property
    def _redis(self):
        return get_redis_client()

    def get_or_wait_for_session(
        self,
        batch_id:   str,
        portal_id:  str,
        case_ref_id: str,
    ) -> str | None:
        """
        Returns session_id if a shared session exists or is successfully created.
        Returns None if ONE_SESSION_PER_BATCH should not apply (fallback to individual).
        """
        session_key = SESSION_KEY_TEMPLATE.format(batch_id=batch_id)
        lock_key    = LOCK_KEY_TEMPLATE.format(batch_id=batch_id)

        # Fast path: session already exists and is active
        existing = self._get_session(session_key)
        if existing and existing.get("status") == "ACTIVE":
            logger.info("batch_session_reused", batch_id=batch_id,
                        session_id=existing["session_id"])
            return existing["session_id"]

        # Try to become the "first case" (acquire lock)
        is_first = self._redis.set(lock_key, case_ref_id, nx=True, ex=SESSION_TTL)

        if is_first:
            # This case will trigger the login — record PENDING state
            self._set_session(session_key, {
                "status":     "PENDING",
                "batch_id":   batch_id,
                "portal_id":  portal_id,
                "session_id": None,
            })
            logger.info("batch_session_first_case", batch_id=batch_id,
                        case_ref_id=case_ref_id)
            # Return None — control-plane handles login for this case
            return None

        # Subsequent case — wait for session to become ACTIVE
        return self._wait_for_session(session_key, batch_id, case_ref_id)

    def _wait_for_session(
        self, session_key: str, batch_id: str, case_ref_id: str
    ) -> str | None:
        deadline = time.monotonic() + WAIT_TIMEOUT
        logger.info("batch_session_waiting", batch_id=batch_id,
                    case_ref_id=case_ref_id, timeout=WAIT_TIMEOUT)

        while time.monotonic() < deadline:
            data = self._get_session(session_key)
            if data and data.get("status") == "ACTIVE":
                logger.info("batch_session_ready", batch_id=batch_id,
                            session_id=data["session_id"])
                return data["session_id"]
            if data and data.get("status") == "FAILED":
                logger.warning("batch_session_failed", batch_id=batch_id)
                return None   # Fall back to individual session
            time.sleep(POLL_INTERVAL)

        logger.warning("batch_session_wait_timeout", batch_id=batch_id,
                       case_ref_id=case_ref_id)
        return None

    def mark_session_active(self, batch_id: str, session_id: str, pod_ip: str) -> None:
        """Called by control-plane once the shared session is logged in."""
        session_key = SESSION_KEY_TEMPLATE.format(batch_id=batch_id)
        data        = self._get_session(session_key) or {}
        data.update({"status": "ACTIVE", "session_id": session_id, "pod_ip": pod_ip})
        self._set_session(session_key, data)
        logger.info("batch_session_activated", batch_id=batch_id,
                    session_id=session_id)

    def mark_session_failed(self, batch_id: str) -> None:
        """Called if the shared login fails."""
        session_key = SESSION_KEY_TEMPLATE.format(batch_id=batch_id)
        data        = self._get_session(session_key) or {}
        data["status"] = "FAILED"
        self._set_session(session_key, data)
        logger.warning("batch_session_marked_failed", batch_id=batch_id)

    def invalidate_session(self, batch_id: str) -> None:
        """Called when batch completes or session expires."""
        session_key = SESSION_KEY_TEMPLATE.format(batch_id=batch_id)
        lock_key    = LOCK_KEY_TEMPLATE.format(batch_id=batch_id)
        self._redis.delete(session_key, lock_key)
        logger.info("batch_session_invalidated", batch_id=batch_id)

    def _get_session(self, key: str) -> dict | None:
        raw = self._redis.get(key)
        return json.loads(raw) if raw else None

    def _set_session(self, key: str, data: dict) -> None:
        self._redis.setex(key, SESSION_TTL, json.dumps(data))
```

---

## 8. N8N Webhook Trigger

```python
# planner/src/services/n8n_trigger.py
"""
HTTP client for triggering N8N workflows via webhooks.
Uses HMAC-SHA256 signature for webhook authentication.

All N8N webhook calls are synchronous (httpx) because:
  - The Pub/Sub consumer runs in a thread (not async)
  - httpx is used rather than requests for better timeout control
  - N8N webhook response confirms receipt; actual work is async inside N8N
"""
import hashlib
import hmac
import json
import time
import httpx
from common.logs.logger import get_logger
from config import get_settings

logger = get_logger(__name__)

WEBHOOK_TIMEOUT_SECONDS = 15
MAX_RETRIES             = 3
RETRY_BACKOFF_SECONDS   = [1, 3, 5]


class N8NTriggerService:

    def __init__(self):
        self._settings = get_settings()
        self._client   = httpx.Client(timeout=WEBHOOK_TIMEOUT_SECONDS)

    def trigger_submission(self, payload: dict) -> str:
        """
        POST the PA case payload to N8N submission webhook.
        Returns N8N execution ID (workflow_id) from response.
        Raises on failure after retries.
        """
        return self._post_webhook(
            url=self._settings.n8n_submission_webhook_url,
            payload=payload,
            event_type="PRIOR_AUTH_SUBMISSION",
        )

    def trigger_mfa_notification(self, case_ref_id: str, message: str,
                                 screenshot_url: str | None) -> None:
        """Notify N8N that agent needs MFA OTP."""
        self._post_webhook(
            url=self._settings.n8n_mfa_webhook_url,
            payload={
                "case_ref_id":    case_ref_id,
                "message":        message,
                "screenshot_url": screenshot_url,
            },
            event_type="MFA_REQUIRED",
        )

    def _post_webhook(self, url: str, payload: dict, event_type: str) -> str:
        body      = json.dumps(payload, default=str)
        signature = self._sign(body)
        headers   = {
            "Content-Type":     "application/json",
            "X-Webhook-Event":  event_type,
            "X-Webhook-Sig":    signature,
            "X-Timestamp":      str(int(time.time())),
        }

        last_error = None
        for attempt, backoff in enumerate(RETRY_BACKOFF_SECONDS, start=1):
            try:
                resp = self._client.post(url, content=body, headers=headers)
                resp.raise_for_status()
                data = resp.json()
                workflow_id = data.get("executionId", data.get("id", "unknown"))
                logger.info("n8n_triggered", event=event_type,
                            workflow_id=workflow_id, attempt=attempt)
                return str(workflow_id)

            except httpx.HTTPStatusError as e:
                last_error = e
                logger.warning("n8n_http_error", event=event_type,
                               status=e.response.status_code, attempt=attempt)
            except httpx.RequestError as e:
                last_error = e
                logger.warning("n8n_request_error", event=event_type,
                               error=str(e), attempt=attempt)

            if attempt < MAX_RETRIES:
                time.sleep(backoff)

        raise RuntimeError(
            f"N8N webhook failed after {MAX_RETRIES} attempts: {last_error}"
        )

    def _sign(self, body: str) -> str:
        """HMAC-SHA256 signature for webhook verification by N8N."""
        return hmac.new(
            self._settings.n8n_webhook_secret.encode(),
            body.encode(),
            hashlib.sha256,
        ).hexdigest()

    def __del__(self):
        try:
            self._client.close()
        except Exception:
            pass
```

---

## 9. Planner API Endpoints

```python
# planner/src/routers/planner_router.py
"""
Internal endpoints — only reachable within the GKE cluster.
Not exposed via Ingress.
"""
import asyncio
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import PriorAuthCaseRequest, PriorAuthPlannerAgentStatus
from common.pubsub_layer.publisher import publish_case_to_submission_queue
from common.logs.logger import get_logger
from services.case_updater import CaseUpdater
from services.mfa_service import MFAService
from consumer.dedup_cache import DeduplicationCache
from config import get_settings

logger = get_logger(__name__)
router = APIRouter(tags=["Planner"])

# Module-level references (set in main.py lifespan)
_dedup_cache: DeduplicationCache | None = None


def set_dedup_cache(cache: DeduplicationCache) -> None:
    global _dedup_cache
    _dedup_cache = cache


# ── POST /planner-preauth ─────────────────────────────────────────────────
class PlannerPreAuthRequest(BaseModel):
    case_ref_id: str
    portal_id:   str
    batch_id:    str | None = None


@router.post("/planner-preauth", status_code=202)
def planner_preauth(payload: PlannerPreAuthRequest):
    """
    Called by N8N (agents webhook) to initiate planner processing for a case.
    Alternative entry point to Pub/Sub — used for manual triggers or retries.
    """
    with get_session_factory()() as session:
        case = session.query(PriorAuthCaseRequest).filter_by(
            case_ref_id=payload.case_ref_id).first()
        if not case:
            raise HTTPException(status_code=404, detail="Case not found")

    # Publish to Pub/Sub — consumer will pick it up normally
    try:
        publish_case_to_submission_queue(
            case_ref_id=payload.case_ref_id,
            portal_id=payload.portal_id,
            batch_id=payload.batch_id,
            retry=True,
        )
        logger.info("planner_preauth_queued", case_ref_id=payload.case_ref_id)
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Queue publish failed: {e}")

    return {"status": "queued", "case_ref_id": payload.case_ref_id}


# ── POST /retrigger/{case_ref_id} ─────────────────────────────────────────
@router.post("/retrigger/{case_ref_id}", status_code=202)
def retrigger_case(case_ref_id: str):
    """
    Force re-trigger a case. Clears dedup cache first so the case is
    not skipped as a duplicate.
    Used by: crash recovery, operator manual retry, HITL resolution.
    """
    with get_session_factory()() as session:
        case = session.query(PriorAuthCaseRequest).filter_by(
            case_ref_id=case_ref_id).first()
        if not case:
            raise HTTPException(status_code=404, detail="Case not found")

        if case.status in ("APPROVED", "DENIED", "CANCELLED"):
            raise HTTPException(
                status_code=409,
                detail=f"Cannot retrigger case in terminal status: {case.status}")

        # Increment retry count
        case.retry_count += 1
        case.status       = "PENDING"
        case.last_retry_at = __import__("datetime").datetime.utcnow()
        session.commit()
        portal_id = session.query(
            __import__("common.db_layer.orm_models",
                       fromlist=["PriorAuthPortal"]).PriorAuthPortal
        ).get(case.portal_id).portal_id

    # Clear from dedup cache so consumer processes it
    if _dedup_cache:
        _dedup_cache.remove(case_ref_id)

    # Publish to Pub/Sub
    publish_case_to_submission_queue(
        case_ref_id=case_ref_id,
        portal_id=portal_id,
        retry=True,
    )

    logger.info("case_retriggered", case_ref_id=case_ref_id,
                retry_count=case.retry_count)
    return {"status": "retriggered", "case_ref_id": case_ref_id,
            "retry_count": case.retry_count}


# ── POST /handle-mfa/{case_ref_id} ───────────────────────────────────────
class MFAPayload(BaseModel):
    otp_code: str


@router.post("/handle-mfa/{case_ref_id}", status_code=200)
def handle_mfa(case_ref_id: str, payload: MFAPayload):
    """
    Called by ADK chatbot when operator provides OTP code.
    Forwards OTP to the browser-agent via the MFAService asyncio queue.
    """
    delivered = MFAService.deliver_otp(case_ref_id, payload.otp_code)
    if not delivered:
        raise HTTPException(
            status_code=404,
            detail=f"No active MFA session for case: {case_ref_id}")
    logger.info("mfa_otp_delivered", case_ref_id=case_ref_id)
    return {"status": "delivered", "case_ref_id": case_ref_id}
```

---

## 10. MFA Handler

```python
# planner/src/services/mfa_service.py
"""
MFA OTP delivery service using asyncio.Queue per case.
Browser-agent creates a queue when it hits an MFA step.
Planner's /handle-mfa endpoint puts the OTP into that queue.
Browser-agent's asyncio.Queue.get() unblocks and receives the OTP.

Queue lifecycle:
  1. browser-agent calls MFAService.create_queue(case_ref_id)
  2. Agent awaits queue.get(timeout=300)
  3. Operator submits OTP via ADK chatbot → POST /handle-mfa/{case_ref_id}
  4. MFAService.deliver_otp(case_ref_id, otp) → queue.put_nowait(otp)
  5. Agent resumes with OTP value
  6. On completion or timeout, MFAService.close_queue(case_ref_id) cleans up

Thread-safety: asyncio.Queue is not thread-safe for cross-thread use.
Since planner consumer runs in a thread but FastAPI endpoints are async,
we use a threading.Queue (not asyncio.Queue) here, and browser-agent
handles the async interface on its side via run_in_executor if needed.
"""
import threading
from common.logs.logger import get_logger

logger = get_logger(__name__)

# Registry of active MFA queues: {case_ref_id: threading.Queue}
_mfa_queues: dict[str, threading.Queue] = {}
_lock = threading.Lock()


class MFAService:

    @staticmethod
    def create_queue(case_ref_id: str) -> threading.Queue:
        """Create an OTP queue for a case. Called by browser-agent at MFA step."""
        q = threading.Queue(maxsize=1)
        with _lock:
            _mfa_queues[case_ref_id] = q
        logger.info("mfa_queue_created", case_ref_id=case_ref_id)
        return q

    @staticmethod
    def deliver_otp(case_ref_id: str, otp_code: str) -> bool:
        """
        Put OTP into the case's queue.
        Returns True if delivered, False if no active queue for that case.
        """
        with _lock:
            queue = _mfa_queues.get(case_ref_id)
        if not queue:
            return False
        try:
            queue.put_nowait(otp_code)
            return True
        except Exception:
            return False

    @staticmethod
    def close_queue(case_ref_id: str) -> None:
        """Remove and discard the queue when MFA flow completes."""
        with _lock:
            _mfa_queues.pop(case_ref_id, None)
        logger.info("mfa_queue_closed", case_ref_id=case_ref_id)

    @staticmethod
    def wait_for_otp(case_ref_id: str, timeout_seconds: int = 300) -> str | None:
        """
        Block until OTP is delivered or timeout expires.
        Called from browser-agent recipe step (runs in executor thread).
        Returns OTP string or None on timeout.
        """
        with _lock:
            queue = _mfa_queues.get(case_ref_id)
        if not queue:
            logger.warning("mfa_queue_not_found", case_ref_id=case_ref_id)
            return None
        try:
            otp = queue.get(timeout=timeout_seconds)
            logger.info("mfa_otp_received", case_ref_id=case_ref_id)
            return otp
        except Exception:
            logger.warning("mfa_wait_timeout", case_ref_id=case_ref_id,
                           timeout=timeout_seconds)
            return None
```

---

## 11. SSE Log Streaming

```python
# planner/src/routers/sse_router.py
"""
SSE endpoint for real-time case log streaming.
Reads from Redis Stream: stream:{case_ref_id}/logs

Dashboard connects to this endpoint to show live agent activity
(step-by-step actions, screenshots, timings) while a case is in-progress.
"""
import asyncio
import json
from fastapi import APIRouter, HTTPException
from sse_starlette.sse import EventSourceResponse

from common.redis_layer.redis_config import get_redis_client
from common.logs.logger import get_logger

logger = get_logger(__name__)
router = APIRouter(tags=["SSE"])

STREAM_KEY_TEMPLATE    = "stream:{case_ref_id}/logs"
SSE_POLL_INTERVAL      = 0.5     # Seconds between Redis XREAD polls
SSE_HEARTBEAT_INTERVAL = 15      # Seconds between keepalive events
SSE_MAX_IDLE_SECONDS   = 300     # Close connection if no new logs for 5 min


@router.get(
    "/sse/cases/{case_ref_id}/logs",
    summary="Stream real-time logs for a case via SSE",
)
async def stream_case_logs(case_ref_id: str):
    """
    SSE stream of agent logs for a case.
    Client connects once; server pushes log entries as they arrive.
    Stream ends when case reaches a terminal status or connection is closed.
    """
    stream_key = STREAM_KEY_TEMPLATE.format(case_ref_id=case_ref_id)
    redis      = get_redis_client()

    # Verify stream exists (case must be active or recently completed)
    if not redis.exists(stream_key):
        raise HTTPException(status_code=404,
                            detail=f"No log stream found for case: {case_ref_id}")

    async def event_generator():
        last_id   = "0"    # Read from beginning of stream
        idle_secs = 0

        try:
            while True:
                # Non-blocking read (count=50 entries, no blocking timeout)
                entries = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: redis.xread({stream_key: last_id}, count=50)
                )

                if entries:
                    _, messages = entries[0]
                    idle_secs   = 0
                    for msg_id, fields in messages:
                        last_id = msg_id
                        yield {
                            "event": "log",
                            "id":    msg_id,
                            "data":  json.dumps({
                                "case_ref_id": fields.get("case_ref_id"),
                                "level":       fields.get("level", "INFO"),
                                "step_name":   fields.get("step_name", ""),
                                "action_type": fields.get("action_type", ""),
                                "message":     fields.get("message", ""),
                                "metadata":    json.loads(
                                    fields.get("metadata", "{}") or "{}"),
                                "ts":          fields.get("ts", ""),
                            }),
                        }
                else:
                    # No new logs — send heartbeat to keep connection alive
                    idle_secs += SSE_POLL_INTERVAL
                    if idle_secs >= SSE_HEARTBEAT_INTERVAL:
                        yield {"event": "heartbeat", "data": json.dumps({
                            "case_ref_id": case_ref_id, "ts": "now"})}
                        idle_secs = 0

                    if idle_secs >= SSE_MAX_IDLE_SECONDS:
                        # No activity for 5 min — assume case is done
                        yield {"event": "stream_end",
                               "data": json.dumps({"reason": "idle_timeout"})}
                        return

                await asyncio.sleep(SSE_POLL_INTERVAL)

        except asyncio.CancelledError:
            logger.info("sse_client_disconnected", case_ref_id=case_ref_id)

    return EventSourceResponse(event_generator())


@router.post(
    "/sync-case-logs/{case_ref_id}",
    status_code=200,
    summary="Sync Redis Stream logs to DB (called by browser-agent on completion)",
)
async def sync_case_logs(case_ref_id: str):
    """
    Called by browser-agent after a session completes to persist Redis
    Stream logs to prior_auth_case_logs table for long-term storage.
    """
    from common.db_layer.db_config import get_session_factory
    from common.db_layer.orm_models import PriorAuthCaseLog

    redis      = get_redis_client()
    stream_key = STREAM_KEY_TEMPLATE.format(case_ref_id=case_ref_id)
    entries    = redis.xrange(stream_key, count=1000)

    if not entries:
        return {"synced": 0}

    with get_session_factory()() as session:
        logs = []
        for msg_id, fields in entries:
            metadata_raw = fields.get("metadata", "{}")
            try:
                metadata = json.loads(metadata_raw) if metadata_raw else {}
            except Exception:
                metadata = {}

            logs.append(PriorAuthCaseLog(
                case_ref_id=fields.get("case_ref_id", case_ref_id),
                session_id=fields.get("session_id"),
                log_level=fields.get("level", "INFO"),
                step_name=fields.get("step_name"),
                action_type=fields.get("action_type"),
                message=fields.get("message", ""),
                metadata=metadata,
            ))
        session.add_all(logs)
        session.commit()

    logger.info("case_logs_synced", case_ref_id=case_ref_id, count=len(logs))
    return {"synced": len(logs)}
```

---

## 12. Unit Tests

```python
# planner/tests/test_dedup_cache.py
import time
import pytest
from consumer.dedup_cache import DeduplicationCache


def test_not_duplicate_on_first_call():
    cache = DeduplicationCache(ttl_seconds=60)
    assert cache.is_duplicate("CASE-001") is False


def test_duplicate_after_mark_seen():
    cache = DeduplicationCache(ttl_seconds=60)
    cache.mark_seen("CASE-001")
    assert cache.is_duplicate("CASE-001") is True


def test_not_duplicate_after_ttl_expired():
    cache = DeduplicationCache(ttl_seconds=1)
    cache.mark_seen("CASE-001")
    time.sleep(1.1)
    assert cache.is_duplicate("CASE-001") is False


def test_remove_clears_entry():
    cache = DeduplicationCache(ttl_seconds=60)
    cache.mark_seen("CASE-001")
    cache.remove("CASE-001")
    assert cache.is_duplicate("CASE-001") is False


def test_max_size_evicts_oldest():
    cache = DeduplicationCache(ttl_seconds=60, max_size=3)
    cache.mark_seen("A")
    cache.mark_seen("B")
    cache.mark_seen("C")
    cache.mark_seen("D")          # Should evict "A"
    assert cache.size() == 3
    assert cache.is_duplicate("A") is False   # Evicted
    assert cache.is_duplicate("D") is True


def test_purge_expired():
    cache = DeduplicationCache(ttl_seconds=1)
    cache.mark_seen("CASE-X")
    time.sleep(1.1)
    removed = cache.purge_expired()
    assert removed == 1
    assert cache.size() == 0
```

```python
# planner/tests/test_planner_consumer.py
import pytest
from unittest.mock import MagicMock, patch, call
from consumer.planner_consumer import PlannerConsumer
from common.pubsub_layer.base_consumer import PermanentError


@pytest.fixture
def mock_session():
    session = MagicMock()
    case    = MagicMock()
    case.case_ref_id = "CASE-001"
    case.status      = "PENDING"
    case.batch_id    = None
    case.retry_count = 0
    case.patient_data  = {"member_id": "M001"}
    case.clinical_data = {"procedure_codes": ["27447"]}
    session.__enter__ = MagicMock(return_value=session)
    session.__exit__  = MagicMock(return_value=False)
    session.query.return_value.filter_by.return_value.first.return_value = case
    return session, case


def test_permanent_error_on_missing_case_ref():
    consumer = PlannerConsumer.__new__(PlannerConsumer)
    consumer._settings        = MagicMock(one_session_per_batch=False)
    consumer._n8n             = MagicMock()
    consumer._session_manager = MagicMock()

    with pytest.raises(PermanentError):
        consumer.process_message({}, {})


def test_skips_terminal_case(mock_session):
    session, case = mock_session
    case.status = "APPROVED"   # Terminal status

    consumer = PlannerConsumer.__new__(PlannerConsumer)
    consumer._settings        = MagicMock(one_session_per_batch=False,
                                           dedup_ttl_seconds=300)
    consumer._n8n             = MagicMock()
    consumer._session_manager = MagicMock()

    with patch("consumer.planner_consumer.get_session_factory",
               return_value=MagicMock(return_value=session)), \
         patch("consumer.planner_consumer._dedup_cache") as dedup:
        dedup.is_duplicate.return_value = False

        consumer.process_message(
            {"case_ref_id": "CASE-001", "portal_id": "availity"}, {}
        )

    consumer._n8n.trigger_submission.assert_not_called()


def test_triggers_n8n_for_valid_case(mock_session):
    session, case = mock_session

    consumer = PlannerConsumer.__new__(PlannerConsumer)
    consumer._settings        = MagicMock(one_session_per_batch=False)
    consumer._n8n             = MagicMock()
    consumer._session_manager = MagicMock()
    consumer._n8n.trigger_submission.return_value = "exec-123"

    with patch("consumer.planner_consumer.get_session_factory",
               return_value=MagicMock(return_value=session)), \
         patch("consumer.planner_consumer._dedup_cache") as dedup, \
         patch("consumer.planner_consumer.CaseUpdater"):
        dedup.is_duplicate.return_value = False

        consumer.process_message(
            {"case_ref_id": "CASE-001", "portal_id": "availity"}, {}
        )

    consumer._n8n.trigger_submission.assert_called_once()
```

```python
# planner/tests/test_mfa_service.py
import pytest
import threading
from services.mfa_service import MFAService


def test_deliver_otp_to_waiting_queue():
    queue = MFAService.create_queue("CASE-OTP-001")
    MFAService.deliver_otp("CASE-OTP-001", "123456")
    otp = queue.get_nowait()
    assert otp == "123456"
    MFAService.close_queue("CASE-OTP-001")


def test_deliver_returns_false_for_unknown_case():
    result = MFAService.deliver_otp("CASE-UNKNOWN", "999999")
    assert result is False


def test_wait_for_otp_with_threaded_delivery():
    MFAService.create_queue("CASE-THREAD-001")

    result = []

    def waiter():
        otp = MFAService.wait_for_otp("CASE-THREAD-001", timeout_seconds=5)
        result.append(otp)

    t = threading.Thread(target=waiter)
    t.start()

    threading.Timer(0.5, lambda: MFAService.deliver_otp(
        "CASE-THREAD-001", "654321")).start()

    t.join(timeout=6)
    MFAService.close_queue("CASE-THREAD-001")
    assert result == ["654321"]
```

---

## Appendix — CaseUpdater Helper

```python
# planner/src/services/case_updater.py
"""
Thin helper for common case status transitions.
Used by consumer and routers to keep DB update logic in one place.
"""
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from common.db_layer.orm_models import PriorAuthCaseRequest
from common.logs.logger import get_logger

logger = get_logger(__name__)


class CaseUpdater:

    @staticmethod
    def set_status(
        session:     Session,
        case:        PriorAuthCaseRequest,
        new_status:  str,
        error_msg:   str | None = None,
    ) -> None:
        old_status            = case.status
        case.previous_status  = old_status
        case.status           = new_status
        case.status_changed_at = datetime.now(timezone.utc)

        if new_status == "IN_PROGRESS" and not case.started_at:
            case.started_at = datetime.now(timezone.utc)
        if new_status == "QUEUED" and not case.queued_at:
            case.queued_at = datetime.now(timezone.utc)
        if new_status in ("APPROVED", "DENIED", "FAILED", "CANCELLED"):
            case.completed_at = datetime.now(timezone.utc)
        if error_msg:
            case.last_error = error_msg

        session.commit()
        logger.info("case_status_updated", case_ref_id=case.case_ref_id,
                    old=old_status, new=new_status)
```

---

*Document Status: DRAFT*
*Previous: [08_API_Server_Implementation.md](08_API_Server_Implementation.md)*
*Next: [10_Control_Plane_Implementation.md](10_Control_Plane_Implementation.md)*
