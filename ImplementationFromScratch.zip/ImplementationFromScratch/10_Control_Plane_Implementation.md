# AutoAuth Agent — Control Plane Implementation
**Phase 3 | Sprints 3–4 | Weeks 11–14**
**Author:** Niranjan Sai Koppisetti
**Date:** September 3, 2026
**Version:** 1.0
**Prerequisite:** [09_Planner_Implementation.md](09_Planner_Implementation.md)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Project Structure](#2-project-structure)
3. [Configuration & Settings](#3-configuration--settings)
4. [Application Entry Point & Lifespan](#4-application-entry-point--lifespan)
5. [Worker Pool Managers — Startup Init](#5-worker-pool-managers--startup-init)
6. [ControlPlane Session Consumer — Pub/Sub Topic #2](#6-controlplane-session-consumer--pubsub-topic-2)
7. [Session Management — Core Endpoints](#7-session-management--core-endpoints)
8. [VNC Proxy](#8-vnc-proxy)
9. [Heartbeat — KeepAliveSender](#9-heartbeat--keepalivesender)
10. [Crash Recovery — ExpiredEventConsumer](#10-crash-recovery--expiredeventconsumer)
11. [HITL Management Routes](#11-hitl-management-routes)
12. [Tracking Session Routes](#12-tracking-session-routes)
13. [Unit Tests](#13-unit-tests)

---

## 1. Overview

The **control-plane** is the orchestration hub for all browser-agent and tracking-agent pods. It is an internal service (not publicly exposed) that:

```
Receives N8N trigger (via Pub/Sub Topic #2 or direct HTTP)
    │
    ▼
ControlPlanSessionConsumer
    │
    ├─► Acquire idle worker pod from Redis pool (submission_pool or tracking_pool)
    │
    ├─► POST /sessions on the chosen browser-agent pod
    │       └─► browser-agent starts Xvfb + VNC + Playwright session
    │
    ├─► Update case status → QUEUED (waiting for agent to run)
    │
    └─► Register heartbeat sender (30s keepalive)

VNC Proxy (HTTP + WebSocket)
    └─► Proxies dashboard VNC viewer requests to browser-agent pod's noVNC port

Heartbeat Sender
    └─► Sends keepalive to browser-agent pods every 30s
    └─► If keepalive fails → triggers crash recovery

ExpiredEventConsumer (Redis Keyspace)
    └─► Listens for expired heartbeat keys
    └─► On expiry → marks case CRASHED + returns pod to pool + retriggers

HITL Management
    └─► /hitl/tasks  — list pending HITL tasks
    └─► /hitl/resolve — resolve a task (operator action)
    └─► /hitl/resume/{case_ref_id} — signal browser-agent to continue
```

---

## 2. Project Structure

```
control-plane/
├── pyproject.toml
├── Dockerfile
└── src/
    ├── main.py
    ├── config.py
    ├── consumer/
    │   ├── __init__.py
    │   └── session_consumer.py         # Pub/Sub Topic #2 consumer
    ├── managers/
    │   ├── __init__.py
    │   ├── worker_manager.py           # Startup pool initialization
    │   └── session_registry.py         # In-memory active session tracking
    ├── services/
    │   ├── __init__.py
    │   ├── browser_agent_client.py     # HTTP client for browser-agent API
    │   ├── keepalive_sender.py         # 30s heartbeat thread
    │   ├── expired_event_consumer.py   # Redis keyspace crash detection
    │   ├── completion_handler.py       # Post-completion N8N callbacks
    │   └── case_updater.py             # DB status helpers (same pattern as planner)
    └── routers/
        ├── __init__.py
        ├── sessions.py                 # /sessions CRUD
        ├── vnc_proxy.py                # VNC HTTP + WebSocket proxy
        ├── hitl.py                     # HITL task management
        ├── tracking.py                 # Tracking session routes
        ├── admin.py                    # /clear-all-pools (admin)
        └── health.py
```

---

## 3. Configuration & Settings

```python
# control-plane/src/config.py
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    app_env:      str = Field("prod",          env="APP_ENV")
    service_name: str = Field("control-plane", env="SERVICE_NAME")
    log_level:    str = Field("INFO",          env="LOG_LEVEL")

    # Database
    db_host:     str = Field(..., env="DB_HOST")
    db_port:     int = Field(5432, env="DB_PORT")
    db_user:     str = Field(..., env="DB_USER")
    db_password: str = Field(..., env="DB_PASSWORD")
    db_name:     str = Field(..., env="DB_NAME")

    # Redis
    redis_host: str  = Field(..., env="REDIS_HOST")
    redis_port: int  = Field(6379, env="REDIS_PORT")
    redis_auth: str  = Field("",   env="REDIS_AUTH")
    redis_tls:  bool = Field(False, env="REDIS_TLS")

    # Pub/Sub
    gcp_project_id:              str = Field(..., env="GCP_PROJECT_ID")
    control_plane_subscription:  str = Field(
        "prior-auth-control-plane-sub", env="CONTROL_PLANE_SUBSCRIPTION_ID")

    # N8N Webhooks (called by control-plane on completion/crash)
    n8n_completed_webhook_url:      str = Field(..., env="N8N_COMPLETED_WEBHOOK_URL")
    n8n_status_capture_webhook_url: str = Field(..., env="N8N_STATUS_CAPTURE_WEBHOOK_URL")
    n8n_webhook_secret:             str = Field(..., env="N8N_WEBHOOK_SECRET")

    # Planner (for retrigger on crash recovery)
    planner_url: str = Field("http://planner:8082", env="PLANNER_URL")

    # Heartbeat
    heartbeat_interval_seconds: int  = Field(30, env="HEARTBEAT_INTERVAL_SECONDS")
    heartbeat_ttl_seconds:      int  = Field(90, env="HEARTBEAT_TTL_SECONDS")
                                        # Key expires if no heartbeat for 90s → crash

    # Worker pool cooling
    cooling_seconds: int = Field(60, env="COOLING_SECONDS")

    # Browser-agent default port
    browser_agent_port: int = Field(8081, env="BROWSER_AGENT_PORT")

    class Config:
        env_file = ".env"
        case_sensitive = False


_settings: Settings | None = None

def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
```

---

## 4. Application Entry Point & Lifespan

```python
# control-plane/src/main.py
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI

from common.logs.logger import configure_logging, get_logger
from common.db_layer.db_config import get_engine
from common.redis_layer.redis_config import get_redis_client
from common.pubsub_layer.consumer_thread import ConsumerThread

from config import get_settings
from consumer.session_consumer import ControlPlaneSessionConsumer
from managers.worker_manager import WorkerManager
from services.keepalive_sender import KeepAliveSender
from services.expired_event_consumer import ExpiredEventConsumer
from routers import sessions, vnc_proxy, hitl, tracking, admin, health

os.environ.setdefault("SERVICE_NAME", "control-plane")
configure_logging()
logger = get_logger(__name__)

_consumer_thread: ConsumerThread | None = None
_keepalive: KeepAliveSender | None = None
_expired_consumer: ExpiredEventConsumer | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _consumer_thread, _keepalive, _expired_consumer
    settings = get_settings()
    logger.info("control_plane_starting", env=settings.app_env)

    # Verify connections
    with get_engine().connect() as conn:
        conn.execute("SELECT 1")
    get_redis_client().ping()

    # Initialize worker pools (discover existing pods from Redis)
    WorkerManager.initialize_pools()

    # Start Pub/Sub consumer
    consumer         = ControlPlaneSessionConsumer(settings.control_plane_subscription)
    _consumer_thread = ConsumerThread(consumer, name="CPSessionConsumer")
    _consumer_thread.start()

    # Start heartbeat sender
    _keepalive = KeepAliveSender()
    _keepalive.start()

    # Start Redis keyspace expiry listener (crash detection)
    _expired_consumer = ExpiredEventConsumer()
    _expired_consumer.start()

    logger.info("control_plane_ready")
    yield

    # Shutdown
    if _consumer_thread:
        _consumer_thread.stop()
    if _keepalive:
        _keepalive.stop()
    if _expired_consumer:
        _expired_consumer.stop()
    get_engine().dispose()
    logger.info("control_plane_shutdown")


def create_app() -> FastAPI:
    app = FastAPI(
        title="AutoAuth Agent — Control Plane",
        version="1.0.0",
        docs_url=None, redoc_url=None,
        lifespan=lifespan,
    )
    app.include_router(sessions.router,   prefix="/api/v1")
    app.include_router(vnc_proxy.router,  prefix="/api/v1")
    app.include_router(hitl.router,       prefix="/api/v1")
    app.include_router(tracking.router,   prefix="/api/v1")
    app.include_router(admin.router,      prefix="/api/v1")
    app.include_router(health.router)
    return app


app = create_app()
```

---

## 5. Worker Pool Managers — Startup Init

```python
# control-plane/src/managers/worker_manager.py
"""
At startup, reads all registered browser-agent and tracking-agent pods
from the DB (agentic_platform_agent table) and populates Redis worker pools.
Handles scenarios where control-plane restarts but pods are still running.
"""
from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import AgenticPlatformAgent
from common.redis_layer.worker_pool import (
    WorkerPool, WorkerInfo, submission_pool, tracking_pool
)
from common.logs.logger import get_logger

logger = get_logger(__name__)


class WorkerManager:

    @staticmethod
    def initialize_pools() -> None:
        """
        Sync DB-registered pods into Redis pools.
        Called once at control-plane startup.
        """
        with get_session_factory()() as session:
            agents = session.query(AgenticPlatformAgent).filter(
                AgenticPlatformAgent.status.in_(["IDLE", "BUSY"]),
                AgenticPlatformAgent.deregistered_at.is_(None),
            ).all()

        submission_count = 0
        tracking_count   = 0

        for agent in agents:
            worker = WorkerInfo(
                pod_id=agent.pod_id,
                pod_ip=agent.pod_ip or "",
                pod_port=agent.pod_port or 8081,
                max_sessions=agent.max_sessions,
            )
            if agent.agent_type == "browser_agent":
                submission_pool.register_worker(worker)
                submission_count += 1
            elif agent.agent_type == "tracking_agent":
                tracking_pool.register_worker(worker)
                tracking_count += 1

        logger.info("worker_pools_initialized",
                    submission_workers=submission_count,
                    tracking_workers=tracking_count)

    @staticmethod
    def register_browser_agent(pod_id: str, pod_ip: str, pod_port: int,
                                max_sessions: int) -> None:
        """Called when a new browser-agent pod comes online."""
        from datetime import datetime, timezone
        with get_session_factory()() as session:
            existing = session.query(AgenticPlatformAgent).filter_by(
                pod_id=pod_id).first()
            if not existing:
                agent = AgenticPlatformAgent(
                    agent_type="browser_agent",
                    pod_id=pod_id,
                    pod_ip=pod_ip,
                    pod_port=pod_port,
                    max_sessions=max_sessions,
                    status="IDLE",
                    registered_at=datetime.now(timezone.utc),
                )
                session.add(agent)
                session.commit()

        worker = WorkerInfo(pod_id=pod_id, pod_ip=pod_ip,
                            pod_port=pod_port, max_sessions=max_sessions)
        submission_pool.register_worker(worker)
        logger.info("browser_agent_registered", pod_id=pod_id, pod_ip=pod_ip)
```

---

## 6. ControlPlane Session Consumer — Pub/Sub Topic #2

```python
# control-plane/src/consumer/session_consumer.py
"""
Consumes Pub/Sub Topic #2 (prior-auth-control-plane-topic).
N8N publishes to this topic after receiving the submission webhook
from the planner (the "agents" N8N webhook triggers this).

Message payload:
  {case_ref_id, portal_id, batch_id, patient_data, clinical_data,
   credential_id, shared_session_id (optional)}

On receipt: acquire idle worker → create browser session → case → IN_PROGRESS
"""
from typing import Any
from common.pubsub_layer.base_consumer import BaseConsumer, TransientError, PermanentError
from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import PriorAuthCaseRequest
from common.redis_layer.worker_pool import submission_pool
from common.logs.logger import get_logger

from services.browser_agent_client import BrowserAgentClient
from services.case_updater import CaseUpdater
from managers.session_registry import SessionRegistry

logger = get_logger(__name__)


class ControlPlaneSessionConsumer(BaseConsumer):

    def process_message(self, data: dict[str, Any], attributes: dict[str, str]) -> None:
        case_ref_id       = data.get("case_ref_id")
        portal_id         = data.get("portal_id")
        credential_id     = data.get("credential_id")
        shared_session_id = data.get("shared_session_id")

        if not case_ref_id or not portal_id:
            raise PermanentError(f"Missing required fields: {data}")

        logger.info("cp_session_message_received", case_ref_id=case_ref_id,
                    portal_id=portal_id)

        # ── Step 1: Fetch case ────────────────────────────────────
        with get_session_factory()() as session:
            case = session.query(PriorAuthCaseRequest).filter_by(
                case_ref_id=case_ref_id).first()
            if not case:
                raise PermanentError(f"Case not found: {case_ref_id}")
            if case.status in ("CANCELLED", "APPROVED", "DENIED", "FAILED"):
                logger.info("cp_skip_terminal", case_ref_id=case_ref_id,
                            status=case.status)
                return

        # ── Step 2: Acquire idle worker ───────────────────────────
        worker = submission_pool.acquire_worker()
        if not worker:
            logger.warning("no_idle_workers", case_ref_id=case_ref_id)
            # Nack — message will be redelivered when a worker becomes free
            raise TransientError("No idle browser-agent workers available")

        pod_ip   = worker.pod_ip
        pod_port = worker.pod_port

        try:
            # ── Step 3: Create browser session ────────────────────
            client     = BrowserAgentClient(pod_ip, pod_port)
            session_resp = client.create_session(
                case_ref_id=case_ref_id,
                portal_id=portal_id,
                patient_data=data.get("patient_data", {}),
                clinical_data=data.get("clinical_data", {}),
                credential_id=credential_id,
                shared_session_id=shared_session_id,
            )
            session_id  = session_resp["session_id"]
            display_slot = session_resp.get("display_slot")
            vnc_url      = session_resp.get("vnc_url")

            # ── Step 4: Register in session registry ──────────────
            SessionRegistry.add(
                session_id=session_id,
                case_ref_id=case_ref_id,
                pod_id=worker.pod_id,
                pod_ip=pod_ip,
            )

            # ── Step 5: Update case status ────────────────────────
            with get_session_factory()() as db:
                case = db.query(PriorAuthCaseRequest).filter_by(
                    case_ref_id=case_ref_id).first()
                CaseUpdater.set_status(db, case, "IN_PROGRESS")

            # ── Step 6: Persist agent session to DB ───────────────
            from common.db_layer.orm_models import PriorAuthAgentSession
            from datetime import datetime, timezone
            with get_session_factory()() as db:
                agent_session = PriorAuthAgentSession(
                    case_ref_id=case_ref_id,
                    attempt_number=case.retry_count + 1,
                    pod_id=worker.pod_id,
                    pod_ip=pod_ip,
                    pod_port=pod_port,
                    session_id=session_id,
                    display_slot=display_slot,
                    vnc_url=vnc_url,
                    execution_mode="recipe",
                    status="ACTIVE",
                )
                db.add(agent_session)
                db.commit()

            logger.info("cp_session_created", case_ref_id=case_ref_id,
                        session_id=session_id, pod_ip=pod_ip)

        except Exception as e:
            # Return worker to idle pool on failure
            submission_pool.release_worker(worker.pod_id, cool_down_seconds=0)
            logger.error("cp_session_create_failed", case_ref_id=case_ref_id,
                         pod_ip=pod_ip, error=str(e))
            raise TransientError(f"Session creation failed: {e}") from e
```

---

## 7. Session Management — Core Endpoints

```python
# control-plane/src/routers/sessions.py
"""
Session lifecycle endpoints called by N8N and browser-agent.
"""
import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import PriorAuthAgentSession, PriorAuthCaseRequest
from common.redis_layer.worker_pool import submission_pool
from services.browser_agent_client import BrowserAgentClient
from services.case_updater import CaseUpdater
from managers.session_registry import SessionRegistry
from common.logs.logger import get_logger

router = APIRouter(tags=["Sessions"])
logger = get_logger(__name__)


class CreateSessionRequest(BaseModel):
    case_ref_id:       str
    portal_id:         str
    patient_data:      dict
    clinical_data:     dict
    credential_id:     str | None = None
    shared_session_id: str | None = None


@router.post("/sessions", status_code=201)
def create_session(payload: CreateSessionRequest):
    """
    Direct HTTP alternative to Pub/Sub consumption.
    Called by N8N 'agents' webhook when control-plane subscription is unavailable.
    """
    worker = submission_pool.acquire_worker()
    if not worker:
        raise HTTPException(status_code=503, detail="No idle browser-agent workers")

    client = BrowserAgentClient(worker.pod_ip, worker.pod_port)
    try:
        resp = client.create_session(
            case_ref_id=payload.case_ref_id,
            portal_id=payload.portal_id,
            patient_data=payload.patient_data,
            clinical_data=payload.clinical_data,
            credential_id=payload.credential_id,
            shared_session_id=payload.shared_session_id,
        )
    except Exception as e:
        submission_pool.release_worker(worker.pod_id, cool_down_seconds=0)
        raise HTTPException(status_code=503, detail=f"Browser-agent error: {e}")

    SessionRegistry.add(
        session_id=resp["session_id"],
        case_ref_id=payload.case_ref_id,
        pod_id=worker.pod_id,
        pod_ip=worker.pod_ip,
    )
    return {
        "session_id":   resp["session_id"],
        "vnc_url":      resp.get("vnc_url"),
        "display_slot": resp.get("display_slot"),
        "pod_ip":       worker.pod_ip,
    }


@router.get("/sessions")
def list_sessions():
    """List all active sessions (for dashboard and debugging)."""
    return {"sessions": SessionRegistry.list_all()}


@router.delete("/sessions/{case_ref_id}", status_code=200)
def delete_session(case_ref_id: str):
    """
    Clean up session after case completion or cancellation.
    Returns the browser-agent pod to the cooling pool.
    """
    session_info = SessionRegistry.get_by_case(case_ref_id)
    if not session_info:
        logger.warning("delete_session_not_found", case_ref_id=case_ref_id)
        return {"message": "Session not found — may have already been cleaned up"}

    session_id = session_info["session_id"]
    pod_id     = session_info["pod_id"]
    pod_ip     = session_info["pod_ip"]
    pod_port   = session_info.get("pod_port", 8081)

    # Tell browser-agent to stop and clean up the session
    try:
        client = BrowserAgentClient(pod_ip, pod_port)
        client.delete_session(session_id)
    except Exception as e:
        logger.warning("browser_agent_delete_failed", session_id=session_id,
                       error=str(e))

    # Remove from registry
    SessionRegistry.remove(session_id)

    # Return pod to cooling pool
    from config import get_settings
    submission_pool.release_worker(pod_id,
                                   cool_down_seconds=get_settings().cooling_seconds)

    # Update DB session record
    with get_session_factory()() as db:
        agent_session = db.query(PriorAuthAgentSession).filter_by(
            case_ref_id=case_ref_id,
            status="ACTIVE").first()
        if agent_session:
            agent_session.status    = "COMPLETED"
            agent_session.ended_at  = datetime.now(timezone.utc)
            if agent_session.started_at:
                delta = (agent_session.ended_at - agent_session.started_at)
                agent_session.duration_seconds = int(delta.total_seconds())
            db.commit()

    logger.info("session_deleted", case_ref_id=case_ref_id,
                session_id=session_id, pod_id=pod_id)
    return {"message": "Session cleaned up", "session_id": session_id}
```

---

## 8. VNC Proxy

```python
# control-plane/src/routers/vnc_proxy.py
"""
Proxies VNC viewer HTTP and WebSocket requests from the dashboard
to the specific browser-agent pod running that case.

Dashboard URL pattern:
  GET  /api/v1/vnc/{case_ref_id}/...  → HTTP proxy to pod
  WS   /api/v1/vnc/{case_ref_id}/websockify → WebSocket proxy to pod

The dashboard doesn't need to know pod IPs — control-plane handles routing.
"""
import httpx
from fastapi import APIRouter, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import Response

from managers.session_registry import SessionRegistry
from common.logs.logger import get_logger

router = APIRouter(tags=["VNC Proxy"])
logger = get_logger(__name__)

NOVNC_HTTP_TIMEOUT = 30
WS_BUFFER_SIZE     = 65536


@router.api_route(
    "/vnc/{case_ref_id}/{path:path}",
    methods=["GET", "POST"],
    summary="Proxy HTTP requests to browser-agent noVNC",
)
async def vnc_http_proxy(case_ref_id: str, path: str, request: Request):
    session = SessionRegistry.get_by_case(case_ref_id)
    if not session:
        raise HTTPException(status_code=404,
                            detail=f"No active session for case: {case_ref_id}")

    pod_ip   = session["pod_ip"]
    web_port = session.get("web_port", 6080)
    target   = f"http://{pod_ip}:{web_port}/{path}"

    async with httpx.AsyncClient(timeout=NOVNC_HTTP_TIMEOUT) as client:
        try:
            resp = await client.request(
                method=request.method,
                url=target,
                headers={k: v for k, v in request.headers.items()
                         if k.lower() not in ("host", "content-length")},
                content=await request.body(),
            )
            return Response(
                content=resp.content,
                status_code=resp.status_code,
                headers=dict(resp.headers),
            )
        except httpx.RequestError as e:
            raise HTTPException(status_code=502,
                                detail=f"VNC proxy error: {e}")


@router.websocket("/vnc/{case_ref_id}/websockify")
async def vnc_websocket_proxy(case_ref_id: str, websocket: WebSocket):
    """
    WebSocket proxy for noVNC websockify connection.
    Bidirectional: dashboard client ↔ control-plane ↔ browser-agent websockify.
    """
    session = SessionRegistry.get_by_case(case_ref_id)
    if not session:
        await websocket.close(code=1008)
        return

    pod_ip   = session["pod_ip"]
    web_port = session.get("web_port", 6080)
    ws_url   = f"ws://{pod_ip}:{web_port}/websockify"

    await websocket.accept()
    logger.info("vnc_ws_proxy_started", case_ref_id=case_ref_id, target=ws_url)

    import websockets
    try:
        async with websockets.connect(ws_url, max_size=WS_BUFFER_SIZE) as pod_ws:
            import asyncio

            async def client_to_pod():
                while True:
                    data = await websocket.receive_bytes()
                    await pod_ws.send(data)

            async def pod_to_client():
                async for data in pod_ws:
                    if isinstance(data, bytes):
                        await websocket.send_bytes(data)
                    else:
                        await websocket.send_text(data)

            await asyncio.gather(client_to_pod(), pod_to_client())

    except WebSocketDisconnect:
        logger.info("vnc_ws_client_disconnected", case_ref_id=case_ref_id)
    except Exception as e:
        logger.warning("vnc_ws_proxy_error", case_ref_id=case_ref_id, error=str(e))
        await websocket.close(code=1011)
```

---

## 9. Heartbeat — KeepAliveSender

```python
# control-plane/src/services/keepalive_sender.py
"""
Sends heartbeat keepalive signals to all active browser-agent sessions every 30s.
Heartbeat mechanism:
  - control-plane SETEXes a Redis key: keepalive:{session_id} with TTL=90s
  - browser-agent refreshes this key from its own heartbeat loop
  - If key expires (no refresh for 90s) → ExpiredEventConsumer detects crash
"""
import threading
import time
from common.redis_layer.redis_config import get_redis_client
from common.logs.logger import get_logger
from config import get_settings
from managers.session_registry import SessionRegistry

logger = get_logger(__name__)

KEEPALIVE_KEY_TEMPLATE = "keepalive:{session_id}"


class KeepAliveSender:
    """
    Background thread: refreshes heartbeat TTL for every active session.
    If a browser-agent pod crashes, its sessions stop refreshing → TTL expires
    → ExpiredEventConsumer triggers crash recovery.
    """

    def __init__(self):
        self._stop   = threading.Event()
        self._thread = threading.Thread(
            target=self._run, name="KeepAliveSender", daemon=True)

    def start(self) -> None:
        self._thread.start()
        logger.info("keepalive_sender_started")

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=5)
        logger.info("keepalive_sender_stopped")

    def _run(self) -> None:
        settings = get_settings()
        interval = settings.heartbeat_interval_seconds
        ttl      = settings.heartbeat_ttl_seconds

        while not self._stop.wait(timeout=interval):
            sessions = SessionRegistry.list_all()
            redis    = get_redis_client()

            for sess in sessions:
                session_id  = sess["session_id"]
                keepalive_key = KEEPALIVE_KEY_TEMPLATE.format(
                    session_id=session_id)
                try:
                    redis.setex(keepalive_key, ttl, session_id)
                except Exception as e:
                    logger.warning("keepalive_set_failed",
                                   session_id=session_id, error=str(e))

            if sessions:
                logger.debug("keepalive_sent", count=len(sessions))

    @staticmethod
    def register_session(session_id: str) -> None:
        """Create the initial heartbeat key when session starts."""
        settings = get_settings()
        key      = KEEPALIVE_KEY_TEMPLATE.format(session_id=session_id)
        get_redis_client().setex(key, settings.heartbeat_ttl_seconds, session_id)

    @staticmethod
    def deregister_session(session_id: str) -> None:
        """Delete heartbeat key when session completes cleanly."""
        key = KEEPALIVE_KEY_TEMPLATE.format(session_id=session_id)
        get_redis_client().delete(key)
```

---

## 10. Crash Recovery — ExpiredEventConsumer

```python
# control-plane/src/services/expired_event_consumer.py
"""
Listens for Redis keyspace expiry events.
When a keepalive:{session_id} key expires, it means the browser-agent
pod stopped refreshing it → likely crashed.

Recovery steps:
  1. Find the case associated with the expired session
  2. Update case status → CRASHED
  3. Remove pod from worker pool
  4. Retrigger case via planner (if retry_count < max_retries)
  5. Notify N8N completed webhook with failure (if out of retries)
"""
import re
import httpx
from common.redis_layer.keyspace import KeyspaceEventConsumer
from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import (
    PriorAuthCaseRequest, PriorAuthAgentSession
)
from common.redis_layer.worker_pool import submission_pool
from common.logs.logger import get_logger
from managers.session_registry import SessionRegistry

logger = get_logger(__name__)

KEEPALIVE_PATTERN       = "keepalive:*"
COOLING_EXPIRED_PATTERN = "prior_auth_submission_cooling_*"


class ExpiredEventConsumer:
    """
    Listens for two types of key expiry:
    1. keepalive:{session_id} → pod crash detection
    2. prior_auth_submission_cooling_{pod_id} → move pod from cooling → idle
    """

    def __init__(self):
        self._consumer = KeyspaceEventConsumer()
        self._consumer.register_handler(KEEPALIVE_PATTERN, self._on_keepalive_expired)
        self._consumer.register_handler(COOLING_EXPIRED_PATTERN,
                                        self._on_cooling_expired)

    def start(self) -> None:
        self._consumer.start()
        logger.info("expired_event_consumer_started")

    def stop(self) -> None:
        self._consumer.stop()

    def _on_keepalive_expired(self, key: str) -> None:
        """
        Called when keepalive:{session_id} expires.
        Indicates the browser-agent pod crashed or lost network.
        """
        # Extract session_id from key name
        session_id = key.replace("keepalive:", "")
        logger.warning("keepalive_expired_crash_detected", session_id=session_id)

        session_info = SessionRegistry.get(session_id)
        if not session_info:
            logger.warning("expired_session_not_in_registry",
                           session_id=session_id)
            return

        case_ref_id = session_info["case_ref_id"]
        pod_id      = session_info["pod_id"]

        # Clean up registry
        SessionRegistry.remove(session_id)

        # Mark pod as crashed in pool
        submission_pool.mark_crashed(pod_id)

        # Update case status
        with get_session_factory()() as db:
            case = db.query(PriorAuthCaseRequest).filter_by(
                case_ref_id=case_ref_id).first()

            if not case:
                return

            from datetime import datetime, timezone
            case.previous_status = case.status
            case.status          = "CRASHED"
            case.last_error      = f"Pod {pod_id} crashed (heartbeat expired)"
            db.commit()

            # Update agent session record
            agent_sess = db.query(PriorAuthAgentSession).filter_by(
                session_id=session_id).first()
            if agent_sess:
                agent_sess.status   = "CRASHED"
                agent_sess.ended_at = datetime.now(timezone.utc)
                db.commit()

            can_retry = case.retry_count < case.max_retries

        logger.warning("case_crashed", case_ref_id=case_ref_id,
                       pod_id=pod_id, can_retry=can_retry)

        if can_retry:
            self._retrigger_case(case_ref_id)
        else:
            self._notify_failure(case_ref_id)

    def _on_cooling_expired(self, key: str) -> None:
        """
        Called when prior_auth_submission_cooling_{pod_id} expires.
        Moves the pod from cooling → idle in the worker pool.
        """
        pod_id = key.replace("prior_auth_submission_cooling_", "")
        submission_pool.promote_from_cooling(pod_id)
        logger.info("worker_cooling_complete", pod_id=pod_id)

    def _retrigger_case(self, case_ref_id: str) -> None:
        """POST /retrigger/{case_ref_id} on the planner service."""
        from config import get_settings
        planner_url = get_settings().planner_url
        try:
            resp = httpx.post(
                f"{planner_url}/api/v1/retrigger/{case_ref_id}",
                timeout=10,
            )
            resp.raise_for_status()
            logger.info("case_retriggered_after_crash", case_ref_id=case_ref_id)
        except Exception as e:
            logger.error("retrigger_failed", case_ref_id=case_ref_id, error=str(e))

    def _notify_failure(self, case_ref_id: str) -> None:
        """Notify N8N that case has exhausted retries."""
        from services.completion_handler import CompletionHandler
        CompletionHandler.notify_failure(case_ref_id)
```

---

## 11. HITL Management Routes

```python
# control-plane/src/routers/hitl.py
"""
HITL task management endpoints.
Operators use these (via dashboard) to:
  - List pending HITL/MFA tasks
  - Resolve a task (mark as resolved + resume agent)
  - View VNC session for the case
"""
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import PriorAuthHitlTask
from services.browser_agent_client import BrowserAgentClient
from managers.session_registry import SessionRegistry
from common.logs.logger import get_logger

router = APIRouter(tags=["HITL"])
logger = get_logger(__name__)


@router.get("/hitl/tasks")
def list_hitl_tasks(status: str = "PENDING"):
    """List HITL/MFA tasks. Used by dashboard to show pending operator actions."""
    with get_session_factory()() as session:
        tasks = session.query(PriorAuthHitlTask).filter_by(
            status=status
        ).order_by(
            PriorAuthHitlTask.task_type == "MFA",   # MFA first (shorter timeout)
            PriorAuthHitlTask.created_at.asc()
        ).all()

        return {"tasks": [
            {
                "task_id":       str(t.id),
                "case_ref_id":   t.case_ref_id,
                "task_type":     t.task_type,
                "status":        t.status,
                "message":       t.message,
                "screenshot_url":t.screenshot_url,
                "vnc_url":       t.vnc_url,
                "step_name":     t.step_name,
                "portal_id":     t.portal_id,
                "created_at":    t.created_at.isoformat(),
                "expires_at":    t.expires_at.isoformat() if t.expires_at else None,
            }
            for t in tasks
        ]}


class ResolveHitlRequest(BaseModel):
    task_id:    str
    resolution: str
    user_id:    str | None = None


@router.post("/hitl/resolve", status_code=200)
def resolve_hitl_task(payload: ResolveHitlRequest):
    """
    Operator marks a HITL task as resolved.
    Then signals the browser-agent to resume execution.
    """
    with get_session_factory()() as session:
        task = session.query(PriorAuthHitlTask).get(payload.task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        if task.status != "PENDING":
            raise HTTPException(status_code=409,
                                detail=f"Task already {task.status}")

        task.status      = "RESOLVED"
        task.resolution  = payload.resolution
        task.resolved_at = datetime.now(timezone.utc)
        if payload.user_id:
            import uuid
            task.resolved_by = uuid.UUID(payload.user_id)
        session.commit()

        case_ref_id = task.case_ref_id

    # Signal browser-agent to resume
    return _resume_agent(case_ref_id)


@router.post("/hitl/resume/{case_ref_id}", status_code=200)
def resume_agent(case_ref_id: str):
    """
    Direct resume signal — browser-agent's threading.Event is set.
    Called after HITL resolution or by operator manually.
    """
    return _resume_agent(case_ref_id)


def _resume_agent(case_ref_id: str) -> dict:
    sess = SessionRegistry.get_by_case(case_ref_id)
    if not sess:
        raise HTTPException(status_code=404,
                            detail=f"No active session for case: {case_ref_id}")

    client = BrowserAgentClient(sess["pod_ip"], sess.get("pod_port", 8081))
    try:
        client.resume_session(case_ref_id)
        logger.info("hitl_agent_resumed", case_ref_id=case_ref_id)
        return {"status": "resumed", "case_ref_id": case_ref_id}
    except Exception as e:
        raise HTTPException(status_code=502,
                            detail=f"Resume signal failed: {e}")
```

---

## 12. Tracking Session Routes

```python
# control-plane/src/routers/tracking.py
"""
Post-submission tracking session management.
Tracking-agent periodically checks the portal for PA status updates.
control-plane creates, manages, and queries tracking sessions.
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import PriorAuthTrackingSession, PriorAuthCaseRequest
from common.redis_layer.worker_pool import tracking_pool
from services.browser_agent_client import BrowserAgentClient
from common.logs.logger import get_logger

router = APIRouter(tags=["Tracking"])
logger = get_logger(__name__)


class CreateTrackingSessionRequest(BaseModel):
    case_ref_id:         str
    pa_reference_number: str
    portal_id:           str


@router.post("/tracking/sessions", status_code=201)
def create_tracking_session(payload: CreateTrackingSessionRequest):
    """
    Create a post-submission tracking session.
    Called by N8N 'completed' webhook when a case is submitted successfully.
    """
    # Acquire tracking-agent worker
    worker = tracking_pool.acquire_worker()
    if not worker:
        raise HTTPException(status_code=503,
                            detail="No idle tracking-agent workers")

    client = BrowserAgentClient(worker.pod_ip, worker.pod_port)
    try:
        resp = client.create_tracking_session(
            case_ref_id=payload.case_ref_id,
            pa_reference_number=payload.pa_reference_number,
            portal_id=payload.portal_id,
        )
    except Exception as e:
        tracking_pool.release_worker(worker.pod_id, cool_down_seconds=0)
        raise HTTPException(status_code=503, detail=f"Tracking agent error: {e}")

    # Persist tracking session to DB
    with get_session_factory()() as db:
        ts = PriorAuthTrackingSession(
            case_ref_id=payload.case_ref_id,
            pa_reference_number=payload.pa_reference_number,
            pod_id=worker.pod_id,
            pod_ip=worker.pod_ip,
            session_id=resp.get("session_id"),
            status="IN_PROGRESS",
        )
        db.add(ts)
        db.commit()

    logger.info("tracking_session_created",
                case_ref_id=payload.case_ref_id,
                pa_reference_number=payload.pa_reference_number)
    return {"session_id": resp.get("session_id"), "status": "IN_PROGRESS"}


@router.get("/tracking/sessions/{case_ref_id}")
def get_tracking_session(case_ref_id: str):
    with get_session_factory()() as db:
        ts = db.query(PriorAuthTrackingSession).filter_by(
            case_ref_id=case_ref_id).order_by(
            PriorAuthTrackingSession.created_at.desc()).first()
        if not ts:
            raise HTTPException(status_code=404,
                                detail=f"No tracking session for: {case_ref_id}")
        return {
            "case_ref_id":         ts.case_ref_id,
            "pa_reference_number": ts.pa_reference_number,
            "status":              ts.status,
            "portal_status":       ts.portal_status,
            "normalized_status":   ts.normalized_status,
            "check_count":         ts.check_count,
            "next_check_at":       ts.next_check_at.isoformat() if ts.next_check_at else None,
        }
```

---

## 13. Unit Tests

```python
# control-plane/tests/test_session_consumer.py
import pytest
from unittest.mock import MagicMock, patch
from consumer.session_consumer import ControlPlaneSessionConsumer
from common.pubsub_layer.base_consumer import PermanentError, TransientError
from common.redis_layer.worker_pool import WorkerInfo


@pytest.fixture
def consumer():
    return ControlPlaneSessionConsumer.__new__(ControlPlaneSessionConsumer)


def test_permanent_error_on_missing_case_ref(consumer):
    with pytest.raises(PermanentError):
        consumer.process_message({"portal_id": "availity"}, {})


def test_transient_error_when_no_workers(consumer):
    mock_case = MagicMock()
    mock_case.status      = "PENDING"
    mock_case.retry_count = 0

    with patch("consumer.session_consumer.get_session_factory") as mock_sf, \
         patch("consumer.session_consumer.submission_pool") as mock_pool:

        mock_session = MagicMock()
        mock_session.__enter__ = MagicMock(return_value=mock_session)
        mock_session.__exit__  = MagicMock(return_value=False)
        mock_session.query.return_value.filter_by.return_value.first.return_value = mock_case
        mock_sf.return_value.return_value = mock_session

        mock_pool.acquire_worker.return_value = None

        with pytest.raises(TransientError, match="No idle"):
            consumer.process_message(
                {"case_ref_id": "CASE-001", "portal_id": "availity"}, {}
            )


def test_skips_cancelled_case(consumer):
    mock_case        = MagicMock()
    mock_case.status = "CANCELLED"

    with patch("consumer.session_consumer.get_session_factory") as mock_sf, \
         patch("consumer.session_consumer.submission_pool") as mock_pool:

        mock_session = MagicMock()
        mock_session.__enter__ = MagicMock(return_value=mock_session)
        mock_session.__exit__  = MagicMock(return_value=False)
        mock_session.query.return_value.filter_by.return_value.first.return_value = mock_case
        mock_sf.return_value.return_value = mock_session

        consumer.process_message(
            {"case_ref_id": "CASE-CANCEL", "portal_id": "availity"}, {}
        )

        mock_pool.acquire_worker.assert_not_called()
```

```python
# control-plane/tests/test_expired_event_consumer.py
import pytest
from unittest.mock import MagicMock, patch, call
from services.expired_event_consumer import ExpiredEventConsumer


def test_on_cooling_expired_promotes_worker():
    consumer = ExpiredEventConsumer.__new__(ExpiredEventConsumer)
    consumer._consumer = MagicMock()

    with patch("services.expired_event_consumer.submission_pool") as mock_pool:
        consumer._on_cooling_expired("prior_auth_submission_cooling_pod-abc")
        mock_pool.promote_from_cooling.assert_called_once_with("pod-abc")


def test_on_keepalive_expired_marks_case_crashed():
    consumer = ExpiredEventConsumer.__new__(ExpiredEventConsumer)
    consumer._consumer = MagicMock()

    mock_session_info = {
        "session_id":  "sess-xyz",
        "case_ref_id": "CASE-001",
        "pod_id":      "pod-abc",
    }
    mock_case = MagicMock()
    mock_case.status      = "IN_PROGRESS"
    mock_case.retry_count = 0
    mock_case.max_retries = 3

    db_session = MagicMock()
    db_session.__enter__ = MagicMock(return_value=db_session)
    db_session.__exit__  = MagicMock(return_value=False)
    db_session.query.return_value.filter_by.return_value.first.return_value = mock_case

    with patch("services.expired_event_consumer.SessionRegistry") as mock_reg, \
         patch("services.expired_event_consumer.submission_pool") as mock_pool, \
         patch("services.expired_event_consumer.get_session_factory",
               return_value=MagicMock(return_value=db_session)), \
         patch.object(consumer, "_retrigger_case") as mock_retrigger:

        mock_reg.get.return_value       = mock_session_info
        mock_reg.get_by_case.return_value = mock_session_info

        consumer._on_keepalive_expired("keepalive:sess-xyz")

        mock_pool.mark_crashed.assert_called_once_with("pod-abc")
        assert mock_case.status == "CRASHED"
        mock_retrigger.assert_called_once_with("CASE-001")
```

---

*Document Status: DRAFT*
*Previous: [09_Planner_Implementation.md](09_Planner_Implementation.md)*
*Next: [11_Browser_Agent_Implementation.md](11_Browser_Agent_Implementation.md)*
