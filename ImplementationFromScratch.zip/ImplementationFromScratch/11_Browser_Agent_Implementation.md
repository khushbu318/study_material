# AutoAuth Agent — Browser Agent Implementation
**Phase 3 | Sprints 5–6 | Weeks 13–16**
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026
**Version:** 1.0
**Prerequisite:** [10_Control_Plane_Implementation.md](10_Control_Plane_Implementation.md)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Project Structure](#2-project-structure)
3. [Configuration & Settings](#3-configuration--settings)
4. [Display Allocation — Xvfb + VNC](#4-display-allocation--xvfb--vnc)
5. [Application Entry Point & Lifespan](#5-application-entry-point--lifespan)
6. [Session Lifecycle — Core Endpoints](#6-session-lifecycle--core-endpoints)
7. [Recipe Loading & Caching](#7-recipe-loading--caching)
8. [RecipeRunner — All 14 Action Types](#8-reciperunner--all-14-action-types)
9. [resolve_value() Runtime](#9-resolve_value-runtime)
10. [CAPTCHA Integration](#10-captcha-integration)
11. [HITL Flow — threading.Event](#11-hitl-flow--threadingevent)
12. [MFA Flow — threading.Queue](#12-mfa-flow--threadingqueue)
13. [LLM Agent Mode — browser-use](#13-llm-agent-mode--browser-use)
14. [Completion Callbacks & SummarizationThread](#14-completion-callbacks--summarizationthread)
15. [Redis Log Streaming & Heartbeat](#15-redis-log-streaming--heartbeat)
16. [Unit Tests](#16-unit-tests)

---

## 1. Overview

The **browser-agent** is the execution engine that physically navigates payer portals. Each pod:

```
Control-plane sends POST /sessions
       │
       ▼
DisplayAllocator.acquire()  → Xvfb :99, :100, :101 (3 slots per pod)
       │
       ▼
VNCManager.start(display)   → x11vnc + websockify on ports 5900/6080
       │
       ▼
Playwright.launch()         → Chromium on DISPLAY=:99
       │
       ▼
SessionThread (daemon)
  ├── load_recipe()         → GET /recipes/{portal_id} (LRU cached)
  ├── RecipeRunner.run()    → 14 action types (click, type, select, ...)
  │     ├── resolve_value() → 7 template sources
  │     ├── CAPTCHA         → Capsolver 2captcha/image
  │     ├── HITL wait       → threading.Event.wait(timeout)
  │     └── MFA wait        → threading.Queue.get(timeout)
  ├── extract PA reference
  ├── POST completion webhook to N8N
  └── SummarizationThread  → AI summary of case run
       │
       ▼
Redis Stream                → XADD for dashboard log streaming
Heartbeat Thread            → SETEX keepalive key every 30s
```

---

## 2. Project Structure

```
browser-agent/
├── pyproject.toml
├── Dockerfile                     # See Document 6 for full Dockerfile
└── src/
    ├── main.py
    ├── config.py
    ├── display/
    │   ├── __init__.py
    │   ├── allocator.py           # Xvfb slot management
    │   └── vnc_manager.py         # x11vnc + websockify lifecycle
    ├── sessions/
    │   ├── __init__.py
    │   ├── session_store.py       # In-memory session registry
    │   └── session_thread.py      # Background execution thread
    ├── recipe/
    │   ├── __init__.py
    │   ├── loader.py              # LRU-cached recipe fetch
    │   ├── runner.py              # RecipeRunner (all 14 action types)
    │   ├── resolver.py            # resolve_value() with 7 sources
    │   └── pick_option.py         # Fuzzy dropdown matching
    ├── captcha/
    │   ├── __init__.py
    │   └── capsolver_client.py    # Capsolver API integration
    ├── hitl/
    │   ├── __init__.py
    │   └── hitl_manager.py        # threading.Event registry
    ├── mfa/
    │   ├── __init__.py
    │   └── mfa_manager.py         # threading.Queue registry (shared with planner via HTTP)
    ├── llm/
    │   ├── __init__.py
    │   ├── agent_runner.py        # browser-use LLM agent
    │   └── custom_tools.py        # 5 custom ADK tools
    ├── services/
    │   ├── __init__.py
    │   ├── api_server_client.py   # GET /recipes, PATCH case status
    │   ├── completion_service.py  # N8N webhook callbacks
    │   └── summarization.py       # SummarizationThread (AI summary)
    ├── streaming/
    │   ├── __init__.py
    │   └── log_streamer.py        # Redis XADD log streaming
    ├── heartbeat/
    │   ├── __init__.py
    │   └── heartbeat_thread.py    # 30s keepalive SETEX
    └── routers/
        ├── __init__.py
        ├── sessions.py            # POST/DELETE /sessions
        ├── control.py             # /resume, /abort
        └── health.py
```

---

## 3. Configuration & Settings

```python
# browser-agent/src/config.py
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    app_env:      str = Field("prod",          env="APP_ENV")
    service_name: str = Field("browser-agent", env="SERVICE_NAME")
    log_level:    str = Field("INFO",          env="LOG_LEVEL")

    pod_id:  str = Field(..., env="POD_ID")    # K8s downward API: metadata.name
    pod_ip:  str = Field(..., env="POD_IP")    # K8s downward API: status.podIP
    pod_port: int = Field(8081, env="POD_PORT")

    # Database
    db_host:     str = Field(..., env="DB_HOST")
    db_port:     int = Field(5432, env="DB_PORT")
    db_user:     str = Field(..., env="DB_USER")
    db_password: str = Field(..., env="DB_PASSWORD")
    db_name:     str = Field(..., env="DB_NAME")

    # Redis
    redis_host: str  = Field(..., env="REDIS_HOST")
    redis_port: int  = Field(6379, env="REDIS_PORT")
    redis_auth: str  = Field("",   env="REDIS_AUTH")
    redis_tls:  bool = Field(False, env="REDIS_TLS")

    # API server (for recipe fetch + case patching)
    api_server_url: str = Field("http://api-server:8080", env="API_SERVER_URL")

    # Control plane (for completion callbacks + HITL creation)
    control_plane_url: str = Field("http://control-plane:8083", env="CONTROL_PLANE_URL")

    # N8N
    n8n_completed_webhook_url:      str = Field(..., env="N8N_COMPLETED_WEBHOOK_URL")
    n8n_status_capture_webhook_url: str = Field(..., env="N8N_STATUS_CAPTURE_WEBHOOK_URL")
    n8n_webhook_secret:             str = Field(..., env="N8N_WEBHOOK_SECRET")

    # Capsolver (CAPTCHA)
    capsolver_api_key: str = Field(..., env="CAPSOLVER_API_KEY")

    # Display / VNC
    display_slots:      int = Field(3,    env="DISPLAY_SLOTS")
    base_display_number: int = Field(99,  env="BASE_DISPLAY_NUMBER")
    base_vnc_port:      int = Field(5900, env="BASE_VNC_PORT")
    base_web_port:      int = Field(6080, env="BASE_WEB_PORT")

    # Heartbeat
    heartbeat_interval_seconds: int = Field(30, env="HEARTBEAT_INTERVAL_SECONDS")
    heartbeat_ttl_seconds:      int = Field(90, env="HEARTBEAT_TTL_SECONDS")

    # Recipe timeout defaults (seconds)
    default_action_timeout: int = Field(30,  env="DEFAULT_ACTION_TIMEOUT")
    default_page_timeout:   int = Field(60,  env="DEFAULT_PAGE_TIMEOUT")
    hitl_wait_timeout:      int = Field(1800, env="HITL_WAIT_TIMEOUT")
    mfa_wait_timeout:       int = Field(300,  env="MFA_WAIT_TIMEOUT")

    # AI summarization
    anthropic_api_key: str = Field(..., env="ANTHROPIC_API_KEY")
    summary_model:     str = Field("claude-haiku-4-5-20251001", env="SUMMARY_MODEL")

    class Config:
        env_file = ".env"
        case_sensitive = False


_settings: Settings | None = None

def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
```

---

## 4. Display Allocation — Xvfb + VNC

```python
# browser-agent/src/display/allocator.py
"""
Manages Xvfb virtual display slots. Each session gets its own
DISPLAY number, VNC port, and web (noVNC) port.

Slot layout (default 3 slots):
  Slot 0: DISPLAY=:99  VNC=5900  WEB=6080
  Slot 1: DISPLAY=:100 VNC=5901  WEB=6081
  Slot 2: DISPLAY=:101 VNC=5902  WEB=6082
"""
import subprocess
import threading
from dataclasses import dataclass
from typing import Optional
from common.logs.logger import get_logger
from config import get_settings

logger = get_logger(__name__)


@dataclass
class DisplaySlot:
    slot_index:     int
    display_number: int
    display_env:    str   # e.g. ":99"
    vnc_port:       int
    web_port:       int
    session_id:     str | None = None
    xvfb_process:   object     = None


class DisplayAllocator:
    """Thread-safe allocator for Xvfb virtual display slots."""

    _lock:  threading.Lock
    _slots: list[DisplaySlot]
    _initialized: bool = False

    @classmethod
    def initialize(cls) -> None:
        settings     = get_settings()
        cls._lock    = threading.Lock()
        cls._slots   = []
        cls._initialized = True

        for i in range(settings.display_slots):
            display_num = settings.base_display_number + i
            slot = DisplaySlot(
                slot_index=i,
                display_number=display_num,
                display_env=f":{display_num}",
                vnc_port=settings.base_vnc_port + i,
                web_port=settings.base_web_port + i,
            )
            # Start Xvfb for this slot immediately at startup
            slot.xvfb_process = cls._start_xvfb(display_num)
            cls._slots.append(slot)
            logger.info("display_slot_initialized",
                        slot_index=i, display=slot.display_env)

    @classmethod
    def _start_xvfb(cls, display_number: int) -> subprocess.Popen:
        cmd = [
            "Xvfb", f":{display_number}",
            "-screen", "0", "1920x1080x24",
            "-ac",         # disable access control
            "+extension", "GLX",
            "+render",
            "-noreset",
        ]
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        logger.info("xvfb_started", display=f":{display_number}", pid=proc.pid)
        return proc

    @classmethod
    def acquire(cls, session_id: str) -> Optional[DisplaySlot]:
        """Find a free slot and assign it to this session."""
        with cls._lock:
            for slot in cls._slots:
                if slot.session_id is None:
                    slot.session_id = session_id
                    logger.info("display_slot_acquired",
                                slot=slot.slot_index, session_id=session_id)
                    return slot
        return None

    @classmethod
    def release(cls, session_id: str) -> None:
        """Free the slot when session ends."""
        with cls._lock:
            for slot in cls._slots:
                if slot.session_id == session_id:
                    slot.session_id = None
                    logger.info("display_slot_released",
                                slot=slot.slot_index, session_id=session_id)
                    return

    @classmethod
    def get_slot_for_session(cls, session_id: str) -> Optional[DisplaySlot]:
        for slot in cls._slots:
            if slot.session_id == session_id:
                return slot
        return None

    @classmethod
    def shutdown(cls) -> None:
        """Terminate all Xvfb processes at pod shutdown."""
        for slot in cls._slots:
            if slot.xvfb_process:
                slot.xvfb_process.terminate()
```

```python
# browser-agent/src/display/vnc_manager.py
"""
Manages x11vnc and websockify processes per display slot.
x11vnc: exports the Xvfb framebuffer over VNC protocol
websockify: bridges WebSocket → VNC for noVNC web client
"""
import subprocess
import time
from common.logs.logger import get_logger
from display.allocator import DisplaySlot

logger = get_logger(__name__)


class VNCManager:

    @staticmethod
    def start(slot: DisplaySlot) -> tuple[subprocess.Popen, subprocess.Popen]:
        """Start x11vnc + websockify for the given display slot."""
        # x11vnc
        x11vnc_proc = subprocess.Popen([
            "x11vnc",
            "-display", slot.display_env,
            "-rfbport", str(slot.vnc_port),
            "-shared",
            "-forever",
            "-nopw",           # no VNC password (cluster-internal only)
            "-quiet",
            "-noxdamage",
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # Brief pause to let x11vnc bind its port
        time.sleep(0.5)

        # websockify (bridges WS → VNC for noVNC browser client)
        websockify_proc = subprocess.Popen([
            "websockify",
            "--web", "/opt/novnc",
            str(slot.web_port),
            f"localhost:{slot.vnc_port}",
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        logger.info("vnc_started",
                    display=slot.display_env,
                    vnc_port=slot.vnc_port,
                    web_port=slot.web_port)

        return x11vnc_proc, websockify_proc

    @staticmethod
    def stop(x11vnc_proc: subprocess.Popen,
             websockify_proc: subprocess.Popen) -> None:
        for proc in (x11vnc_proc, websockify_proc):
            if proc and proc.poll() is None:
                proc.terminate()
```

---

## 5. Application Entry Point & Lifespan

```python
# browser-agent/src/main.py
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI

from common.logs.logger import configure_logging, get_logger
from common.db_layer.db_config import get_engine
from common.redis_layer.redis_config import get_redis_client
from config import get_settings
from display.allocator import DisplayAllocator
from routers import sessions, control, health

os.environ.setdefault("SERVICE_NAME", "browser-agent")
configure_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    logger.info("browser_agent_starting",
                pod_id=settings.pod_id, env=settings.app_env)

    # Verify connections
    with get_engine().connect() as conn:
        conn.execute("SELECT 1")
    get_redis_client().ping()

    # Initialize virtual displays (Xvfb)
    DisplayAllocator.initialize()

    # Register this pod with control-plane
    _register_with_control_plane(settings)

    logger.info("browser_agent_ready",
                display_slots=settings.display_slots)
    yield

    # Shutdown: clean up all displays
    DisplayAllocator.shutdown()
    logger.info("browser_agent_shutdown")


def _register_with_control_plane(settings) -> None:
    """Tell control-plane this pod is available."""
    import httpx
    try:
        httpx.post(
            f"{settings.control_plane_url}/api/v1/agents/register",
            json={
                "pod_id":       settings.pod_id,
                "pod_ip":       settings.pod_ip,
                "pod_port":     settings.pod_port,
                "agent_type":   "browser_agent",
                "max_sessions": settings.display_slots,
            },
            timeout=10,
        )
        logger.info("registered_with_control_plane")
    except Exception as e:
        logger.warning("control_plane_registration_failed", error=str(e))


def create_app() -> FastAPI:
    app = FastAPI(
        title="AutoAuth Agent — Browser Agent",
        version="1.0.0",
        docs_url=None, redoc_url=None,
        lifespan=lifespan,
    )
    app.include_router(sessions.router, prefix="/api/v1")
    app.include_router(control.router,  prefix="/api/v1")
    app.include_router(health.router)
    return app


app = create_app()
```

---

## 6. Session Lifecycle — Core Endpoints

```python
# browser-agent/src/routers/sessions.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sessions.session_store import SessionStore
from sessions.session_thread import SessionThread
from display.allocator import DisplayAllocator
from display.vnc_manager import VNCManager
from config import get_settings
from common.logs.logger import get_logger

router = APIRouter(tags=["Sessions"])
logger = get_logger(__name__)


class CreateSessionRequest(BaseModel):
    case_ref_id:       str
    portal_id:         str
    patient_data:      dict
    clinical_data:     dict
    credential_id:     str | None = None
    shared_session_id: str | None = None


@router.post("/sessions", status_code=201)
def create_session(payload: CreateSessionRequest):
    """
    Called by control-plane when it assigns this pod to a case.
    1. Acquire Xvfb display slot
    2. Start x11vnc + websockify for VNC access
    3. Launch SessionThread (recipe execution)
    """
    settings = get_settings()

    # Acquire display slot
    import uuid
    session_id = str(uuid.uuid4())
    slot = DisplayAllocator.acquire(session_id)
    if not slot:
        raise HTTPException(
            status_code=503,
            detail="All display slots are occupied on this pod"
        )

    # Start VNC
    x11vnc_proc, websockify_proc = VNCManager.start(slot)
    vnc_url = (
        f"http://{settings.pod_ip}:{slot.web_port}/vnc.html"
        f"?host={settings.pod_ip}&port={slot.web_port}&autoconnect=true"
    )

    # Launch session thread
    thread = SessionThread(
        session_id=session_id,
        case_ref_id=payload.case_ref_id,
        portal_id=payload.portal_id,
        patient_data=payload.patient_data,
        clinical_data=payload.clinical_data,
        credential_id=payload.credential_id,
        shared_session_id=payload.shared_session_id,
        slot=slot,
        x11vnc_proc=x11vnc_proc,
        websockify_proc=websockify_proc,
    )
    SessionStore.add(session_id, thread)
    thread.start()

    logger.info("session_created",
                session_id=session_id,
                case_ref_id=payload.case_ref_id,
                display=slot.display_env)

    return {
        "session_id":   session_id,
        "display_slot": slot.slot_index,
        "vnc_url":      vnc_url,
        "web_port":     slot.web_port,
        "vnc_port":     slot.vnc_port,
    }


@router.delete("/sessions/{session_id}", status_code=200)
def delete_session(session_id: str):
    """Stop a running session (cancel or cleanup after completion)."""
    thread = SessionStore.get(session_id)
    if not thread:
        return {"message": "Session not found or already cleaned up"}

    thread.abort()
    SessionStore.remove(session_id)
    DisplayAllocator.release(session_id)
    return {"message": "Session stopped", "session_id": session_id}


# browser-agent/src/routers/control.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from hitl.hitl_manager import HITLManager
from sessions.session_store import SessionStore
from common.logs.logger import get_logger

router = APIRouter(tags=["Control"])
logger = get_logger(__name__)


@router.post("/resume/{case_ref_id}", status_code=200)
def resume_case(case_ref_id: str):
    """Signal browser-agent to resume after HITL resolution."""
    event = HITLManager.get_event(case_ref_id)
    if not event:
        raise HTTPException(status_code=404,
                            detail=f"No HITL event for case: {case_ref_id}")
    event.set()
    logger.info("hitl_resumed", case_ref_id=case_ref_id)
    return {"status": "resumed", "case_ref_id": case_ref_id}


@router.post("/abort/{case_ref_id}", status_code=200)
def abort_case(case_ref_id: str):
    """Abort a running session immediately."""
    thread = SessionStore.get_by_case(case_ref_id)
    if not thread:
        return {"message": "No active session for case"}
    thread.abort()
    return {"status": "aborted", "case_ref_id": case_ref_id}
```

---

## 7. Recipe Loading & Caching

```python
# browser-agent/src/recipe/loader.py
"""
Fetches YAML recipes from api-server and caches them in-process.
LRU cache of 32 portals — sufficient for all payers.
Cache invalidation: explicit call from admin endpoint,
or TTL-based via timestamp check every 5 minutes.
"""
import time
import yaml
import httpx
from functools import lru_cache
from common.logs.logger import get_logger
from config import get_settings

logger = get_logger(__name__)

_recipe_cache:       dict[str, dict] = {}
_recipe_fetch_times: dict[str, float] = {}
CACHE_TTL_SECONDS = 300  # 5 minutes


def load_recipe(portal_id: str) -> dict:
    """
    Load recipe for a portal_id.
    Returns parsed YAML as a dict with 'steps' list.
    """
    now = time.monotonic()
    cached_time = _recipe_fetch_times.get(portal_id, 0)

    if portal_id in _recipe_cache and (now - cached_time) < CACHE_TTL_SECONDS:
        return _recipe_cache[portal_id]

    settings  = get_settings()
    url       = f"{settings.api_server_url}/api/v1/recipes/{portal_id}"
    try:
        resp = httpx.get(url, timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except httpx.RequestError as e:
        raise RuntimeError(f"Failed to fetch recipe for {portal_id}: {e}")

    recipe_yaml = data.get("recipe_yaml") or data.get("yaml_content")
    if not recipe_yaml:
        raise ValueError(f"No recipe content returned for portal: {portal_id}")

    parsed = yaml.safe_load(recipe_yaml)
    _recipe_cache[portal_id]       = parsed
    _recipe_fetch_times[portal_id] = now

    logger.info("recipe_loaded", portal_id=portal_id,
                steps=len(parsed.get("steps", [])))
    return parsed


def invalidate_recipe_cache(portal_id: str | None = None) -> None:
    """Invalidate one portal's cache, or all caches."""
    if portal_id:
        _recipe_cache.pop(portal_id, None)
        _recipe_fetch_times.pop(portal_id, None)
    else:
        _recipe_cache.clear()
        _recipe_fetch_times.clear()
```

---

## 8. RecipeRunner — All 14 Action Types

```python
# browser-agent/src/recipe/runner.py
"""
Executes a loaded recipe against a live Playwright page.
Supports all 14 action types. Each step is wrapped in error handling
with configurable retry and screenshot-on-failure.
"""
import time
import json
import base64
from typing import Any

from playwright.sync_api import Page, TimeoutError as PwTimeout
from common.logs.logger import get_logger
from streaming.log_streamer import LogStreamer
from recipe.resolver import resolve_value
from recipe.pick_option import pick_option
from captcha.capsolver_client import CapsolverClient
from hitl.hitl_manager import HITLManager
from mfa.mfa_manager import MFAManager
from config import get_settings

logger = get_logger(__name__)


class RecipeStepError(Exception):
    pass

class RecipeExtractError(Exception):
    pass


class RecipeRunner:
    """
    Executes recipe steps sequentially against a Playwright page.
    Context accumulates extracted values across steps via ctx dict.
    """

    def __init__(self, page: Page, session_id: str, case_ref_id: str,
                 patient_data: dict, clinical_data: dict, credentials: dict,
                 log_streamer: LogStreamer):
        self.page         = page
        self.session_id   = session_id
        self.case_ref_id  = case_ref_id
        self.patient_data = patient_data
        self.clinical_data = clinical_data
        self.credentials  = credentials
        self.streamer     = log_streamer
        self.settings     = get_settings()
        self.ctx: dict[str, Any] = {}   # runtime context: extracted values, loop vars

    def run(self, recipe: dict) -> dict:
        """Execute all steps. Returns final context (including pa_reference_number)."""
        steps = recipe.get("steps", [])
        self._log(f"Starting recipe '{recipe.get('name')}' — {len(steps)} steps")

        i = 0
        while i < len(steps):
            step = steps[i]
            action = step.get("action")

            if action == "foreach":
                self._run_foreach(step)
                i += 1
                continue

            try:
                self._execute_step(step)
            except RecipeStepError as e:
                if step.get("on_failure") == "continue":
                    self._log(f"[WARN] Step '{step.get('name')}' failed (continuing): {e}")
                elif step.get("on_failure") == "abort":
                    raise RuntimeError(f"Aborted at step '{step.get('name')}': {e}")
                else:
                    raise

            i += 1

        return self.ctx

    # ─────────────────────────────────────────────────────────────────────────
    # Core dispatcher
    # ─────────────────────────────────────────────────────────────────────────

    def _execute_step(self, step: dict) -> None:
        action   = step.get("action")
        name     = step.get("name", action)
        timeout  = step.get("timeout", self.settings.default_action_timeout) * 1000
        retry    = step.get("retry", 1)

        self._log(f"Step: [{action}] {name}")

        for attempt in range(1, retry + 1):
            try:
                match action:
                    case "navigate":        self._navigate(step, timeout)
                    case "click":           self._click(step, timeout)
                    case "type":            self._type(step, timeout)
                    case "select":          self._select(step, timeout)
                    case "wait":            self._wait(step, timeout)
                    case "wait_for_text":   self._wait_for_text(step, timeout)
                    case "extract":         self._extract(step, timeout)
                    case "screenshot":      self._screenshot(step)
                    case "solve_captcha":   self._solve_captcha(step, timeout)
                    case "request_hitl":    self._request_hitl(step)
                    case "wait_for_mfa":    self._wait_for_mfa(step)
                    case "upload_file":     self._upload_file(step, timeout)
                    case "check_checkbox":  self._check_checkbox(step, timeout)
                    case "condition":       self._condition(step, timeout)
                    case _:
                        raise RecipeStepError(f"Unknown action type: '{action}'")
                return  # success — break retry loop

            except (RecipeStepError, PwTimeout) as e:
                if attempt < retry:
                    self._log(f"  Retry {attempt}/{retry} after error: {e}")
                    time.sleep(1)
                else:
                    raise RecipeStepError(f"{name} failed after {retry} attempts: {e}")

    # ─────────────────────────────────────────────────────────────────────────
    # Action Implementations
    # ─────────────────────────────────────────────────────────────────────────

    def _navigate(self, step: dict, timeout: int) -> None:
        """Action: navigate — load a URL."""
        url = self._resolve(step["url"])
        self.page.goto(url, timeout=timeout, wait_until="networkidle")
        self._log(f"  Navigated to: {url}")

    def _click(self, step: dict, timeout: int) -> None:
        """Action: click — click a selector."""
        selector  = self._resolve(step["selector"])
        wait_for  = step.get("wait_for_navigation", False)
        locator   = self.page.locator(selector)
        locator.wait_for(state="visible", timeout=timeout)
        if wait_for:
            with self.page.expect_navigation(timeout=timeout):
                locator.click(timeout=timeout)
        else:
            locator.click(timeout=timeout)
        self._log(f"  Clicked: {selector}")

    def _type(self, step: dict, timeout: int) -> None:
        """Action: type — fill an input field."""
        selector = self._resolve(step["selector"])
        value    = self._resolve(step["value"])
        clear    = step.get("clear_first", True)

        locator = self.page.locator(selector)
        locator.wait_for(state="visible", timeout=timeout)

        if clear:
            locator.clear()
        locator.fill(value)
        self._log(f"  Typed into: {selector} (value redacted)")

    def _select(self, step: dict, timeout: int) -> None:
        """
        Action: select — choose option from <select> or custom dropdown.
        Supports exact match, fuzzy match, and aria-label-based dropdowns.
        """
        selector    = self._resolve(step["selector"])
        value       = self._resolve(step["value"])
        match_type  = step.get("match_type", "exact")
        select_type = step.get("select_type", "native")

        locator = self.page.locator(selector)
        locator.wait_for(state="visible", timeout=timeout)

        if select_type == "native":
            # Native HTML <select>
            options = locator.locator("option").all_inner_texts()
            matched = pick_option(value, options, match_type)
            locator.select_option(label=matched)

        elif select_type == "custom":
            # Custom dropdown: click to open, then click matching option
            locator.click()
            option_selector = step.get("option_selector", "li[role='option']")
            all_options = self.page.locator(option_selector).all()
            texts   = [o.inner_text() for o in all_options]
            matched = pick_option(value, texts, match_type)
            self.page.locator(option_selector).filter(has_text=matched).click()

        self._log(f"  Selected '{value}' from: {selector}")

    def _wait(self, step: dict, timeout: int) -> None:
        """Action: wait — sleep for given milliseconds."""
        ms = step.get("duration_ms", 1000)
        self.page.wait_for_timeout(ms)
        self._log(f"  Waited {ms}ms")

    def _wait_for_text(self, step: dict, timeout: int) -> None:
        """Action: wait_for_text — wait until element contains expected text."""
        selector      = self._resolve(step["selector"])
        expected_text = self._resolve(step["text"])
        self.page.locator(selector).filter(
            has_text=expected_text
        ).wait_for(state="visible", timeout=timeout)
        self._log(f"  Found text '{expected_text}' in: {selector}")

    def _extract(self, step: dict, timeout: int) -> None:
        """
        Action: extract — pull a value from the page and store in ctx.
        Supports: text_content, inner_html, attribute, input_value, url, regex.
        """
        selector       = self._resolve(step["selector"])
        extract_type   = step.get("extract_type", "text_content")
        variable_name  = step["variable_name"]
        regex_pattern  = step.get("regex")

        locator = self.page.locator(selector)
        locator.wait_for(state="visible", timeout=timeout)

        match extract_type:
            case "text_content":
                raw = locator.inner_text()
            case "inner_html":
                raw = locator.inner_html()
            case "attribute":
                raw = locator.get_attribute(step["attribute"])
            case "input_value":
                raw = locator.input_value()
            case "url":
                raw = self.page.url
            case _:
                raise RecipeExtractError(f"Unknown extract_type: {extract_type}")

        if regex_pattern:
            import re
            match = re.search(regex_pattern, raw or "")
            if not match:
                raise RecipeExtractError(
                    f"Regex '{regex_pattern}' found no match in: {raw!r}")
            raw = match.group(step.get("regex_group", 1))

        self.ctx[variable_name] = raw
        self._log(f"  Extracted '{variable_name}' = '{raw}'")

    def _screenshot(self, step: dict) -> None:
        """Action: screenshot — capture current page state to Redis stream."""
        png_bytes   = self.page.screenshot(type="png")
        b64_data    = base64.b64encode(png_bytes).decode()
        description = step.get("description", "screenshot")
        self.streamer.push_screenshot(b64_data, description)
        self._log(f"  Screenshot captured: {description}")

    def _solve_captcha(self, step: dict, timeout: int) -> None:
        """
        Action: solve_captcha — submit CAPTCHA to Capsolver and fill result.
        Supports: image_captcha, recaptcha_v2, hcaptcha.
        """
        captcha_type  = step.get("captcha_type", "image_captcha")
        target_field  = step.get("target_selector")
        client        = CapsolverClient()

        if captcha_type == "image_captcha":
            img_selector = self._resolve(step["image_selector"])
            locator      = self.page.locator(img_selector)
            locator.wait_for(state="visible", timeout=timeout)
            img_bytes = locator.screenshot()
            b64_img   = base64.b64encode(img_bytes).decode()
            solution  = client.solve_image(b64_img)

        elif captcha_type == "recaptcha_v2":
            site_key = step["site_key"]
            page_url = self.page.url
            solution = client.solve_recaptcha_v2(site_key, page_url)
            # Inject into g-recaptcha-response field
            self.page.evaluate(
                f"document.getElementById('g-recaptcha-response').innerHTML = '{solution}'"
            )
            if target_field:
                self.page.locator(target_field).fill(solution)
            self._log("  ReCAPTCHA v2 solved")
            return

        elif captcha_type == "hcaptcha":
            site_key = step["site_key"]
            page_url = self.page.url
            solution = client.solve_hcaptcha(site_key, page_url)

        else:
            raise RecipeStepError(f"Unknown captcha_type: {captcha_type}")

        if target_field:
            field = self.page.locator(self._resolve(target_field))
            field.wait_for(state="visible", timeout=timeout)
            field.fill(solution)

        self.ctx["captcha_solution"] = solution
        self._log(f"  CAPTCHA solved (type={captcha_type})")

    def _request_hitl(self, step: dict) -> None:
        """
        Action: request_hitl — pause execution, notify operator via N8N/dashboard.
        Waits up to hitl_wait_timeout seconds for operator to resolve and resume.
        """
        message         = self._resolve(step.get("message", "Manual intervention required"))
        step_name       = step.get("name", "hitl_step")
        screenshot_b64  = None

        # Capture screenshot for operator context
        try:
            png_bytes      = self.page.screenshot(type="png")
            screenshot_b64 = base64.b64encode(png_bytes).decode()
        except Exception:
            pass

        self._log(f"  Requesting HITL: {message}")

        # Persist HITL task to DB + notify N8N
        _create_hitl_task(
            case_ref_id=self.case_ref_id,
            session_id=self.session_id,
            task_type="HITL",
            message=message,
            step_name=step_name,
            screenshot_b64=screenshot_b64,
        )

        # Register threading.Event
        event = HITLManager.create_event(self.case_ref_id)

        # Block until operator resolves (or timeout)
        timeout_s = self.settings.hitl_wait_timeout
        resolved  = event.wait(timeout=timeout_s)

        HITLManager.close_event(self.case_ref_id)

        if not resolved:
            raise RecipeStepError(f"HITL timed out after {timeout_s}s: {message}")

        self._log("  HITL resolved — resuming")

    def _wait_for_mfa(self, step: dict) -> None:
        """
        Action: wait_for_mfa — wait for OTP delivered via planner /handle-mfa endpoint.
        OTP is stored in planner's MFAService.threading.Queue, forwarded here via Redis
        pub/sub or directly through a shared in-process mechanism (see note below).

        Note: In production, MFA OTP is delivered from planner → api-server /handle-mfa
        → planner MFAService.deliver_otp() → threading.Queue.
        The browser-agent polls via Redis key: mfa_otp:{case_ref_id}.
        Planner writes the OTP there; browser-agent reads and deletes it.
        This avoids cross-service threading.Queue coordination.
        """
        target_selector = self._resolve(step.get("target_selector", ""))
        timeout_s       = step.get("timeout", self.settings.mfa_wait_timeout)

        # Notify operator MFA is needed (push to dashboard)
        _create_hitl_task(
            case_ref_id=self.case_ref_id,
            session_id=self.session_id,
            task_type="MFA",
            message="MFA code required — please enter OTP in dashboard",
            step_name=step.get("name", "mfa_step"),
        )
        self._log("  Waiting for MFA OTP...")

        # Poll Redis for OTP (written by planner MFAService after operator input)
        import time as t
        from common.redis_layer.redis_config import get_redis_client
        otp_key   = f"mfa_otp:{self.case_ref_id}"
        redis     = get_redis_client()
        deadline  = t.monotonic() + timeout_s
        otp_value = None

        while t.monotonic() < deadline:
            otp_value = redis.get(otp_key)
            if otp_value:
                redis.delete(otp_key)
                break
            t.sleep(2)

        if not otp_value:
            raise RecipeStepError(f"MFA OTP not received within {timeout_s}s")

        if target_selector:
            field = self.page.locator(target_selector)
            field.wait_for(state="visible",
                           timeout=self.settings.default_action_timeout * 1000)
            field.fill(otp_value)

        self.ctx["mfa_otp"] = otp_value
        self._log("  MFA OTP received and entered")

    def _upload_file(self, step: dict, timeout: int) -> None:
        """Action: upload_file — attach a file to an input[type=file]."""
        selector  = self._resolve(step["selector"])
        file_path = self._resolve(step["file_path"])
        locator   = self.page.locator(selector)
        locator.wait_for(state="attached", timeout=timeout)
        locator.set_input_files(file_path)
        self._log(f"  Uploaded file: {file_path}")

    def _check_checkbox(self, step: dict, timeout: int) -> None:
        """Action: check_checkbox — ensure a checkbox is checked or unchecked."""
        selector = self._resolve(step["selector"])
        checked  = step.get("checked", True)
        locator  = self.page.locator(selector)
        locator.wait_for(state="visible", timeout=timeout)

        if checked and not locator.is_checked():
            locator.check()
        elif not checked and locator.is_checked():
            locator.uncheck()

        self._log(f"  Checkbox {'checked' if checked else 'unchecked'}: {selector}")

    def _condition(self, step: dict, timeout: int) -> None:
        """
        Action: condition — branch on element presence.
        Executes 'then_steps' if selector is visible, 'else_steps' otherwise.
        """
        selector   = self._resolve(step["selector"])
        then_steps = step.get("then_steps", [])
        else_steps = step.get("else_steps", [])

        try:
            self.page.locator(selector).wait_for(state="visible", timeout=timeout)
            is_present = True
        except PwTimeout:
            is_present = False

        branch_steps = then_steps if is_present else else_steps
        for branch_step in branch_steps:
            self._execute_step(branch_step)

    def _run_foreach(self, step: dict) -> None:
        """
        Action: foreach — iterate over a list extracted to ctx.
        Context variable name from 'iterate_over', loop var in 'loop_variable'.
        """
        iterate_over   = step["iterate_over"]
        loop_variable  = step["loop_variable"]
        loop_steps     = step.get("steps", [])

        items = self.ctx.get(iterate_over, [])
        if isinstance(items, str):
            # Allow comma-separated string
            items = [i.strip() for i in items.split(",") if i.strip()]

        self._log(f"  foreach over '{iterate_over}' — {len(items)} items")
        for item in items:
            self.ctx[loop_variable] = item
            for loop_step in loop_steps:
                self._execute_step(loop_step)

    # ─────────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _resolve(self, template: Any) -> str:
        if not isinstance(template, str):
            return str(template)
        return resolve_value(
            template,
            patient_data=self.patient_data,
            clinical_data=self.clinical_data,
            credentials=self.credentials,
            context=self.ctx,
        )

    def _log(self, message: str) -> None:
        logger.info("recipe_step", case_ref_id=self.case_ref_id, msg=message)
        self.streamer.push_log(message)
```

---

## 9. resolve_value() Runtime

```python
# browser-agent/src/recipe/resolver.py
"""
Resolves {{source.path}} template strings.

7 sources:
  patient    → patient_data JSONB (e.g. {{patient.member_id}})
  clinical   → clinical_data JSONB (e.g. {{clinical.diagnosis_codes}})
  credentials → portal credentials from GCP Secret Manager
  env        → OS environment variables
  context    → runtime ctx dict (extracted values, loop variables)
  static     → literal string pass-through (no braces)
  computed   → built-in computations: today_date, now_iso, uuid
"""
import os
import re
import uuid
from datetime import date, datetime, timezone
from typing import Any

_TEMPLATE_RE = re.compile(r"\{\{([^}]+)\}\}")


def resolve_value(template: str, patient_data: dict, clinical_data: dict,
                  credentials: dict, context: dict) -> str:
    """Replace all {{source.key}} tokens in template."""
    def _replace(match: re.Match) -> str:
        token = match.group(1).strip()
        return _resolve_token(token, patient_data, clinical_data,
                               credentials, context)

    return _TEMPLATE_RE.sub(_replace, template)


def _resolve_token(token: str, patient_data: dict, clinical_data: dict,
                   credentials: dict, context: dict) -> str:
    parts  = token.split(".", maxsplit=1)
    source = parts[0]
    path   = parts[1] if len(parts) > 1 else ""

    match source:
        case "patient":
            value = _get_nested(patient_data, path)
        case "clinical":
            value = _get_nested(clinical_data, path)
        case "credentials":
            value = credentials.get(path, "")
        case "env":
            value = os.environ.get(path, "")
        case "context":
            value = _get_nested(context, path)
        case "computed":
            value = _computed(path)
        case _:
            # Treat as static passthrough
            value = token

    return str(value) if value is not None else ""


def _get_nested(data: dict, path: str) -> Any:
    """Traverse dot-separated path through nested dict/list."""
    keys  = path.split(".")
    value = data
    for key in keys:
        if isinstance(value, dict):
            value = value.get(key)
        elif isinstance(value, list):
            try:
                value = value[int(key)]
            except (ValueError, IndexError):
                return None
        else:
            return None
        if value is None:
            return None
    return value


def _computed(name: str) -> str:
    match name:
        case "today_date":
            return date.today().strftime("%m/%d/%Y")
        case "today_iso":
            return date.today().isoformat()
        case "now_iso":
            return datetime.now(timezone.utc).isoformat()
        case "uuid":
            return str(uuid.uuid4())
        case _:
            return ""
```

```python
# browser-agent/src/recipe/pick_option.py
"""
Fuzzy matching for dropdown option selection.
Strategy (in order):
  1. Exact match (case-insensitive)
  2. Contains match (target in option)
  3. Starts-with match
  4. Levenshtein distance ≤ 3
"""
from common.logs.logger import get_logger

logger = get_logger(__name__)


def pick_option(target: str, options: list[str],
                match_type: str = "fuzzy") -> str:
    """
    Find best match for target in options list.
    Raises ValueError if no match found.
    """
    target_lower = target.lower().strip()

    # 1. Exact
    for opt in options:
        if opt.lower().strip() == target_lower:
            return opt

    if match_type == "exact":
        raise ValueError(f"No exact match for '{target}' in {options}")

    # 2. Contains
    for opt in options:
        if target_lower in opt.lower():
            return opt

    # 3. Starts-with
    for opt in options:
        if opt.lower().startswith(target_lower):
            return opt

    # 4. Levenshtein ≤ 3
    best_opt   = None
    best_dist  = 999
    for opt in options:
        dist = _levenshtein(target_lower, opt.lower().strip())
        if dist < best_dist:
            best_dist = dist
            best_opt  = opt

    if best_opt and best_dist <= 3:
        logger.warning("pick_option_fuzzy_match",
                       target=target, matched=best_opt, distance=best_dist)
        return best_opt

    raise ValueError(
        f"No match for '{target}' in {options} (best distance: {best_dist})")


def _levenshtein(a: str, b: str) -> int:
    if len(a) < len(b):
        return _levenshtein(b, a)
    if len(b) == 0:
        return len(a)
    prev_row = range(len(b) + 1)
    for i, ca in enumerate(a):
        curr_row = [i + 1]
        for j, cb in enumerate(b):
            insert = prev_row[j + 1] + 1
            delete = curr_row[j] + 1
            replace = prev_row[j] + (ca != cb)
            curr_row.append(min(insert, delete, replace))
        prev_row = curr_row
    return prev_row[-1]
```

---

## 10. CAPTCHA Integration

```python
# browser-agent/src/captcha/capsolver_client.py
"""
Capsolver API client for automated CAPTCHA solving.
Supports: ImageToText, ReCaptchaV2Task, HCaptchaTask.
Capsolver docs: https://docs.capsolver.com
"""
import time
import httpx
from config import get_settings
from common.logs.logger import get_logger

logger = get_logger(__name__)

CAPSOLVER_API = "https://api.capsolver.com"
POLL_INTERVAL = 3   # seconds between status checks
MAX_WAIT      = 120 # seconds before giving up


class CapsolverClient:

    def __init__(self):
        self.api_key = get_settings().capsolver_api_key

    def solve_image(self, image_b64: str) -> str:
        """Solve image/text CAPTCHA. Returns text solution."""
        task_id = self._create_task({
            "type":   "ImageToTextTask",
            "body":   image_b64,
            "module": "common",
        })
        return self._wait_for_solution(task_id)

    def solve_recaptcha_v2(self, site_key: str, page_url: str) -> str:
        """Solve ReCAPTCHA v2. Returns g-recaptcha-response token."""
        task_id = self._create_task({
            "type":        "ReCaptchaV2Task",
            "websiteURL":  page_url,
            "websiteKey":  site_key,
        })
        return self._wait_for_solution(task_id)

    def solve_hcaptcha(self, site_key: str, page_url: str) -> str:
        """Solve HCaptcha. Returns token."""
        task_id = self._create_task({
            "type":       "HCaptchaTask",
            "websiteURL": page_url,
            "websiteKey": site_key,
        })
        return self._wait_for_solution(task_id)

    def _create_task(self, task: dict) -> str:
        resp = httpx.post(
            f"{CAPSOLVER_API}/createTask",
            json={"clientKey": self.api_key, "task": task},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        if data.get("errorId", 0) != 0:
            raise RuntimeError(f"Capsolver error: {data.get('errorDescription')}")
        task_id = data["taskId"]
        logger.info("captcha_task_created", task_id=task_id,
                    task_type=task["type"])
        return task_id

    def _wait_for_solution(self, task_id: str) -> str:
        deadline = time.monotonic() + MAX_WAIT
        while time.monotonic() < deadline:
            time.sleep(POLL_INTERVAL)
            resp = httpx.post(
                f"{CAPSOLVER_API}/getTaskResult",
                json={"clientKey": self.api_key, "taskId": task_id},
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()

            if data.get("status") == "ready":
                solution = (data.get("solution", {}).get("text")
                            or data.get("solution", {}).get("gRecaptchaResponse")
                            or data.get("solution", {}).get("token"))
                logger.info("captcha_solved", task_id=task_id)
                return solution

            if data.get("errorId", 0) != 0:
                raise RuntimeError(f"Capsolver task failed: {data}")

        raise TimeoutError(f"Capsolver task {task_id} timed out after {MAX_WAIT}s")
```

---

## 11. HITL Flow — threading.Event

```python
# browser-agent/src/hitl/hitl_manager.py
"""
Manages per-case threading.Event objects used to pause recipe execution
while waiting for operator intervention.

RecipeRunner calls:
  event = HITLManager.create_event(case_ref_id)
  resolved = event.wait(timeout=1800)  # blocks this SessionThread
  HITLManager.close_event(case_ref_id)

Control-plane /resume endpoint calls:
  event = HITLManager.get_event(case_ref_id)
  event.set()  # unblocks RecipeRunner
"""
import threading
from common.logs.logger import get_logger

logger = get_logger(__name__)

_events: dict[str, threading.Event] = {}
_lock   = threading.Lock()


class HITLManager:

    @staticmethod
    def create_event(case_ref_id: str) -> threading.Event:
        event = threading.Event()
        with _lock:
            _events[case_ref_id] = event
        logger.info("hitl_event_created", case_ref_id=case_ref_id)
        return event

    @staticmethod
    def get_event(case_ref_id: str) -> threading.Event | None:
        with _lock:
            return _events.get(case_ref_id)

    @staticmethod
    def close_event(case_ref_id: str) -> None:
        with _lock:
            _events.pop(case_ref_id, None)
        logger.info("hitl_event_closed", case_ref_id=case_ref_id)

    @staticmethod
    def list_active() -> list[str]:
        with _lock:
            return list(_events.keys())


def _create_hitl_task(case_ref_id: str, session_id: str, task_type: str,
                      message: str, step_name: str,
                      screenshot_b64: str | None = None) -> None:
    """Persist HITL task to DB and notify N8N."""
    from datetime import datetime, timezone, timedelta
    from common.db_layer.db_config import get_session_factory
    from common.db_layer.orm_models import PriorAuthHitlTask
    from config import get_settings

    settings = get_settings()
    expires  = datetime.now(timezone.utc) + timedelta(
        seconds=settings.hitl_wait_timeout)

    with get_session_factory()() as db:
        task = PriorAuthHitlTask(
            case_ref_id=case_ref_id,
            session_id=session_id,
            task_type=task_type,
            status="PENDING",
            message=message,
            step_name=step_name,
            expires_at=expires,
        )
        db.add(task)
        db.commit()

    # Notify N8N (fire-and-forget)
    import httpx, hmac, hashlib, json, time
    payload    = json.dumps({"case_ref_id": case_ref_id,
                              "task_type": task_type, "message": message})
    signature  = hmac.new(
        settings.n8n_webhook_secret.encode(),
        payload.encode(), hashlib.sha256
    ).hexdigest()
    try:
        httpx.post(
            settings.n8n_status_capture_webhook_url,
            content=payload,
            headers={"X-Signature": signature,
                     "Content-Type": "application/json"},
            timeout=5,
        )
    except Exception:
        pass  # Non-critical — operator sees task in dashboard regardless
```

---

## 12. MFA Flow — threading.Queue

```python
# browser-agent/src/mfa/mfa_manager.py
"""
The actual MFA OTP delivery uses Redis as the cross-service transport:

Flow:
  1. Operator enters OTP in dashboard
  2. Dashboard → POST /handle-mfa/{case_ref_id} on api-server
  3. api-server → POST /handle-mfa/{case_ref_id} on planner
  4. Planner: redis.setex(f"mfa_otp:{case_ref_id}", 300, otp_code)
  5. browser-agent: polls redis.get(f"mfa_otp:{case_ref_id}") every 2s
  6. On receipt: redis.delete(key) → fill OTP on page

This module provides the Redis write side used by the planner's MFAService.
The read/poll side is in RecipeRunner._wait_for_mfa().
"""
from common.redis_layer.redis_config import get_redis_client
from common.logs.logger import get_logger

logger = get_logger(__name__)

MFA_KEY_TEMPLATE = "mfa_otp:{case_ref_id}"
MFA_KEY_TTL      = 300   # 5 minutes


class MFARedisWriter:
    """Used by planner MFAService to deliver OTP to the waiting browser-agent."""

    @staticmethod
    def deliver(case_ref_id: str, otp_code: str) -> None:
        key   = MFA_KEY_TEMPLATE.format(case_ref_id=case_ref_id)
        redis = get_redis_client()
        redis.setex(key, MFA_KEY_TTL, otp_code)
        logger.info("mfa_otp_written_to_redis", case_ref_id=case_ref_id)

    @staticmethod
    def is_pending(case_ref_id: str) -> bool:
        key = MFA_KEY_TEMPLATE.format(case_ref_id=case_ref_id)
        return get_redis_client().exists(key) > 0
```

---

## 13. LLM Agent Mode — browser-use

```python
# browser-agent/src/llm/agent_runner.py
"""
LLM fallback mode using browser-use when no recipe exists for a portal
or when recipe execution fails and the step has fallback_to_llm: true.

Uses Google Gemini (via ADK) + browser-use library.
5 custom tools extend the agent's capability for AutoAuth-specific operations.
"""
import asyncio
import threading
from playwright.async_api import async_playwright
from common.logs.logger import get_logger
from llm.custom_tools import (
    CaptchaSolverTool, RequestHitlTool, RequestMfaTool,
    ExtractPaReferenceTool, AbortTaskTool,
)
from config import get_settings
from streaming.log_streamer import LogStreamer

logger = get_logger(__name__)


class LLMAgentRunner:
    """
    Runs browser-use LLM agent in an isolated async event loop
    (SessionThread is synchronous; we spin up a new loop for the agent).
    """

    def __init__(self, session_id: str, case_ref_id: str,
                 portal_id: str, patient_data: dict, clinical_data: dict,
                 credentials: dict, display_env: str,
                 log_streamer: LogStreamer):
        self.session_id   = session_id
        self.case_ref_id  = case_ref_id
        self.portal_id    = portal_id
        self.patient_data = patient_data
        self.credentials  = credentials
        self.display_env  = display_env
        self.streamer     = log_streamer
        settings          = get_settings()

    def run(self, portal_url: str, task_description: str) -> dict:
        """Run LLM agent synchronously (blocks until complete)."""
        loop   = asyncio.new_event_loop()
        result = loop.run_until_complete(
            self._run_async(portal_url, task_description)
        )
        loop.close()
        return result

    async def _run_async(self, portal_url: str, task_description: str) -> dict:
        import os
        os.environ["DISPLAY"] = self.display_env

        # Import browser-use only here (optional dependency)
        from browser_use import Agent as BrowserAgent, Browser, BrowserConfig
        import anthropic

        settings = get_settings()
        client   = anthropic.Anthropic(api_key=settings.anthropic_api_key)

        tools = [
            CaptchaSolverTool(self.session_id),
            RequestHitlTool(self.case_ref_id),
            RequestMfaTool(self.case_ref_id),
            ExtractPaReferenceTool(self.session_id),
            AbortTaskTool(self.session_id),
        ]

        prompt = self._build_prompt(portal_url, task_description)

        browser = Browser(config=BrowserConfig(
            headless=False,          # runs on Xvfb display
            disable_security=False,
        ))

        agent  = BrowserAgent(
            task=prompt,
            llm=client,
            browser=browser,
            additional_tools=tools,
            max_steps=100,
        )

        try:
            result = await agent.run()
            return {"status": "completed", "result": str(result)}
        finally:
            await browser.close()

    def _build_prompt(self, portal_url: str, task_description: str) -> str:
        return f"""
You are an AI assistant completing a Prior Authorization (PA) submission on
a healthcare payer portal. You have access to the following patient info:
  - Member ID: {self.patient_data.get('member_id', 'N/A')}
  - Patient Name: {self.patient_data.get('first_name')} {self.patient_data.get('last_name')}
  - Date of Birth: {self.patient_data.get('date_of_birth', 'N/A')}

Your task: {task_description}

Start at: {portal_url}

Use your portal credentials (provided via the CaptchaSolverTool for CAPTCHAs,
RequestHitlTool when manual intervention is needed, and ExtractPaReferenceTool
once a PA reference number is visible).

IMPORTANT:
- Do NOT navigate away from the portal domain
- Do NOT submit duplicate PA requests — check if a PA already exists first
- Extract and report the PA reference number when submission is confirmed
- If you encounter an unrecoverable error, call AbortTaskTool
""".strip()
```

```python
# browser-agent/src/llm/custom_tools.py
"""
5 custom tools for the LLM agent that expose AutoAuth-specific capabilities.
These integrate with browser-agent internals (CAPTCHA, HITL, MFA, extraction).
"""
from common.logs.logger import get_logger

logger = get_logger(__name__)


class CaptchaSolverTool:
    """Tool: solve a CAPTCHA from a base64-encoded image."""
    name        = "solve_captcha"
    description = "Solve a CAPTCHA. Call with the image selector CSS path."

    def __init__(self, session_id: str):
        self.session_id = session_id

    def __call__(self, image_selector: str) -> str:
        from captcha.capsolver_client import CapsolverClient
        # The agent will have taken a screenshot of the selector externally
        # This tool is invoked as a signal to use Capsolver
        client = CapsolverClient()
        # In practice, agent passes the b64 image in a follow-up interaction
        return "CAPTCHA solving initiated. Please provide the image bytes."


class RequestHitlTool:
    """Tool: pause execution and request human operator intervention."""
    name        = "request_human_intervention"
    description = ("Pause the task and notify a human operator to manually "
                   "complete a step. Provide a description of what is needed.")

    def __init__(self, case_ref_id: str):
        self.case_ref_id = case_ref_id

    def __call__(self, description: str) -> str:
        from hitl.hitl_manager import HITLManager, _create_hitl_task
        import threading
        _create_hitl_task(
            case_ref_id=self.case_ref_id,
            session_id="llm_agent",
            task_type="HITL",
            message=description,
            step_name="llm_hitl",
        )
        event    = HITLManager.create_event(self.case_ref_id)
        resolved = event.wait(timeout=1800)
        HITLManager.close_event(self.case_ref_id)
        return "Human intervention complete. Continue the task." if resolved \
               else "Human intervention timed out. Abort the task."


class RequestMfaTool:
    """Tool: wait for an OTP code from the operator."""
    name        = "request_mfa_code"
    description = "Wait for an MFA/OTP code to be provided by the operator."

    def __init__(self, case_ref_id: str):
        self.case_ref_id = case_ref_id

    def __call__(self) -> str:
        import time
        from common.redis_layer.redis_config import get_redis_client
        key      = f"mfa_otp:{self.case_ref_id}"
        redis    = get_redis_client()
        deadline = time.monotonic() + 300

        while time.monotonic() < deadline:
            otp = redis.get(key)
            if otp:
                redis.delete(key)
                return f"MFA code received: {otp}"
            time.sleep(2)

        return "MFA code not received within 5 minutes. Aborting."


class ExtractPaReferenceTool:
    """Tool: signal that a PA reference number has been found."""
    name        = "extract_pa_reference"
    description = "Call this when you see a PA reference/confirmation number on screen."

    def __init__(self, session_id: str):
        self.session_id = session_id

    def __call__(self, pa_reference_number: str) -> str:
        from sessions.session_store import SessionStore
        thread = SessionStore.get(self.session_id)
        if thread:
            thread.set_pa_reference(pa_reference_number)
        logger.info("llm_pa_reference_extracted",
                    session_id=self.session_id,
                    pa_reference_number=pa_reference_number)
        return f"PA reference number '{pa_reference_number}' captured. Task complete."


class AbortTaskTool:
    """Tool: signal unrecoverable failure and stop execution."""
    name        = "abort_task"
    description = "Call when you encounter an unrecoverable error."

    def __init__(self, session_id: str):
        self.session_id = session_id

    def __call__(self, reason: str) -> str:
        logger.warning("llm_agent_abort",
                       session_id=self.session_id, reason=reason)
        raise RuntimeError(f"LLM agent aborted: {reason}")
```

---

## 14. Completion Callbacks & SummarizationThread

```python
# browser-agent/src/sessions/session_thread.py
"""
SessionThread runs the full case execution lifecycle.
It is a standard daemon thread launched by POST /sessions.
"""
import threading
import time
import traceback
from playwright.sync_api import sync_playwright, Playwright

from display.allocator import DisplaySlot
from display.vnc_manager import VNCManager
from recipe.loader import load_recipe
from recipe.runner import RecipeRunner
from services.completion_service import CompletionService
from services.summarization import SummarizationThread
from streaming.log_streamer import LogStreamer
from heartbeat.heartbeat_thread import HeartbeatThread
from common.secret.secret_manager import get_portal_credentials
from common.logs.logger import get_logger, set_trace_id

logger = get_logger(__name__)


class SessionThread(threading.Thread):

    def __init__(self, session_id: str, case_ref_id: str, portal_id: str,
                 patient_data: dict, clinical_data: dict,
                 credential_id: str | None, shared_session_id: str | None,
                 slot: DisplaySlot, x11vnc_proc, websockify_proc):
        super().__init__(name=f"Session-{case_ref_id}", daemon=True)
        self.session_id        = session_id
        self.case_ref_id       = case_ref_id
        self.portal_id         = portal_id
        self.patient_data      = patient_data
        self.clinical_data     = clinical_data
        self.credential_id     = credential_id
        self.shared_session_id = shared_session_id
        self.slot              = slot
        self.x11vnc_proc       = x11vnc_proc
        self.websockify_proc   = websockify_proc
        self._abort            = threading.Event()
        self._pa_reference: str | None = None

    def set_pa_reference(self, reference: str) -> None:
        self._pa_reference = reference

    def abort(self) -> None:
        self._abort.set()

    def run(self) -> None:
        set_trace_id(self.case_ref_id)
        streamer  = LogStreamer(self.case_ref_id, self.session_id)
        heartbeat = HeartbeatThread(self.session_id)
        heartbeat.start()

        try:
            self._execute(streamer)
        except Exception as e:
            tb = traceback.format_exc()
            logger.error("session_thread_failed",
                         case_ref_id=self.case_ref_id, error=str(e), tb=tb)
            streamer.push_log(f"[FATAL] {e}")
            CompletionService.notify_failure(
                self.case_ref_id, reason=str(e),
                session_id=self.session_id)
        finally:
            heartbeat.stop()
            self._cleanup(streamer)

    def _execute(self, streamer: LogStreamer) -> None:
        import os
        os.environ["DISPLAY"] = self.slot.display_env

        # Load credentials from Secret Manager
        credentials = {}
        if self.credential_id:
            credentials = get_portal_credentials(self.credential_id)

        # Load recipe
        recipe    = load_recipe(self.portal_id)
        exec_mode = recipe.get("mode", "recipe")

        with sync_playwright() as pw:
            browser = pw.chromium.launch(
                headless=False,
                args=[
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-blink-features=AutomationControlled",
                    f"--window-size=1920,1080",
                ],
            )
            page = browser.new_page(
                viewport={"width": 1920, "height": 1080},
                user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                            "AppleWebKit/537.36 Chrome/124.0 Safari/537.36"),
            )

            if exec_mode == "recipe":
                runner = RecipeRunner(
                    page=page,
                    session_id=self.session_id,
                    case_ref_id=self.case_ref_id,
                    patient_data=self.patient_data,
                    clinical_data=self.clinical_data,
                    credentials=credentials,
                    log_streamer=streamer,
                )
                ctx = runner.run(recipe)
                self._pa_reference = (ctx.get("pa_reference_number")
                                      or ctx.get("confirmation_number"))

            elif exec_mode == "llm":
                from llm.agent_runner import LLMAgentRunner
                llm_runner = LLMAgentRunner(
                    session_id=self.session_id,
                    case_ref_id=self.case_ref_id,
                    portal_id=self.portal_id,
                    patient_data=self.patient_data,
                    clinical_data=self.clinical_data,
                    credentials=credentials,
                    display_env=self.slot.display_env,
                    log_streamer=streamer,
                )
                llm_runner.run(
                    portal_url=recipe.get("portal_url", ""),
                    task_description=recipe.get("task_description", ""),
                )

            page.screenshot(path=f"/tmp/{self.case_ref_id}_final.png")
            browser.close()

        # Trigger summarization (non-blocking)
        summary_thread = SummarizationThread(
            case_ref_id=self.case_ref_id,
            session_id=self.session_id,
            log_streamer=streamer,
        )
        summary_thread.start()
        # Notify N8N of successful completion
        CompletionService.notify_success(
            case_ref_id=self.case_ref_id,
            session_id=self.session_id,
            pa_reference_number=self._pa_reference,
        )

    def _cleanup(self, streamer: LogStreamer) -> None:
        VNCManager.stop(self.x11vnc_proc, self.websockify_proc)
        from display.allocator import DisplayAllocator
        DisplayAllocator.release(self.session_id)
        streamer.close()
        logger.info("session_cleaned_up",
                    case_ref_id=self.case_ref_id, session_id=self.session_id)
```

```python
# browser-agent/src/services/completion_service.py
"""N8N webhook callbacks for case completion and failure."""
import hmac
import hashlib
import json
import httpx
from config import get_settings
from common.logs.logger import get_logger

logger = get_logger(__name__)


class CompletionService:

    @staticmethod
    def notify_success(case_ref_id: str, session_id: str,
                       pa_reference_number: str | None) -> None:
        settings = get_settings()
        payload  = {
            "case_ref_id":         case_ref_id,
            "session_id":          session_id,
            "status":              "SUBMITTED",
            "pa_reference_number": pa_reference_number,
        }
        _post_with_signature(settings.n8n_completed_webhook_url,
                             payload, settings.n8n_webhook_secret)
        logger.info("completion_notified",
                    case_ref_id=case_ref_id, pa_ref=pa_reference_number)

    @staticmethod
    def notify_failure(case_ref_id: str, reason: str, session_id: str) -> None:
        settings = get_settings()
        payload  = {
            "case_ref_id": case_ref_id,
            "session_id":  session_id,
            "status":      "CRASHED",
            "reason":      reason,
        }
        _post_with_signature(settings.n8n_status_capture_webhook_url,
                             payload, settings.n8n_webhook_secret)
        logger.warning("failure_notified",
                       case_ref_id=case_ref_id, reason=reason)


def _post_with_signature(url: str, payload: dict, secret: str,
                          retries: int = 3) -> None:
    body      = json.dumps(payload)
    signature = hmac.new(secret.encode(), body.encode(),
                          hashlib.sha256).hexdigest()
    headers   = {"X-Signature": signature, "Content-Type": "application/json"}

    for attempt in range(1, retries + 1):
        try:
            resp = httpx.post(url, content=body, headers=headers, timeout=15)
            resp.raise_for_status()
            return
        except Exception as e:
            if attempt == retries:
                logger.error("n8n_webhook_failed", url=url, error=str(e))
            else:
                import time
                time.sleep(attempt * 2)
```

```python
# browser-agent/src/services/summarization.py
"""
SummarizationThread: runs after case completion to generate an AI summary
of the execution log. Stored as an annotation on the case record.
"""
import threading
from common.logs.logger import get_logger
from streaming.log_streamer import LogStreamer
from config import get_settings

logger = get_logger(__name__)


class SummarizationThread(threading.Thread):

    def __init__(self, case_ref_id: str, session_id: str,
                 log_streamer: LogStreamer):
        super().__init__(name=f"Summary-{case_ref_id}", daemon=True)
        self.case_ref_id  = case_ref_id
        self.session_id   = session_id
        self.streamer     = log_streamer

    def run(self) -> None:
        try:
            log_text = self.streamer.get_full_log_text()
            if not log_text:
                return

            settings = get_settings()
            import anthropic
            client   = anthropic.Anthropic(api_key=settings.anthropic_api_key)

            message  = client.messages.create(
                model=settings.summary_model,
                max_tokens=512,
                messages=[{
                    "role": "user",
                    "content": (
                        "Summarize the following prior authorization submission "
                        "log in 3-4 sentences. Focus on: portal navigated, "
                        "steps completed, any issues encountered, "
                        "and the final outcome.\n\n"
                        f"LOG:\n{log_text[:4000]}"
                    ),
                }],
            )
            summary  = message.content[0].text

            # Persist to DB
            from common.db_layer.db_config import get_session_factory
            from common.db_layer.orm_models import PriorAuthAgentSession
            with get_session_factory()() as db:
                sess = db.query(PriorAuthAgentSession).filter_by(
                    session_id=self.session_id).first()
                if sess:
                    sess.execution_summary = summary
                    db.commit()

            logger.info("summarization_complete", case_ref_id=self.case_ref_id)
        except Exception as e:
            logger.warning("summarization_failed",
                           case_ref_id=self.case_ref_id, error=str(e))
```

---

## 15. Redis Log Streaming & Heartbeat

```python
# browser-agent/src/streaming/log_streamer.py
"""
Streams execution logs to Redis XADD for live dashboard consumption.
Also provides a method to retrieve all logs as text for summarization.
"""
import threading
from datetime import datetime, timezone
from common.redis_layer.redis_config import get_redis_client
from common.logs.logger import get_logger

logger = get_logger(__name__)

STREAM_KEY_TEMPLATE = "case_logs:{case_ref_id}"
STREAM_MAXLEN       = 500    # approx max entries per stream
STREAM_TTL_SECONDS  = 172800 # 2 days


class LogStreamer:

    def __init__(self, case_ref_id: str, session_id: str):
        self.case_ref_id = case_ref_id
        self.session_id  = session_id
        self.stream_key  = STREAM_KEY_TEMPLATE.format(case_ref_id=case_ref_id)
        self._lock       = threading.Lock()

    def push_log(self, message: str, level: str = "INFO") -> None:
        """Add a text log line to the Redis Stream."""
        with self._lock:
            try:
                redis = get_redis_client()
                redis.xadd(
                    self.stream_key,
                    {
                        "ts":         datetime.now(timezone.utc).isoformat(),
                        "level":      level,
                        "session_id": self.session_id,
                        "msg":        message,
                    },
                    maxlen=STREAM_MAXLEN,
                    approximate=True,
                )
                redis.expire(self.stream_key, STREAM_TTL_SECONDS)
            except Exception as e:
                # Never raise — log streaming is non-critical
                logger.debug("log_stream_xadd_failed", error=str(e))

    def push_screenshot(self, b64_png: str, description: str) -> None:
        """Add a screenshot entry (base64 PNG) to the stream."""
        with self._lock:
            try:
                redis = get_redis_client()
                redis.xadd(
                    self.stream_key,
                    {
                        "ts":          datetime.now(timezone.utc).isoformat(),
                        "type":        "screenshot",
                        "description": description,
                        "data":        b64_png[:32768],  # cap at ~24KB
                    },
                    maxlen=STREAM_MAXLEN,
                    approximate=True,
                )
            except Exception:
                pass

    def get_full_log_text(self) -> str:
        """Read all stream entries and concatenate as plain text."""
        try:
            redis   = get_redis_client()
            entries = redis.xrange(self.stream_key, count=500)
            lines   = []
            for _, fields in entries:
                if fields.get("type") == "screenshot":
                    continue
                ts  = fields.get("ts", "")
                msg = fields.get("msg", "")
                lines.append(f"[{ts}] {msg}")
            return "\n".join(lines)
        except Exception as e:
            logger.warning("log_stream_read_failed", error=str(e))
            return ""

    def close(self) -> None:
        """Mark the stream as completed (final log entry)."""
        self.push_log("[SESSION END]")
```

```python
# browser-agent/src/heartbeat/heartbeat_thread.py
"""
Refreshes the keepalive Redis key every heartbeat_interval_seconds.
Stops when stop() is called or the session ends.
The control-plane's ExpiredEventConsumer watches this key.
If not refreshed within heartbeat_ttl_seconds → crash is detected.
"""
import threading
from common.redis_layer.redis_config import get_redis_client
from config import get_settings
from common.logs.logger import get_logger

logger = get_logger(__name__)

KEEPALIVE_KEY_TEMPLATE = "keepalive:{session_id}"


class HeartbeatThread(threading.Thread):

    def __init__(self, session_id: str):
        super().__init__(name=f"Heartbeat-{session_id}", daemon=True)
        self.session_id = session_id
        self._stop      = threading.Event()

    def start(self) -> None:
        # Write initial key immediately on start
        self._refresh()
        super().start()

    def stop(self) -> None:
        self._stop.set()
        # Delete key on clean shutdown so control-plane doesn't think we crashed
        key = KEEPALIVE_KEY_TEMPLATE.format(session_id=self.session_id)
        try:
            get_redis_client().delete(key)
        except Exception:
            pass
        logger.info("heartbeat_stopped", session_id=self.session_id)

    def run(self) -> None:
        settings = get_settings()
        interval = settings.heartbeat_interval_seconds

        while not self._stop.wait(timeout=interval):
            self._refresh()

    def _refresh(self) -> None:
        settings = get_settings()
        key      = KEEPALIVE_KEY_TEMPLATE.format(session_id=self.session_id)
        try:
            get_redis_client().setex(key, settings.heartbeat_ttl_seconds,
                                     self.session_id)
        except Exception as e:
            logger.warning("heartbeat_refresh_failed",
                           session_id=self.session_id, error=str(e))
```

---

## 16. Unit Tests

```python
# browser-agent/tests/test_resolver.py
import pytest
from recipe.resolver import resolve_value


PATIENT  = {"member_id": "M12345", "first_name": "Jane", "dob": "1990-05-15",
             "address": {"zip": "30301"}}
CLINICAL = {"diagnosis_codes": ["M79.3", "G89.29"]}
CREDS    = {"username": "portal_user"}
CTX      = {"pa_number": "PA-2024-001", "loop_item": "M79.3"}


def test_patient_simple():
    assert resolve_value("{{patient.member_id}}", PATIENT, CLINICAL, CREDS, CTX) == "M12345"

def test_patient_nested():
    assert resolve_value("{{patient.address.zip}}", PATIENT, CLINICAL, CREDS, CTX) == "30301"

def test_clinical_list_index():
    assert resolve_value("{{clinical.diagnosis_codes.0}}", PATIENT, CLINICAL, CREDS, CTX) == "M79.3"

def test_context_loop_variable():
    assert resolve_value("{{context.loop_item}}", PATIENT, CLINICAL, CREDS, CTX) == "M79.3"

def test_mixed_template():
    tmpl   = "Member: {{patient.member_id}} — PA: {{context.pa_number}}"
    result = resolve_value(tmpl, PATIENT, CLINICAL, CREDS, CTX)
    assert result == "Member: M12345 — PA: PA-2024-001"

def test_computed_today_date():
    import re
    result = resolve_value("{{computed.today_date}}", PATIENT, CLINICAL, CREDS, CTX)
    assert re.match(r"\d{2}/\d{2}/\d{4}", result)

def test_unknown_source_passthrough():
    result = resolve_value("{{static_value}}", PATIENT, CLINICAL, CREDS, CTX)
    assert result == "static_value"

def test_missing_patient_field_returns_empty():
    result = resolve_value("{{patient.nonexistent}}", PATIENT, CLINICAL, CREDS, CTX)
    assert result == ""
```

```python
# browser-agent/tests/test_pick_option.py
import pytest
from recipe.pick_option import pick_option


OPTIONS = ["Diagnosis Code", "Procedure Code", "UnitedHealthcare", "Aetna", "BCBS"]


def test_exact_match():
    assert pick_option("Aetna", OPTIONS) == "Aetna"

def test_case_insensitive_exact():
    assert pick_option("aetna", OPTIONS) == "Aetna"

def test_contains_match():
    assert pick_option("Diagnosis", OPTIONS) == "Diagnosis Code"

def test_levenshtein_match():
    assert pick_option("Aetno", OPTIONS) == "Aetna"   # distance = 1

def test_no_match_raises():
    with pytest.raises(ValueError):
        pick_option("ZZZ", OPTIONS, match_type="exact")

def test_fuzzy_best_effort():
    result = pick_option("BCBC", OPTIONS)   # distance = 1
    assert result == "BCBS"
```

```python
# browser-agent/tests/test_captcha_client.py
import pytest
from unittest.mock import patch, MagicMock
from captcha.capsolver_client import CapsolverClient


def test_create_task_returns_task_id():
    client = CapsolverClient.__new__(CapsolverClient)
    client.api_key = "test_key"

    mock_resp = MagicMock()
    mock_resp.json.return_value = {"errorId": 0, "taskId": "task-123"}
    mock_resp.raise_for_status = MagicMock()

    with patch("captcha.capsolver_client.httpx.post", return_value=mock_resp):
        task_id = client._create_task({
            "type": "ImageToTextTask",
            "body": "base64data",
        })
        assert task_id == "task-123"


def test_wait_for_solution_returns_text():
    client = CapsolverClient.__new__(CapsolverClient)
    client.api_key = "test_key"

    ready_resp = MagicMock()
    ready_resp.json.return_value = {
        "status": "ready",
        "solution": {"text": "ABCD"},
    }
    ready_resp.raise_for_status = MagicMock()

    with patch("captcha.capsolver_client.httpx.post", return_value=ready_resp), \
         patch("captcha.capsolver_client.time.sleep"):
        result = client._wait_for_solution("task-123")
        assert result == "ABCD"


def test_timeout_raises():
    client = CapsolverClient.__new__(CapsolverClient)
    client.api_key = "test_key"

    pending_resp = MagicMock()
    pending_resp.json.return_value = {"status": "processing"}
    pending_resp.raise_for_status = MagicMock()

    with patch("captcha.capsolver_client.httpx.post", return_value=pending_resp), \
         patch("captcha.capsolver_client.time.sleep"), \
         patch("captcha.capsolver_client.time.monotonic",
               side_effect=[0, 200]):  # instant timeout
        with pytest.raises(TimeoutError):
            client._wait_for_solution("task-abc")
```

```python
# browser-agent/tests/test_hitl_manager.py
import threading
import pytest
from hitl.hitl_manager import HITLManager


def test_create_and_get_event():
    event = HITLManager.create_event("CASE-TEST-001")
    assert isinstance(event, threading.Event)
    assert HITLManager.get_event("CASE-TEST-001") is event
    HITLManager.close_event("CASE-TEST-001")
    assert HITLManager.get_event("CASE-TEST-001") is None


def test_event_resolved_by_set():
    event = HITLManager.create_event("CASE-TEST-002")
    # Simulate operator resolution in another thread
    def resolve():
        import time
        time.sleep(0.05)
        event.set()
    threading.Thread(target=resolve).start()

    resolved = event.wait(timeout=5)
    HITLManager.close_event("CASE-TEST-002")
    assert resolved is True


def test_event_timeout():
    event    = HITLManager.create_event("CASE-TEST-003")
    resolved = event.wait(timeout=0.01)  # immediately timeout
    HITLManager.close_event("CASE-TEST-003")
    assert resolved is False
```

---

*Document Status: DRAFT*
*Previous: [10_Control_Plane_Implementation.md](10_Control_Plane_Implementation.md)*
*Next: [12_Tracking_Agent_Implementation.md](12_Tracking_Agent_Implementation.md)*
