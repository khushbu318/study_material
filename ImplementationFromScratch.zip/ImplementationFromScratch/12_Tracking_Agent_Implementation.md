# AutoAuth Agent — Tracking Agent Implementation
**Phase 3 | Sprint 7 | Weeks 17–18**
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026
**Version:** 1.0
**Prerequisite:** [11_Browser_Agent_Implementation.md](11_Browser_Agent_Implementation.md)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Project Structure](#2-project-structure)
3. [Configuration & Settings](#3-configuration--settings)
4. [Application Entry Point & Lifespan](#4-application-entry-point--lifespan)
5. [Tracking Session Store & Registry](#5-tracking-session-store--registry)
6. [Tracking Session — Core Endpoints](#6-tracking-session--core-endpoints)
7. [TrackingRunner — Portal Status Check](#7-trackingrunner--portal-status-check)
8. [Status Normalization](#8-status-normalization)
9. [Polling Scheduler — Exponential Backoff](#9-polling-scheduler--exponential-backoff)
10. [Status Change Callbacks](#10-status-change-callbacks)
11. [Tracking Recipes — YAML Schema](#11-tracking-recipes--yaml-schema)
12. [Worker Registration & Heartbeat](#12-worker-registration--heartbeat)
13. [Unit Tests](#13-unit-tests)

---

## 1. Overview

The **tracking-agent** is a lightweight post-submission service that periodically
logs into payer portals to check the status of submitted Prior Authorization requests.

```
N8N 'completed' webhook fires (PA submitted)
       │
       ▼
control-plane POST /tracking/sessions
       │
       ▼
tracking-agent POST /sessions
       │
       ▼
TrackingSession created:
  - pa_reference_number stored
  - portal_id + credential_id resolved
  - TrackingThread spawned
       │
       ▼
TrackingThread loop (with exponential backoff):
  ┌─────────────────────────────────────────┐
  │  1. Sleep until next_check_at           │
  │  2. Launch headless Playwright          │
  │  3. Navigate to PA status page          │
  │  4. Extract raw portal status text      │
  │  5. Normalize → APPROVED/DENIED/        │
  │     PENDING/PENDING_INFO                │
  │  6. If changed → update DB + N8N        │
  │  7. Schedule next check (backoff)       │
  │  8. If terminal status → close session  │
  └─────────────────────────────────────────┘

Check schedule (default):
  Check 1:  1 hour  after submission
  Check 2:  4 hours after submission
  Check 3:  24 hours after submission
  Check 4:  48 hours after submission
  Check 5+: 48 hours (capped)
  Max checks: 20 (≈ 40 days)
```

**Key differences from browser-agent:**
- Runs headless Chromium (no Xvfb/VNC needed — no operator visibility required)
- Stateless between checks — each check is an independent Playwright session
- One tracking recipe per portal (login → navigate to PA status page → extract)
- Multiple tracking sessions per pod (no display slot limit)
- No HITL/MFA during tracking (uses pre-authenticated credential; MFA only on initial login)

---

## 2. Project Structure

```
tracking-agent/
├── pyproject.toml
├── Dockerfile
└── src/
    ├── main.py
    ├── config.py
    ├── sessions/
    │   ├── __init__.py
    │   ├── tracking_store.py       # In-memory session registry
    │   └── tracking_thread.py      # Background polling thread
    ├── runner/
    │   ├── __init__.py
    │   ├── tracking_runner.py      # Playwright status check
    │   ├── status_normalizer.py    # Portal status → normalized status
    │   └── tracking_recipe.py      # Tracking recipe loader (subset of recipe)
    ├── scheduler/
    │   ├── __init__.py
    │   └── poll_scheduler.py       # Exponential backoff scheduling
    ├── services/
    │   ├── __init__.py
    │   ├── status_callback.py      # N8N webhook on status change
    │   └── case_updater.py         # DB update helper
    ├── routers/
    │   ├── __init__.py
    │   ├── sessions.py             # POST/DELETE /sessions
    │   └── health.py
    └── heartbeat/
        ├── __init__.py
        └── heartbeat_thread.py     # 30s keepalive (reused pattern from browser-agent)
```

---

## 3. Configuration & Settings

```python
# tracking-agent/src/config.py
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    app_env:      str = Field("prod",            env="APP_ENV")
    service_name: str = Field("tracking-agent",  env="SERVICE_NAME")
    log_level:    str = Field("INFO",            env="LOG_LEVEL")

    pod_id:   str = Field(..., env="POD_ID")
    pod_ip:   str = Field(..., env="POD_IP")
    pod_port: int = Field(8084, env="POD_PORT")

    # Database
    db_host:     str = Field(..., env="DB_HOST")
    db_port:     int = Field(5432, env="DB_PORT")
    db_user:     str = Field(..., env="DB_USER")
    db_password: str = Field(..., env="DB_PASSWORD")
    db_name:     str = Field(..., env="DB_NAME")

    # Redis
    redis_host: str  = Field(..., env="REDIS_HOST")
    redis_port: int  = Field(6379, env="REDIS_PORT")
    redis_auth: str  = Field("",   env="REDIS_AUTH")
    redis_tls:  bool = Field(False, env="REDIS_TLS")

    # API server (recipe fetch)
    api_server_url: str = Field("http://api-server:8080", env="API_SERVER_URL")

    # Control plane
    control_plane_url: str = Field("http://control-plane:8083", env="CONTROL_PLANE_URL")

    # N8N webhooks
    n8n_status_capture_webhook_url: str = Field(..., env="N8N_STATUS_CAPTURE_WEBHOOK_URL")
    n8n_webhook_secret:             str = Field(..., env="N8N_WEBHOOK_SECRET")

    # Polling schedule (hours between checks)
    poll_schedule_hours: list[int] = Field(
        default=[1, 4, 24, 48], env="POLL_SCHEDULE_HOURS"
    )
    poll_max_checks: int = Field(20, env="POLL_MAX_CHECKS")

    # Heartbeat
    heartbeat_interval_seconds: int = Field(30, env="HEARTBEAT_INTERVAL_SECONDS")
    heartbeat_ttl_seconds:      int = Field(90, env="HEARTBEAT_TTL_SECONDS")

    # Playwright
    default_page_timeout:   int = Field(60,  env="DEFAULT_PAGE_TIMEOUT")
    default_action_timeout: int = Field(30,  env="DEFAULT_ACTION_TIMEOUT")

    class Config:
        env_file = ".env"
        case_sensitive = False


_settings: Settings | None = None

def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
```

---

## 4. Application Entry Point & Lifespan

```python
# tracking-agent/src/main.py
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI

from common.logs.logger import configure_logging, get_logger
from common.db_layer.db_config import get_engine
from common.redis_layer.redis_config import get_redis_client
from config import get_settings
from routers import sessions, health

os.environ.setdefault("SERVICE_NAME", "tracking-agent")
configure_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    logger.info("tracking_agent_starting",
                pod_id=settings.pod_id, env=settings.app_env)

    # Verify connections
    with get_engine().connect() as conn:
        conn.execute("SELECT 1")
    get_redis_client().ping()

    # Register with control-plane (tracking_pool)
    _register_with_control_plane(settings)

    # Resume any tracking sessions that were interrupted by a pod restart
    _resume_interrupted_sessions(settings)

    logger.info("tracking_agent_ready")
    yield

    # On shutdown: tracking threads are daemon threads — they stop automatically
    get_engine().dispose()
    logger.info("tracking_agent_shutdown")


def _register_with_control_plane(settings) -> None:
    import httpx
    try:
        httpx.post(
            f"{settings.control_plane_url}/api/v1/agents/register",
            json={
                "pod_id":       settings.pod_id,
                "pod_ip":       settings.pod_ip,
                "pod_port":     settings.pod_port,
                "agent_type":   "tracking_agent",
                "max_sessions": 10,   # tracking sessions are lightweight
            },
            timeout=10,
        )
        logger.info("registered_with_control_plane_tracking")
    except Exception as e:
        logger.warning("tracking_registration_failed", error=str(e))


def _resume_interrupted_sessions(settings) -> None:
    """
    On pod restart, query DB for tracking sessions that were IN_PROGRESS
    on this pod and restart their polling threads.
    """
    from common.db_layer.db_config import get_session_factory
    from common.db_layer.orm_models import PriorAuthTrackingSession
    from sessions.tracking_store import TrackingStore
    from sessions.tracking_thread import TrackingThread

    with get_session_factory()() as db:
        interrupted = db.query(PriorAuthTrackingSession).filter_by(
            pod_id=settings.pod_id,
            status="IN_PROGRESS",
        ).all()

    for ts in interrupted:
        thread = TrackingThread(
            tracking_session_id=str(ts.id),
            case_ref_id=ts.case_ref_id,
            pa_reference_number=ts.pa_reference_number,
            portal_id=ts.portal_id,
            credential_id=ts.credential_id,
            check_count=ts.check_count,
        )
        TrackingStore.add(str(ts.id), thread)
        thread.start()
        logger.info("tracking_session_resumed",
                    case_ref_id=ts.case_ref_id,
                    check_count=ts.check_count)


def create_app() -> FastAPI:
    app = FastAPI(
        title="AutoAuth Agent — Tracking Agent",
        version="1.0.0",
        docs_url=None, redoc_url=None,
        lifespan=lifespan,
    )
    app.include_router(sessions.router, prefix="/api/v1")
    app.include_router(health.router)
    return app


app = create_app()
```

---

## 5. Tracking Session Store & Registry

```python
# tracking-agent/src/sessions/tracking_store.py
import threading
from common.logs.logger import get_logger

logger = get_logger(__name__)

_store: dict[str, "TrackingThread"] = {}
_lock  = threading.Lock()


class TrackingStore:

    @staticmethod
    def add(tracking_session_id: str, thread: "TrackingThread") -> None:
        with _lock:
            _store[tracking_session_id] = thread

    @staticmethod
    def get(tracking_session_id: str) -> "TrackingThread | None":
        with _lock:
            return _store.get(tracking_session_id)

    @staticmethod
    def get_by_case(case_ref_id: str) -> "TrackingThread | None":
        with _lock:
            for thread in _store.values():
                if thread.case_ref_id == case_ref_id:
                    return thread
        return None

    @staticmethod
    def remove(tracking_session_id: str) -> None:
        with _lock:
            _store.pop(tracking_session_id, None)

    @staticmethod
    def list_all() -> list[dict]:
        with _lock:
            return [
                {
                    "tracking_session_id": tid,
                    "case_ref_id":         t.case_ref_id,
                    "check_count":         t.check_count,
                    "is_alive":            t.is_alive(),
                }
                for tid, t in _store.items()
            ]

    @staticmethod
    def count() -> int:
        with _lock:
            return len(_store)
```

---

## 6. Tracking Session — Core Endpoints

```python
# tracking-agent/src/routers/sessions.py
import uuid
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import PriorAuthTrackingSession
from sessions.tracking_store import TrackingStore
from sessions.tracking_thread import TrackingThread
from config import get_settings
from common.logs.logger import get_logger

router = APIRouter(tags=["Tracking Sessions"])
logger = get_logger(__name__)


class CreateTrackingSessionRequest(BaseModel):
    case_ref_id:         str
    pa_reference_number: str
    portal_id:           str
    credential_id:       str | None = None


@router.post("/sessions", status_code=201)
def create_tracking_session(payload: CreateTrackingSessionRequest):
    """
    Called by control-plane after successful PA submission.
    Starts a long-running polling thread for this case.
    """
    settings = get_settings()

    # Prevent duplicate tracking sessions
    existing = TrackingStore.get_by_case(payload.case_ref_id)
    if existing and existing.is_alive():
        return {
            "message": "Tracking session already active",
            "case_ref_id": payload.case_ref_id,
        }

    tracking_session_id = str(uuid.uuid4())

    # Persist to DB
    with get_session_factory()() as db:
        ts = PriorAuthTrackingSession(
            id=tracking_session_id,
            case_ref_id=payload.case_ref_id,
            pa_reference_number=payload.pa_reference_number,
            portal_id=payload.portal_id,
            credential_id=payload.credential_id,
            pod_id=settings.pod_id,
            pod_ip=settings.pod_ip,
            status="IN_PROGRESS",
            check_count=0,
        )
        db.add(ts)
        db.commit()

    # Spawn polling thread
    thread = TrackingThread(
        tracking_session_id=tracking_session_id,
        case_ref_id=payload.case_ref_id,
        pa_reference_number=payload.pa_reference_number,
        portal_id=payload.portal_id,
        credential_id=payload.credential_id,
        check_count=0,
    )
    TrackingStore.add(tracking_session_id, thread)
    thread.start()

    logger.info("tracking_session_started",
                case_ref_id=payload.case_ref_id,
                pa_reference_number=payload.pa_reference_number,
                portal_id=payload.portal_id)

    return {
        "tracking_session_id": tracking_session_id,
        "case_ref_id":         payload.case_ref_id,
        "status":              "IN_PROGRESS",
    }


@router.get("/sessions")
def list_tracking_sessions():
    return {"sessions": TrackingStore.list_all(), "count": TrackingStore.count()}


@router.delete("/sessions/{tracking_session_id}", status_code=200)
def stop_tracking_session(tracking_session_id: str):
    thread = TrackingStore.get(tracking_session_id)
    if not thread:
        raise HTTPException(status_code=404, detail="Tracking session not found")

    thread.stop()
    TrackingStore.remove(tracking_session_id)

    with get_session_factory()() as db:
        ts = db.query(PriorAuthTrackingSession).get(tracking_session_id)
        if ts:
            ts.status = "STOPPED"
            db.commit()

    return {"message": "Tracking session stopped", "id": tracking_session_id}
```

---

## 7. TrackingRunner — Portal Status Check

```python
# tracking-agent/src/sessions/tracking_thread.py
"""
Background thread that implements the polling loop for a single tracking session.
Each check:
  1. Sleep until next_check_at
  2. Run TrackingRunner (Playwright headless check)
  3. Compare result with last_known_status
  4. On change: update DB + fire N8N callback
  5. Schedule next check (or close if terminal)
"""
import threading
import time
from datetime import datetime, timezone

from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import PriorAuthTrackingSession
from common.logs.logger import get_logger, set_trace_id
from runner.tracking_runner import TrackingRunner
from runner.status_normalizer import normalize_status
from scheduler.poll_scheduler import PollScheduler
from services.status_callback import StatusCallback
from services.case_updater import CaseUpdater

logger = get_logger(__name__)

TERMINAL_STATUSES = {"APPROVED", "DENIED", "CANCELLED"}


class TrackingThread(threading.Thread):

    def __init__(self, tracking_session_id: str, case_ref_id: str,
                 pa_reference_number: str, portal_id: str,
                 credential_id: str | None, check_count: int = 0):
        super().__init__(
            name=f"Tracking-{case_ref_id}", daemon=True)
        self.tracking_session_id = tracking_session_id
        self.case_ref_id         = case_ref_id
        self.pa_reference_number = pa_reference_number
        self.portal_id           = portal_id
        self.credential_id       = credential_id
        self.check_count         = check_count
        self._stop               = threading.Event()

    def stop(self) -> None:
        self._stop.set()

    def run(self) -> None:
        set_trace_id(self.case_ref_id)
        scheduler = PollScheduler(initial_check_count=self.check_count)

        logger.info("tracking_thread_started",
                    case_ref_id=self.case_ref_id,
                    pa_ref=self.pa_reference_number)

        while not self._stop.is_set():
            # Sleep until next check
            delay_seconds = scheduler.seconds_until_next_check()
            logger.info("tracking_next_check",
                        case_ref_id=self.case_ref_id,
                        delay_seconds=delay_seconds,
                        check_number=scheduler.check_count + 1)

            interrupted = self._stop.wait(timeout=delay_seconds)
            if interrupted:
                break

            # Max checks reached → close session without terminal status
            if scheduler.is_exhausted():
                logger.warning("tracking_max_checks_reached",
                               case_ref_id=self.case_ref_id)
                self._close_session(status="EXHAUSTED")
                break

            # Run the portal status check
            try:
                result = self._run_check()
                scheduler.record_check()
                self.check_count = scheduler.check_count
                self._persist_check_result(result)

                if result.get("normalized_status") in TERMINAL_STATUSES:
                    logger.info("tracking_terminal_status",
                                case_ref_id=self.case_ref_id,
                                status=result["normalized_status"])
                    self._close_session(status="COMPLETED")
                    break

            except Exception as e:
                logger.error("tracking_check_failed",
                             case_ref_id=self.case_ref_id, error=str(e))
                scheduler.record_check()   # still increment to avoid infinite retry

        logger.info("tracking_thread_ended", case_ref_id=self.case_ref_id)

    def _run_check(self) -> dict:
        """Execute one Playwright status check. Returns result dict."""
        from common.secret.secret_manager import get_portal_credentials
        credentials = {}
        if self.credential_id:
            credentials = get_portal_credentials(self.credential_id)

        runner = TrackingRunner(
            case_ref_id=self.case_ref_id,
            pa_reference_number=self.pa_reference_number,
            portal_id=self.portal_id,
            credentials=credentials,
        )
        return runner.check()

    def _persist_check_result(self, result: dict) -> None:
        """Update DB and fire callback if status changed."""
        raw_status        = result.get("raw_status", "")
        normalized_status = result.get("normalized_status", "PENDING")
        portal_message    = result.get("message", "")
        screenshot_b64    = result.get("screenshot_b64")

        with get_session_factory()() as db:
            ts = db.query(PriorAuthTrackingSession).get(self.tracking_session_id)
            if not ts:
                return

            previous_status     = ts.normalized_status
            ts.check_count      = self.check_count
            ts.portal_status    = raw_status
            ts.normalized_status = normalized_status
            ts.portal_message   = portal_message
            ts.last_checked_at  = datetime.now(timezone.utc)

            # Schedule next check timestamp
            from config import get_settings
            next_delay = PollScheduler(
                initial_check_count=self.check_count).seconds_until_next_check()
            ts.next_check_at = datetime.fromtimestamp(
                time.time() + next_delay, tz=timezone.utc)

            db.commit()

        logger.info("tracking_check_result",
                    case_ref_id=self.case_ref_id,
                    check=self.check_count,
                    raw=raw_status,
                    normalized=normalized_status)

        # Fire callback only on status change
        if normalized_status != (previous_status or "PENDING"):
            StatusCallback.notify_status_change(
                case_ref_id=self.case_ref_id,
                pa_reference_number=self.pa_reference_number,
                previous_status=previous_status,
                new_status=normalized_status,
                portal_status=raw_status,
                message=portal_message,
            )
            # Update the main case record too
            CaseUpdater.update_case_status(
                case_ref_id=self.case_ref_id,
                normalized_status=normalized_status,
                pa_reference_number=self.pa_reference_number,
            )

    def _close_session(self, status: str) -> None:
        from sessions.tracking_store import TrackingStore
        with get_session_factory()() as db:
            ts = db.query(PriorAuthTrackingSession).get(self.tracking_session_id)
            if ts:
                ts.status     = status
                ts.closed_at  = datetime.now(timezone.utc)
                db.commit()
        TrackingStore.remove(self.tracking_session_id)
```

```python
# tracking-agent/src/runner/tracking_runner.py
"""
Executes a single Playwright headless check against the payer portal.
Uses a tracking recipe (a simplified recipe for PA status lookup only).

Tracking recipe defines:
  1. Login steps (navigate + fill credentials + click submit)
  2. Navigate to PA status page (search by PA reference number)
  3. Extract raw status text
  4. Optional: extract decision letter URL
  5. Screenshot current state
"""
import base64
from playwright.sync_api import sync_playwright, TimeoutError as PwTimeout

from runner.tracking_recipe import load_tracking_recipe
from runner.status_normalizer import normalize_status
from common.logs.logger import get_logger

logger = get_logger(__name__)


class TrackingRunner:

    def __init__(self, case_ref_id: str, pa_reference_number: str,
                 portal_id: str, credentials: dict):
        self.case_ref_id         = case_ref_id
        self.pa_reference_number = pa_reference_number
        self.portal_id           = portal_id
        self.credentials         = credentials

    def check(self) -> dict:
        """
        Launch headless Chromium, run tracking recipe steps,
        return status dict.
        """
        recipe = load_tracking_recipe(self.portal_id)

        with sync_playwright() as pw:
            browser = pw.chromium.launch(
                headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )
            page = browser.new_page(
                viewport={"width": 1280, "height": 800},
            )

            ctx: dict = {
                "pa_reference_number": self.pa_reference_number,
            }

            try:
                result = self._run_recipe(page, recipe, ctx)
            except PwTimeout as e:
                logger.warning("tracking_playwright_timeout",
                               case_ref_id=self.case_ref_id, error=str(e))
                result = {
                    "raw_status":        "TIMEOUT",
                    "normalized_status": "PENDING",
                    "message":           f"Page timeout: {e}",
                }
            except Exception as e:
                logger.error("tracking_runner_error",
                             case_ref_id=self.case_ref_id, error=str(e))
                result = {
                    "raw_status":        "ERROR",
                    "normalized_status": "PENDING",
                    "message":           str(e),
                }
            finally:
                # Always capture a screenshot for audit
                try:
                    png      = page.screenshot(type="png")
                    result["screenshot_b64"] = base64.b64encode(png).decode()
                except Exception:
                    pass
                browser.close()

        return result

    def _run_recipe(self, page, recipe: dict, ctx: dict) -> dict:
        """Execute tracking recipe steps and return extracted status."""
        from config import get_settings
        settings  = get_settings()
        timeout   = settings.default_action_timeout * 1000

        for step in recipe.get("steps", []):
            action = step["action"]
            name   = step.get("name", action)

            resolved_val = lambda key: self._resolve(step.get(key, ""), ctx)

            match action:
                case "navigate":
                    url = resolved_val("url")
                    page.goto(url, timeout=settings.default_page_timeout * 1000,
                              wait_until="networkidle")

                case "type":
                    sel = resolved_val("selector")
                    val = resolved_val("value")
                    loc = page.locator(sel)
                    loc.wait_for(state="visible", timeout=timeout)
                    loc.clear()
                    loc.fill(val)

                case "click":
                    sel = resolved_val("selector")
                    loc = page.locator(sel)
                    loc.wait_for(state="visible", timeout=timeout)
                    if step.get("wait_for_navigation"):
                        with page.expect_navigation(timeout=timeout):
                            loc.click()
                    else:
                        loc.click()

                case "wait":
                    page.wait_for_timeout(step.get("duration_ms", 1000))

                case "extract_status":
                    # Special action: extract PA status from page
                    sel  = resolved_val("selector")
                    loc  = page.locator(sel)
                    loc.wait_for(state="visible", timeout=timeout)
                    raw  = loc.inner_text().strip()
                    ctx["raw_status"] = raw
                    logger.info("tracking_status_extracted",
                                case_ref_id=self.case_ref_id, raw=raw)

                case "extract":
                    sel           = resolved_val("selector")
                    variable_name = step["variable_name"]
                    loc           = page.locator(sel)
                    loc.wait_for(state="visible", timeout=timeout)
                    ctx[variable_name] = loc.inner_text().strip()

                case "wait_for_text":
                    sel  = resolved_val("selector")
                    text = resolved_val("text")
                    page.locator(sel).filter(
                        has_text=text
                    ).wait_for(state="visible", timeout=timeout)

                case _:
                    logger.warning("tracking_unknown_action",
                                   action=action, step=name)

        raw_status        = ctx.get("raw_status", "")
        normalized_status = normalize_status(self.portal_id, raw_status)
        message           = ctx.get("status_message", "")

        return {
            "raw_status":        raw_status,
            "normalized_status": normalized_status,
            "message":           message,
            "decision_letter_url": ctx.get("decision_letter_url"),
        }

    def _resolve(self, template: str, ctx: dict) -> str:
        """Simplified resolve for tracking (only context + credentials)."""
        import re
        def replace(m: re.Match) -> str:
            token  = m.group(1).strip()
            parts  = token.split(".", 1)
            source = parts[0]
            key    = parts[1] if len(parts) > 1 else ""
            if source == "context":
                return str(ctx.get(key, ""))
            if source == "credentials":
                return str(self.credentials.get(key, ""))
            return token
        return re.sub(r"\{\{([^}]+)\}\}", replace, template)
```

---

## 8. Status Normalization

```python
# tracking-agent/src/runner/status_normalizer.py
"""
Maps raw portal status strings to our normalized status set:
  APPROVED      — PA approved, treatment can proceed
  DENIED        — PA denied
  PENDING_INFO  — additional information requested from provider
  PENDING       — still under review / no decision yet
  CANCELLED     — withdrawn or voided

Each portal uses different terminology. Normalization is case-insensitive
substring matching with a portal-specific mapping table.
"""
from common.logs.logger import get_logger

logger = get_logger(__name__)

# Structure: portal_id → list of (raw_substring, normalized_status)
# Checked in order — first match wins.
PORTAL_STATUS_MAPS: dict[str, list[tuple[str, str]]] = {

    "availity": [
        ("approved",                "APPROVED"),
        ("auth approved",           "APPROVED"),
        ("certification issued",    "APPROVED"),
        ("denied",                  "DENIED"),
        ("not certified",           "DENIED"),
        ("pend",                    "PENDING"),
        ("pending",                 "PENDING"),
        ("additional info",         "PENDING_INFO"),
        ("more information",        "PENDING_INFO"),
        ("info needed",             "PENDING_INFO"),
        ("cancelled",               "CANCELLED"),
        ("voided",                  "CANCELLED"),
        ("withdrawn",               "CANCELLED"),
    ],

    "navinet": [
        ("approved",                "APPROVED"),
        ("authorized",              "APPROVED"),
        ("denied",                  "DENIED"),
        ("not medically necessary", "DENIED"),
        ("in review",               "PENDING"),
        ("pending",                 "PENDING"),
        ("under review",            "PENDING"),
        ("additional info",         "PENDING_INFO"),
        ("peer-to-peer",            "PENDING_INFO"),
        ("cancelled",               "CANCELLED"),
    ],

    "carecore": [
        ("approved",                "APPROVED"),
        ("certified",               "APPROVED"),
        ("denied",                  "DENIED"),
        ("not certified",           "DENIED"),
        ("pended",                  "PENDING"),
        ("pending",                 "PENDING"),
        ("additional clinical",     "PENDING_INFO"),
        ("more info",               "PENDING_INFO"),
        ("cancelled",               "CANCELLED"),
        ("withdrawn",               "CANCELLED"),
    ],

    "gia_carelon": [
        ("approved",                "APPROVED"),
        ("approved with mod",       "APPROVED"),
        ("denied",                  "DENIED"),
        ("partially denied",        "DENIED"),
        ("in process",              "PENDING"),
        ("pending",                 "PENDING"),
        ("additional information",  "PENDING_INFO"),
        ("cancelled",               "CANCELLED"),
    ],

    "humana": [
        ("approved",                "APPROVED"),
        ("approved - full",         "APPROVED"),
        ("denied",                  "DENIED"),
        ("not approved",            "DENIED"),
        ("in process",              "PENDING"),
        ("pending",                 "PENDING"),
        ("additional info needed",  "PENDING_INFO"),
        ("cancelled",               "CANCELLED"),
        ("closed",                  "CANCELLED"),
    ],
}

# Fallback map applied when portal_id is not in PORTAL_STATUS_MAPS
GENERIC_STATUS_MAP: list[tuple[str, str]] = [
    ("approved",   "APPROVED"),
    ("certified",  "APPROVED"),
    ("authorized", "APPROVED"),
    ("denied",     "DENIED"),
    ("not",        "DENIED"),
    ("pend",       "PENDING"),
    ("review",     "PENDING"),
    ("additional", "PENDING_INFO"),
    ("info",       "PENDING_INFO"),
    ("cancel",     "CANCELLED"),
    ("void",       "CANCELLED"),
    ("withdraw",   "CANCELLED"),
]


def normalize_status(portal_id: str, raw_status: str) -> str:
    """
    Return normalized status for a raw portal status string.
    Defaults to PENDING if no match found.
    """
    if not raw_status:
        return "PENDING"

    raw_lower  = raw_status.lower().strip()
    status_map = PORTAL_STATUS_MAPS.get(portal_id, GENERIC_STATUS_MAP)

    for substring, normalized in status_map:
        if substring in raw_lower:
            logger.debug("status_normalized",
                         portal_id=portal_id,
                         raw=raw_status,
                         normalized=normalized,
                         matched_on=substring)
            return normalized

    logger.warning("status_normalization_no_match",
                   portal_id=portal_id, raw=raw_status)
    return "PENDING"
```

---

## 9. Polling Scheduler — Exponential Backoff

```python
# tracking-agent/src/scheduler/poll_scheduler.py
"""
Determines delay between portal status checks.

Default schedule (configurable via POLL_SCHEDULE_HOURS env var):
  Check 1  → wait 1h  → check at T+1h
  Check 2  → wait 4h  → check at T+5h
  Check 3  → wait 24h → check at T+29h
  Check 4+ → wait 48h → check at T+77h, T+125h, ...

Rationale: Most decisions arrive within 24h; early checks are more
frequent to catch fast approvals; 48h cap avoids polling too aggressively
for complex cases.
"""
from config import get_settings


class PollScheduler:

    def __init__(self, initial_check_count: int = 0):
        self.check_count = initial_check_count
        settings         = get_settings()
        self._schedule   = settings.poll_schedule_hours   # e.g. [1, 4, 24, 48]
        self._max_checks = settings.poll_max_checks

    def seconds_until_next_check(self) -> float:
        """Return number of seconds to sleep before the next check."""
        if self.check_count < len(self._schedule):
            hours = self._schedule[self.check_count]
        else:
            hours = self._schedule[-1]   # cap at last (largest) interval
        return hours * 3600

    def record_check(self) -> None:
        """Call after each check completes."""
        self.check_count += 1

    def is_exhausted(self) -> bool:
        """True when max_checks reached — stop polling."""
        return self.check_count >= self._max_checks

    def next_check_hours(self) -> float:
        """Human-readable hours until next check."""
        return self.seconds_until_next_check() / 3600
```

---

## 10. Status Change Callbacks

```python
# tracking-agent/src/services/status_callback.py
"""
Fires N8N status_capture webhook when PA status changes.
Also creates a DB alert for dashboard notification.
"""
import hmac
import hashlib
import json
import httpx
from datetime import datetime, timezone

from config import get_settings
from common.logs.logger import get_logger

logger = get_logger(__name__)


class StatusCallback:

    @staticmethod
    def notify_status_change(case_ref_id: str, pa_reference_number: str,
                              previous_status: str | None, new_status: str,
                              portal_status: str, message: str) -> None:
        settings = get_settings()
        payload  = {
            "case_ref_id":         case_ref_id,
            "pa_reference_number": pa_reference_number,
            "previous_status":     previous_status,
            "new_status":          new_status,
            "portal_status":       portal_status,
            "message":             message,
            "timestamp":           datetime.now(timezone.utc).isoformat(),
        }
        body      = json.dumps(payload)
        signature = hmac.new(
            settings.n8n_webhook_secret.encode(),
            body.encode(), hashlib.sha256
        ).hexdigest()
        headers = {
            "X-Signature":   signature,
            "Content-Type":  "application/json",
        }

        for attempt in range(1, 4):
            try:
                resp = httpx.post(
                    settings.n8n_status_capture_webhook_url,
                    content=body, headers=headers, timeout=15,
                )
                resp.raise_for_status()
                logger.info("status_callback_sent",
                            case_ref_id=case_ref_id,
                            new_status=new_status)
                return
            except Exception as e:
                if attempt == 3:
                    logger.error("status_callback_failed",
                                 case_ref_id=case_ref_id, error=str(e))
                else:
                    import time
                    time.sleep(attempt * 2)

        # Also persist a DB alert so dashboard can show notification
        StatusCallback._create_db_alert(case_ref_id, new_status, message)

    @staticmethod
    def _create_db_alert(case_ref_id: str, status: str, message: str) -> None:
        try:
            from common.db_layer.db_config import get_session_factory
            from common.db_layer.orm_models import AgenticPlatformAlert
            with get_session_factory()() as db:
                alert = AgenticPlatformAlert(
                    case_ref_id=case_ref_id,
                    alert_type="STATUS_CHANGE",
                    severity="INFO" if status == "APPROVED" else "WARNING",
                    message=f"PA status changed to {status}: {message}",
                )
                db.add(alert)
                db.commit()
        except Exception as e:
            logger.warning("db_alert_create_failed", error=str(e))
```

```python
# tracking-agent/src/services/case_updater.py
"""
Updates the main prior_auth_case_request record when PA status is finalized.
Maps tracking normalized_status → case status state machine.
"""
from common.db_layer.db_config import get_session_factory
from common.db_layer.orm_models import PriorAuthCaseRequest
from common.logs.logger import get_logger
from datetime import datetime, timezone

logger = get_logger(__name__)

TRACKING_TO_CASE_STATUS = {
    "APPROVED":     "APPROVED",
    "DENIED":       "DENIED",
    "PENDING_INFO": "PENDING_INFO",
    "PENDING":      None,          # No case update needed — still in progress
    "CANCELLED":    "CANCELLED",
}


class CaseUpdater:

    @staticmethod
    def update_case_status(case_ref_id: str, normalized_status: str,
                            pa_reference_number: str | None = None) -> None:
        case_status = TRACKING_TO_CASE_STATUS.get(normalized_status)
        if not case_status:
            return   # PENDING → no update needed

        with get_session_factory()() as db:
            case = db.query(PriorAuthCaseRequest).filter_by(
                case_ref_id=case_ref_id).first()
            if not case:
                logger.warning("case_not_found_for_update",
                               case_ref_id=case_ref_id)
                return

            # Only update if not already in a terminal state
            if case.status in ("CANCELLED", "FAILED"):
                return

            case.previous_status = case.status
            case.status          = case_status
            case.completed_at    = datetime.now(timezone.utc)

            if pa_reference_number:
                case.pa_reference_number = pa_reference_number

            db.commit()
            logger.info("case_status_updated",
                        case_ref_id=case_ref_id,
                        previous=case.previous_status,
                        new=case_status)
```

---

## 11. Tracking Recipes — YAML Schema

Tracking recipes are stored alongside submission recipes in the `prior_auth_portal_recipe` table, differentiated by `recipe_type = 'tracking'`. They are fetched via `GET /recipes/{portal_id}?type=tracking`.

```yaml
# Example: Availity tracking recipe
name: Availity PA Status Check
portal_id: availity
version: "1.2"
recipe_type: tracking
portal_url: https://apps.availity.com

steps:
  # ── Login ─────────────────────────────────────────────────────────────────
  - name: Navigate to login
    action: navigate
    url: https://apps.availity.com/availity/web/public.elegant.login

  - name: Enter username
    action: type
    selector: "#username"
    value: "{{credentials.username}}"

  - name: Enter password
    action: type
    selector: "#password"
    value: "{{credentials.password}}"

  - name: Click login button
    action: click
    selector: "button[type='submit']"
    wait_for_navigation: true

  - name: Wait for dashboard
    action: wait_for_text
    selector: ".dashboard-header"
    text: "Welcome"

  # ── Navigate to PA Status ──────────────────────────────────────────────────
  - name: Navigate to prior auth
    action: navigate
    url: https://apps.availity.com/availity/web/prior-authorization

  - name: Enter PA reference number
    action: type
    selector: "input[data-testid='auth-number-search']"
    value: "{{context.pa_reference_number}}"

  - name: Click search
    action: click
    selector: "button[data-testid='search-btn']"

  - name: Wait for results
    action: wait
    duration_ms: 2000

  # ── Extract Status ─────────────────────────────────────────────────────────
  - name: Extract PA status
    action: extract_status
    selector: ".auth-status-badge"
    # raw text is stored to ctx.raw_status automatically

  - name: Extract status message
    action: extract
    selector: ".auth-status-description"
    variable_name: status_message

  - name: Extract decision letter URL
    action: extract
    selector: "a[data-testid='decision-letter-link']"
    variable_name: decision_letter_url

---
# Example: Navinet tracking recipe (with MFA on login)
name: Navinet PA Status Check
portal_id: navinet
version: "1.1"
recipe_type: tracking

steps:
  - name: Navigate to Navinet
    action: navigate
    url: https://portal.navinet.net/login

  - name: Enter username
    action: type
    selector: "#user-name"
    value: "{{credentials.username}}"

  - name: Enter password
    action: type
    selector: "#password"
    value: "{{credentials.password}}"

  - name: Login
    action: click
    selector: "#login-btn"
    wait_for_navigation: true

  # Navinet MFA check: only appears if session cookie is expired
  - name: Check for MFA prompt
    action: condition
    selector: "#security-code-input"
    timeout: 5
    then_steps:
      - name: Wait for MFA code
        action: wait_for_mfa
        target_selector: "#security-code-input"
      - name: Submit MFA
        action: click
        selector: "#verify-btn"
        wait_for_navigation: true
    else_steps: []

  - name: Navigate to authorization search
    action: navigate
    url: https://portal.navinet.net/authorizations/search

  - name: Search by auth number
    action: type
    selector: "input.auth-number-field"
    value: "{{context.pa_reference_number}}"

  - name: Submit search
    action: click
    selector: "button.search-submit"

  - name: Wait for result row
    action: wait_for_text
    selector: "table.auth-results tbody tr:first-child"
    text: "{{context.pa_reference_number}}"

  - name: Extract status
    action: extract_status
    selector: "table.auth-results tbody tr:first-child td.status-col"

  - name: Extract message
    action: extract
    selector: "table.auth-results tbody tr:first-child td.decision-col"
    variable_name: status_message
```

---

## 12. Worker Registration & Heartbeat

```python
# tracking-agent/src/runner/tracking_recipe.py
"""Fetch and cache tracking recipes from api-server."""
import yaml
import httpx
import time
from common.logs.logger import get_logger
from config import get_settings

logger = get_logger(__name__)

_cache:       dict[str, dict]  = {}
_cache_times: dict[str, float] = {}
CACHE_TTL = 300


def load_tracking_recipe(portal_id: str) -> dict:
    now = time.monotonic()
    if portal_id in _cache and (now - _cache_times.get(portal_id, 0)) < CACHE_TTL:
        return _cache[portal_id]

    settings = get_settings()
    url      = (f"{settings.api_server_url}/api/v1/recipes/{portal_id}"
                f"?type=tracking")
    resp     = httpx.get(url, timeout=15)
    resp.raise_for_status()

    data        = resp.json()
    recipe_yaml = data.get("recipe_yaml") or data.get("yaml_content")
    if not recipe_yaml:
        raise ValueError(f"No tracking recipe for portal: {portal_id}")

    parsed                    = yaml.safe_load(recipe_yaml)
    _cache[portal_id]         = parsed
    _cache_times[portal_id]   = now

    logger.info("tracking_recipe_loaded",
                portal_id=portal_id,
                steps=len(parsed.get("steps", [])))
    return parsed
```

```python
# tracking-agent/src/heartbeat/heartbeat_thread.py
"""
Same pattern as browser-agent heartbeat.
Tracking sessions do NOT use session_id-keyed keepalive keys
(tracking pods don't have browser sessions that can crash mid-run).
Instead, this is a pod-level liveness signal to control-plane's tracking pool.
"""
import threading
from common.redis_layer.redis_config import get_redis_client
from config import get_settings
from common.logs.logger import get_logger

logger = get_logger(__name__)


class TrackingHeartbeatThread(threading.Thread):
    """Pod-level heartbeat: keepalive:tracking:{pod_id}"""

    def __init__(self):
        super().__init__(name="TrackingHeartbeat", daemon=True)
        settings       = get_settings()
        self._pod_id   = settings.pod_id
        self._interval = settings.heartbeat_interval_seconds
        self._ttl      = settings.heartbeat_ttl_seconds
        self._stop     = threading.Event()

    def start(self) -> None:
        self._refresh()
        super().start()

    def stop(self) -> None:
        self._stop.set()
        key = f"keepalive:tracking:{self._pod_id}"
        try:
            get_redis_client().delete(key)
        except Exception:
            pass

    def run(self) -> None:
        while not self._stop.wait(timeout=self._interval):
            self._refresh()

    def _refresh(self) -> None:
        key = f"keepalive:tracking:{self._pod_id}"
        try:
            get_redis_client().setex(key, self._ttl, self._pod_id)
        except Exception as e:
            logger.warning("tracking_heartbeat_failed",
                           pod_id=self._pod_id, error=str(e))
```

---

## 13. Unit Tests

```python
# tracking-agent/tests/test_status_normalizer.py
import pytest
from runner.status_normalizer import normalize_status


def test_availity_approved():
    assert normalize_status("availity", "Auth Approved") == "APPROVED"

def test_availity_denied():
    assert normalize_status("availity", "Not Certified - Medical Necessity") == "DENIED"

def test_availity_pending_info():
    assert normalize_status("availity", "Additional Info Required") == "PENDING_INFO"

def test_availity_pending():
    assert normalize_status("availity", "Pending Review") == "PENDING"

def test_availity_cancelled():
    assert normalize_status("availity", "Request Voided") == "CANCELLED"

def test_navinet_approved():
    assert normalize_status("navinet", "Authorized") == "APPROVED"

def test_carecore_denied():
    assert normalize_status("carecore", "Not Certified - Does Not Meet Criteria") == "DENIED"

def test_unknown_portal_generic_approved():
    assert normalize_status("unknown_payer", "Request Approved by reviewer") == "APPROVED"

def test_empty_raw_returns_pending():
    assert normalize_status("availity", "") == "PENDING"

def test_no_match_returns_pending():
    assert normalize_status("availity", "xyz123 gobbledygook") == "PENDING"

def test_humana_partial_approval():
    # "approved with mod" not in humana map — falls to "approved" substring
    assert normalize_status("humana", "Approved - Full") == "APPROVED"
```

```python
# tracking-agent/tests/test_poll_scheduler.py
import pytest
from unittest.mock import patch, MagicMock
from scheduler.poll_scheduler import PollScheduler


@pytest.fixture
def scheduler():
    with patch("scheduler.poll_scheduler.get_settings") as mock_settings:
        mock_settings.return_value = MagicMock(
            poll_schedule_hours=[1, 4, 24, 48],
            poll_max_checks=20,
        )
        return PollScheduler(initial_check_count=0)


def test_first_check_is_1h(scheduler):
    assert scheduler.seconds_until_next_check() == 3600

def test_second_check_is_4h(scheduler):
    scheduler.record_check()
    assert scheduler.seconds_until_next_check() == 4 * 3600

def test_third_check_is_24h(scheduler):
    scheduler.record_check(); scheduler.record_check()
    assert scheduler.seconds_until_next_check() == 24 * 3600

def test_beyond_schedule_caps_at_last(scheduler):
    for _ in range(10):
        scheduler.record_check()
    assert scheduler.seconds_until_next_check() == 48 * 3600

def test_exhausted_after_max_checks(scheduler):
    for _ in range(20):
        scheduler.record_check()
    assert scheduler.is_exhausted() is True

def test_not_exhausted_initially(scheduler):
    assert scheduler.is_exhausted() is False

def test_resume_from_check_count():
    with patch("scheduler.poll_scheduler.get_settings") as mock_settings:
        mock_settings.return_value = MagicMock(
            poll_schedule_hours=[1, 4, 24, 48],
            poll_max_checks=20,
        )
        # Simulate pod restart after 2 checks already done
        s = PollScheduler(initial_check_count=2)
        assert s.seconds_until_next_check() == 24 * 3600
```

```python
# tracking-agent/tests/test_tracking_thread.py
import pytest
import threading
from unittest.mock import patch, MagicMock


def test_terminal_status_closes_session():
    """TrackingThread stops when a terminal status is returned."""
    with patch("sessions.tracking_thread.TrackingRunner") as MockRunner, \
         patch("sessions.tracking_thread.get_session_factory") as mock_sf, \
         patch("sessions.tracking_thread.StatusCallback"), \
         patch("sessions.tracking_thread.CaseUpdater"), \
         patch("sessions.tracking_thread.PollScheduler") as MockScheduler:

        mock_runner_instance = MagicMock()
        mock_runner_instance.check.return_value = {
            "raw_status":        "Auth Approved",
            "normalized_status": "APPROVED",
            "message":           "",
        }
        MockRunner.return_value = mock_runner_instance

        mock_sched = MagicMock()
        mock_sched.check_count              = 0
        mock_sched.seconds_until_next_check.return_value = 0.01
        mock_sched.is_exhausted.return_value = False
        MockScheduler.return_value          = mock_sched

        db_session = MagicMock()
        db_session.__enter__ = MagicMock(return_value=db_session)
        db_session.__exit__  = MagicMock(return_value=False)
        mock_ts              = MagicMock()
        mock_ts.normalized_status = None
        db_session.query.return_value.get.return_value = mock_ts
        mock_sf.return_value.return_value = db_session

        from sessions.tracking_thread import TrackingThread
        thread = TrackingThread(
            tracking_session_id="ts-001",
            case_ref_id="CASE-001",
            pa_reference_number="PA-2024-001",
            portal_id="availity",
            credential_id=None,
            check_count=0,
        )
        thread.start()
        thread.join(timeout=3)

        assert not thread.is_alive(), "Thread should have exited after APPROVED status"


def test_stop_event_exits_loop():
    """Calling stop() exits the polling loop cleanly."""
    with patch("sessions.tracking_thread.TrackingRunner"), \
         patch("sessions.tracking_thread.get_session_factory"), \
         patch("sessions.tracking_thread.PollScheduler") as MockScheduler:

        mock_sched = MagicMock()
        mock_sched.seconds_until_next_check.return_value = 60  # long delay
        mock_sched.is_exhausted.return_value = False
        MockScheduler.return_value = mock_sched

        from sessions.tracking_thread import TrackingThread
        thread = TrackingThread(
            tracking_session_id="ts-002",
            case_ref_id="CASE-002",
            pa_reference_number="PA-002",
            portal_id="availity",
            credential_id=None,
            check_count=0,
        )
        thread.start()
        # Give thread time to enter wait
        import time
        time.sleep(0.1)
        thread.stop()
        thread.join(timeout=2)

        assert not thread.is_alive(), "Thread should exit after stop()"
```

---

*Document Status: DRAFT*
*Previous: [11_Browser_Agent_Implementation.md](11_Browser_Agent_Implementation.md)*
*Next: [13_Frontend_Implementation.md](13_Frontend_Implementation.md)*
