# AutoAuth Agent — Frontend Implementation
**Phase 3 | Sprint 8 | Weeks 19–20**
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026
**Version:** 1.0
**Prerequisite:** [12_Tracking_Agent_Implementation.md](12_Tracking_Agent_Implementation.md)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Tech Stack & Project Structure](#2-tech-stack--project-structure)
3. [Routing & Layout](#3-routing--layout)
4. [Authentication — JWT & Protected Routes](#4-authentication--jwt--protected-routes)
5. [API Client Layer](#5-api-client-layer)
6. [Case Management — List & Detail](#6-case-management--list--detail)
7. [Live Log Streaming — SSE](#7-live-log-streaming--sse)
8. [VNC Viewer Integration](#8-vnc-viewer-integration)
9. [HITL & MFA Operator Interface](#9-hitl--mfa-operator-interface)
10. [Batch Ingestion UI](#10-batch-ingestion-ui)
11. [Analytics Dashboard](#11-analytics-dashboard)
12. [Alert SSE — Dashboard Notifications](#12-alert-sse--dashboard-notifications)
13. [Recipe Editor](#13-recipe-editor)
14. [Unit & Component Tests](#14-unit--component-tests)

---

## 1. Overview

The **frontend** is a React single-page application served by nginx. It provides:

```
┌──────────────────────────────────────────────────────────────────┐
│  AutoAuth Agent Dashboard                                        │
│                                                                  │
│  ┌─────────────┐  ┌──────────────────────────────────────────┐  │
│  │  Sidebar    │  │  Main Content                            │  │
│  │             │  │                                          │  │
│  │ • Cases     │  │  Cases Table                             │  │
│  │ • HITL      │  │  ├─ Filter by status/portal/date         │  │
│  │ • Analytics │  │  ├─ Paginated list                       │  │
│  │ • Recipes   │  │  └─ Row click → Case Detail              │  │
│  │ • Settings  │  │                                          │  │
│  │             │  │  Case Detail                             │  │
│  │  [Badge: 3] │  │  ├─ Status + timeline                    │  │
│  │  pending    │  │  ├─ SSE log stream (live tail)           │  │
│  │  HITL tasks │  │  ├─ VNC viewer (noVNC embed)             │  │
│  │             │  │  └─ Patient/clinical data (redacted)     │  │
│  └─────────────┘  │                                          │  │
│                   │  HITL Queue                              │  │
│  Alert Toast      │  ├─ Pending task list                    │  │
│  (SSE broadcast)  │  ├─ Screenshot preview                   │  │
│                   │  ├─ MFA OTP entry form                   │  │
│                   │  └─ Resolve / Take control buttons       │  │
│                   │                                          │  │
│                   │  Analytics                               │  │
│                   │  ├─ Run volume chart (7/30/90d)          │  │
│                   │  ├─ LLM cost breakdown                   │  │
│                   │  └─ Case status distribution             │  │
│                   └──────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────┘
```

**Technology choices:**
- **React 18** + **TypeScript 5** — component model + type safety
- **Vite 5** — fast HMR dev server, production bundler
- **TailwindCSS 3** — utility-first styling
- **React Query (TanStack Query v5)** — server state, caching, background refresh
- **React Router v6** — client-side routing
- **Recharts** — analytics charts
- **noVNC** — WebSocket VNC viewer (loaded as npm package)
- **Zustand** — lightweight client state (auth token, alerts)
- **Vitest + React Testing Library** — unit + component tests

---

## 2. Tech Stack & Project Structure

```
frontend/
├── package.json
├── vite.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── index.html
├── public/
│   └── favicon.ico
└── src/
    ├── main.tsx                    # ReactDOM.createRoot entry
    ├── App.tsx                     # Router + layout wrapper
    ├── api/
    │   ├── client.ts               # Axios instance + interceptors
    │   ├── auth.ts                 # Login / register calls
    │   ├── cases.ts                # Cases CRUD + patch + cancel
    │   ├── batches.ts              # Batch ingest
    │   ├── hitl.ts                 # HITL task list + resolve
    │   ├── recipes.ts              # Recipe CRUD
    │   ├── analytics.ts            # Dashboard metrics
    │   └── types.ts                # Shared TS interfaces
    ├── store/
    │   ├── authStore.ts            # Zustand: JWT token + user
    │   └── alertStore.ts           # Zustand: SSE alerts queue
    ├── hooks/
    │   ├── useSSELogs.ts           # SSE log stream hook
    │   ├── useAlertSSE.ts          # Alert SSE hook
    │   └── useVNCViewer.ts         # noVNC initialization hook
    ├── components/
    │   ├── layout/
    │   │   ├── AppLayout.tsx       # Sidebar + content wrapper
    │   │   ├── Sidebar.tsx
    │   │   └── TopBar.tsx
    │   ├── common/
    │   │   ├── Badge.tsx           # Status badge (color-coded)
    │   │   ├── DataTable.tsx       # Generic paginated table
    │   │   ├── LoadingSpinner.tsx
    │   │   ├── ErrorBoundary.tsx
    │   │   ├── ConfirmModal.tsx
    │   │   └── AlertToast.tsx      # SSE alert notification
    │   ├── cases/
    │   │   ├── CaseFilters.tsx
    │   │   ├── CaseRow.tsx
    │   │   ├── CaseStatusTimeline.tsx
    │   │   ├── LogStream.tsx       # SSE live log tail
    │   │   └── VNCViewer.tsx       # noVNC embed
    │   ├── hitl/
    │   │   ├── HITLTaskCard.tsx
    │   │   ├── MFAEntryForm.tsx
    │   │   └── HITLResolveModal.tsx
    │   ├── analytics/
    │   │   ├── RunVolumeChart.tsx
    │   │   ├── CostBreakdownChart.tsx
    │   │   └── StatusDistribution.tsx
    │   └── recipes/
    │       ├── RecipeList.tsx
    │       └── RecipeEditor.tsx    # YAML editor with validation
    └── pages/
        ├── LoginPage.tsx
        ├── CasesPage.tsx
        ├── CaseDetailPage.tsx
        ├── HITLPage.tsx
        ├── AnalyticsPage.tsx
        ├── RecipesPage.tsx
        └── NotFoundPage.tsx
```

**`package.json` key dependencies:**
```json
{
  "dependencies": {
    "react": "^18.3.0",
    "react-dom": "^18.3.0",
    "react-router-dom": "^6.24.0",
    "@tanstack/react-query": "^5.45.0",
    "axios": "^1.7.0",
    "zustand": "^4.5.0",
    "recharts": "^2.12.0",
    "@novnc/novnc": "^1.4.0",
    "tailwindcss": "^3.4.0",
    "@codemirror/lang-yaml": "^6.1.0",
    "@uiw/react-codemirror": "^4.23.0",
    "date-fns": "^3.6.0",
    "lucide-react": "^0.395.0"
  },
  "devDependencies": {
    "vite": "^5.3.0",
    "@vitejs/plugin-react": "^4.3.0",
    "vitest": "^1.6.0",
    "@testing-library/react": "^16.0.0",
    "@testing-library/user-event": "^14.5.0",
    "typescript": "^5.5.0"
  }
}
```

---

## 3. Routing & Layout

```tsx
// src/App.tsx
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AppLayout } from "./components/layout/AppLayout";
import { ProtectedRoute } from "./components/layout/ProtectedRoute";
import LoginPage       from "./pages/LoginPage";
import CasesPage       from "./pages/CasesPage";
import CaseDetailPage  from "./pages/CaseDetailPage";
import HITLPage        from "./pages/HITLPage";
import AnalyticsPage   from "./pages/AnalyticsPage";
import RecipesPage     from "./pages/RecipesPage";
import NotFoundPage    from "./pages/NotFoundPage";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime:    30_000,  // 30s — don't refetch on every render
      retry:        2,
      refetchOnWindowFocus: false,
    },
  },
});

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route element={<ProtectedRoute />}>
            <Route element={<AppLayout />}>
              <Route index element={<Navigate to="/cases" replace />} />
              <Route path="/cases"          element={<CasesPage />} />
              <Route path="/cases/:caseRefId" element={<CaseDetailPage />} />
              <Route path="/hitl"           element={<HITLPage />} />
              <Route path="/analytics"      element={<AnalyticsPage />} />
              <Route path="/recipes"        element={<RecipesPage />} />
            </Route>
          </Route>
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
```

```tsx
// src/components/layout/AppLayout.tsx
import { Outlet } from "react-router-dom";
import { Sidebar }  from "./Sidebar";
import { TopBar }   from "./TopBar";
import { AlertToast } from "../common/AlertToast";
import { useAlertSSE } from "../../hooks/useAlertSSE";

export function AppLayout() {
  // Connect SSE alert stream for the entire app
  useAlertSSE();

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <Sidebar />
      <div className="flex flex-col flex-1 overflow-hidden">
        <TopBar />
        <main className="flex-1 overflow-auto p-6">
          <Outlet />
        </main>
      </div>
      <AlertToast />
    </div>
  );
}
```

```tsx
// src/components/layout/Sidebar.tsx
import { NavLink } from "react-router-dom";
import {
  FileText, AlertCircle, BarChart2, BookOpen, LogOut
} from "lucide-react";
import { useHITLBadge } from "../../hooks/useHITLBadge";
import { useAuthStore } from "../../store/authStore";

const navItems = [
  { to: "/cases",     icon: FileText,    label: "Cases"     },
  { to: "/hitl",      icon: AlertCircle, label: "HITL Queue" },
  { to: "/analytics", icon: BarChart2,   label: "Analytics" },
  { to: "/recipes",   icon: BookOpen,    label: "Recipes"   },
];

export function Sidebar() {
  const pendingHITL = useHITLBadge();
  const logout      = useAuthStore((s) => s.logout);

  return (
    <aside className="w-56 bg-slate-900 text-slate-100 flex flex-col">
      <div className="px-4 py-5 border-b border-slate-700">
        <h1 className="text-lg font-bold tracking-tight">AutoAuth</h1>
        <p className="text-xs text-slate-400 mt-0.5">Prior Auth Agent</p>
      </div>

      <nav className="flex-1 py-4 space-y-1 px-2">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium
               transition-colors ${
                 isActive
                   ? "bg-slate-700 text-white"
                   : "text-slate-400 hover:bg-slate-800 hover:text-white"
               }`
            }
          >
            <Icon size={16} />
            <span>{label}</span>
            {label === "HITL Queue" && pendingHITL > 0 && (
              <span className="ml-auto bg-red-500 text-white text-xs
                               rounded-full px-2 py-0.5">
                {pendingHITL}
              </span>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="px-2 py-4 border-t border-slate-700">
        <button
          onClick={logout}
          className="flex items-center gap-3 px-3 py-2 w-full rounded-md
                     text-sm text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <LogOut size={16} />
          Sign out
        </button>
      </div>
    </aside>
  );
}
```

---

## 4. Authentication — JWT & Protected Routes

```tsx
// src/store/authStore.ts
import { create } from "zustand";
import { persist } from "zustand/middleware";

interface AuthState {
  token:    string | null;
  user:     { id: string; email: string; role: string } | null;
  setAuth:  (token: string, user: AuthState["user"]) => void;
  logout:   () => void;
  isAuthenticated: boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      token:           null,
      user:            null,
      isAuthenticated: false,

      setAuth: (token, user) =>
        set({ token, user, isAuthenticated: true }),

      logout: () => {
        set({ token: null, user: null, isAuthenticated: false });
        window.location.href = "/login";
      },
    }),
    { name: "autoauth-auth" }
  )
);
```

```tsx
// src/components/layout/ProtectedRoute.tsx
import { Navigate, Outlet } from "react-router-dom";
import { useAuthStore } from "../../store/authStore";

export function ProtectedRoute() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
}
```

```tsx
// src/pages/LoginPage.tsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login } from "../api/auth";
import { useAuthStore } from "../store/authStore";

export default function LoginPage() {
  const navigate = useNavigate();
  const setAuth  = useAuthStore((s) => s.setAuth);
  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [error,    setError]    = useState<string | null>(null);
  const [loading,  setLoading]  = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { token, user } = await login(email, password);
      setAuth(token, user);
      navigate("/cases");
    } catch (err: any) {
      setError(err?.response?.data?.detail ?? "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white rounded-xl shadow-md p-8 w-full max-w-sm">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Sign in</h2>
        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded-md">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2
                         text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2
                         text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400
                       text-white font-medium py-2 px-4 rounded-md text-sm
                       transition-colors"
          >
            {loading ? "Signing in..." : "Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
}
```

---

## 5. API Client Layer

```typescript
// src/api/client.ts
import axios from "axios";
import { useAuthStore } from "../store/authStore";

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? "/api/v1",
  timeout: 30_000,
  headers: { "Content-Type": "application/json" },
});

// Attach JWT token to every request
apiClient.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle 401 → logout
apiClient.interceptors.response.use(
  (resp) => resp,
  (err) => {
    if (err.response?.status === 401) {
      useAuthStore.getState().logout();
    }
    return Promise.reject(err);
  }
);

export default apiClient;
```

```typescript
// src/api/types.ts
export type CaseStatus =
  | "PENDING" | "PLANNING" | "QUEUED" | "IN_PROGRESS"
  | "HITL_WAIT" | "MFA_WAIT" | "SUBMITTED" | "APPROVED"
  | "DENIED" | "PENDING_INFO" | "CRASHED" | "FAILED" | "CANCELLED";

export interface CaseSummary {
  id:                  string;
  case_ref_id:         string;
  status:              CaseStatus;
  portal_id:           string;
  payer_name:          string;
  created_at:          string;
  updated_at:          string;
  pa_reference_number: string | null;
  retry_count:         number;
  vnc_url:             string | null;
}

export interface CaseDetail extends CaseSummary {
  patient_data:    Record<string, unknown>;
  clinical_data:   Record<string, unknown>;
  batch_id:        string | null;
  started_at:      string | null;
  completed_at:    string | null;
  last_error:      string | null;
  active_hitl_task: HITLTask | null;
}

export interface HITLTask {
  task_id:         string;
  case_ref_id:     string;
  task_type:       "HITL" | "MFA";
  status:          "PENDING" | "RESOLVED";
  message:         string;
  screenshot_url:  string | null;
  step_name:       string;
  portal_id:       string;
  created_at:      string;
  expires_at:      string | null;
}

export interface PaginatedResponse<T> {
  items:       T[];
  total:       number;
  page:        number;
  page_size:   number;
  total_pages: number;
}

export interface AnalyticsRunVolume {
  date:        string;
  portal_id:   string;
  total:       number;
  approved:    number;
  denied:      number;
  pending:     number;
  failed:      number;
}

export interface LLMCostEntry {
  model:       string;
  total_cost:  number;
  total_tokens: number;
  request_count: number;
}
```

```typescript
// src/api/cases.ts
import apiClient from "./client";
import type { CaseDetail, CaseSummary, PaginatedResponse } from "./types";

export interface ListCasesParams {
  page?:      number;
  page_size?: number;
  status?:    string;
  portal_id?: string;
  date_from?: string;
  date_to?:   string;
  search?:    string;
}

export const listCases = async (
  params: ListCasesParams = {}
): Promise<PaginatedResponse<CaseSummary>> => {
  const { data } = await apiClient.get("/prior-auths/requests", { params });
  return data;
};

export const getCase = async (caseRefId: string): Promise<CaseDetail> => {
  const { data } = await apiClient.get(`/prior-auths/${caseRefId}`);
  return data;
};

export const cancelCase = async (caseRefId: string): Promise<void> => {
  await apiClient.post(`/prior-auths/${caseRefId}/cancel`);
};

export const retriggerCase = async (caseRefId: string): Promise<void> => {
  await apiClient.post(`/retrigger/${caseRefId}`);
};

// src/api/hitl.ts
import apiClient from "./client";
import type { HITLTask } from "./types";

export const listHITLTasks = async (
  status = "PENDING"
): Promise<{ tasks: HITLTask[] }> => {
  const { data } = await apiClient.get("/hitl/tasks", { params: { status } });
  return data;
};

export const resolveHITLTask = async (
  task_id: string,
  resolution: string,
  user_id?: string
): Promise<void> => {
  await apiClient.post("/hitl/resolve", { task_id, resolution, user_id });
};

export const submitMFACode = async (
  caseRefId: string,
  otp_code: string
): Promise<void> => {
  await apiClient.post(`/handle-mfa/${caseRefId}`, { otp_code });
};

// src/api/auth.ts
import apiClient from "./client";

export const login = async (
  email: string,
  password: string
): Promise<{ token: string; user: { id: string; email: string; role: string } }> => {
  const { data } = await apiClient.post("/auth/login", { email, password });
  return { token: data.access_token, user: data.user };
};
```

---

## 6. Case Management — List & Detail

```tsx
// src/pages/CasesPage.tsx
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { listCases, type ListCasesParams } from "../api/cases";
import { CaseFilters } from "../components/cases/CaseFilters";
import { DataTable }   from "../components/common/DataTable";
import { Badge }       from "../components/common/Badge";
import type { CaseSummary } from "../api/types";
import { formatDistanceToNow } from "date-fns";

export default function CasesPage() {
  const navigate = useNavigate();
  const [params, setParams] = useState<ListCasesParams>({
    page: 1, page_size: 20,
  });

  const { data, isLoading, error } = useQuery({
    queryKey: ["cases", params],
    queryFn:  () => listCases(params),
    refetchInterval: 15_000,   // auto-refresh every 15s
  });

  const columns = [
    {
      key:    "case_ref_id",
      header: "Case ID",
      render: (c: CaseSummary) => (
        <span className="font-mono text-sm text-blue-600">{c.case_ref_id}</span>
      ),
    },
    {
      key:    "status",
      header: "Status",
      render: (c: CaseSummary) => <Badge status={c.status} />,
    },
    {
      key:    "payer_name",
      header: "Payer / Portal",
      render: (c: CaseSummary) => (
        <span className="text-sm text-gray-700">{c.payer_name}</span>
      ),
    },
    {
      key:    "pa_reference_number",
      header: "PA Reference",
      render: (c: CaseSummary) => (
        <span className="font-mono text-sm">
          {c.pa_reference_number ?? "—"}
        </span>
      ),
    },
    {
      key:    "created_at",
      header: "Created",
      render: (c: CaseSummary) => (
        <span className="text-sm text-gray-500">
          {formatDistanceToNow(new Date(c.created_at), { addSuffix: true })}
        </span>
      ),
    },
    {
      key:    "retry_count",
      header: "Retries",
      render: (c: CaseSummary) => (
        <span className={`text-sm ${c.retry_count > 0 ? "text-orange-600" : "text-gray-400"}`}>
          {c.retry_count}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-900">
          Prior Auth Cases
        </h1>
        <span className="text-sm text-gray-500">
          {data?.total ?? 0} total
        </span>
      </div>

      <CaseFilters
        value={params}
        onChange={(filters) => setParams({ ...filters, page: 1 })}
      />

      <DataTable
        columns={columns}
        data={data?.items ?? []}
        isLoading={isLoading}
        error={error?.message}
        onRowClick={(c) => navigate(`/cases/${c.case_ref_id}`)}
        pagination={{
          page:        params.page ?? 1,
          totalPages:  data?.total_pages ?? 1,
          onPageChange: (p) => setParams((prev) => ({ ...prev, page: p })),
        }}
        rowClassName={(c) =>
          c.status === "HITL_WAIT" || c.status === "MFA_WAIT"
            ? "bg-yellow-50 border-l-4 border-yellow-400"
            : ""
        }
      />
    </div>
  );
}
```

```tsx
// src/pages/CaseDetailPage.tsx
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getCase, cancelCase, retriggerCase } from "../api/cases";
import { Badge }                from "../components/common/Badge";
import { CaseStatusTimeline }   from "../components/cases/CaseStatusTimeline";
import { LogStream }            from "../components/cases/LogStream";
import { VNCViewer }            from "../components/cases/VNCViewer";
import { HITLResolveModal }     from "../components/hitl/HITLResolveModal";
import { useState }             from "react";
import { formatDistanceToNow } from "date-fns";

export default function CaseDetailPage() {
  const { caseRefId } = useParams<{ caseRefId: string }>();
  const navigate      = useNavigate();
  const qc            = useQueryClient();
  const [showHITL, setShowHITL] = useState(false);

  const { data: caseData, isLoading } = useQuery({
    queryKey:        ["case", caseRefId],
    queryFn:         () => getCase(caseRefId!),
    refetchInterval: 5_000,
    enabled:         !!caseRefId,
  });

  const cancelMutation = useMutation({
    mutationFn: () => cancelCase(caseRefId!),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ["case", caseRefId] }),
  });

  const retriggerMutation = useMutation({
    mutationFn: () => retriggerCase(caseRefId!),
    onSuccess:  () => qc.invalidateQueries({ queryKey: ["case", caseRefId] }),
  });

  if (isLoading || !caseData) {
    return <div className="p-8 text-center text-gray-500">Loading...</div>;
  }

  const isActive = ["IN_PROGRESS", "HITL_WAIT", "MFA_WAIT"].includes(
    caseData.status
  );

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <button
            onClick={() => navigate("/cases")}
            className="text-sm text-blue-600 hover:underline mb-2 block"
          >
            ← Back to Cases
          </button>
          <h1 className="text-xl font-mono font-semibold text-gray-900">
            {caseData.case_ref_id}
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            {caseData.payer_name} ·{" "}
            Created {formatDistanceToNow(
              new Date(caseData.created_at), { addSuffix: true }
            )}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Badge status={caseData.status} size="lg" />

          {caseData.status === "HITL_WAIT" && (
            <button
              onClick={() => setShowHITL(true)}
              className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2
                         rounded-md text-sm font-medium"
            >
              Resolve HITL
            </button>
          )}
          {["CRASHED", "FAILED"].includes(caseData.status) &&
            caseData.retry_count < 3 && (
              <button
                onClick={() => retriggerMutation.mutate()}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2
                           rounded-md text-sm font-medium"
              >
                Retry
              </button>
            )}
          {!["CANCELLED", "APPROVED", "DENIED", "FAILED"].includes(
            caseData.status
          ) && (
            <button
              onClick={() => cancelMutation.mutate()}
              className="border border-red-300 text-red-600 hover:bg-red-50
                         px-4 py-2 rounded-md text-sm font-medium"
            >
              Cancel
            </button>
          )}
        </div>
      </div>

      {/* Status timeline */}
      <CaseStatusTimeline caseData={caseData} />

      <div className="grid grid-cols-2 gap-6">
        {/* Left column: info */}
        <div className="space-y-4">
          {/* PA reference */}
          {caseData.pa_reference_number && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-xs text-green-600 font-medium uppercase tracking-wide">
                PA Reference Number
              </p>
              <p className="font-mono text-lg text-green-800 mt-1">
                {caseData.pa_reference_number}
              </p>
            </div>
          )}

          {/* Error message */}
          {caseData.last_error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-xs text-red-600 font-medium uppercase">Last Error</p>
              <p className="text-sm text-red-800 mt-1 font-mono">
                {caseData.last_error}
              </p>
            </div>
          )}

          {/* Patient data (redacted display) */}
          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">
              Patient Information
            </h3>
            <PatientDataDisplay data={caseData.patient_data} />
          </div>
        </div>

        {/* Right column: VNC viewer */}
        {isActive && caseData.vnc_url && (
          <div className="bg-gray-900 rounded-lg overflow-hidden"
               style={{ height: 400 }}>
            <VNCViewer caseRefId={caseData.case_ref_id} />
          </div>
        )}
      </div>

      {/* Live log stream */}
      <div className="bg-gray-950 rounded-lg overflow-hidden">
        <div className="px-4 py-2 border-b border-gray-800">
          <h3 className="text-sm font-medium text-gray-300">Execution Log</h3>
        </div>
        <LogStream caseRefId={caseData.case_ref_id} />
      </div>

      {/* HITL resolve modal */}
      {showHITL && caseData.active_hitl_task && (
        <HITLResolveModal
          task={caseData.active_hitl_task}
          onClose={() => setShowHITL(false)}
          onResolved={() => {
            setShowHITL(false);
            qc.invalidateQueries({ queryKey: ["case", caseRefId] });
          }}
        />
      )}
    </div>
  );
}

function PatientDataDisplay({ data }: { data: Record<string, unknown> }) {
  const SHOW_FIELDS = ["member_id", "date_of_birth", "insurance_plan", "provider_npi"];
  return (
    <dl className="grid grid-cols-2 gap-x-4 gap-y-2">
      {SHOW_FIELDS.map((key) => (
        <div key={key}>
          <dt className="text-xs text-gray-500 capitalize">
            {key.replace(/_/g, " ")}
          </dt>
          <dd className="text-sm text-gray-800 font-mono">
            {String(data[key] ?? "—")}
          </dd>
        </div>
      ))}
    </dl>
  );
}
```

```tsx
// src/components/common/Badge.tsx
import type { CaseStatus } from "../../api/types";

const STATUS_CONFIG: Record<CaseStatus, { label: string; className: string }> = {
  PENDING:      { label: "Pending",      className: "bg-gray-100 text-gray-600"  },
  PLANNING:     { label: "Planning",     className: "bg-blue-100 text-blue-700"  },
  QUEUED:       { label: "Queued",       className: "bg-indigo-100 text-indigo-700" },
  IN_PROGRESS:  { label: "In Progress",  className: "bg-blue-500 text-white animate-pulse" },
  HITL_WAIT:    { label: "HITL Wait",    className: "bg-yellow-400 text-yellow-900" },
  MFA_WAIT:     { label: "MFA Wait",     className: "bg-orange-400 text-white"   },
  SUBMITTED:    { label: "Submitted",    className: "bg-teal-100 text-teal-700"  },
  APPROVED:     { label: "Approved",     className: "bg-green-100 text-green-700" },
  DENIED:       { label: "Denied",       className: "bg-red-100 text-red-700"    },
  PENDING_INFO: { label: "Pending Info", className: "bg-amber-100 text-amber-700" },
  CRASHED:      { label: "Crashed",      className: "bg-red-500 text-white"      },
  FAILED:       { label: "Failed",       className: "bg-red-700 text-white"      },
  CANCELLED:    { label: "Cancelled",    className: "bg-gray-200 text-gray-500"  },
};

interface BadgeProps {
  status: CaseStatus;
  size?:  "sm" | "md" | "lg";
}

export function Badge({ status, size = "md" }: BadgeProps) {
  const config = STATUS_CONFIG[status] ?? {
    label: status, className: "bg-gray-100 text-gray-600",
  };
  const sizeClass = size === "sm" ? "text-xs px-2 py-0.5"
                  : size === "lg" ? "text-sm px-3 py-1.5"
                  : "text-xs px-2.5 py-1";

  return (
    <span className={`inline-flex items-center rounded-full font-medium
                      ${sizeClass} ${config.className}`}>
      {config.label}
    </span>
  );
}
```

---

## 7. Live Log Streaming — SSE

```typescript
// src/hooks/useSSELogs.ts
import { useEffect, useRef, useState } from "react";
import { useAuthStore } from "../store/authStore";

export interface LogEntry {
  id:        string;
  ts:        string;
  level:     string;
  msg:       string;
  type?:     "screenshot";
  data?:     string;
}

export function useSSELogs(caseRefId: string | undefined) {
  const [entries, setEntries] = useState<LogEntry[]>([]);
  const [connected, setConnected] = useState(false);
  const token    = useAuthStore((s) => s.token);
  const esRef    = useRef<EventSource | null>(null);
  const idxRef   = useRef(0);

  useEffect(() => {
    if (!caseRefId || !token) return;

    const url = `/api/v1/sse/cases/${caseRefId}/logs?token=${token}`;
    const es  = new EventSource(url);
    esRef.current = es;

    es.onopen = () => setConnected(true);

    es.onmessage = (event) => {
      if (event.data === ":heartbeat") return;
      try {
        const parsed = JSON.parse(event.data) as LogEntry;
        parsed.id = String(idxRef.current++);
        setEntries((prev) => {
          // Cap at 500 entries in UI
          const next = [...prev, parsed];
          return next.length > 500 ? next.slice(-500) : next;
        });
      } catch {
        // Ignore malformed events
      }
    };

    es.onerror = () => {
      setConnected(false);
      es.close();
    };

    return () => {
      es.close();
      setConnected(false);
    };
  }, [caseRefId, token]);

  return { entries, connected };
}
```

```tsx
// src/components/cases/LogStream.tsx
import { useEffect, useRef } from "react";
import { useSSELogs } from "../../hooks/useSSELogs";

interface LogStreamProps {
  caseRefId: string;
}

export function LogStream({ caseRefId }: LogStreamProps) {
  const { entries, connected } = useSSELogs(caseRefId);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom on new entries
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [entries.length]);

  const levelColor = (level: string) => {
    switch (level?.toUpperCase()) {
      case "ERROR": return "text-red-400";
      case "WARN":  return "text-yellow-400";
      case "DEBUG": return "text-gray-500";
      default:      return "text-gray-300";
    }
  };

  return (
    <div className="font-mono text-xs overflow-y-auto"
         style={{ height: 300 }}>
      <div className="px-4 py-3 space-y-0.5">
        {entries.length === 0 && (
          <p className="text-gray-600 italic">No logs yet...</p>
        )}
        {entries.map((entry) => {
          if (entry.type === "screenshot") {
            return (
              <div key={entry.id} className="my-2">
                <p className="text-blue-400 mb-1">
                  📷 Screenshot: {entry.data}
                </p>
              </div>
            );
          }
          return (
            <div key={entry.id} className="flex gap-3">
              <span className="text-gray-600 shrink-0 w-24 truncate">
                {entry.ts ? new Date(entry.ts).toLocaleTimeString() : ""}
              </span>
              <span className={`shrink-0 w-12 ${levelColor(entry.level)}`}>
                {entry.level}
              </span>
              <span className="text-gray-200 break-all">{entry.msg}</span>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>
      {/* Connection indicator */}
      <div className="sticky bottom-0 px-4 py-1 bg-gray-900 border-t border-gray-800
                      flex items-center gap-2">
        <span className={`w-2 h-2 rounded-full ${
          connected ? "bg-green-400" : "bg-gray-600"
        }`} />
        <span className="text-gray-500 text-xs">
          {connected ? "Live" : "Disconnected"}
        </span>
        <span className="ml-auto text-gray-600 text-xs">
          {entries.length} entries
        </span>
      </div>
    </div>
  );
}
```

---

## 8. VNC Viewer Integration

```typescript
// src/hooks/useVNCViewer.ts
import { useEffect, useRef } from "react";
import { useAuthStore } from "../store/authStore";

export function useVNCViewer(
  containerRef: React.RefObject<HTMLDivElement>,
  caseRefId: string
) {
  const rfbRef = useRef<any>(null);

  useEffect(() => {
    if (!containerRef.current || !caseRefId) return;

    // VNC WebSocket proxied through control-plane:
    // /api/v1/vnc/{caseRefId}/websockify
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl    = `${protocol}//${window.location.host}/api/v1/vnc/${caseRefId}/websockify`;

    // Dynamically import noVNC to avoid SSR issues
    import("@novnc/novnc/core/rfb").then(({ default: RFB }) => {
      if (!containerRef.current) return;

      const rfb = new RFB(containerRef.current, wsUrl, {
        credentials: { password: "" },
      });

      rfb.scaleViewport = true;
      rfb.resizeSession = false;
      rfb.viewOnly      = false;

      rfbRef.current = rfb;

      rfb.addEventListener("connect",    () => console.log("VNC connected"));
      rfb.addEventListener("disconnect", () => console.log("VNC disconnected"));
    });

    return () => {
      if (rfbRef.current) {
        rfbRef.current.disconnect();
        rfbRef.current = null;
      }
    };
  }, [caseRefId]);

  return rfbRef;
}
```

```tsx
// src/components/cases/VNCViewer.tsx
import { useRef } from "react";
import { useVNCViewer } from "../../hooks/useVNCViewer";

interface VNCViewerProps {
  caseRefId: string;
}

export function VNCViewer({ caseRefId }: VNCViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  useVNCViewer(containerRef, caseRefId);

  return (
    <div className="relative w-full h-full bg-black">
      <div
        ref={containerRef}
        className="w-full h-full"
        style={{ cursor: "default" }}
      />
      <div className="absolute top-2 left-2 bg-black/60 text-white text-xs
                      px-2 py-1 rounded font-mono">
        VNC — {caseRefId}
      </div>
    </div>
  );
}
```

---

## 9. HITL & MFA Operator Interface

```tsx
// src/pages/HITLPage.tsx
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listHITLTasks }  from "../api/hitl";
import { HITLTaskCard }   from "../components/hitl/HITLTaskCard";
import type { HITLTask }  from "../api/types";

export default function HITLPage() {
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey:        ["hitl", "PENDING"],
    queryFn:         () => listHITLTasks("PENDING"),
    refetchInterval: 5_000,
  });

  const tasks = data?.tasks ?? [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-900">HITL Queue</h1>
        <span className="text-sm text-gray-500">
          {tasks.length} pending task{tasks.length !== 1 ? "s" : ""}
        </span>
      </div>

      {isLoading && (
        <div className="text-center py-10 text-gray-500">Loading...</div>
      )}

      {!isLoading && tasks.length === 0 && (
        <div className="text-center py-16 text-gray-400">
          <p className="text-lg font-medium">No pending HITL tasks</p>
          <p className="text-sm mt-1">
            Automation is running smoothly — check back if a case needs attention.
          </p>
        </div>
      )}

      <div className="space-y-4">
        {tasks.map((task) => (
          <HITLTaskCard
            key={task.task_id}
            task={task}
            onResolved={() =>
              qc.invalidateQueries({ queryKey: ["hitl"] })
            }
          />
        ))}
      </div>
    </div>
  );
}
```

```tsx
// src/components/hitl/HITLTaskCard.tsx
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { resolveHITLTask, submitMFACode } from "../../api/hitl";
import { useNavigate } from "react-router-dom";
import type { HITLTask } from "../../api/types";
import { formatDistanceToNow } from "date-fns";
import { MFAEntryForm } from "./MFAEntryForm";
import { AlertTriangle, Monitor } from "lucide-react";

interface HITLTaskCardProps {
  task:       HITLTask;
  onResolved: () => void;
}

export function HITLTaskCard({ task, onResolved }: HITLTaskCardProps) {
  const navigate = useNavigate();
  const [showMFA, setShowMFA] = useState(false);

  const resolveMutation = useMutation({
    mutationFn: () => resolveHITLTask(task.task_id, "operator_resolved"),
    onSuccess:  onResolved,
  });

  const isMFA     = task.task_type === "MFA";
  const isExpired = task.expires_at
    ? new Date(task.expires_at) < new Date()
    : false;

  return (
    <div className={`bg-white rounded-lg border shadow-sm overflow-hidden ${
      isMFA ? "border-orange-300" : "border-yellow-300"
    }`}>
      {/* Header */}
      <div className={`px-4 py-3 flex items-center justify-between ${
        isMFA ? "bg-orange-50" : "bg-yellow-50"
      }`}>
        <div className="flex items-center gap-2">
          <AlertTriangle
            size={16}
            className={isMFA ? "text-orange-500" : "text-yellow-600"}
          />
          <span className="font-medium text-sm text-gray-800">
            {isMFA ? "MFA Code Required" : "Manual Intervention Required"}
          </span>
          <span className="ml-2 text-xs text-gray-500 font-mono">
            {task.case_ref_id}
          </span>
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <span>
            {formatDistanceToNow(new Date(task.created_at), { addSuffix: true })}
          </span>
          {isExpired && (
            <span className="text-red-500 font-medium">EXPIRED</span>
          )}
        </div>
      </div>

      {/* Body */}
      <div className="p-4 space-y-3">
        {/* Message */}
        <p className="text-sm text-gray-700">{task.message}</p>

        {/* Step info */}
        <p className="text-xs text-gray-400 font-mono">
          Step: {task.step_name} · Portal: {task.portal_id}
        </p>

        {/* Screenshot preview */}
        {task.screenshot_url && (
          <div className="rounded-md overflow-hidden border border-gray-200 bg-gray-50">
            <img
              src={task.screenshot_url}
              alt="Page screenshot"
              className="w-full max-h-48 object-contain"
            />
          </div>
        )}

        {/* MFA entry form (inline) */}
        {isMFA && showMFA && (
          <MFAEntryForm
            caseRefId={task.case_ref_id}
            onSubmitted={onResolved}
          />
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-1">
          {isMFA ? (
            <>
              <button
                onClick={() => setShowMFA(!showMFA)}
                className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2
                           rounded-md text-sm font-medium"
              >
                {showMFA ? "Hide OTP Entry" : "Enter OTP Code"}
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => navigate(`/cases/${task.case_ref_id}`)}
                className="flex items-center gap-2 border border-gray-300
                           hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-md
                           text-sm font-medium"
              >
                <Monitor size={14} />
                Open VNC
              </button>
              <button
                onClick={() => resolveMutation.mutate()}
                disabled={resolveMutation.isPending}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2
                           rounded-md text-sm font-medium disabled:opacity-50"
              >
                {resolveMutation.isPending ? "Resolving..." : "Mark Resolved"}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
```

```tsx
// src/components/hitl/MFAEntryForm.tsx
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { submitMFACode } from "../../api/hitl";

interface MFAEntryFormProps {
  caseRefId:   string;
  onSubmitted: () => void;
}

export function MFAEntryForm({ caseRefId, onSubmitted }: MFAEntryFormProps) {
  const [otp, setOtp] = useState("");

  const mutation = useMutation({
    mutationFn: () => submitMFACode(caseRefId, otp),
    onSuccess:  onSubmitted,
  });

  return (
    <div className="bg-orange-50 border border-orange-200 rounded-md p-4">
      <label className="block text-sm font-medium text-orange-800 mb-2">
        Enter MFA / OTP Code
      </label>
      <div className="flex gap-2">
        <input
          type="text"
          value={otp}
          onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
          placeholder="6-digit code"
          maxLength={8}
          className="font-mono text-lg tracking-widest w-40 border border-orange-300
                     rounded-md px-3 py-2 text-center focus:outline-none
                     focus:ring-2 focus:ring-orange-400"
          onKeyDown={(e) => {
            if (e.key === "Enter" && otp.length >= 4) mutation.mutate();
          }}
        />
        <button
          onClick={() => mutation.mutate()}
          disabled={otp.length < 4 || mutation.isPending}
          className="bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300
                     text-white px-6 py-2 rounded-md text-sm font-medium"
        >
          {mutation.isPending ? "Submitting..." : "Submit OTP"}
        </button>
      </div>
      {mutation.isError && (
        <p className="text-red-600 text-xs mt-2">
          Failed to submit OTP. Please try again.
        </p>
      )}
    </div>
  );
}
```

---

## 10. Batch Ingestion UI

```tsx
// src/components/cases/BatchIngestForm.tsx
/**
 * JSON paste form for batch ingestion.
 * Validates required patient fields before submitting.
 */
import { useState }       from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import apiClient          from "../../api/client";

const REQUIRED_FIELDS = ["case_ref_id", "member_id", "first_name",
                          "last_name", "date_of_birth"];

export function BatchIngestForm() {
  const qc          = useQueryClient();
  const [raw, setRaw] = useState("");
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  const mutation = useMutation({
    mutationFn: async (payload: object) => {
      const { data } = await apiClient.post(
        "/agentic-platform/prior-auths", payload
      );
      return data;
    },
    onSuccess: () => {
      setRaw("");
      qc.invalidateQueries({ queryKey: ["cases"] });
    },
  });

  function validate(parsed: any): string[] {
    const errors: string[] = [];
    const cases = parsed.cases ?? [parsed];
    cases.forEach((c: any, i: number) => {
      const patient = c.patient_data ?? c;
      REQUIRED_FIELDS.forEach((field) => {
        if (!patient[field] && !c[field]) {
          errors.push(`Case ${i + 1}: missing required field '${field}'`);
        }
      });
    });
    return errors;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setValidationErrors([]);
    let parsed: any;
    try {
      parsed = JSON.parse(raw);
    } catch {
      setValidationErrors(["Invalid JSON — check your input"]);
      return;
    }
    const errs = validate(parsed);
    if (errs.length > 0) {
      setValidationErrors(errs);
      return;
    }
    mutation.mutate(parsed);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Batch Payload (JSON)
        </label>
        <textarea
          value={raw}
          onChange={(e) => setRaw(e.target.value)}
          rows={12}
          placeholder='{"portal_id": "availity", "cases": [...]}'
          className="w-full font-mono text-xs border border-gray-300 rounded-md
                     px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {validationErrors.length > 0 && (
        <ul className="bg-red-50 border border-red-200 rounded-md p-3 space-y-1">
          {validationErrors.map((err, i) => (
            <li key={i} className="text-sm text-red-700 font-mono">
              {err}
            </li>
          ))}
        </ul>
      )}

      {mutation.isSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-md p-3">
          <p className="text-sm text-green-700">
            Batch ingested successfully.
          </p>
        </div>
      )}

      <button
        type="submit"
        disabled={!raw.trim() || mutation.isPending}
        className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400
                   text-white px-6 py-2 rounded-md text-sm font-medium"
      >
        {mutation.isPending ? "Submitting..." : "Submit Batch"}
      </button>
    </form>
  );
}
```

---

## 11. Analytics Dashboard

```tsx
// src/pages/AnalyticsPage.tsx
import { useState }                from "react";
import { useQuery }                from "@tanstack/react-query";
import { RunVolumeChart }          from "../components/analytics/RunVolumeChart";
import { CostBreakdownChart }      from "../components/analytics/CostBreakdownChart";
import { StatusDistribution }      from "../components/analytics/StatusDistribution";
import apiClient                   from "../api/client";
import { subDays, format }         from "date-fns";

type Range = "7d" | "30d" | "90d";

function dateRange(r: Range) {
  const to   = format(new Date(), "yyyy-MM-dd");
  const days = r === "7d" ? 7 : r === "30d" ? 30 : 90;
  const from = format(subDays(new Date(), days), "yyyy-MM-dd");
  return { date_from: from, date_to: to };
}

export default function AnalyticsPage() {
  const [range, setRange] = useState<Range>("30d");
  const { date_from, date_to } = dateRange(range);

  const { data: volumeData } = useQuery({
    queryKey: ["analytics", "volume", range],
    queryFn:  () =>
      apiClient.get("/dashboard/run-volume", {
        params: { date_from, date_to, group_by: "day" },
      }).then((r) => r.data),
  });

  const { data: costData } = useQuery({
    queryKey: ["analytics", "cost", range],
    queryFn:  () =>
      apiClient.get("/dashboard/llm-cost", {
        params: { date_from, date_to },
      }).then((r) => r.data),
  });

  const { data: statsData } = useQuery({
    queryKey: ["analytics", "stats", range],
    queryFn:  () =>
      apiClient.get("/dashboard/case-stats", {
        params: { date_from, date_to },
      }).then((r) => r.data),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-gray-900">Analytics</h1>
        <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
          {(["7d", "30d", "90d"] as Range[]).map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`px-3 py-1 text-sm rounded-md font-medium transition-colors ${
                range === r
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* KPI tiles */}
      {statsData && <KPIRow stats={statsData} />}

      {/* Run volume chart */}
      <div className="bg-white rounded-lg border border-gray-200 p-5">
        <h2 className="text-sm font-semibold text-gray-700 mb-4">
          Daily Run Volume
        </h2>
        <RunVolumeChart data={volumeData?.rows ?? []} />
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Cost breakdown */}
        <div className="bg-white rounded-lg border border-gray-200 p-5">
          <h2 className="text-sm font-semibold text-gray-700 mb-4">
            LLM Cost by Model
          </h2>
          <CostBreakdownChart data={costData?.rows ?? []} />
        </div>

        {/* Status distribution */}
        <div className="bg-white rounded-lg border border-gray-200 p-5">
          <h2 className="text-sm font-semibold text-gray-700 mb-4">
            Case Status Distribution
          </h2>
          <StatusDistribution data={statsData?.by_status ?? []} />
        </div>
      </div>
    </div>
  );
}

function KPIRow({ stats }: { stats: any }) {
  const tiles = [
    { label: "Total Cases",    value: stats.total_cases,    color: "text-gray-900" },
    { label: "Approved",       value: stats.approved,       color: "text-green-600" },
    { label: "Denied",         value: stats.denied,         color: "text-red-600"   },
    { label: "In Progress",    value: stats.in_progress,    color: "text-blue-600"  },
    { label: "Total LLM Cost", value: `$${stats.total_llm_cost?.toFixed(2) ?? "0.00"}`,
      color: "text-gray-900" },
    { label: "Avg Duration",
      value: stats.avg_duration_minutes
        ? `${stats.avg_duration_minutes.toFixed(1)}m`
        : "—",
      color: "text-gray-900" },
  ];

  return (
    <div className="grid grid-cols-3 gap-4 lg:grid-cols-6">
      {tiles.map((t) => (
        <div key={t.label}
             className="bg-white rounded-lg border border-gray-200 p-4 text-center">
          <p className={`text-2xl font-bold ${t.color}`}>{t.value}</p>
          <p className="text-xs text-gray-500 mt-1">{t.label}</p>
        </div>
      ))}
    </div>
  );
}
```

```tsx
// src/components/analytics/RunVolumeChart.tsx
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from "recharts";
import { format, parseISO } from "date-fns";

interface DataRow {
  date:     string;
  total:    number;
  approved: number;
  denied:   number;
  failed:   number;
}

export function RunVolumeChart({ data }: { data: DataRow[] }) {
  const formatted = data.map((d) => ({
    ...d,
    date: format(parseISO(d.date), "MMM d"),
  }));

  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={formatted}
                 margin={{ top: 4, right: 16, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.2} />
            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}   />
          </linearGradient>
          <linearGradient id="colorApproved" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor="#22c55e" stopOpacity={0.2} />
            <stop offset="95%" stopColor="#22c55e" stopOpacity={0}   />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="date" tick={{ fontSize: 11 }} />
        <YAxis tick={{ fontSize: 11 }} />
        <Tooltip />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Area type="monotone" dataKey="total"    name="Total"
              stroke="#3b82f6" fill="url(#colorTotal)"    strokeWidth={2} />
        <Area type="monotone" dataKey="approved" name="Approved"
              stroke="#22c55e" fill="url(#colorApproved)" strokeWidth={2} />
        <Area type="monotone" dataKey="denied"   name="Denied"
              stroke="#ef4444" fill="none"                strokeWidth={2} />
        <Area type="monotone" dataKey="failed"   name="Failed"
              stroke="#f97316" fill="none"                strokeWidth={1}
              strokeDasharray="4 2" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
```

---

## 12. Alert SSE — Dashboard Notifications

```typescript
// src/hooks/useAlertSSE.ts
import { useEffect } from "react";
import { useAuthStore } from "../store/authStore";
import { useAlertStore } from "../store/alertStore";

export function useAlertSSE() {
  const token    = useAuthStore((s) => s.token);
  const pushAlert = useAlertStore((s) => s.push);

  useEffect(() => {
    if (!token) return;
    const es = new EventSource(`/api/v1/alert-sse?token=${token}`);

    es.onmessage = (event) => {
      if (event.data === ":heartbeat") return;
      try {
        const alert = JSON.parse(event.data);
        pushAlert(alert);
      } catch { /* ignore */ }
    };

    return () => es.close();
  }, [token, pushAlert]);
}
```

```typescript
// src/store/alertStore.ts
import { create } from "zustand";

export interface AppAlert {
  id:        string;
  type:      "STATUS_CHANGE" | "HITL_CREATED" | "CRASH" | "INFO";
  message:   string;
  severity:  "INFO" | "WARNING" | "ERROR";
  timestamp: string;
}

interface AlertState {
  alerts:    AppAlert[];
  push:      (a: AppAlert) => void;
  dismiss:   (id: string) => void;
  dismissAll: () => void;
}

let _nextId = 0;

export const useAlertStore = create<AlertState>()((set) => ({
  alerts: [],
  push: (a) =>
    set((s) => ({
      alerts: [{ ...a, id: String(_nextId++) }, ...s.alerts].slice(0, 10),
    })),
  dismiss:    (id) => set((s) => ({ alerts: s.alerts.filter((a) => a.id !== id) })),
  dismissAll: ()   => set({ alerts: [] }),
}));
```

```tsx
// src/components/common/AlertToast.tsx
import { useAlertStore } from "../../store/alertStore";
import { X, CheckCircle, AlertTriangle, AlertCircle } from "lucide-react";

export function AlertToast() {
  const { alerts, dismiss } = useAlertStore();

  if (alerts.length === 0) return null;

  const severityIcon = (s: string) => {
    switch (s) {
      case "ERROR":   return <AlertCircle   size={16} className="text-red-500"   />;
      case "WARNING": return <AlertTriangle size={16} className="text-yellow-500" />;
      default:        return <CheckCircle   size={16} className="text-green-500" />;
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2 max-w-sm w-full">
      {alerts.slice(0, 4).map((alert) => (
        <div
          key={alert.id}
          className="bg-white rounded-lg shadow-lg border border-gray-200
                     flex items-start gap-3 p-3 animate-slide-in"
        >
          <div className="shrink-0 mt-0.5">
            {severityIcon(alert.severity)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-gray-800 leading-tight">
              {alert.message}
            </p>
            <p className="text-xs text-gray-400 mt-0.5">
              {new Date(alert.timestamp).toLocaleTimeString()}
            </p>
          </div>
          <button
            onClick={() => dismiss(alert.id)}
            className="shrink-0 text-gray-400 hover:text-gray-600"
          >
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
```

---

## 13. Recipe Editor

```tsx
// src/components/recipes/RecipeEditor.tsx
/**
 * YAML recipe editor with CodeMirror syntax highlighting.
 * Validates YAML on-the-fly and submits to PUT /recipes/{portal_id}.
 */
import { useState, useEffect }  from "react";
import CodeMirror               from "@uiw/react-codemirror";
import { yaml }                 from "@codemirror/lang-yaml";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import apiClient                from "../../api/client";
import jsYaml                   from "js-yaml";

interface RecipeEditorProps {
  portalId:    string;
  initialYaml: string;
  onSaved?:    () => void;
}

export function RecipeEditor({
  portalId, initialYaml, onSaved
}: RecipeEditorProps) {
  const qc = useQueryClient();
  const [value,        setValue]        = useState(initialYaml);
  const [parseError,   setParseError]   = useState<string | null>(null);

  useEffect(() => {
    setValue(initialYaml);
  }, [initialYaml]);

  function handleChange(v: string) {
    setValue(v);
    try {
      jsYaml.load(v);
      setParseError(null);
    } catch (e: any) {
      setParseError(e.message);
    }
  }

  const mutation = useMutation({
    mutationFn: () =>
      apiClient.put(`/recipes/${portalId}`, { yaml_content: value }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["recipes"] });
      onSaved?.();
    },
  });

  return (
    <div className="space-y-3">
      <div className="border border-gray-300 rounded-lg overflow-hidden">
        <CodeMirror
          value={value}
          extensions={[yaml()]}
          onChange={handleChange}
          theme="light"
          height="500px"
          basicSetup={{
            lineNumbers:     true,
            foldGutter:      true,
            highlightActiveLine: true,
          }}
        />
      </div>

      {parseError && (
        <div className="bg-red-50 border border-red-200 rounded-md px-3 py-2">
          <p className="text-xs text-red-600 font-mono">{parseError}</p>
        </div>
      )}

      {mutation.isError && (
        <div className="bg-red-50 border border-red-200 rounded-md px-3 py-2">
          <p className="text-xs text-red-600">
            Save failed — check server logs.
          </p>
        </div>
      )}

      {mutation.isSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-md px-3 py-2">
          <p className="text-xs text-green-700">Recipe saved successfully.</p>
        </div>
      )}

      <div className="flex gap-2 justify-end">
        <button
          onClick={() => setValue(initialYaml)}
          className="border border-gray-300 text-gray-600 hover:bg-gray-50
                     px-4 py-2 rounded-md text-sm"
        >
          Reset
        </button>
        <button
          onClick={() => mutation.mutate()}
          disabled={!!parseError || mutation.isPending}
          className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400
                     text-white px-4 py-2 rounded-md text-sm font-medium"
        >
          {mutation.isPending ? "Saving..." : "Save Recipe"}
        </button>
      </div>
    </div>
  );
}
```

---

## 14. Unit & Component Tests

```typescript
// src/__tests__/statusNormalization.test.ts
import { describe, it, expect } from "vitest";
import type { CaseStatus } from "../api/types";

// Test the Badge component's status config coverage
const ALL_STATUSES: CaseStatus[] = [
  "PENDING", "PLANNING", "QUEUED", "IN_PROGRESS",
  "HITL_WAIT", "MFA_WAIT", "SUBMITTED", "APPROVED",
  "DENIED", "PENDING_INFO", "CRASHED", "FAILED", "CANCELLED",
];

describe("Status coverage", () => {
  it("has a config entry for every case status", () => {
    // Validates Badge component won't silently fall back for any known status
    const STATUS_CONFIG_KEYS = [
      "PENDING", "PLANNING", "QUEUED", "IN_PROGRESS",
      "HITL_WAIT", "MFA_WAIT", "SUBMITTED", "APPROVED",
      "DENIED", "PENDING_INFO", "CRASHED", "FAILED", "CANCELLED",
    ];
    ALL_STATUSES.forEach((s) => {
      expect(STATUS_CONFIG_KEYS).toContain(s);
    });
  });
});
```

```tsx
// src/__tests__/Badge.test.tsx
import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { Badge } from "../components/common/Badge";

describe("Badge", () => {
  it("renders APPROVED with green styling", () => {
    render(<Badge status="APPROVED" />);
    const el = screen.getByText("Approved");
    expect(el).toBeTruthy();
    expect(el.className).toContain("green");
  });

  it("renders DENIED with red styling", () => {
    render(<Badge status="DENIED" />);
    const el = screen.getByText("Denied");
    expect(el.className).toContain("red");
  });

  it("renders HITL_WAIT with yellow styling", () => {
    render(<Badge status="HITL_WAIT" />);
    const el = screen.getByText("HITL Wait");
    expect(el.className).toContain("yellow");
  });

  it("renders MFA_WAIT with orange styling", () => {
    render(<Badge status="MFA_WAIT" />);
    const el = screen.getByText("MFA Wait");
    expect(el.className).toContain("orange");
  });
});
```

```tsx
// src/__tests__/MFAEntryForm.test.tsx
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, it, expect, vi } from "vitest";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MFAEntryForm } from "../components/hitl/MFAEntryForm";

vi.mock("../api/hitl", () => ({
  submitMFACode: vi.fn().mockResolvedValue(undefined),
}));

function wrapper({ children }: { children: React.ReactNode }) {
  const qc = new QueryClient();
  return <QueryClientProvider client={qc}>{children}</QueryClientProvider>;
}

describe("MFAEntryForm", () => {
  it("disables submit button when OTP is too short", () => {
    render(<MFAEntryForm caseRefId="CASE-001" onSubmitted={() => {}} />,
           { wrapper });
    const btn = screen.getByRole("button", { name: /Submit OTP/i });
    expect(btn).toBeDisabled();
  });

  it("enables submit when OTP has 4+ digits", async () => {
    render(<MFAEntryForm caseRefId="CASE-001" onSubmitted={() => {}} />,
           { wrapper });
    const input = screen.getByPlaceholderText("6-digit code");
    await userEvent.type(input, "123456");
    const btn = screen.getByRole("button", { name: /Submit OTP/i });
    expect(btn).not.toBeDisabled();
  });

  it("strips non-numeric characters", async () => {
    render(<MFAEntryForm caseRefId="CASE-001" onSubmitted={() => {}} />,
           { wrapper });
    const input = screen.getByPlaceholderText("6-digit code");
    await userEvent.type(input, "abc123def");
    expect((input as HTMLInputElement).value).toBe("123");
  });
});
```

```tsx
// src/__tests__/LogStream.test.tsx
import { render, screen } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { LogStream } from "../components/cases/LogStream";

vi.mock("../hooks/useSSELogs", () => ({
  useSSELogs: () => ({
    entries: [
      { id: "0", ts: "2026-09-04T10:00:00Z", level: "INFO",
        msg: "Recipe step: navigate" },
      { id: "1", ts: "2026-09-04T10:00:01Z", level: "ERROR",
        msg: "Click timeout on selector #submit" },
    ],
    connected: true,
  }),
}));

describe("LogStream", () => {
  it("renders log entries", () => {
    render(<LogStream caseRefId="CASE-001" />);
    expect(screen.getByText("Recipe step: navigate")).toBeTruthy();
    expect(screen.getByText("Click timeout on selector #submit")).toBeTruthy();
  });

  it("shows Live indicator when connected", () => {
    render(<LogStream caseRefId="CASE-001" />);
    expect(screen.getByText("Live")).toBeTruthy();
  });

  it("shows entry count", () => {
    render(<LogStream caseRefId="CASE-001" />);
    expect(screen.getByText("2 entries")).toBeTruthy();
  });
});
```

---

*Document Status: DRAFT*
*Previous: [12_Tracking_Agent_Implementation.md](12_Tracking_Agent_Implementation.md)*
*Series complete — all 13 implementation documents delivered.*
