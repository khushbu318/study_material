# AutoAuth Agent — N8N Workflow Setup Guide
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026

N8N is the orchestration glue between services. Without it, cases will never move past `PLANNING`.
This document tells you exactly what to build in N8N, step by step.

---

## Overview: 7 Workflows

| # | Workflow Name | Trigger | What It Does |
|---|---|---|---|
| 1 | `prior-auth-submission` | Webhook (POST) | Receives case from planner, publishes to Pub/Sub Topic #2 |
| 2 | `prior-auth-agents` | Webhook (POST) | Creates browser session on control-plane |
| 3 | `prior-auth-completed` | Webhook (POST) | Handles PA submission success |
| 4 | `prior-auth-status-capture` | Webhook (POST) | Updates case status (HITL, crash, MFA alerts) |
| 5 | `prior-auth-mfa-notification` | Webhook (POST) | Alerts dashboard of MFA requirement |
| 6 | `prior-auth-hitl-notification` | Webhook (POST) | Alerts dashboard of HITL requirement |
| 7 | `prior-auth-retrigger` | Webhook (POST) | Retriggles a failed case via planner |

---

## Setup: Before Building Workflows

### 1. Access N8N
- Local dev: `http://localhost:5678`
- Default login: admin@autoauth.com / admin (change immediately)

### 2. Add Credentials in N8N
Go to **Settings → Credentials → New**. Add these:

**HTTP Header Auth** (for HMAC signature verification):
- Name: `AutoAuth Webhook Secret`
- Header Name: `X-Signature`
- Header Value: (your webhook secret from Secret Manager)

**Google Cloud PubSub** (for Workflow 1):
- Name: `GCP PubSub`
- Project ID: your GCP project ID
- Service Account JSON: your GCP SA key (for dev only; use Workload Identity in prod)

### 3. Set N8N Environment Variables
In your N8N container (docker-compose or K8s):
```
N8N_BASIC_AUTH_ACTIVE=true
N8N_BASIC_AUTH_USER=admin@autoauth.com
N8N_BASIC_AUTH_PASSWORD=<strong password>
WEBHOOK_URL=http://n8n:5678   # internal URL other services use
N8N_HOST=n8n
N8N_PORT=5678
N8N_PROTOCOL=http
```

---

## Workflow 1: `prior-auth-submission`

**Purpose:** Planner triggers this after deciding a case is ready to submit.
Validates the HMAC signature, then publishes the case payload to Pub/Sub Topic #2
so control-plane picks it up.

**Nodes:**
```
[Webhook] → [HMAC Validate] → [GCP Pub/Sub: Publish] → [HTTP Response 200]
```

**Webhook node config:**
- Method: POST
- Path: `/prior-auth-submission`
- Response Mode: Last Node
- Authentication: None (signature validated manually in next node)

**HMAC Validate node** (Function node):
```javascript
const crypto = require('crypto');
const secret  = $env.WEBHOOK_SECRET;
const payload = JSON.stringify($input.body);
const expected = crypto
  .createHmac('sha256', secret)
  .update(payload)
  .digest('hex');
const received = $input.headers['x-signature'] ?? '';

if (received !== expected) {
  throw new Error('Invalid webhook signature');
}
return $input.all();
```

**GCP Pub/Sub Publish node:**
- Operation: Publish
- Topic: `projects/{PROJECT_ID}/topics/prior-auth-control-plane-topic`
- Message: `{{ JSON.stringify($input.body) }}`
- Credentials: `GCP PubSub`

**HTTP Response node:**
- Status Code: 200
- Body: `{"status": "queued"}`

---

## Workflow 2: `prior-auth-agents`

**Purpose:** Alternative path — control-plane can be called directly (bypassing Pub/Sub)
for cases that need immediate session creation. Also used during local dev when
Pub/Sub emulator is not running.

**Nodes:**
```
[Webhook] → [HMAC Validate] → [HTTP: POST control-plane/sessions] → [HTTP Response]
```

**HTTP Request node (call control-plane):**
- Method: POST
- URL: `http://control-plane:8083/api/v1/sessions`
- Body (JSON):
```json
{
  "case_ref_id":       "{{ $input.body.case_ref_id }}",
  "portal_id":         "{{ $input.body.portal_id }}",
  "patient_data":      "{{ $input.body.patient_data }}",
  "clinical_data":     "{{ $input.body.clinical_data }}",
  "credential_id":     "{{ $input.body.credential_id }}",
  "shared_session_id": "{{ $input.body.shared_session_id }}"
}
```
- On Error: Continue (log failure to status-capture webhook)

---

## Workflow 3: `prior-auth-completed`

**Purpose:** Called by browser-agent's `CompletionService.notify_success()`.
Updates case status to SUBMITTED and triggers tracking session creation.

**Nodes:**
```
[Webhook] → [HMAC Validate] → [HTTP: PATCH api-server case status]
                             → [IF: pa_reference_number exists]
                                  → [HTTP: POST control-plane/tracking/sessions]
                             → [HTTP Response 200]
```

**PATCH case status (HTTP Request node):**
- Method: PATCH
- URL: `http://api-server:8080/api/v1/prior-auths/{{ $input.body.case_ref_id }}`
- Body:
```json
{
  "status": "SUBMITTED",
  "pa_reference_number": "{{ $input.body.pa_reference_number }}"
}
```

**IF node (check pa_reference_number):**
- Condition: `{{ $input.body.pa_reference_number }}` is not empty

**POST tracking session (true branch):**
- URL: `http://control-plane:8083/api/v1/tracking/sessions`
- Body:
```json
{
  "case_ref_id":         "{{ $input.body.case_ref_id }}",
  "pa_reference_number": "{{ $input.body.pa_reference_number }}",
  "portal_id":           "{{ $input.body.portal_id }}"
}
```

---

## Workflow 4: `prior-auth-status-capture`

**Purpose:** Generic status update webhook. Called by:
- browser-agent on HITL/MFA creation
- control-plane on crash detection
- tracking-agent on APPROVED/DENIED
- Any service that needs to update a case status

**Nodes:**
```
[Webhook] → [HMAC Validate] → [Switch: status field]
               CRASHED/FAILED  → [HTTP: PATCH case status + send alert]
               HITL_WAIT       → [HTTP: PATCH case + broadcast alert]
               MFA_WAIT        → [HTTP: PATCH case + broadcast alert]
               APPROVED/DENIED/PENDING_INFO → [HTTP: PATCH case + send alert]
               default         → [HTTP: PATCH case status only]
          → [HTTP Response 200]
```

**Switch node conditions (on `$input.body.new_status ?? $input.body.status`):**
- Route 1: equals `CRASHED` or `FAILED`
- Route 2: equals `HITL_WAIT`
- Route 3: equals `MFA_WAIT`
- Route 4: equals `APPROVED`, `DENIED`, or `PENDING_INFO`
- Default route: everything else

**PATCH case status (reused across routes):**
- URL: `http://api-server:8080/api/v1/prior-auths/{{ $input.body.case_ref_id }}`
- Method: PATCH
- Body: `{ "status": "{{ $input.body.new_status ?? $input.body.status }}" }`

**Broadcast alert (HTTP Request node):**
- URL: `http://api-server:8080/api/v1/internal/broadcast-alert`
- Method: POST
- Body:
```json
{
  "case_ref_id": "{{ $input.body.case_ref_id }}",
  "alert_type":  "STATUS_CHANGE",
  "severity":    "{{ $input.body.status === 'CRASHED' ? 'ERROR' : 'INFO' }}",
  "message":     "Case {{ $input.body.case_ref_id }} → {{ $input.body.new_status ?? $input.body.status }}"
}
```

---

## Workflow 5: `prior-auth-mfa-notification`

**Purpose:** Browser-agent fires this when it hits an MFA step.
Sends an alert so the dashboard HITL page shows the MFA task immediately
(in addition to the DB task already created by browser-agent).

**Nodes:**
```
[Webhook] → [HMAC Validate] → [HTTP: PATCH case status → MFA_WAIT]
                             → [HTTP: Broadcast alert]
                             → [HTTP Response 200]
```

**PATCH node:**
- URL: `http://api-server:8080/api/v1/prior-auths/{{ $input.body.case_ref_id }}`
- Body: `{ "status": "MFA_WAIT" }`

**Broadcast node:**
- Message: `"MFA required for case {{ $input.body.case_ref_id }} — enter OTP in dashboard"`
- Severity: `WARNING`

---

## Workflow 6: `prior-auth-hitl-notification`

**Purpose:** Browser-agent fires this when it hits a `request_hitl` step.

**Nodes:**
```
[Webhook] → [HMAC Validate] → [HTTP: PATCH case status → HITL_WAIT]
                             → [HTTP: Broadcast alert]
                             → [HTTP Response 200]
```

**PATCH node:**
- Body: `{ "status": "HITL_WAIT" }`

**Broadcast node:**
- Message: `"Manual intervention needed — {{ $input.body.message }}"`
- Severity: `WARNING`

---

## Workflow 7: `prior-auth-retrigger`

**Purpose:** Called by control-plane's `ExpiredEventConsumer` after crash detection
when the case still has retries remaining.

**Nodes:**
```
[Webhook] → [HMAC Validate] → [HTTP: POST planner/retrigger/{case_ref_id}]
                             → [HTTP Response 200]
```

**HTTP Request node:**
- URL: `http://planner:8082/api/v1/retrigger/{{ $input.body.case_ref_id }}`
- Method: POST
- Body: `{}`

---

## After Building All 7 Workflows

### 1. Activate All Workflows
Click the toggle next to each workflow — inactive workflows won't fire.

### 2. Copy Webhook URLs
Each webhook node shows its URL after activation.
Copy them into your service `.env` files:

```bash
# planner/.env
N8N_SUBMISSION_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-submission
N8N_STATUS_CAPTURE_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-status-capture
N8N_MFA_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-mfa-notification
N8N_HITL_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-hitl-notification

# browser-agent/.env
N8N_COMPLETED_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-completed
N8N_STATUS_CAPTURE_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-status-capture

# control-plane/.env
N8N_COMPLETED_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-completed
N8N_STATUS_CAPTURE_WEBHOOK_URL=http://n8n:5678/webhook/prior-auth-status-capture
```

### 3. Smoke Test Each Workflow
```bash
# Test workflow 1 directly
PAYLOAD='{"case_ref_id":"TEST-001","portal_id":"availity"}'
SIG=$(echo -n "$PAYLOAD" | openssl dgst -sha256 -hmac "your_secret" | awk '{print $2}')
curl -X POST http://localhost:5678/webhook/prior-auth-submission \
  -H "Content-Type: application/json" \
  -H "X-Signature: $SIG" \
  -d "$PAYLOAD"
# Expected: {"status":"queued"}
```

### 4. Export Workflow JSON for Version Control
N8N → Settings → Export → Download JSON.
Save to `n8n/workflows/` in your repo. Commit these files.

---

## Common Errors

| Error | Cause | Fix |
|---|---|---|
| `Invalid webhook signature` | Secret mismatch between service and N8N | Verify `N8N_WEBHOOK_SECRET` matches in both places |
| `Workflow not found` | Workflow not activated | Toggle the workflow active |
| Workflow fires but no DB update | api-server not reachable from N8N | Use service name `api-server`, not `localhost` |
| Pub/Sub publish fails locally | Emulator not running or wrong topic name | Run `docker compose up pubsub-emulator`, check topic name |
| N8N loops / re-fires | HMAC validation skipped | Ensure HMAC node is before any HTTP calls |
