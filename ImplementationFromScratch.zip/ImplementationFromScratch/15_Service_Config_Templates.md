# AutoAuth Agent — Service Config Templates
## `pyproject.toml` + `.env` for Every Service
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026

Copy these files directly into each service directory. Replace placeholder values.

---

## common/ (Shared Library)

### `common/pyproject.toml`
```toml
[tool.poetry]
name        = "autoauth-common"
version     = "1.0.0"
description = "AutoAuth Agent shared library"
packages    = [{include = "common", from = "src"}]

[tool.poetry.dependencies]
python                      = "^3.12"
sqlalchemy                  = "^2.0"
alembic                     = "^1.13"
psycopg2-binary             = "^2.9"
redis                       = {extras = ["hiredis"], version = "^5.0"}
google-cloud-pubsub         = "^2.21"
google-cloud-secret-manager = "^2.20"
structlog                   = "^24.1"
pydantic                    = "^2.7"
pydantic-settings           = "^2.3"

[tool.poetry.dev-dependencies]
pytest       = "^8.2"
pytest-cov   = "^5.0"

[build-system]
requires      = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

---

## api-server/

### `api-server/pyproject.toml`
```toml
[tool.poetry]
name    = "autoauth-api-server"
version = "1.0.0"
packages = [{include = "api_server", from = "src"}]

[tool.poetry.dependencies]
python            = "^3.12"
fastapi           = "^0.111"
uvicorn           = {extras = ["standard"], version = "^0.30"}
python-jose       = {extras = ["cryptography"], version = "^3.3"}
passlib           = {extras = ["bcrypt"], version = "^1.7"}
httpx             = "^0.27"
autoauth-common   = {path = "../common", develop = true}

[tool.poetry.dev-dependencies]
pytest                    = "^8.2"
pytest-asyncio            = "^0.23"
httpx                     = "^0.27"
pytest-cov                = "^5.0"
ruff                      = "^0.4"

[build-system]
requires      = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

### `api-server/.env`
```bash
# ── App ───────────────────────────────────────────────────────────
APP_ENV=dev
SERVICE_NAME=api-server
LOG_LEVEL=INFO

# ── Database ──────────────────────────────────────────────────────
DB_HOST=localhost
DB_PORT=5432
DB_USER=autoauth
DB_PASSWORD=autoauth_dev_password
DB_NAME=autoauth

# ── Redis ─────────────────────────────────────────────────────────
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_AUTH=
REDIS_TLS=false

# ── GCP ───────────────────────────────────────────────────────────
GCP_PROJECT_ID=your-gcp-project-id
GOOGLE_APPLICATION_CREDENTIALS=/path/to/sa-key.json

# ── Pub/Sub ───────────────────────────────────────────────────────
SUBMISSION_TOPIC_ID=prior-auth-submission-topic
PUBSUB_EMULATOR_HOST=localhost:8085    # remove in prod

# ── JWT ───────────────────────────────────────────────────────────
JWT_SECRET_KEY=dev_jwt_secret_change_in_prod_min_32_chars
JWT_ALGORITHM=HS256
JWT_EXPIRY_MINUTES=60

# ── Planner ───────────────────────────────────────────────────────
PLANNER_URL=http://localhost:8082
```

---

## planner/

### `planner/pyproject.toml`
```toml
[tool.poetry]
name    = "autoauth-planner"
version = "1.0.0"
packages = [{include = "planner", from = "src"}]

[tool.poetry.dependencies]
python          = "^3.12"
fastapi         = "^0.111"
uvicorn         = {extras = ["standard"], version = "^0.30"}
httpx           = "^0.27"
autoauth-common = {path = "../common", develop = true}

[tool.poetry.dev-dependencies]
pytest        = "^8.2"
pytest-asyncio = "^0.23"
pytest-cov    = "^5.0"
ruff          = "^0.4"

[build-system]
requires      = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

### `planner/.env`
```bash
APP_ENV=dev
SERVICE_NAME=planner
LOG_LEVEL=INFO

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=autoauth
DB_PASSWORD=autoauth_dev_password
DB_NAME=autoauth

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_AUTH=
REDIS_TLS=false

# GCP
GCP_PROJECT_ID=your-gcp-project-id
GOOGLE_APPLICATION_CREDENTIALS=/path/to/sa-key.json

# Pub/Sub
SUBMISSION_SUBSCRIPTION_ID=prior-auth-submission-sub
PUBSUB_EMULATOR_HOST=localhost:8085

# N8N Webhooks
N8N_SUBMISSION_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-submission
N8N_STATUS_CAPTURE_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-status-capture
N8N_MFA_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-mfa-notification
N8N_HITL_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-hitl-notification
N8N_WEBHOOK_SECRET=dev_n8n_hmac_secret_32chars_minimum

# ONE_SESSION_PER_BATCH
ONE_SESSION_PER_BATCH=true
DEDUP_TTL_SECONDS=300
```

---

## control-plane/

### `control-plane/pyproject.toml`
```toml
[tool.poetry]
name    = "autoauth-control-plane"
version = "1.0.0"
packages = [{include = "control_plane", from = "src"}]

[tool.poetry.dependencies]
python          = "^3.12"
fastapi         = "^0.111"
uvicorn         = {extras = ["standard"], version = "^0.30"}
httpx           = "^0.27"
websockets      = "^12.0"
autoauth-common = {path = "../common", develop = true}

[tool.poetry.dev-dependencies]
pytest        = "^8.2"
pytest-asyncio = "^0.23"
pytest-cov    = "^5.0"
ruff          = "^0.4"

[build-system]
requires      = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

### `control-plane/.env`
```bash
APP_ENV=dev
SERVICE_NAME=control-plane
LOG_LEVEL=INFO

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=autoauth
DB_PASSWORD=autoauth_dev_password
DB_NAME=autoauth

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_AUTH=
REDIS_TLS=false

# GCP
GCP_PROJECT_ID=your-gcp-project-id
GOOGLE_APPLICATION_CREDENTIALS=/path/to/sa-key.json

# Pub/Sub
CONTROL_PLANE_SUBSCRIPTION_ID=prior-auth-control-plane-sub
PUBSUB_EMULATOR_HOST=localhost:8085

# N8N
N8N_COMPLETED_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-completed
N8N_STATUS_CAPTURE_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-status-capture
N8N_WEBHOOK_SECRET=dev_n8n_hmac_secret_32chars_minimum

# Service URLs
PLANNER_URL=http://localhost:8082
BROWSER_AGENT_PORT=8081

# Heartbeat
HEARTBEAT_INTERVAL_SECONDS=30
HEARTBEAT_TTL_SECONDS=90
COOLING_SECONDS=60
```

---

## browser-agent/

### `browser-agent/pyproject.toml`
```toml
[tool.poetry]
name    = "autoauth-browser-agent"
version = "1.0.0"
packages = [{include = "browser_agent", from = "src"}]

[tool.poetry.dependencies]
python           = "^3.12"
fastapi          = "^0.111"
uvicorn          = {extras = ["standard"], version = "^0.30"}
playwright       = "^1.44"
httpx            = "^0.27"
pyyaml           = "^6.0"
anthropic        = "^0.28"
# browser-use is optional — only needed for LLM mode
# browser-use      = "^0.1"
autoauth-common  = {path = "../common", develop = true}

[tool.poetry.dev-dependencies]
pytest        = "^8.2"
pytest-asyncio = "^0.23"
pytest-cov    = "^5.0"
ruff          = "^0.4"

[tool.poetry.scripts]
install-browsers = "playwright._impl._driver:main"

[build-system]
requires      = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

### `browser-agent/.env`
```bash
APP_ENV=dev
SERVICE_NAME=browser-agent
LOG_LEVEL=INFO

# Pod identity (set by K8s downward API; for local dev use these)
POD_ID=browser-agent-local-dev
POD_IP=127.0.0.1
POD_PORT=8081

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=autoauth
DB_PASSWORD=autoauth_dev_password
DB_NAME=autoauth

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_AUTH=
REDIS_TLS=false

# GCP
GCP_PROJECT_ID=your-gcp-project-id
GOOGLE_APPLICATION_CREDENTIALS=/path/to/sa-key.json

# Service URLs
API_SERVER_URL=http://localhost:8080
CONTROL_PLANE_URL=http://localhost:8083

# N8N
N8N_COMPLETED_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-completed
N8N_STATUS_CAPTURE_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-status-capture
N8N_WEBHOOK_SECRET=dev_n8n_hmac_secret_32chars_minimum

# Capsolver
CAPSOLVER_API_KEY=your_capsolver_api_key

# Display / VNC  (only relevant on Linux/WSL2)
DISPLAY_SLOTS=3
BASE_DISPLAY_NUMBER=99
BASE_VNC_PORT=5900
BASE_WEB_PORT=6080

# Heartbeat
HEARTBEAT_INTERVAL_SECONDS=30
HEARTBEAT_TTL_SECONDS=90

# AI Summarization
ANTHROPIC_API_KEY=your_anthropic_api_key
SUMMARY_MODEL=claude-haiku-4-5-20251001

# Timeouts
DEFAULT_ACTION_TIMEOUT=30
DEFAULT_PAGE_TIMEOUT=60
HITL_WAIT_TIMEOUT=1800
MFA_WAIT_TIMEOUT=300
```

---

## tracking-agent/

### `tracking-agent/pyproject.toml`
```toml
[tool.poetry]
name    = "autoauth-tracking-agent"
version = "1.0.0"
packages = [{include = "tracking_agent", from = "src"}]

[tool.poetry.dependencies]
python          = "^3.12"
fastapi         = "^0.111"
uvicorn         = {extras = ["standard"], version = "^0.30"}
playwright      = "^1.44"
httpx           = "^0.27"
pyyaml          = "^6.0"
autoauth-common = {path = "../common", develop = true}

[tool.poetry.dev-dependencies]
pytest        = "^8.2"
pytest-asyncio = "^0.23"
pytest-cov    = "^5.0"
ruff          = "^0.4"

[build-system]
requires      = ["poetry-core"]
build-backend = "poetry.core.masonry.api"
```

### `tracking-agent/.env`
```bash
APP_ENV=dev
SERVICE_NAME=tracking-agent
LOG_LEVEL=INFO

POD_ID=tracking-agent-local-dev
POD_IP=127.0.0.1
POD_PORT=8084

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=autoauth
DB_PASSWORD=autoauth_dev_password
DB_NAME=autoauth

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_AUTH=
REDIS_TLS=false

# GCP
GCP_PROJECT_ID=your-gcp-project-id
GOOGLE_APPLICATION_CREDENTIALS=/path/to/sa-key.json

# Service URLs
API_SERVER_URL=http://localhost:8080
CONTROL_PLANE_URL=http://localhost:8083

# N8N
N8N_STATUS_CAPTURE_WEBHOOK_URL=http://localhost:5678/webhook/prior-auth-status-capture
N8N_WEBHOOK_SECRET=dev_n8n_hmac_secret_32chars_minimum

# Polling
POLL_SCHEDULE_HOURS=[1, 4, 24, 48]
POLL_MAX_CHECKS=20

# Heartbeat
HEARTBEAT_INTERVAL_SECONDS=30
HEARTBEAT_TTL_SECONDS=90

# Playwright
DEFAULT_PAGE_TIMEOUT=60
DEFAULT_ACTION_TIMEOUT=30
```

---

## frontend/

### `frontend/.env`
```bash
VITE_API_BASE_URL=http://localhost:8080/api/v1
```

### `frontend/.env.production`
```bash
VITE_API_BASE_URL=/api/v1
```

### `frontend/vite.config.ts`
```typescript
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Proxy all API calls to api-server during local dev
      "/api": {
        target: "http://localhost:8080",
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: "dist",
    sourcemap: false,
  },
});
```

---

## Alembic Config (common/)

### `common/alembic.ini`
```ini
[alembic]
script_location = alembic
sqlalchemy.url  = postgresql://%(DB_USER)s:%(DB_PASSWORD)s@%(DB_HOST)s:%(DB_PORT)s/%(DB_NAME)s

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level   = WARN
handlers = console

[logger_sqlalchemy]
level     = WARN
handlers  =
qualname  = sqlalchemy.engine

[logger_alembic]
level     = INFO
handlers  =
qualname  = alembic

[handler_console]
class     = StreamHandler
args      = (sys.stderr,)
level     = NOTSET
formatter = generic

[formatter_generic]
format    = %(levelname)-5.5s [%(name)s] %(message)s
datefmt   = %H:%M:%S
```

### `common/alembic/env.py`
```python
import os
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context
from common.db_layer.orm_models import Base

config = context.config

# Read DB URL from environment
db_url = (
    f"postgresql://{os.environ['DB_USER']}:{os.environ['DB_PASSWORD']}"
    f"@{os.environ.get('DB_HOST','localhost')}:{os.environ.get('DB_PORT','5432')}"
    f"/{os.environ.get('DB_NAME','autoauth')}"
)
config.set_main_option("sqlalchemy.url", db_url)

if config.config_file_name:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline():
    context.configure(
        url=db_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        include_schemas=True,
        version_table_schema="iks_schema",
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            include_schemas=True,
            version_table_schema="iks_schema",
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
```

---

## Quick Install Commands

Run these from each service directory after copying `pyproject.toml`:

```bash
# Install all services + common
cd common        && poetry install && cd ..
cd api-server    && poetry install && cd ..
cd planner       && poetry install && cd ..
cd control-plane && poetry install && cd ..
cd browser-agent && poetry install && cd ..
cd tracking-agent && poetry install && cd ..

# Install Playwright browsers (browser-agent and tracking-agent)
cd browser-agent  && poetry run playwright install chromium && cd ..
cd tracking-agent && poetry run playwright install chromium && cd ..

# Frontend
cd frontend && npm install && cd ..

# Run migrations (from common/, with DB running)
cd common
export DB_HOST=localhost DB_PORT=5432 DB_USER=autoauth \
       DB_PASSWORD=autoauth_dev_password DB_NAME=autoauth
poetry run alembic upgrade head
```
