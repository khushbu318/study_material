# AutoAuth Agent — Testing & Local Dev Cookbook
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026

How to develop and test every part of this system without touching real payer portals.

---

## The Core Problem

You cannot test against real Availity, Navinet, or CareCore portals during development:
- Submitting fake PAs to real portals is a HIPAA violation
- Real portals require valid provider credentials and NPI numbers
- Portal behavior changes without notice and will break your tests

**Solution:** Three-layer testing strategy:
1. **Unit tests** — mock everything, test logic in isolation
2. **Integration tests** — real DB + Redis, mocked HTTP/Playwright
3. **End-to-end** — run the full stack with a fake portal (mock server)

---

## Layer 1: Unit Tests

### Running Tests (any service)
```bash
cd api-server
poetry run pytest tests/ -v --cov=src --cov-report=term-missing

# Run a single test file
poetry run pytest tests/test_batch_service.py -v

# Run a single test
poetry run pytest tests/test_batch_service.py::test_duplicate_case_not_reprocessed -v
```

### What to Mock in Each Service

**api-server:**
```python
# Mock DB session
from unittest.mock import MagicMock, patch

@patch("api_server.services.batch_service.get_session_factory")
@patch("api_server.services.batch_service.publish_message")
def test_ingest_batch(mock_publish, mock_sf):
    mock_session = MagicMock()
    mock_session.__enter__ = MagicMock(return_value=mock_session)
    mock_session.__exit__  = MagicMock(return_value=False)
    mock_session.query.return_value.filter_by.return_value.first.return_value = None
    mock_sf.return_value.return_value = mock_session
    # ... test logic
```

**planner:**
```python
# Mock N8N webhook call
@patch("planner.services.n8n_trigger.httpx.Client")
def test_trigger_fires_hmac(mock_client):
    mock_resp = MagicMock()
    mock_resp.raise_for_status = MagicMock()
    mock_client.return_value.__enter__.return_value.post.return_value = mock_resp
    # ... test logic
```

**browser-agent (RecipeRunner):**
```python
# Mock Playwright page
from unittest.mock import MagicMock
page = MagicMock()
page.locator.return_value.inner_text.return_value = "Approved"
page.locator.return_value.wait_for = MagicMock()
# Run runner against fake page
runner = RecipeRunner(page=page, ...)
```

---

## Layer 2: Integration Tests

### Local Test Database
Use a separate test DB to avoid polluting dev data:
```bash
# Create test DB (one time)
docker exec -it autoauth-postgres psql -U autoauth -c "CREATE DATABASE autoauth_test;"

# Run integration tests with test DB
DB_NAME=autoauth_test poetry run pytest tests/integration/ -v
```

### Test Fixtures (`conftest.py` pattern)
```python
# tests/conftest.py  (api-server)
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from common.db_layer.orm_models import Base
import os

TEST_DB_URL = (
    f"postgresql://{os.environ.get('DB_USER','autoauth')}"
    f":{os.environ.get('DB_PASSWORD','autoauth_dev_password')}"
    f"@{os.environ.get('DB_HOST','localhost')}"
    f"/{os.environ.get('DB_NAME','autoauth_test')}"
)

@pytest.fixture(scope="session")
def engine():
    eng = create_engine(TEST_DB_URL)
    Base.metadata.create_all(eng)
    yield eng
    Base.metadata.drop_all(eng)

@pytest.fixture()
def db_session(engine):
    """Each test gets a transaction that is rolled back."""
    connection   = engine.connect()
    transaction  = connection.begin()
    Session      = sessionmaker(bind=connection)
    session      = Session()
    yield session
    session.close()
    transaction.rollback()
    connection.close()

@pytest.fixture()
def test_payer(db_session):
    from common.db_layer.orm_models import PriorAuthPayer
    payer = PriorAuthPayer(name="Test Payer", code="test_payer")
    db_session.add(payer)
    db_session.flush()
    return payer

@pytest.fixture()
def test_portal(db_session, test_payer):
    from common.db_layer.orm_models import PriorAuthPortal
    portal = PriorAuthPortal(
        payer_id=test_payer.id,
        name="Test Portal",
        code="test_portal",
        portal_url="http://fake-portal.test",
    )
    db_session.add(portal)
    db_session.flush()
    return portal

@pytest.fixture()
def test_case(db_session, test_portal, test_payer):
    from common.db_layer.orm_models import PriorAuthCaseRequest
    case = PriorAuthCaseRequest(
        case_ref_id="TEST-CASE-001",
        portal_id=test_portal.id,
        payer_id=test_payer.id,
        patient_data={
            "member_id":    "M12345",
            "first_name":   "Jane",
            "last_name":    "Doe",
            "date_of_birth":"1990-05-15",
        },
        clinical_data={
            "diagnosis_codes": ["M79.3"],
            "procedure_codes": ["97110"],
        },
        status="PENDING",
    )
    db_session.add(case)
    db_session.flush()
    return case
```

### Integration Test: Full Case Ingest
```python
# tests/integration/test_case_ingest.py
def test_case_ingest_creates_db_row(db_session, test_portal, test_payer):
    from api_server.services.batch_service import BatchService
    from unittest.mock import patch

    with patch("api_server.services.batch_service.publish_message"):
        result = BatchService.ingest_batch(
            db=db_session,
            portal_id=str(test_portal.id),
            cases=[{
                "case_ref_id":  "INT-TEST-001",
                "patient_data": {
                    "member_id":    "M99999",
                    "first_name":   "Test",
                    "last_name":    "User",
                    "date_of_birth":"1985-01-01",
                },
                "clinical_data": {"diagnosis_codes": ["G89.29"]},
            }],
        )

    from common.db_layer.orm_models import PriorAuthCaseRequest
    case = db_session.query(PriorAuthCaseRequest).filter_by(
        case_ref_id="INT-TEST-001").first()
    assert case is not None
    assert case.status == "PENDING"
```

---

## Layer 3: End-to-End with a Fake Portal

### Setting Up a Mock Portal Server
Create a simple HTTP server that mimics a payer portal for E2E testing.
Playwright navigates this just like a real portal.

```python
# tests/e2e/mock_portal/server.py
"""
Minimal Flask server that simulates a payer portal for E2E testing.
Run with: python server.py
Accessible at: http://localhost:9090
"""
from flask import Flask, request, redirect, session, render_template_string

app = Flask(__name__)
app.secret_key = "test"

LOGIN_TEMPLATE = """
<html><body>
  <form method="POST" action="/login">
    <input id="username" name="username" type="text" placeholder="Username" />
    <input id="password" name="password" type="password" placeholder="Password" />
    <button type="submit" id="login-btn">Login</button>
  </form>
</body></html>
"""

PA_FORM_TEMPLATE = """
<html><body>
  <h1>Submit Prior Authorization</h1>
  <form method="POST" action="/submit-pa">
    <input id="member-id"   name="member_id"   value="{{ member_id }}" />
    <input id="diagnosis"   name="diagnosis"   value="{{ diagnosis }}" />
    <button type="submit" id="submit-pa-btn">Submit</button>
  </form>
</body></html>
"""

CONFIRMATION_TEMPLATE = """
<html><body>
  <h1>Authorization Submitted</h1>
  <div class="confirmation-number">PA-TEST-{{ ref_number }}</div>
  <div class="auth-status-badge">Pending Review</div>
</body></html>
"""

@app.route("/login", methods=["GET"])
def login_page():
    return render_template_string(LOGIN_TEMPLATE)

@app.route("/login", methods=["POST"])
def login():
    if (request.form.get("username") == "test_user"
            and request.form.get("password") == "test_pass"):
        session["logged_in"] = True
        return redirect("/pa-form")
    return "Invalid credentials", 401

@app.route("/pa-form")
def pa_form():
    if not session.get("logged_in"):
        return redirect("/login")
    return render_template_string(PA_FORM_TEMPLATE,
                                  member_id="", diagnosis="")

@app.route("/submit-pa", methods=["POST"])
def submit_pa():
    import random
    ref = random.randint(100000, 999999)
    return render_template_string(CONFIRMATION_TEMPLATE, ref_number=ref)

@app.route("/pa-status")
def pa_status():
    return render_template_string("""
    <html><body>
      <div class="auth-status-badge">Approved</div>
    </body></html>
    """)

if __name__ == "__main__":
    app.run(port=9090, debug=False)
```

### Fake Portal Recipe (`test_portal_recipe.yaml`)
```yaml
name: Test Portal (Mock)
portal_id: test_portal
version: "1.0"
recipe_type: submission
portal_url: http://localhost:9090

steps:
  - name: Navigate to login
    action: navigate
    url: http://localhost:9090/login

  - name: Enter username
    action: type
    selector: "#username"
    value: "{{credentials.username}}"

  - name: Enter password
    action: type
    selector: "#password"
    value: "{{credentials.password}}"

  - name: Click login
    action: click
    selector: "#login-btn"
    wait_for_navigation: true

  - name: Navigate to PA form
    action: navigate
    url: http://localhost:9090/pa-form

  - name: Fill member ID
    action: type
    selector: "#member-id"
    value: "{{patient.member_id}}"

  - name: Fill diagnosis
    action: type
    selector: "#diagnosis"
    value: "{{clinical.diagnosis_codes.0}}"

  - name: Submit
    action: click
    selector: "#submit-pa-btn"
    wait_for_navigation: true

  - name: Extract PA reference
    action: extract
    selector: ".confirmation-number"
    variable_name: pa_reference_number
    extract_type: text_content
    regex: "PA-TEST-(\d+)"
    regex_group: 0
```

### Running the E2E Test
```bash
# Terminal 1: start all services
docker compose up

# Terminal 2: start fake portal
cd tests/e2e/mock_portal
pip install flask
python server.py

# Terminal 3: run E2E test
python tests/e2e/test_full_pipeline.py
```

```python
# tests/e2e/test_full_pipeline.py
"""
Full pipeline test:
  1. Seed test portal + credentials
  2. Submit a case via api-server
  3. Poll case status until SUBMITTED or timeout
  4. Verify PA reference number extracted
"""
import time
import httpx

API_URL    = "http://localhost:8080"
JWT_TOKEN  = None


def get_token():
    resp = httpx.post(f"{API_URL}/api/v1/auth/login",
                      json={"email": "admin@autoauth.com",
                            "password": "admin123"})
    return resp.json()["access_token"]


def submit_case(token: str) -> str:
    resp = httpx.post(
        f"{API_URL}/api/v1/agentic-platform/prior-auths",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "portal_id": "test_portal",   # seeded in DB
            "cases": [{
                "case_ref_id": f"E2E-{int(time.time())}",
                "patient_data": {
                    "member_id":    "M-E2E-001",
                    "first_name":   "E2E",
                    "last_name":    "Test",
                    "date_of_birth": "1990-01-01",
                },
                "clinical_data": {
                    "diagnosis_codes": ["M79.3"],
                    "procedure_codes": ["97110"],
                },
            }],
        },
    )
    resp.raise_for_status()
    return resp.json()["cases"][0]["case_ref_id"]


def poll_case_status(token: str, case_ref_id: str,
                     target: str = "SUBMITTED",
                     timeout: int = 120) -> dict:
    deadline = time.time() + timeout
    while time.time() < deadline:
        resp = httpx.get(
            f"{API_URL}/api/v1/prior-auths/{case_ref_id}",
            headers={"Authorization": f"Bearer {token}"},
        )
        data = resp.json()
        print(f"  [{data['status']}] {case_ref_id}")
        if data["status"] == target:
            return data
        if data["status"] in ("FAILED", "CANCELLED", "CRASHED"):
            raise AssertionError(f"Case reached terminal error: {data['status']}")
        time.sleep(3)
    raise TimeoutError(f"Case did not reach {target} within {timeout}s")


if __name__ == "__main__":
    print("=== AutoAuth E2E Test ===")
    token = get_token()
    print(f"Authenticated. Token: {token[:20]}...")

    case_ref_id = submit_case(token)
    print(f"Case submitted: {case_ref_id}")

    result = poll_case_status(token, case_ref_id, target="SUBMITTED", timeout=120)
    assert result["pa_reference_number"] is not None, "PA reference not extracted!"
    print(f"PA reference: {result['pa_reference_number']}")
    print("=== E2E TEST PASSED ===")
```

---

## Local Dev Tips

### Pub/Sub Emulator
```bash
# The emulator must have topics created before services start
# Add this to your dev-start.sh:
PUBSUB_EMULATOR_HOST=localhost:8085

gcloud beta emulators pubsub start --project=local-dev &
sleep 2

curl -X PUT \
  "http://localhost:8085/v1/projects/local-dev/topics/prior-auth-submission-topic"
curl -X PUT \
  "http://localhost:8085/v1/projects/local-dev/topics/prior-auth-control-plane-topic"
curl -X PUT \
  "http://localhost:8085/v1/projects/local-dev/subscriptions/prior-auth-submission-sub" \
  -H "Content-Type: application/json" \
  -d '{"topic":"projects/local-dev/topics/prior-auth-submission-topic"}'
curl -X PUT \
  "http://localhost:8085/v1/projects/local-dev/subscriptions/prior-auth-control-plane-sub" \
  -H "Content-Type: application/json" \
  -d '{"topic":"projects/local-dev/topics/prior-auth-control-plane-topic"}'
```

### Secret Manager in Dev
For local dev, avoid Secret Manager entirely. Patch `get_secret()` to read from env:

```python
# common/secret/secret_manager.py — add at top of get_secret()
import os
if os.environ.get("APP_ENV") == "dev":
    # In dev: read from env vars instead of Secret Manager
    # Path: autoauth/dev/portal/availity/password → AUTOAUTH_DEV_PORTAL_AVAILITY_PASSWORD
    env_key = secret_path.replace("/", "_").upper()
    value = os.environ.get(env_key)
    if value:
        return value
```

Then add portal credentials to browser-agent `.env`:
```bash
AUTOAUTH_DEV_PORTAL_TEST_PORTAL_USERNAME=test_user
AUTOAUTH_DEV_PORTAL_TEST_PORTAL_PASSWORD=test_pass
```

### Watching All Service Logs at Once
```bash
docker compose logs -f api-server planner control-plane browser-agent
```

### Resetting Everything Between Tests
```bash
# Wipe DB, Redis, and restart
docker compose down -v
docker compose up -d
# Re-run migrations + seed
cd common && poetry run alembic upgrade head
python scripts/seed_data.py
```

### Inspecting Redis State
```bash
docker exec -it autoauth-redis redis-cli

# See worker pool
SMEMBERS prior_auth_submission_idle_pool
SMEMBERS prior_auth_submission_busy_pool

# See active sessions
KEYS keepalive:*

# See log streams
XLEN case_logs:CASE-REF-001
XRANGE case_logs:CASE-REF-001 - + COUNT 10

# See MFA OTP key
GET mfa_otp:CASE-REF-001
```

### Testing HITL Flow Manually
```bash
# 1. Submit a case that has a request_hitl step in its recipe
# 2. Watch case status → HITL_WAIT
# 3. Call the resume endpoint directly (skipping dashboard)
curl -X POST http://localhost:8083/api/v1/hitl/resume/YOUR-CASE-REF-ID
# 4. Watch case status continue → SUBMITTED
```

### Testing MFA Flow Manually
```bash
# 1. Submit a case that has a wait_for_mfa step
# 2. Watch case status → MFA_WAIT
# 3. Deliver OTP via api-server endpoint
curl -X POST http://localhost:8080/api/v1/handle-mfa/YOUR-CASE-REF-ID \
  -H "Content-Type: application/json" \
  -d '{"otp_code": "123456"}'
```

---

## CI Pipeline Test Commands

These are what `cloudbuild-*.yaml` runs in CI:

```bash
# Lint
ruff check src/ tests/

# Unit tests with coverage gate (75%)
pytest tests/ -v \
  --cov=src \
  --cov-report=xml \
  --cov-fail-under=75

# Integration tests (only on main branch builds)
DB_NAME=autoauth_test pytest tests/integration/ -v
```
