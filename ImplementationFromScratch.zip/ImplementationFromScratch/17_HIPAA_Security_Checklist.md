# AutoAuth Agent — HIPAA & Security Pre-Production Checklist
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026

Complete every item on this list before any real patient data enters the system.
This is not a legal compliance document — consult your compliance officer.
This is a technical checklist for developers.

---

## Section 1: PHI Data Handling

### Logging (CRITICAL)
- [ ] Confirm `configure_logging()` is called at startup in every service
- [ ] Run this test against every service log output — none of these must appear in plaintext:
  - `member_id`, `first_name`, `last_name`, `date_of_birth`, `ssn`
  - `password`, `api_key`, `secret`, `token`
  ```bash
  # Submit a real case and grep service logs
  docker compose logs api-server | grep -i "member_id\|first_name\|date_of_birth"
  # Should return 0 results
  ```
- [ ] Confirm `patient_data` and `clinical_data` are never logged directly
- [ ] Confirm `credentials` dict is never logged
- [ ] Confirm Redis Stream log entries (`case_logs:*`) contain no PHI field values
  ```bash
  docker exec autoauth-redis redis-cli XRANGE case_logs:TEST-001 - + COUNT 50 \
    | grep -i "member_id\|first_name\|ssn"
  # Should return 0 results
  ```
- [ ] Verify PHI redactor regex patterns cover SSN (`\d{3}-\d{2}-\d{4}`) and NPI (`\d{10}`)

### Storage
- [ ] Confirm `patient_data` and `clinical_data` columns are `JSONB NOT NULL` — no unstructured text columns for PHI
- [ ] Confirm no PHI is stored in Redis outside of the primary case data
- [ ] Confirm Pub/Sub message payloads do not duplicate PHI outside `patient_data`/`clinical_data` keys
- [ ] Confirm screenshots stored in DB or Redis are stripped of any text overlays that could expose PHI (or are not stored at all in prod)
- [ ] Confirm `prior_auth_case_logs` table partitions are on a retention schedule (7-year minimum per HIPAA)

### Data Minimization
- [ ] Confirm `GET /prior-auths/requests` (list view) does NOT return `patient_data` or `clinical_data` in the response
- [ ] Confirm dashboard UI's patient info panel shows only non-sensitive identifiers (`member_id`, `dob`, plan) — no full name in list views

---

## Section 2: Secrets Management

- [ ] Zero portal passwords in any `.env`, K8s ConfigMap, or environment variable — only in Secret Manager
- [ ] Zero secrets in any Docker image layer (run `docker history` to verify)
  ```bash
  docker history your-project/autoauth/browser-agent:latest | grep -i "password\|secret\|key"
  # Should return 0 results
  ```
- [ ] All Secret Manager paths follow the convention: `autoauth/{env}/{category}/{name}`
- [ ] `GOOGLE_APPLICATION_CREDENTIALS` is removed from all K8s manifests — Workload Identity only in prod
- [ ] Confirm `lru_cache` on `get_secret()` works correctly — secrets fetched once per pod lifetime, not per request
- [ ] Confirm `invalidate_cache()` can be triggered when a secret is rotated
- [ ] JWT `SECRET_KEY` is a minimum 32-character random string, stored in Secret Manager (not `.env` in prod)
- [ ] Capsolver API key is in Secret Manager
- [ ] Anthropic API key is in Secret Manager

---

## Section 3: Authentication & Authorization

- [ ] JWT expiry is 60 minutes (no longer)
- [ ] Account lockout after 5 failed login attempts — `locked_until = now + 15min`
- [ ] `require_role("ADMIN")` is on all recipe PUT endpoints
- [ ] `require_role("OPERATOR", "ADMIN")` is on all HITL resolve endpoints
- [ ] `require_role("VIEWER", "OPERATOR", "ADMIN")` is on all GET endpoints
- [ ] `/health` endpoint is NOT behind JWT auth (needed for K8s liveness probes)
- [ ] All internal service-to-service endpoints (control-plane → browser-agent, etc.) are NOT exposed to the internet
- [ ] Confirm GKE Ingress only exposes `api-server` and `frontend` — all other services are `ClusterIP`

### Test Authorization
```bash
# Should fail with 403 (viewer cannot resolve HITL)
VIEWER_TOKEN=$(curl -s -X POST http://localhost:8080/api/v1/auth/login \
  -d '{"email":"viewer@test.com","password":"test"}' | jq -r .access_token)
curl -X POST http://localhost:8080/api/v1/hitl/resolve \
  -H "Authorization: Bearer $VIEWER_TOKEN" \
  -d '{"task_id":"xxx","resolution":"done"}'
# Expected: {"detail":"Insufficient permissions"}

# Should fail with 401 (no token)
curl http://localhost:8080/api/v1/prior-auths/requests
# Expected: {"detail":"Not authenticated"}
```

---

## Section 4: Network Security

- [ ] All GKE services are `ClusterIP` except api-server (LoadBalancer/Ingress)
- [ ] `NetworkPolicy` is defined for each service:
  - `api-server` accepts traffic from: ingress, all internal services
  - `planner` accepts from: api-server, N8N
  - `control-plane` accepts from: planner, N8N, browser-agent (for registration)
  - `browser-agent` accepts from: control-plane only
  - `tracking-agent` accepts from: control-plane only
- [ ] GKE Ingress has `FrontendConfig` with HTTPS redirect enabled
- [ ] `ManagedCertificate` is provisioned for your domain
- [ ] HSTS header is set in nginx frontend config
- [ ] No `hostNetwork: true` on any pod
- [ ] No `privileged: true` on any container except Xvfb setup in browser-agent (and only that container)

### Verify No Exposed Ports
```bash
# In prod: only api-server LoadBalancer IP should be reachable externally
kubectl get services -n autoauth
# All except api-server should show ClusterIP, not LoadBalancer
```

---

## Section 5: Database Security

- [ ] DB user `autoauth` has permissions only on `iks_schema` — not superuser, not public schema owner
  ```sql
  -- Verify
  \du autoauth
  -- Should show: no superuser, no createdb, no createrole
  ```
- [ ] DB connection uses SSL in prod (`?sslmode=require` in connection string)
- [ ] No hard `DELETE` on case or batch tables anywhere in codebase
  ```bash
  grep -r "\.delete()" api-server/src/ planner/src/ control-plane/src/ | grep -v ".pyc"
  # Review each result — none should be on case/batch tables
  ```
- [ ] Soft delete flag `is_deleted=True` is respected in all list queries
- [ ] `prior_auth_case_logs` monthly partitions are scheduled for creation (stored procedure in Doc 04)
- [ ] Cloud SQL automated backups are enabled (7-year retention for HIPAA)
- [ ] Point-in-time recovery is enabled on Cloud SQL

---

## Section 6: Audit Trail

- [ ] Every case status change is logged to `prior_auth_case_logs` or Redis Stream
- [ ] HITL task resolution records `resolved_by` (user UUID) and `resolved_at` timestamp
- [ ] Every login attempt (success and failure) is logged (structlog, no PHI in log)
- [ ] Account lockout events are logged
- [ ] Recipe edits record `created_by` user UUID and `version`
- [ ] All API requests log method, path, status code, and duration — no request bodies

---

## Section 7: Container & Runtime Security

- [ ] All Dockerfiles use non-root user (`USER 1000`)
  ```bash
  docker run --rm your-project/autoauth/api-server:latest whoami
  # Should return: appuser (or numeric UID 1000)
  ```
- [ ] Trivy scan passes with zero CRITICAL vulnerabilities on all images
  ```bash
  trivy image --severity CRITICAL your-project/autoauth/api-server:latest
  ```
- [ ] No `latest` tags in K8s manifests — always use `SHORT_SHA` pinned tags
- [ ] Resource limits are set on all containers (`requests` and `limits` for CPU and memory)
- [ ] `readOnlyRootFilesystem: true` where possible (not browser-agent — it writes to /tmp)
- [ ] Secrets are mounted via Secret Store CSI, not environment variables in K8s

---

## Section 8: Browser Agent Specific

- [ ] VNC access is only proxied through control-plane — browser-agent VNC ports (5900/6080) are NOT in any K8s Service
- [ ] `viewOnly: false` on VNC viewer is intentional (operators need to take over) — document this decision
- [ ] Portal session cookies are stored in Playwright browser context only — never persisted to DB or Redis
- [ ] Browser-agent Playwright args include `--no-sandbox` — document that this is acceptable because the container itself is the sandbox (GKE node isolation)
- [ ] Screenshots stored in Redis Stream are capped at 24KB and auto-expire in 2 days

---

## Section 9: Incident Response

### Before Go-Live, Confirm You Can:
- [ ] Immediately cancel a running case from the dashboard
- [ ] Immediately revoke an operator's access (set `is_active=False` in DB, JWT will expire naturally within 60 min)
- [ ] Identify which pod handled a specific case (via `prior_auth_agent_session.pod_id`)
- [ ] Export all case data for a specific patient (for HIPAA Right of Access requests) via DB query
- [ ] Wipe all data for a specific patient (for Right to Erasure where applicable — check your BAA)

### Right of Access Query (keep this saved):
```sql
SELECT
    c.case_ref_id,
    c.patient_data,
    c.clinical_data,
    c.status,
    c.pa_reference_number,
    c.created_at,
    c.completed_at
FROM iks_schema.prior_auth_case_request c
WHERE c.patient_data->>'member_id' = 'MEMBER_ID_HERE'
  AND c.is_deleted = false
ORDER BY c.created_at DESC;
```

---

## Pre-Launch Sign-Off

Complete this section with your compliance officer before first production case:

| Item | Owner | Sign-Off Date |
|---|---|---|
| BAA executed with all payer portals | Legal | |
| BAA executed with GCP (Cloud Data Processing Amendment) | Legal | |
| PHI logging verified by security review | Engineering | |
| Pen test on GKE ingress completed | Security | |
| Disaster recovery plan documented | Engineering | |
| Staff HIPAA training completed | All staff with portal access | |
| Incident response runbook reviewed | Engineering + Compliance | |

---

*This checklist must be reviewed and updated every 6 months or after any major architecture change.*
