# AutoAuth Agent — How to Use AI Agents to Build This Product
## Step-by-Step Guide for Claude Code & Cursor
**Author:** Niranjan Sai Koppisetti
**Date:** September 4, 2026

This guide tells you exactly what to say to an AI agent, when to say it,
and how to verify it worked — for every step from empty repo to running system.

---

## Before You Start: The Golden Rules

**Rule 1: One service per session.**
Never ask an agent to build multiple services in one go. Each service is ~500–800 lines.
Exceeding context = the agent forgets earlier decisions and breaks things.

**Rule 2: Always give the agent the documents, don't describe from memory.**
Paste or attach the relevant `.md` files. The agent needs the exact spec, not your paraphrase of it.

**Rule 3: Verify before moving on.**
Run the smoke test at the end of each step. If it fails, fix it in the same session before starting the next service.

**Rule 4: Tell the agent what already exists.**
Every session starts with: "X is already built and working. Now build Y."
An agent that doesn't know what's done will re-invent things incorrectly.

---

## Tool Setup

### Option A: Claude Code (Recommended)
Claude Code is a CLI tool that runs in your terminal with access to your full filesystem.
It can read multiple files, write code, and run commands.

```bash
# Install
npm install -g @anthropic-ai/claude-code

# Start in your project root
cd C:\Users\niranjansai.k\Documents\autoauthagent
claude
```

**Why Claude Code for this project:**
- Can read all your `.md` spec files directly
- Can write multiple files at once
- Can run `poetry install`, `pytest`, `alembic upgrade head` to verify
- Keeps full context of what it has written across the session

### Option B: Cursor
Cursor is a VS Code fork with AI built in. Good for viewing code as it's written.

```
1. Open autoauthagent/ folder in Cursor
2. Use Cursor Chat (Ctrl+L) for each prompt
3. Use "Apply" button to write files
4. Use Cursor Composer (Ctrl+Shift+I) for multi-file tasks
```

**Cursor tip:** Add all `.md` spec files to `.cursorignore` EXCEPT the one you're currently using.
This keeps context clean.

---

## Phase 0 — Workspace Setup (Do This Yourself, Not the Agent)

These are one-time manual steps. Do them before involving any agent.

### Step 0A: Create Repo Structure
```bash
mkdir -p autoauthagent/{common,api-server,planner,control-plane,browser-agent,tracking-agent,frontend}
mkdir -p autoauthagent/common/src/common/{db_layer,redis_layer,pubsub_layer,secret,logs}
mkdir -p autoauthagent/common/alembic/versions
cd autoauthagent
git init
```

### Step 0B: Copy the ORM Models File
```bash
cp ImplementationFromScratch/common_orm_models.py common/src/common/db_layer/orm_models.py
```
This is the one file that's already written. Every agent session assumes it exists.

### Step 0C: Start Infrastructure
```bash
# Copy docker-compose.yaml from Doc 06 into root, then:
docker compose up -d postgres redis n8n pubsub-emulator
```

### Step 0D: Create GCP Secrets (dev values)
```bash
# Replace with your GCP project ID
for secret in db/password redis/auth n8n/webhook_secret jwt/secret_key anthropic/api_key; do
  echo -n "dev_placeholder_change_me" | \
    gcloud secrets create "autoauth/dev/$secret" --data-file=- --project=YOUR_PROJECT_ID
done
```

---

## Step 1 — Build `common/` Library

**Documents to give the agent:**
- `07_Common_Library_Implementation.md`
- `15_Service_Config_Templates.md` (for pyproject.toml)
- `common_orm_models.py` (already exists — tell agent this)

### Prompt to use (Claude Code):
```
I am building the AutoAuth Agent system — an AI-powered Prior Authorization 
automation platform for healthcare payer portals.

I need you to build the common/ shared library. This library is used by 
every other service as a local editable dependency.

The ORM models file is already written at:
  common/src/common/db_layer/orm_models.py

Please read these documents carefully before writing any code:
  ImplementationFromScratch/07_Common_Library_Implementation.md
  ImplementationFromScratch/15_Service_Config_Templates.md

Then build the following files (use the exact implementations in the spec):
1. common/pyproject.toml  (from Service Config Templates)
2. common/src/common/__init__.py  (empty)
3. common/src/common/logs/logger.py
4. common/src/common/logs/phi_redactor.py
5. common/src/common/logs/trace_context.py
6. common/src/common/db_layer/db_config.py
7. common/src/common/db_layer/base_repository.py
8. common/src/common/db_layer/unit_of_work.py
9. common/src/common/redis_layer/redis_config.py
10. common/src/common/redis_layer/worker_pool.py
11. common/src/common/redis_layer/credential_pool.py
12. common/src/common/redis_layer/stream_logger.py
13. common/src/common/redis_layer/keyspace.py
14. common/src/common/pubsub_layer/publisher.py
15. common/src/common/pubsub_layer/base_consumer.py
16. common/src/common/pubsub_layer/consumer_thread.py
17. common/src/common/secret/secret_manager.py
18. common/alembic.ini
19. common/alembic/env.py  (from Service Config Templates)

Security requirements that must be enforced:
- PHI_FIELDS in phi_redactor.py must cover: first_name, last_name, member_id, 
  ssn, date_of_birth, password, secret, token, api_key, username, credential
- lru_cache(maxsize=256) must be on get_secret()
- Redis client must use decode_responses=True and TLS support

After writing all files, run:
  cd common && poetry install
and confirm it installs without errors.
```

### Smoke Test (run yourself):
```bash
cd common
poetry install
poetry run python -c "
from common.logs.logger import configure_logging, get_logger
configure_logging()
log = get_logger('test')
log.info('test', member_id='M12345', first_name='Jane')
"
# Verify: member_id and first_name values are REDACTED in output
```

---

## Step 2 — Run Database Migrations

**Do this yourself** (one command):
```bash
cd common
export DB_HOST=localhost DB_PORT=5432 DB_USER=autoauth \
       DB_PASSWORD=autoauth_dev_password DB_NAME=autoauth
poetry run alembic upgrade head
```

If migration fails → the ORM models file has a column type issue.
Ask agent: "The alembic migration failed with this error: [paste error]. Fix orm_models.py."

---

## Step 3 — Build `api-server/`

**Documents to give the agent:**
- `08_API_Server_Implementation.md`
- `15_Service_Config_Templates.md`

### Prompt:
```
The common/ library is built and working. PostgreSQL and Redis are running locally.

Now build the api-server/ service. Read these documents:
  ImplementationFromScratch/08_API_Server_Implementation.md
  ImplementationFromScratch/15_Service_Config_Templates.md

Build ALL files listed in the document's project structure section.
The api-server imports from autoauth-common which is at ../common.

Key requirements:
- JWT expiry: 60 minutes exactly
- Account lockout: 5 failed attempts → lock for 15 minutes
- POST /agentic-platform/prior-auths returns 202 (not 201)
- Soft-delete only: never hard DELETE on case or batch rows
- PHI never logged: patient_data and clinical_data are never passed to logger

After writing all files, run:
  cd api-server && poetry install
  cp ImplementationFromScratch/15_Service_Config_Templates.md .  # reference for .env
Then create api-server/.env from the template in the config doc.
Then run:
  poetry run uvicorn src.main:app --port 8080
and confirm the server starts without errors.
```

### Smoke Test:
```bash
# Health check
curl http://localhost:8080/health
# Expected: {"status":"ok","checks":{"db":"ok","redis":"ok"}}

# Register + login
curl -X POST http://localhost:8080/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"Test1234!"}'

curl -X POST http://localhost:8080/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"Test1234!"}'
# Expected: {"access_token":"eyJ...","token_type":"bearer"}
```

---

## Step 4 — Build `planner/`

**Documents to give the agent:**
- `09_Planner_Implementation.md`
- `15_Service_Config_Templates.md`

### Prompt:
```
The common/ library and api-server/ are built and passing smoke tests.

Now build the planner/ service. Read these documents:
  ImplementationFromScratch/09_Planner_Implementation.md
  ImplementationFromScratch/15_Service_Config_Templates.md

Key requirements:
- DeduplicationCache must use OrderedDict (not dict) for O(1) LRU eviction
- MFA OTP delivery uses Redis key "mfa_otp:{case_ref_id}" with SETEX — 
  NOT threading.Queue (that was changed — Redis is the transport)
- N8N webhook calls use HMAC-SHA256 signing on the JSON body
- PlannerConsumer is a BaseConsumer subclass (from common/pubsub_layer)
- TransientError → nack the message; PermanentError → ack + log

After writing all files:
  cd planner && poetry install
Create planner/.env from the template (N8N webhook URLs can be placeholder for now).
Run: poetry run uvicorn src.main:app --port 8082
Confirm it starts. The consumer will log "waiting for messages" — that is correct.
```

### Smoke Test:
```bash
curl http://localhost:8082/health
# Expected: {"status":"ok"}

# Test retrigger endpoint exists
curl -X POST http://localhost:8082/api/v1/retrigger/TEST-CASE-001
# Expected: 404 (case doesn't exist) — proves endpoint is wired up
```

---

## Step 5 — Set Up N8N Workflows

**Do this yourself** using the N8N guide.

```
1. Open http://localhost:5678
2. Follow every step in:
   ImplementationFromScratch/14_N8N_Workflow_Setup.md
3. Build all 7 workflows
4. Activate all 7 workflows
5. Copy webhook URLs into planner/.env and update the service
```

This step has no agent involvement — it's clicking in the N8N UI.

---

## Step 6 — Build `control-plane/`

**Documents to give the agent:**
- `10_Control_Plane_Implementation.md`
- `15_Service_Config_Templates.md`

### Prompt:
```
Common, api-server, and planner are built. N8N workflows are configured.

Now build the control-plane/ service. Read:
  ImplementationFromScratch/10_Control_Plane_Implementation.md
  ImplementationFromScratch/15_Service_Config_Templates.md

Key requirements:
- WorkerPool from common/redis_layer must be used — do not re-implement
- SessionRegistry is in-memory (dict) — not Redis, not DB
- VNC proxy supports BOTH HTTP (api_route) and WebSocket endpoints
- KeepAliveSender is a daemon thread — stops automatically on shutdown
- ExpiredEventConsumer uses common/redis_layer/keyspace.py (KeyspaceEventConsumer)
- crash recovery: mark CRASHED → retrigger via POST planner/retrigger/{id}

After writing all files:
  cd control-plane && poetry install
Create control-plane/.env from the template.
Run: poetry run uvicorn src.main:app --port 8083
Confirm it starts and logs "worker_pools_initialized".
```

### Smoke Test:
```bash
curl http://localhost:8083/health
# Expected: {"status":"ok"}

curl http://localhost:8083/api/v1/sessions
# Expected: {"sessions":[]}  (empty — no sessions yet)
```

---

## Step 7 — Build `browser-agent/`

**This is the most complex service. Give it a full fresh session.**

**Documents to give the agent:**
- `11_Browser_Agent_Implementation.md`
- `05_Recipe_Engine_and_Portal_Specification.md` (for action type details)
- `15_Service_Config_Templates.md`

### Prompt:
```
Common, api-server, planner, and control-plane are built and working.

Now build the browser-agent/ service — the most complex one.
Read these documents COMPLETELY before writing any code:
  ImplementationFromScratch/11_Browser_Agent_Implementation.md
  ImplementationFromScratch/05_Recipe_Engine_and_Portal_Specification.md
  ImplementationFromScratch/15_Service_Config_Templates.md

Critical implementation details:
- DisplayAllocator uses subprocess.Popen to start Xvfb — 3 slots per pod
- resolve_value() supports 7 sources: patient, clinical, credentials, env, 
  context, computed, static — all from regex template {{source.path}}
- RecipeRunner has ALL 14 action types: navigate, click, type, select, wait,
  wait_for_text, extract, screenshot, solve_captcha, request_hitl, wait_for_mfa,
  upload_file, check_checkbox, condition — plus foreach loop
- HITL uses threading.Event (NOT asyncio.Event) — browser runs in a thread
- MFA OTP is READ from Redis key "mfa_otp:{case_ref_id}" — planner writes it there
- HeartbeatThread must DELETE the Redis key cleanly on stop() — so control-plane 
  doesn't think we crashed
- SummarizationThread uses Anthropic SDK with model from SUMMARY_MODEL env var
- LLM mode is optional — only if browser-use package is installed

On Windows/local dev: DisplayAllocator.initialize() will fail (no Xvfb).
Add this guard at the top of DisplayAllocator.initialize():
  import platform
  if platform.system() == "Windows":
      logger.warning("Xvfb not available on Windows — display slots disabled")
      cls._slots = []
      return

After writing all files:
  cd browser-agent && poetry install
  poetry run playwright install chromium
Create browser-agent/.env from the template.
Run: poetry run uvicorn src.main:app --port 8081
Confirm it starts.
```

### Smoke Test (Linux/WSL2 only for full test):
```bash
curl http://localhost:8081/health

# On Linux: test display allocation
curl -X POST http://localhost:8081/api/v1/sessions \
  -H "Content-Type: application/json" \
  -d '{
    "case_ref_id": "SMOKE-001",
    "portal_id": "test_portal",
    "patient_data": {"member_id":"M001","first_name":"Test",
                     "last_name":"User","date_of_birth":"1990-01-01"},
    "clinical_data": {"diagnosis_codes":["M79.3"]}
  }'
# Expected: {"session_id":"...","display_slot":0,"vnc_url":"..."}
```

---

## Step 8 — Build `tracking-agent/`

**Documents to give the agent:**
- `12_Tracking_Agent_Implementation.md`
- `15_Service_Config_Templates.md`

### Prompt:
```
All previous services are built. Now build the tracking-agent/ service.
Read:
  ImplementationFromScratch/12_Tracking_Agent_Implementation.md
  ImplementationFromScratch/15_Service_Config_Templates.md

Key requirements:
- Playwright runs headless=True (no Xvfb needed — no display required)
- TrackingThread is a daemon thread with a stop() method using threading.Event
- PollScheduler reads POLL_SCHEDULE_HOURS as a list: [1, 4, 24, 48]
- StatusNormalizer uses substring matching (case-insensitive) — not exact match
- Status callbacks fire ONLY when status changes from the previous check
- Pod restart recovery: query DB for IN_PROGRESS sessions on this pod_id at startup

After writing all files:
  cd tracking-agent && poetry install
  poetry run playwright install chromium
Create tracking-agent/.env from the template.
Run: poetry run uvicorn src.main:app --port 8084
Confirm it starts.
```

### Smoke Test:
```bash
curl http://localhost:8084/health
curl http://localhost:8084/api/v1/sessions
# Expected: {"sessions":[],"count":0}
```

---

## Step 9 — Build `frontend/`

**Documents to give the agent:**
- `13_Frontend_Implementation.md`

### Prompt:
```
All backend services are built. Now build the React frontend.
Read:
  ImplementationFromScratch/13_Frontend_Implementation.md

Build ALL files listed in the project structure section.
The frontend proxies all /api requests to http://localhost:8080 (api-server).

Key requirements:
- useSSELogs hook uses native EventSource (not a library)
- useVNCViewer loads @novnc/novnc dynamically (import() not require)
- Badge component covers ALL 13 case statuses with color mapping
- MFAEntryForm strips non-numeric characters from OTP input
- React Query staleTime is 30 seconds — do not use 0
- AlertToast shows max 4 alerts at once

After writing all files:
  cd frontend && npm install
  npm run dev
Open http://localhost:5173 and confirm the login page loads.
```

### Smoke Test (manual in browser):
```
1. Open http://localhost:5173
2. Login with admin@autoauth.com / admin123
3. Cases page loads (empty table is fine)
4. HITL Queue page loads
5. Analytics page loads (zero data charts are fine)
6. No console errors in browser devtools
```

---

## Step 10 — End-to-End Verification

### Prompt (new session):
```
The AutoAuth Agent system is fully built. I need to run an end-to-end test.

The mock portal test setup is described in:
  ImplementationFromScratch/16_Testing_and_Local_Dev.md

Please:
1. Create the mock portal Flask server at tests/e2e/mock_portal/server.py
2. Create the test recipe YAML at tests/e2e/test_portal_recipe.yaml
3. Create the E2E test script at tests/e2e/test_full_pipeline.py
4. Write a seed script at tests/e2e/seed_test_portal.py that inserts:
   - A payer with code "test_payer"
   - A portal with code "test_portal" and portal_url "http://localhost:9090"
   - A portal credential with username_path and password_path pointing to dev secrets
   - The test_portal_recipe.yaml content into prior_auth_portal_recipe table

Then run:
  python tests/e2e/seed_test_portal.py
  python tests/e2e/mock_portal/server.py &
  python tests/e2e/test_full_pipeline.py
```

---

## When the Agent Gets It Wrong

These are the most common failures and exactly what to say:

### "Import error: cannot import name X from common"
```
The import failed because common/ is not installed as editable.
Run: cd common && pip install -e .
Then retry.
```

### "Table iks_schema.X does not exist"
```
Alembic migration hasn't been run, or ran against wrong DB.
Run from common/:
  export DB_NAME=autoauth && poetry run alembic upgrade head
Then confirm: psql -U autoauth autoauth -c "\dt iks_schema.*"
```

### "No idle workers available" (control-plane returns 503)
```
The browser-agent pod is not registered in the Redis worker pool.
Either:
1. browser-agent failed to call control-plane at startup (check browser-agent logs)
2. Redis was restarted and pool was cleared

Fix: POST to control-plane manually:
  curl -X POST http://localhost:8083/api/v1/agents/register \
    -d '{"pod_id":"dev","pod_ip":"127.0.0.1","pod_port":8081,
         "agent_type":"browser_agent","max_sessions":3}'
```

### "HMAC signature mismatch" (N8N rejects requests)
```
N8N_WEBHOOK_SECRET does not match between the calling service and N8N.
Check: planner/.env N8N_WEBHOOK_SECRET value
vs: N8N Settings → Credentials → AutoAuth Webhook Secret → Header Value
They must be identical strings.
```

### "PHI appearing in logs"
```
configure_logging() was not called before the first log statement.
Ensure it is the FIRST call in main.py lifespan(), before any import side effects.
```

### Agent wrote code that doesn't match the spec
```
The code you wrote in [file] does not match the spec. 
Specifically: [describe what's wrong].
Re-read ImplementationFromScratch/[relevant doc].md section [section name]
and rewrite [file] to match it exactly.
```

---

## Session Management Best Practices

### Start of every agent session — say this first:
```
Context for this session:
- Project: AutoAuth Agent — AI-powered Prior Authorization automation
- Already built and working: [list what's done]
- This session: building [service name]
- Python version: 3.12
- All services use Poetry for dependency management
- Shared library is at ../common (installed as editable)
- DB schema is in iks_schema PostgreSQL schema
- No hard DELETEs on case/batch data ever
- PHI must never appear in logs
```

### End of every agent session — verify before closing:
```bash
# Run the unit tests for the service just built
cd [service] && poetry run pytest tests/ -v --cov=src
# Minimum 70% coverage or investigate gaps

# Run the smoke test
curl http://localhost:808X/health
```

### When to start a new session vs continue:
- Start new: moving to a different service
- Start new: more than 2 hours have passed (context may be stale)
- Continue: fixing bugs in what was just written
- Continue: adding tests to what was just written

---

## Recommended Session Order (Summary)

| Session | Agent Task | Time Estimate |
|---|---|---|
| 0 | You: repo setup, docker compose, GCP secrets | 1 hour |
| 1 | Agent: build common/ library | 45 min |
| 2 | You: run alembic migrations + seed | 15 min |
| 3 | Agent: build api-server/ | 1 hour |
| 4 | Agent: build planner/ | 45 min |
| 5 | You: set up N8N workflows (UI) | 1 hour |
| 6 | Agent: build control-plane/ | 45 min |
| 7 | Agent: build browser-agent/ | 90 min |
| 8 | Agent: build tracking-agent/ | 45 min |
| 9 | Agent: build frontend/ | 90 min |
| 10 | Agent: build E2E test suite + run it | 45 min |
| — | **Total** | **~9 hours across 2 days** |

---

## File Handoff Cheat Sheet

When starting each agent session, attach these files:

| Service | Attach these files |
|---|---|
| common | Doc 07, Doc 15, `common_orm_models.py` |
| api-server | Doc 08, Doc 15 |
| planner | Doc 09, Doc 15 |
| control-plane | Doc 10, Doc 15 |
| browser-agent | Doc 11, Doc 05, Doc 15 |
| tracking-agent | Doc 12, Doc 15 |
| frontend | Doc 13 |
| E2E test | Doc 16 |
| Bug fixing (any) | Doc 00 (build guide) + the relevant service doc |

**In Claude Code:** Use `/read ImplementationFromScratch/07_Common_Library_Implementation.md` at the start.

**In Cursor:** Drag the `.md` files into the chat window before typing your prompt.
