# AutoAuth Agent — Build-From-Scratch Project Plan

## Assumptions

| Item | Assumption |
|---|---|
| Team size | 1 Tech Lead/Architect + 4 Backend Engineers + 1 Frontend Engineer + 1 QA Engineer |
| Methodology | 2-week sprints (Agile) |
| Cloud | GCP (GKE, Pub/Sub, Secret Manager, Vertex AI) |
| Timeline start | Sept 3, 2026 |

---

## Timeline Overview

```
Phase 1: Documentation & Architecture       Weeks 1–4     (Sept 3 – Sept 28)
Phase 2: Foundation & Infrastructure        Weeks 3–8     (Sept 17 – Oct 26)   [overlaps P1]
Phase 3: Service Development                Weeks 7–20    (Oct 12 – Jan 4)     [overlaps P2]
Phase 4: Testing                            Weeks 17–23   (Dec 21 – Feb 1)     [overlaps P3]
Phase 5: Staging, Hardening & Go-Live       Weeks 22–26   (Jan 25 – Mar 1)
─────────────────────────────────────────────────────────────────────────────
Total Duration: ~26 weeks  (~6.5 months)    Target Go-Live: March 1, 2027
```

---

## Phase 1 — Documentation & Architecture (Weeks 1–4)

**Goal:** Align the entire team on what is being built before a single line of code is written.

### Week 1–2: Requirements & System Design
- [ ] **Product Requirements Document (PRD)** — scope, use cases, payer portal list, HITL flows, SLA targets
- [ ] **High-Level Design (HLD)** — microservices map, data flow diagram, external integrations, execution modes (recipe vs. LLM)
- [ ] **API Contract Design** — OpenAPI 3.0 specs for all 5 services before coding begins
- [ ] **Database Schema Design** — all 25+ tables, relationships, indexes, schema versioning strategy (Alembic)
- [ ] **Recipe Format Specification** — the YAML schema for payer portal recipes, all 14 action types, validation rules

### Week 3–4: Infrastructure & Security Design
- [ ] **Infrastructure Architecture** — GKE cluster design, node pools, namespaces, KEDA autoscaling strategy
- [ ] **GCP Resource Plan** — Pub/Sub topics/subscriptions, Secret Manager layout, GCS bucket structure, IAM roles
- [ ] **Security Design** — Workload Identity, JWT auth, credential isolation per portal, Secret Store CSI driver
- [ ] **N8N Workflow Design** — all 7 webhooks mapped, workflow diagrams for submission, HITL, MFA, completion
- [ ] **ADR Log** — Architecture Decision Records for every key choice (recipe vs. LLM, Redis pool vs. K8s jobs, etc.)

**Deliverables:** HLD doc, LLD doc, OpenAPI specs, DB ERD, Recipe schema spec, ADR log, N8N flow diagrams

---

## Phase 2 — Foundation & Infrastructure (Weeks 3–8)

**Goal:** Everything the services need to run — before services are written.

### Week 3–4: Dev Environment
- [ ] `docker-compose.yaml` — PostgreSQL, Redis, N8N, all services scaffolded (empty FastAPI apps)
- [ ] `common/` shared library skeleton — db_layer, redis_layer, pubsub_layer, secret, logs
- [ ] Monorepo structure, `pyproject.toml`, linting (ruff), formatting (black), pre-commit hooks
- [ ] Local `.env` template with all required variables documented

### Week 5–6: Database & Redis
- [ ] PostgreSQL schema — all ORM models (SQLAlchemy), Alembic migrations, seed data scripts
- [ ] Unit-of-Work pattern, Repository pattern, DI container in `common/db_layer`
- [ ] Redis layer — `RedisConnectionManager`, worker pool (idle/busy/cooling sets), credential pool, in-flight tracking
- [ ] Redis Streams setup for log streaming
- [ ] Redis keyspace notification config for heartbeat/expiry monitoring

### Week 7–8: GCP & CI/CD
- [ ] GCP Pub/Sub — 2 topics + subscriptions, IAM bindings
- [ ] GCP Secret Manager — structure, naming conventions, CSI driver config
- [ ] Cloud Build pipelines (`cloudbuild.yaml`) per service — build, test, push to Artifact Registry
- [ ] GKE cluster — namespace `agentic-app`, node pools, Workload Identity bindings
- [ ] KEDA installation + `ScaledObject` template for browser-agent

**Deliverables:** Working local dev stack, all DB tables migrated, CI/CD green, GCP resources provisioned

---

## Phase 3 — Service Development (Weeks 7–20)

Running in 2-week sprints. Services developed in dependency order.

### Sprint 1 (Weeks 7–8): `api-server`
- [ ] FastAPI app scaffold, lifespan, health endpoint
- [ ] JWT auth — `POST /auth/register`, `POST /auth/login` (bcrypt + JWT)
- [ ] Batch ingestion — `POST /agentic-platform/prior-auths` → validates, persists to DB, publishes to Pub/Sub Topic #1
- [ ] Case management CRUD — `GET /prior-auths/requests`, status updates
- [ ] Recipe serving endpoint — `GET /recipes/{portal_id}` (DB + YAML fallback)
- [ ] `PriorAuthSubmissionCredentialManager` + `PriorAuthTrackingCredentialManager` startup init

### Sprint 2 (Weeks 9–10): `planner`
- [ ] `BaseConsumer` + `ConsumerThread` in `common/pubsub_layer`
- [ ] `PlannerConsumer` — consumes Pub/Sub Topic #1, deduplication (`InMemoryCache` with TTL)
- [ ] `ONE_SESSION_PER_BATCH` logic — one browser session reused across a batch
- [ ] N8N webhook trigger — `trigger_n8n_logic()` → `PRIOR_AUTH_SUBMISSION_WEBHOOK_URL`
- [ ] `POST /api/v1/agentic-platform/prior-auths/planner-preauth` endpoint
- [ ] ADK chatbot handler for MFA flows
- [ ] Retrigger endpoint for expired cases

### Sprint 3 (Weeks 11–12): `control-plane` — Core
- [ ] `ControlPlaneSessionConsumer` — consumes Pub/Sub Topic #2, calls `create_session()`
- [ ] Worker pool selection — pick idle browser-agent from Redis, mark busy
- [ ] `POST /sessions` — calls browser-agent to create a session
- [ ] `DELETE /sessions/{id}` — cleanup + return worker to idle pool
- [ ] `PriorAuthSubmissionWorkerManager` + `PriorAuthTrackingWorkerManager` startup init
- [ ] `ExpiredEventConsumer` — listens to Redis keyspace expiry → handles pod crash callbacks

### Sprint 4 (Weeks 13–14): `control-plane` — VNC & Heartbeat
- [ ] VNC proxy — HTTP + WebSocket routes proxying to browser-agent's noVNC
- [ ] `PriorAuthSubmissionKeepAliveSender` — 30s heartbeat from control-plane
- [ ] `PriorAuthSubmissionWorkerCompletionHandler` — crash recovery, status capture webhook call
- [ ] HITL management routes (`/hitl/*`)
- [ ] Tracking session routes (`/tracking/*`)

### Sprint 5 (Weeks 13–15): `browser-agent` — Session & Recipe Engine
- [ ] Xvfb + x11vnc + websockify process management (`displayAllocation.py`)
- [ ] `POST /sessions` — allocates display, starts VNC, launches Playwright
- [ ] `load_recipe()` — fetch from api-server or YAML file (LRU cached)
- [ ] **`RecipeRunner`** — all 14 action types: navigate, fill, click, click_path, type_and_pick, select_if_mismatch, select_row, foreach, wait, upload, mfa, hitl, extract, assert_visible
- [ ] `resolve_value()` — value resolution from patient data / credentials
- [ ] `pick_option()` — fuzzy/exact dropdown matching
- [ ] Capsolver CAPTCHA integration

### Sprint 6 (Weeks 15–16): `browser-agent` — LLM Mode, HITL, Telemetry
- [ ] `CustomGoogleChat` — Gemini/Vertex AI wrapper for browser-use
- [ ] LLM Agent mode (`PLAYWRIGHT_EXECUTION_ENGINE=no`) — browser-use integration
- [ ] HITL flow — `request_hitl()`, `request_mfa()` → N8N webhook → pause/resume endpoints
- [ ] Completion callbacks — `COMP_WEBHOOK_URL`, `STATUS_CAPTURE_WEBHOOK_URL`
- [ ] `SummarizationThread` — background LLM log summarization → `SUMMARY_WEBHOOK_URL`
- [ ] `log_agent_activity()` — LLM cost telemetry to DB
- [ ] Redis log streaming — `setup_redis_logging()`, `redirect_std_streams()`
- [ ] `PriorAuthSubmissionKeepAliveSender` + `PriorAuthSubmissionInFlightSender` heartbeats

### Sprint 7 (Weeks 17–18): `tracking-agent` + First Portal Recipes
- [ ] `tracking-agent` — mirrors browser-agent for post-submission status checks
- [ ] `PriorAuthTrackingKeepAliveSender` + worker registration
- [ ] Profile cleanup endpoint
- [ ] Write first 2–3 portal YAML recipes (start with simplest portals)
- [ ] `check_portal_recipes/` validation tooling

### Sprint 8 (Weeks 19–20): `frontend` (ui) + Dashboard APIs
- [ ] React/Vite dashboard — case list, status, VNC viewer embed
- [ ] Dashboard API endpoints — `run-volume`, `llm-cost`, `payer-prompts`, `alert-sse` (SSE)
- [ ] Portal secret management UI
- [ ] HITL resolution UI — agent paused → human acts → resume
- [ ] Login / JWT token management in frontend

**Deliverables:** All 5 services functionally complete, first portal recipes working end-to-end

---

## Phase 4 — Testing (Weeks 17–23)

Overlaps with late development — QA starts as soon as Sprint 5 is done.

### Unit Testing (Weeks 17–19)
- [ ] `RecipeRunner` — all 14 action types with mock Playwright pages
- [ ] `resolve_value()`, `pick_option()` — value resolution logic
- [ ] Worker pool Redis operations — acquire, release, expire
- [ ] `PlannerConsumer` deduplication logic
- [ ] DB services — all CRUD operations against test PostgreSQL

### Integration Testing (Weeks 19–21)
- [ ] Full Pub/Sub flow — api-server → planner → control-plane (with local emulator)
- [ ] Browser-agent session lifecycle — create, run recipe, complete, cleanup
- [ ] HITL flow — agent pauses, human resolves via API, agent resumes
- [ ] MFA flow — OTP request → chatbot → agent continues
- [ ] Heartbeat + crash recovery — kill browser-agent pod, verify control-plane recovers

### End-to-End Testing (Weeks 21–22)
- [ ] Test against real (sandboxed) payer portals for each recipe
- [ ] Batch submission — 10+ cases in one batch, `ONE_SESSION_PER_BATCH` mode
- [ ] KEDA autoscaling — simulate queue depth spike, verify pod scale-up

### Load & Performance Testing (Weeks 22–23)
- [ ] Locust load test on api-server ingestion endpoint
- [ ] Concurrent browser sessions — test pod limits, VNC display allocation conflicts
- [ ] Redis pool contention under high concurrency
- [ ] PostgreSQL query performance under load (add missing indexes)

### Security Testing (Weeks 22–23)
- [ ] OWASP Top 10 scan on api-server
- [ ] JWT token validation edge cases
- [ ] Secret Manager access — verify no secrets in logs or environment leakage
- [ ] HITL authorization — verify only authorized users can resolve tasks

**Deliverables:** Test report, coverage report (target >80% on `common/` and `browser-agent/engine/`), all P0/P1 bugs fixed

---

## Phase 5 — Staging, Hardening & Go-Live (Weeks 22–26)

### Week 22–23: Staging Deployment
- [ ] Deploy full stack to GKE staging environment (`agentic-app-staging` namespace)
- [ ] Staging Pub/Sub topics, Redis (Memorystore), PostgreSQL (Cloud SQL)
- [ ] N8N staging workflows
- [ ] Smoke test every API endpoint and webhook
- [ ] Configure Cloud Monitoring dashboards + alerting policies

### Week 24–25: UAT & Hardening
- [ ] UAT with clinical/ops team — real PA cases through staging
- [ ] Portal recipe fixes from UAT findings
- [ ] Performance tuning — connection pool sizes, Pub/Sub ack deadlines, Redis TTLs
- [ ] Observability — structured logging, Cloud Logging sinks, trace IDs in all logs
- [ ] Runbook documentation — on-call playbook, incident response, recipe authoring guide

### Week 26: Production Go-Live
- [ ] GKE production deployment (blue/green)
- [ ] KEDA autoscaling validated (1–6 browser-agent replicas)
- [ ] Secrets migrated to production Secret Manager
- [ ] DNS, ingress, TLS certificates
- [ ] Monitoring live — alerts wired to PagerDuty/Slack
- [ ] Go/no-go sign-off from leadership

**Deliverables:** Production system live, runbook complete, monitoring active

---

## Summary Timeline

| Phase | Weeks | Target Date | Owner |
|---|---|---|---|
| Documentation & Architecture | 1–4 | Sept 28, 2026 | Tech Lead |
| Foundation & Infrastructure | 3–8 | Oct 26, 2026 | Backend Lead + DevOps |
| Service Development (8 sprints) | 7–20 | Jan 4, 2027 | Full team |
| Testing | 17–23 | Feb 1, 2027 | QA + Backend |
| Staging & Go-Live | 22–26 | **Mar 1, 2027** | All |

---

## Key Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Payer portal UI changes break recipes | Modular recipe YAML + validation tooling; version-pin portal recipes |
| LLM cost overruns | Cost tracking table (`agentic_platform_request_cost`) + budget alerts from day 1 |
| KEDA autoscaling VNC port conflicts | `constants.py` display allocation must be tested under concurrent load early |
| N8N single point of failure | N8N on persistent volume in K8s with PVC; consider HA setup |
| Pub/Sub message ordering / deduplication | `InMemoryCache` TTL dedup in planner must be stress-tested |
| Team unfamiliar with Playwright + VNC stack | Spike in Week 3 — get one end-to-end browser session working in isolation |
