# common/db_layer/orm_models.py
"""
Complete SQLAlchemy ORM models for all 18 tables in iks_schema.
Every service imports from this file. Do not split into multiple files —
keeping them here avoids circular import issues across services.

Usage:
    from common.db_layer.orm_models import PriorAuthCaseRequest, PriorAuthHitlTask
"""
import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    Boolean, CheckConstraint, DateTime, ForeignKey, Index,
    Integer, String, Text, UniqueConstraint, event, text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

# ─────────────────────────────────────────────────────────────────────────────
# Base
# ─────────────────────────────────────────────────────────────────────────────

convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

from sqlalchemy import MetaData
metadata = MetaData(schema="iks_schema", naming_convention=convention)


class Base(DeclarativeBase):
    metadata = metadata

    # All tables get id, created_at, updated_at automatically
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        server_default=text("CURRENT_TIMESTAMP"),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        server_default=text("CURRENT_TIMESTAMP"),
        nullable=False,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Reference / Lookup Tables
# ─────────────────────────────────────────────────────────────────────────────

class PriorAuthPayer(Base):
    """Payer organizations — Availity, UHC, Aetna, etc."""
    __tablename__ = "prior_auth_payer"

    name:      Mapped[str]  = mapped_column(String(255), nullable=False)
    code:      Mapped[str]  = mapped_column(String(100), nullable=False, unique=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    portals:  "list[PriorAuthPortal]"  = relationship("PriorAuthPortal",  back_populates="payer")
    prompts:  "list[PriorAuthPayerPrompt]" = relationship("PriorAuthPayerPrompt", back_populates="payer")
    cases:    "list[PriorAuthCaseRequest]" = relationship("PriorAuthCaseRequest", back_populates="payer")
    batches:  "list[PriorAuthBatchRequest]" = relationship("PriorAuthBatchRequest", back_populates="payer")

    __table_args__ = (
        Index("ix_prior_auth_payer_code", "code"),
        {"schema": "iks_schema"},
    )


class PriorAuthPortal(Base):
    """Portal entry points per payer (e.g. Availity, Navinet)."""
    __tablename__ = "prior_auth_portal"

    payer_id:   Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_payer.id"), nullable=False)
    name:       Mapped[str]  = mapped_column(String(255), nullable=False)
    code:       Mapped[str]  = mapped_column(String(100), nullable=False, unique=True)
    portal_url: Mapped[str]  = mapped_column(String(500), nullable=False)
    auth_type:  Mapped[str]  = mapped_column(
        String(50), nullable=False, default="username_password")
    is_active:  Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    payer:       "PriorAuthPayer"              = relationship("PriorAuthPayer", back_populates="portals")
    credentials: "list[PriorAuthPortalCredential]" = relationship(
        "PriorAuthPortalCredential", back_populates="portal")
    recipes:     "list[PriorAuthPortalRecipe]"    = relationship(
        "PriorAuthPortalRecipe", back_populates="portal")
    cases:       "list[PriorAuthCaseRequest]"     = relationship(
        "PriorAuthCaseRequest", back_populates="portal")
    batches:     "list[PriorAuthBatchRequest]"    = relationship(
        "PriorAuthBatchRequest", back_populates="portal")

    __table_args__ = (
        Index("ix_prior_auth_portal_code",     "code"),
        Index("ix_prior_auth_portal_payer_id", "payer_id"),
        {"schema": "iks_schema"},
    )


class PriorAuthPortalCredential(Base):
    """
    Paths to GCP Secret Manager secrets for portal credentials.
    Actual passwords are NEVER stored here — only the secret path.
    """
    __tablename__ = "prior_auth_portal_credential"

    portal_id:               Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_portal.id"), nullable=False)
    credential_label:        Mapped[str]  = mapped_column(String(255), nullable=False)
    secret_path_username:    Mapped[str]  = mapped_column(String(500), nullable=False)
    secret_path_password:    Mapped[str]  = mapped_column(String(500), nullable=False)
    is_active:               Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_mfa_enabled:          Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    notes:                   Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    portal: "PriorAuthPortal" = relationship("PriorAuthPortal", back_populates="credentials")

    __table_args__ = (
        Index("ix_portal_credential_portal_id", "portal_id"),
        {"schema": "iks_schema"},
    )


class PriorAuthPortalRecipe(Base):
    """
    YAML automation recipes for each portal.
    recipe_type: 'submission' (browser-agent) or 'tracking' (tracking-agent)
    """
    __tablename__ = "prior_auth_portal_recipe"

    portal_id:    Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_portal.id"), nullable=False)
    recipe_type:  Mapped[str]  = mapped_column(String(50),  nullable=False, default="submission")
    version:      Mapped[str]  = mapped_column(String(20),  nullable=False, default="1.0")
    yaml_content: Mapped[str]  = mapped_column(Text,        nullable=False)
    is_active:    Mapped[bool] = mapped_column(Boolean,     default=True, nullable=False)
    created_by:   Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.agentic_platform_user.id"), nullable=True)

    portal: "PriorAuthPortal" = relationship("PriorAuthPortal", back_populates="recipes")

    __table_args__ = (
        Index("ix_portal_recipe_portal_type", "portal_id", "recipe_type"),
        CheckConstraint("recipe_type IN ('submission','tracking')",
                        name="ck_recipe_type"),
        {"schema": "iks_schema"},
    )


class PriorAuthPayerPrompt(Base):
    """AI prompt templates per payer for LLM-mode portal navigation."""
    __tablename__ = "prior_auth_payer_prompt"

    payer_id:    Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_payer.id"), nullable=False)
    prompt_type: Mapped[str] = mapped_column(String(100), nullable=False)
    prompt_text: Mapped[str] = mapped_column(Text, nullable=False)
    version:     Mapped[str] = mapped_column(String(20), nullable=False, default="1.0")
    is_active:   Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    payer: "PriorAuthPayer" = relationship("PriorAuthPayer", back_populates="prompts")

    __table_args__ = (
        Index("ix_payer_prompt_payer_id", "payer_id"),
        {"schema": "iks_schema"},
    )


# ─────────────────────────────────────────────────────────────────────────────
# Users & Auth
# ─────────────────────────────────────────────────────────────────────────────

class AgenticPlatformUser(Base):
    """Dashboard users — operators, admins, viewers."""
    __tablename__ = "agentic_platform_user"

    email:                 Mapped[str]  = mapped_column(String(255), nullable=False, unique=True)
    password_hash:         Mapped[str]  = mapped_column(String(255), nullable=False)
    role:                  Mapped[str]  = mapped_column(
        String(50), nullable=False, default="VIEWER")
    is_active:             Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    failed_login_attempts: Mapped[int]  = mapped_column(Integer, default=0, nullable=False)
    locked_until:          Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True)
    last_login_at:         Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True)

    resolved_hitl_tasks: "list[PriorAuthHitlTask]" = relationship(
        "PriorAuthHitlTask", back_populates="resolver")
    submitted_batches:   "list[PriorAuthBatchRequest]" = relationship(
        "PriorAuthBatchRequest", back_populates="submitted_by_user")

    __table_args__ = (
        Index("ix_platform_user_email", "email"),
        CheckConstraint("role IN ('ADMIN','OPERATOR','VIEWER')", name="ck_user_role"),
        {"schema": "iks_schema"},
    )


# ─────────────────────────────────────────────────────────────────────────────
# Batch & Case — Core Workflow Tables
# ─────────────────────────────────────────────────────────────────────────────

class PriorAuthBatchRequest(Base):
    """
    Groups of PA cases submitted together.
    A batch shares one portal + payer + (optionally) one login session.
    """
    __tablename__ = "prior_auth_batch_request"

    batch_ref_id:     Mapped[str]  = mapped_column(String(255), nullable=False, unique=True)
    portal_id:        Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_portal.id"), nullable=False)
    payer_id:         Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_payer.id"), nullable=False)
    submitted_by:     Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.agentic_platform_user.id"), nullable=True)
    total_cases:      Mapped[int]  = mapped_column(Integer, default=0, nullable=False)
    processed_cases:  Mapped[int]  = mapped_column(Integer, default=0, nullable=False)
    failed_cases:     Mapped[int]  = mapped_column(Integer, default=0, nullable=False)
    status:           Mapped[str]  = mapped_column(
        String(50), nullable=False, default="PENDING")
    metadata_:        Mapped[Optional[dict]] = mapped_column(
        "metadata", JSONB, nullable=True)

    portal:            "PriorAuthPortal"      = relationship("PriorAuthPortal",  back_populates="batches")
    payer:             "PriorAuthPayer"       = relationship("PriorAuthPayer",   back_populates="batches")
    submitted_by_user: "AgenticPlatformUser"  = relationship(
        "AgenticPlatformUser", back_populates="submitted_batches")
    cases:             "list[PriorAuthCaseRequest]" = relationship(
        "PriorAuthCaseRequest", back_populates="batch")
    login_sessions:    "list[PriorAuthLoginSession]" = relationship(
        "PriorAuthLoginSession", back_populates="batch")

    __table_args__ = (
        Index("ix_batch_ref_id",   "batch_ref_id"),
        Index("ix_batch_portal",   "portal_id"),
        Index("ix_batch_status",   "status"),
        Index("ix_batch_created",  "created_at"),
        CheckConstraint(
            "status IN ('PENDING','IN_PROGRESS','COMPLETED','PARTIAL','FAILED')",
            name="ck_batch_status"),
        {"schema": "iks_schema"},
    )


class PriorAuthCaseRequest(Base):
    """
    Central table — one row per PA case.
    This is the single source of truth for case state.
    """
    __tablename__ = "prior_auth_case_request"

    case_ref_id:          Mapped[str]  = mapped_column(String(255), nullable=False, unique=True)
    batch_id:             Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_batch_request.id"), nullable=True)
    portal_id:            Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_portal.id"), nullable=False)
    payer_id:             Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_payer.id"), nullable=False)

    # PHI — stored as JSONB, never logged in plaintext
    patient_data:         Mapped[dict] = mapped_column(JSONB, nullable=False)
    clinical_data:        Mapped[dict] = mapped_column(JSONB, nullable=False)

    # State machine
    status:               Mapped[str]  = mapped_column(
        String(50), nullable=False, default="PENDING")
    previous_status:      Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    # Retry
    retry_count:          Mapped[int]  = mapped_column(Integer, default=0,  nullable=False)
    max_retries:          Mapped[int]  = mapped_column(Integer, default=3,  nullable=False)

    # Result
    pa_reference_number:  Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    last_error:           Mapped[Optional[str]] = mapped_column(Text,        nullable=True)

    # Timestamps
    started_at:           Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    queued_at:            Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at:         Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Soft delete — never hard DELETE
    is_deleted:           Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Relationships
    batch:            "PriorAuthBatchRequest"         = relationship(
        "PriorAuthBatchRequest", back_populates="cases")
    portal:           "PriorAuthPortal"               = relationship(
        "PriorAuthPortal", back_populates="cases")
    payer:            "PriorAuthPayer"                = relationship(
        "PriorAuthPayer", back_populates="cases")
    agent_sessions:   "list[PriorAuthAgentSession]"   = relationship(
        "PriorAuthAgentSession", back_populates="case",
        primaryjoin="PriorAuthCaseRequest.case_ref_id == foreign(PriorAuthAgentSession.case_ref_id)")
    tracking_sessions:"list[PriorAuthTrackingSession]"= relationship(
        "PriorAuthTrackingSession", back_populates="case",
        primaryjoin="PriorAuthCaseRequest.case_ref_id == foreign(PriorAuthTrackingSession.case_ref_id)")
    planner_status:   "Optional[PriorAuthPlannerAgentStatus]" = relationship(
        "PriorAuthPlannerAgentStatus", back_populates="case", uselist=False,
        primaryjoin="PriorAuthCaseRequest.case_ref_id == foreign(PriorAuthPlannerAgentStatus.case_ref_id)")
    hitl_tasks:       "list[PriorAuthHitlTask]"       = relationship(
        "PriorAuthHitlTask", back_populates="case",
        primaryjoin="PriorAuthCaseRequest.case_ref_id == foreign(PriorAuthHitlTask.case_ref_id)")
    case_logs:        "list[PriorAuthCaseLog]"        = relationship(
        "PriorAuthCaseLog", back_populates="case",
        primaryjoin="PriorAuthCaseRequest.case_ref_id == foreign(PriorAuthCaseLog.case_ref_id)")
    costs:            "list[AgenticPlatformRequestCost]" = relationship(
        "AgenticPlatformRequestCost", back_populates="case",
        primaryjoin="PriorAuthCaseRequest.case_ref_id == foreign(AgenticPlatformRequestCost.case_ref_id)")

    __table_args__ = (
        Index("ix_case_ref_id",          "case_ref_id"),
        Index("ix_case_status",          "status"),
        Index("ix_case_portal_status",   "portal_id", "status"),
        Index("ix_case_batch_id",        "batch_id"),
        Index("ix_case_created_at",      "created_at"),
        Index("ix_case_pa_ref",          "pa_reference_number"),
        CheckConstraint(
            "status IN ('PENDING','PLANNING','QUEUED','IN_PROGRESS',"
            "'HITL_WAIT','MFA_WAIT','SUBMITTED','APPROVED','DENIED',"
            "'PENDING_INFO','CRASHED','FAILED','CANCELLED')",
            name="ck_case_status"),
        {"schema": "iks_schema"},
    )


# ─────────────────────────────────────────────────────────────────────────────
# Session Tables
# ─────────────────────────────────────────────────────────────────────────────

class PriorAuthAgentSession(Base):
    """One browser-agent execution session per case attempt."""
    __tablename__ = "prior_auth_agent_session"

    case_ref_id:        Mapped[str]  = mapped_column(String(255), nullable=False)
    attempt_number:     Mapped[int]  = mapped_column(Integer, default=1, nullable=False)
    pod_id:             Mapped[str]  = mapped_column(String(255), nullable=False)
    pod_ip:             Mapped[str]  = mapped_column(String(100), nullable=False)
    pod_port:           Mapped[int]  = mapped_column(Integer,     nullable=False)
    session_id:         Mapped[str]  = mapped_column(String(255), nullable=False, unique=True)
    display_slot:       Mapped[Optional[int]]  = mapped_column(Integer, nullable=True)
    vnc_url:            Mapped[Optional[str]]  = mapped_column(String(500), nullable=True)
    web_port:           Mapped[Optional[int]]  = mapped_column(Integer,    nullable=True)
    execution_mode:     Mapped[str]  = mapped_column(
        String(50), nullable=False, default="recipe")
    status:             Mapped[str]  = mapped_column(
        String(50), nullable=False, default="ACTIVE")
    started_at:         Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    ended_at:           Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    duration_seconds:   Mapped[Optional[int]]      = mapped_column(Integer, nullable=True)
    execution_summary:  Mapped[Optional[str]]      = mapped_column(Text,    nullable=True)

    case: "PriorAuthCaseRequest" = relationship(
        "PriorAuthCaseRequest", back_populates="agent_sessions",
        primaryjoin="foreign(PriorAuthAgentSession.case_ref_id) == PriorAuthCaseRequest.case_ref_id")

    __table_args__ = (
        Index("ix_agent_session_case_ref_id", "case_ref_id"),
        Index("ix_agent_session_session_id",  "session_id"),
        Index("ix_agent_session_status",      "status"),
        Index("ix_agent_session_pod_id",      "pod_id"),
        CheckConstraint("execution_mode IN ('recipe','llm')", name="ck_exec_mode"),
        CheckConstraint(
            "status IN ('ACTIVE','COMPLETED','CRASHED','ABORTED')",
            name="ck_agent_session_status"),
        {"schema": "iks_schema"},
    )


class PriorAuthTrackingSession(Base):
    """Post-submission status polling session."""
    __tablename__ = "prior_auth_tracking_session"

    case_ref_id:          Mapped[str]  = mapped_column(String(255), nullable=False)
    pa_reference_number:  Mapped[str]  = mapped_column(String(255), nullable=False)
    portal_id:            Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    credential_id:        Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    pod_id:               Mapped[str]  = mapped_column(String(255), nullable=False)
    pod_ip:               Mapped[str]  = mapped_column(String(100), nullable=False)
    session_id:           Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    status:               Mapped[str]  = mapped_column(
        String(50), nullable=False, default="IN_PROGRESS")
    check_count:          Mapped[int]  = mapped_column(Integer, default=0, nullable=False)
    portal_status:        Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    normalized_status:    Mapped[Optional[str]] = mapped_column(String(50),  nullable=True)
    portal_message:       Mapped[Optional[str]] = mapped_column(Text,        nullable=True)
    last_checked_at:      Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    next_check_at:        Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    closed_at:            Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    case: "PriorAuthCaseRequest" = relationship(
        "PriorAuthCaseRequest", back_populates="tracking_sessions",
        primaryjoin="foreign(PriorAuthTrackingSession.case_ref_id) == PriorAuthCaseRequest.case_ref_id")

    __table_args__ = (
        Index("ix_tracking_case_ref_id",   "case_ref_id"),
        Index("ix_tracking_status",        "status"),
        Index("ix_tracking_next_check_at", "next_check_at"),
        CheckConstraint(
            "status IN ('IN_PROGRESS','COMPLETED','STOPPED','EXHAUSTED')",
            name="ck_tracking_status"),
        {"schema": "iks_schema"},
    )


class PriorAuthPlannerAgentStatus(Base):
    """Planner service tracking per case — one row per case_ref_id."""
    __tablename__ = "prior_auth_planner_agent_status"

    case_ref_id:          Mapped[str]  = mapped_column(String(255), nullable=False, unique=True)
    status:               Mapped[str]  = mapped_column(
        String(50), nullable=False, default="PENDING")
    n8n_trigger_attempts: Mapped[int]  = mapped_column(Integer, default=0, nullable=False)
    last_trigger_at:      Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    shared_session_id:    Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    error_message:        Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    case: "PriorAuthCaseRequest" = relationship(
        "PriorAuthCaseRequest", back_populates="planner_status",
        primaryjoin="foreign(PriorAuthPlannerAgentStatus.case_ref_id) == PriorAuthCaseRequest.case_ref_id")

    __table_args__ = (
        Index("ix_planner_status_case_ref_id", "case_ref_id"),
        {"schema": "iks_schema"},
    )


class PriorAuthLoginSession(Base):
    """
    Shared login session per batch (ONE_SESSION_PER_BATCH mode).
    Multiple cases in a batch reuse this session cookie/token.
    """
    __tablename__ = "prior_auth_login_session"

    batch_id:      Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_batch_request.id"), nullable=False)
    portal_id:     Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_portal.id"), nullable=False)
    credential_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.prior_auth_portal_credential.id"), nullable=True)
    session_id:    Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    status:        Mapped[str] = mapped_column(String(50), nullable=False, default="PENDING")
    pod_id:        Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    pod_ip:        Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    expires_at:    Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    batch:  "PriorAuthBatchRequest"      = relationship("PriorAuthBatchRequest", back_populates="login_sessions")
    portal: "PriorAuthPortal"            = relationship("PriorAuthPortal")

    __table_args__ = (
        Index("ix_login_session_batch_id",  "batch_id"),
        Index("ix_login_session_status",    "status"),
        CheckConstraint("status IN ('PENDING','ACTIVE','EXPIRED','FAILED')",
                        name="ck_login_session_status"),
        {"schema": "iks_schema"},
    )


# ─────────────────────────────────────────────────────────────────────────────
# HITL & Logs
# ─────────────────────────────────────────────────────────────────────────────

class PriorAuthHitlTask(Base):
    """
    Human-in-the-loop task — created when browser-agent needs operator action.
    task_type: HITL (visual intervention) or MFA (OTP entry)
    """
    __tablename__ = "prior_auth_hitl_task"

    case_ref_id:     Mapped[str]  = mapped_column(String(255), nullable=False)
    session_id:      Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    task_type:       Mapped[str]  = mapped_column(String(50),  nullable=False)
    status:          Mapped[str]  = mapped_column(
        String(50), nullable=False, default="PENDING")
    message:         Mapped[str]  = mapped_column(Text, nullable=False)
    step_name:       Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    portal_id:       Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    screenshot_url:  Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    vnc_url:         Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    resolution:      Mapped[Optional[str]] = mapped_column(Text,        nullable=True)
    resolved_by:     Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.agentic_platform_user.id"), nullable=True)
    resolved_at:     Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    expires_at:      Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    case:     "PriorAuthCaseRequest" = relationship(
        "PriorAuthCaseRequest", back_populates="hitl_tasks",
        primaryjoin="foreign(PriorAuthHitlTask.case_ref_id) == PriorAuthCaseRequest.case_ref_id")
    resolver: "AgenticPlatformUser"  = relationship(
        "AgenticPlatformUser", back_populates="resolved_hitl_tasks")

    __table_args__ = (
        Index("ix_hitl_case_ref_id", "case_ref_id"),
        Index("ix_hitl_status",      "status"),
        Index("ix_hitl_task_type",   "task_type"),
        CheckConstraint("task_type IN ('HITL','MFA')",        name="ck_hitl_task_type"),
        CheckConstraint("status IN ('PENDING','RESOLVED','EXPIRED','CANCELLED')",
                        name="ck_hitl_status"),
        {"schema": "iks_schema"},
    )


class PriorAuthCaseLog(Base):
    """
    Persisted execution logs per case.
    Populated by POST /sync-case-logs (copies from Redis Stream to DB).
    Table is range-partitioned by created_at (monthly) — see Alembic migration.
    """
    __tablename__ = "prior_auth_case_logs"

    case_ref_id: Mapped[str] = mapped_column(String(255), nullable=False)
    log_level:   Mapped[str] = mapped_column(String(20),  nullable=False, default="INFO")
    message:     Mapped[str] = mapped_column(Text,        nullable=False)
    session_id:  Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    extra_data:  Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    case: "PriorAuthCaseRequest" = relationship(
        "PriorAuthCaseRequest", back_populates="case_logs",
        primaryjoin="foreign(PriorAuthCaseLog.case_ref_id) == PriorAuthCaseRequest.case_ref_id")

    __table_args__ = (
        Index("ix_case_log_case_ref_id",  "case_ref_id"),
        Index("ix_case_log_created_at",   "created_at"),
        CheckConstraint("log_level IN ('DEBUG','INFO','WARNING','ERROR')",
                        name="ck_log_level"),
        # Note: actual partition DDL is in Alembic migration, not here
        {"schema": "iks_schema"},
    )


# ─────────────────────────────────────────────────────────────────────────────
# Platform / Infrastructure Tables
# ─────────────────────────────────────────────────────────────────────────────

class AgenticPlatformAiModelPricing(Base):
    """Cost tracking per AI model (Claude Haiku, Sonnet, etc.)."""
    __tablename__ = "agentic_platform_ai_model_pricing"

    model_id:            Mapped[str]   = mapped_column(String(255), nullable=False, unique=True)
    model_name:          Mapped[str]   = mapped_column(String(255), nullable=False)
    provider:            Mapped[str]   = mapped_column(String(100), nullable=False)
    input_cost_per_1k:   Mapped[float] = mapped_column(nullable=False)
    output_cost_per_1k:  Mapped[float] = mapped_column(nullable=False)
    is_active:           Mapped[bool]  = mapped_column(Boolean, default=True, nullable=False)

    costs: "list[AgenticPlatformRequestCost]" = relationship(
        "AgenticPlatformRequestCost", back_populates="model")

    __table_args__ = (
        Index("ix_ai_model_id", "model_id"),
        {"schema": "iks_schema"},
    )


class AgenticPlatformRequestCost(Base):
    """Per-request AI cost record — used for analytics and billing."""
    __tablename__ = "agentic_platform_request_cost"

    case_ref_id:    Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    model_id:       Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("iks_schema.agentic_platform_ai_model_pricing.id"),
        nullable=True)
    service_name:   Mapped[str]   = mapped_column(String(100), nullable=False)
    input_tokens:   Mapped[int]   = mapped_column(Integer,     nullable=False)
    output_tokens:  Mapped[int]   = mapped_column(Integer,     nullable=False)
    total_cost:     Mapped[float] = mapped_column(nullable=False)
    request_meta:   Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    model: "AgenticPlatformAiModelPricing" = relationship(
        "AgenticPlatformAiModelPricing", back_populates="costs")
    case:  "Optional[PriorAuthCaseRequest]" = relationship(
        "PriorAuthCaseRequest", back_populates="costs",
        primaryjoin="foreign(AgenticPlatformRequestCost.case_ref_id) == PriorAuthCaseRequest.case_ref_id")

    __table_args__ = (
        Index("ix_request_cost_case_ref_id", "case_ref_id"),
        Index("ix_request_cost_created_at",  "created_at"),
        Index("ix_request_cost_service",     "service_name"),
        {"schema": "iks_schema"},
    )


class AgenticPlatformAgent(Base):
    """
    Registry of browser-agent and tracking-agent pods.
    Written by each pod at startup, read by control-plane to initialize pools.
    """
    __tablename__ = "agentic_platform_agent"

    agent_type:       Mapped[str]  = mapped_column(String(100), nullable=False)
    pod_id:           Mapped[str]  = mapped_column(String(255), nullable=False, unique=True)
    pod_ip:           Mapped[Optional[str]]  = mapped_column(String(100), nullable=True)
    pod_port:         Mapped[Optional[int]]  = mapped_column(Integer,     nullable=True)
    max_sessions:     Mapped[int]  = mapped_column(Integer, default=3, nullable=False)
    status:           Mapped[str]  = mapped_column(
        String(50), nullable=False, default="IDLE")
    registered_at:    Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    deregistered_at:  Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        Index("ix_agent_pod_id",     "pod_id"),
        Index("ix_agent_status",     "status"),
        Index("ix_agent_agent_type", "agent_type"),
        CheckConstraint("agent_type IN ('browser_agent','tracking_agent')",
                        name="ck_agent_type"),
        CheckConstraint("status IN ('IDLE','BUSY','COOLING','CRASHED','DEREGISTERED')",
                        name="ck_agent_status"),
        {"schema": "iks_schema"},
    )


class AgenticPlatformAlert(Base):
    """
    System alerts shown in the dashboard (via SSE broadcast).
    Created by tracking-agent on status change, control-plane on crash, etc.
    """
    __tablename__ = "agentic_platform_alert"

    case_ref_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    alert_type:  Mapped[str]  = mapped_column(String(100), nullable=False)
    severity:    Mapped[str]  = mapped_column(
        String(50), nullable=False, default="INFO")
    message:     Mapped[str]  = mapped_column(Text, nullable=False)
    is_read:     Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    __table_args__ = (
        Index("ix_alert_case_ref_id", "case_ref_id"),
        Index("ix_alert_is_read",     "is_read"),
        Index("ix_alert_created_at",  "created_at"),
        CheckConstraint("severity IN ('INFO','WARNING','ERROR','CRITICAL')",
                        name="ck_alert_severity"),
        {"schema": "iks_schema"},
    )
